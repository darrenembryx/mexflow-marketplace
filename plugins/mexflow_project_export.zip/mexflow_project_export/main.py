"""
Mexflow Project Export Plugin
==============================

Official MexFlow project exporter.
Exports complete project data in proper JSON format with:
- Project metadata (title, id, timestamps, etc.)
- Scenes array with scene_prompt data and dedicated columns
- Audio script (optional)
- Media files: audio, video, subtitles, images (optional)
"""

import json
import os
import logging
from datetime import datetime
from typing import Dict, Any, List

logger = logging.getLogger("mexflow.plugins.mexflow_project_export")


class MexflowProjectExportPlugin:
    """
    Official MexFlow Project Export Plugin.
    
    Exports project in the standard MexFlow JSON format with optional media files:
    {
        "project": { title, id, timestamps, etc },
        "scenes": [
            { scene data with all dedicated columns },
            ...
        ],
        "audio_script": "...",
        "audio_scripts": [...],
        "media_summary": { audio: [...], video: [...], ... }
    }
    
    Media files are exported to a `media/` subfolder organized by type:
    - media/audio/    - Generated audio files
    - media/video/    - Generated video files  
    - media/images/   - Generated scene images
    - media/subtitles/ - Subtitle data files
    """
    
    def __init__(self, context):
        """Initialize with ExportContext."""
        self.context = context
    
    async def execute(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the export operation.
        
        Args:
            inputs: Plugin inputs containing:
                - include_audio_script: bool
                - include_media_files: bool
                - include_audio: bool
                - include_video: bool
                - include_images: bool
                - include_subtitles: bool
                - pretty_print: bool
        
        Returns:
            Result dict with success status and exported file info
        """
        try:
            include_audio_script = inputs.get('include_audio_script', True)
            include_media = inputs.get('include_media_files', True)
            include_audio = inputs.get('include_audio', True)
            include_video = inputs.get('include_video', True)
            include_images = inputs.get('include_images', True)
            include_subtitles = inputs.get('include_subtitles', True)
            pretty_print = inputs.get('pretty_print', True)
            
            # Get data from context
            project = self.context.get_project()
            scenes = self.context.get_scenes()
            audio_script = self.context.get_audio_script()
            project_title = self.context.get_project_title()
            
            logger.info(f"[MexflowProjectExport] Starting export for: {project_title}")
            logger.info(f"[MexflowProjectExport] Scenes: {len(scenes)}")
            
            self.context.report_progress(
                stage="Preparing",
                progress=5,
                message="Preparing project data..."
            )
            
            # Build export data
            export_data = {
                "mexflow_version": "1.0",
                "export_date": datetime.now().isoformat(),
                "project": {
                    "id": project.get('id'),
                    "title": project.get('title', 'Untitled'),
                    "project_type": project.get('project_type'),
                    "story_text": project.get('story_text', ''),
                    "character_portraits": project.get('character_portraits', {}),
                    "object_images": project.get('object_images', {}),
                    "created_at": project.get('created_at'),
                    "updated_at": project.get('updated_at'),
                    "scene_count": len(scenes)
                },
                "scenes": []
            }
            
            # Process scenes
            self.context.report_progress(
                stage="Processing Scenes",
                progress=10,
                message=f"Processing {len(scenes)} scenes..."
            )
            
            for i, scene in enumerate(scenes):
                scene_data = self._format_scene(scene)
                export_data["scenes"].append(scene_data)
                
                # Update progress (10-40% for scene processing)
                progress = 10 + int((i + 1) / max(len(scenes), 1) * 30)
                self.context.report_progress(
                    stage="Processing Scenes",
                    progress=progress,
                    message=f"Processing scene {i + 1}/{len(scenes)}..."
                )
            
            # Add audio script if requested
            if include_audio_script and audio_script:
                export_data["audio_script"] = audio_script
            
            # Add audio scripts data
            audio_scripts = self.context.get_audio_scripts()
            if audio_scripts:
                export_data["audio_scripts"] = audio_scripts
            
            # Export media files if requested
            media_exported = {
                "audio": [],
                "video": [],
                "images": [],
                "characters": [],
                "objects": [],
                "subtitles": []
            }
            
            if include_media:
                media_exported = await self._export_media_files(
                    include_audio=include_audio,
                    include_video=include_video,
                    include_images=include_images,
                    include_subtitles=include_subtitles
                )
                export_data["media_summary"] = media_exported
            
            # Generate filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{project_title}_mexflow_{timestamp}.json"
            
            self.context.report_progress(
                stage="Writing JSON",
                progress=90,
                message="Writing project JSON file..."
            )
            
            # Write file
            indent = 2 if pretty_print else None
            filepath = await self.context.write_json_file(filename, export_data, indent=indent)
            
            # Calculate totals
            total_media = sum(len(v) for v in media_exported.values())
            
            self.context.report_progress(
                stage="Complete",
                progress=100,
                message="Export completed successfully!"
            )
            
            return {
                "success": True,
                "message": f"Project exported successfully!",
                "exported_files": [filepath] + self.context.get_exported_files(),
                "data": {
                    "total_scenes": len(scenes),
                    "has_audio": bool(include_audio_script and audio_script),
                    "media_files_exported": total_media,
                    "media_summary": {
                        "audio_files": len(media_exported["audio"]),
                        "video_files": len(media_exported["video"]),
                        "image_files": len(media_exported["images"]),
                        "character_files": len(media_exported.get("characters", [])),
                        "object_files": len(media_exported.get("objects", [])),
                        "subtitle_files": len(media_exported["subtitles"])
                    },
                    "filename": filename,
                    "output_folder": self.context.get_output_folder()
                }
            }
            
        except Exception as e:
            logger.error(f"[MexflowProjectExport] Export failed: {e}")
            import traceback
            traceback.print_exc()
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _export_media_files(
        self,
        include_audio: bool = True,
        include_video: bool = True,
        include_images: bool = True,
        include_subtitles: bool = True
    ) -> Dict[str, List[str]]:
        """
        Export all media files to the media/ subfolder.
        
        Creates organized folder structure:
        - media/audio/
        - media/video/
        - media/images/
        - media/characters/   (character portrait images)
        - media/objects/       (object images)
        - media/subtitles/
        
        Returns:
            Dict with lists of exported file paths per type
        """
        media_summary = self.context.get_media_files_summary()
        exported = {
            "audio": [],
            "video": [],
            "images": [],
            "characters": [],
            "objects": [],
            "subtitles": []
        }
        
        total_files = 0
        if include_audio:
            total_files += len(media_summary.get("audio", []))
        if include_video:
            total_files += len(media_summary.get("video", []))
        if include_images:
            total_files += len(media_summary.get("images", []))
            total_files += len(media_summary.get("characters", []))
            total_files += len(media_summary.get("objects", []))
        if include_subtitles:
            total_files += len(media_summary.get("subtitles", []))
        
        if total_files == 0:
            logger.info("[MexflowProjectExport] No media files to export")
            return exported
        
        current_file = 0
        
        # Export audio files
        if include_audio:
            for audio_info in media_summary.get("audio", []):
                file_path = audio_info.get("file_path")
                file_name = audio_info.get("file_name", os.path.basename(file_path) if file_path else "audio.mp3")
                
                result = await self.context.copy_file(
                    source_path=file_path,
                    dest_filename=file_name,
                    subfolder="media/audio"
                )
                if result:
                    exported["audio"].append(file_name)
                
                current_file += 1
                progress = 40 + int(current_file / max(total_files, 1) * 40)
                self.context.report_progress(
                    stage="Exporting Media",
                    progress=progress,
                    message=f"Exporting audio: {file_name}"
                )
        
        # Export video files
        if include_video:
            for video_info in media_summary.get("video", []):
                file_path = video_info.get("file_path")
                file_name = video_info.get("file_name", os.path.basename(file_path) if file_path else "video.mp4")
                
                # Add scene ID prefix to avoid name collisions
                scene_id = video_info.get("scene_id", "")
                if scene_id:
                    name, ext = os.path.splitext(file_name)
                    file_name = f"scene_{scene_id}_{name}{ext}"
                
                result = await self.context.copy_file(
                    source_path=file_path,
                    dest_filename=file_name,
                    subfolder="media/video"
                )
                if result:
                    exported["video"].append(file_name)
                
                current_file += 1
                progress = 40 + int(current_file / max(total_files, 1) * 40)
                self.context.report_progress(
                    stage="Exporting Media",
                    progress=progress,
                    message=f"Exporting video: {file_name}"
                )
        
        # Export image files
        if include_images:
            for img_info in media_summary.get("images", []):
                file_path = img_info.get("file_path")
                file_name = img_info.get("file_name", os.path.basename(file_path) if file_path else "image.png")
                
                # Add scene ID prefix to avoid name collisions
                scene_id = img_info.get("scene_id", "")
                if scene_id:
                    name, ext = os.path.splitext(file_name)
                    file_name = f"scene_{scene_id}_{name}{ext}"
                
                result = await self.context.copy_file(
                    source_path=file_path,
                    dest_filename=file_name,
                    subfolder="media/images"
                )
                if result:
                    exported["images"].append(file_name)
                
                current_file += 1
                progress = 40 + int(current_file / max(total_files, 1) * 40)
                self.context.report_progress(
                    stage="Exporting Media",
                    progress=progress,
                    message=f"Exporting image: {file_name}"
                )
            
            # Export character portrait images
            for char_info in media_summary.get("characters", []):
                file_path = char_info.get("file_path")
                char_name = char_info.get("name", "character")
                file_name = char_info.get("file_name", os.path.basename(file_path) if file_path else "portrait.png")
                
                # Prefix with character name for clarity
                name, ext = os.path.splitext(file_name)
                safe_char_name = "".join(c if c.isalnum() or c in ('-', '_') else '_' for c in char_name)
                file_name = f"{safe_char_name}_{name}{ext}"
                
                result = await self.context.copy_file(
                    source_path=file_path,
                    dest_filename=file_name,
                    subfolder="media/characters"
                )
                if result:
                    exported["characters"].append(file_name)
                
                current_file += 1
                progress = 40 + int(current_file / max(total_files, 1) * 40)
                self.context.report_progress(
                    stage="Exporting Media",
                    progress=progress,
                    message=f"Exporting character portrait: {char_name}"
                )
            
            # Export object images
            for obj_info in media_summary.get("objects", []):
                file_path = obj_info.get("file_path")
                obj_name = obj_info.get("name", "object")
                file_name = obj_info.get("file_name", os.path.basename(file_path) if file_path else "object.png")
                
                # Prefix with object name for clarity
                name, ext = os.path.splitext(file_name)
                safe_obj_name = "".join(c if c.isalnum() or c in ('-', '_') else '_' for c in obj_name)
                file_name = f"{safe_obj_name}_{name}{ext}"
                
                result = await self.context.copy_file(
                    source_path=file_path,
                    dest_filename=file_name,
                    subfolder="media/objects"
                )
                if result:
                    exported["objects"].append(file_name)
                
                current_file += 1
                progress = 40 + int(current_file / max(total_files, 1) * 40)
                self.context.report_progress(
                    stage="Exporting Media",
                    progress=progress,
                    message=f"Exporting object image: {obj_name}"
                )
        
        # Export subtitle data
        if include_subtitles:
            for sub_info in media_summary.get("subtitles", []):
                subtitle_data = sub_info.get("subtitle_data")
                audio_id = sub_info.get("audio_id", "unknown")
                file_name = f"subtitles_{audio_id}.json"
                
                if subtitle_data:
                    import json as _json
                    subtitle_content = _json.dumps(subtitle_data, indent=2, ensure_ascii=False)
                    result = await self.context.write_text_file(
                        filename=file_name,
                        content=subtitle_content,
                        subfolder="media/subtitles"
                    )
                    if result:
                        exported["subtitles"].append(file_name)
                
                current_file += 1
                progress = 40 + int(current_file / max(total_files, 1) * 40)
                self.context.report_progress(
                    stage="Exporting Media",
                    progress=progress,
                    message=f"Exporting subtitle: {file_name}"
                )
        
        logger.info(f"[MexflowProjectExport] Media export complete: "
                    f"{len(exported['audio'])} audio, {len(exported['video'])} video, "
                    f"{len(exported['images'])} images, {len(exported['characters'])} characters, "
                    f"{len(exported['objects'])} objects, {len(exported['subtitles'])} subtitles")
        
        return exported
    
    def _format_scene(self, scene: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format a scene for export.
        
        Uses the new structure with dedicated columns as primary data source.
        Falls back to scene_json_obj/scene_details_text for legacy data.
        
        Args:
            scene: Scene dict from database
            
        Returns:
            Formatted scene dict for export
        """
        # Base scene data
        scene_data = {
            "scene_id": scene.get('scene_id_str', ''),
            "status": scene.get('status', 'unknown')
        }
        
        # Try to parse scene_prompt as the primary complete scene JSON
        scene_prompt = scene.get('scene_prompt')
        if scene_prompt:
            try:
                if isinstance(scene_prompt, str):
                    prompt_data = json.loads(scene_prompt)
                else:
                    prompt_data = scene_prompt
                
                if isinstance(prompt_data, dict):
                    scene_data["scene_content"] = prompt_data
                    scene_data["content_type"] = "scene_prompt"
                else:
                    scene_data["scene_content"] = {"prompt": scene_prompt}
                    scene_data["content_type"] = "scene_prompt_text"
            except (json.JSONDecodeError, TypeError):
                scene_data["scene_content"] = {"prompt": scene_prompt}
                scene_data["content_type"] = "scene_prompt_text"
        else:
            # Fallback: Use scene_json_obj (legacy)
            scene_json_obj = scene.get('scene_json_obj')
            if scene_json_obj and isinstance(scene_json_obj, dict) and len(scene_json_obj) > 0:
                scene_data["scene_content"] = scene_json_obj
                scene_data["content_type"] = "json_object"
            else:
                # Fallback to scene_details_text
                scene_details = scene.get('scene_details_text', '')
                if scene_details:
                    scene_data["scene_content"] = {
                        "scene_details": scene_details
                    }
                    scene_data["content_type"] = "text_fallback"
                else:
                    scene_data["scene_content"] = None
                    scene_data["content_type"] = "empty"
        
        # Add dedicated column data
        if scene.get('image_prompt'):
            scene_data["image_prompt"] = scene.get('image_prompt')
        if scene.get('scene_description'):
            scene_data["scene_description"] = scene.get('scene_description')
        if scene.get('scene_duration'):
            scene_data["scene_duration"] = scene.get('scene_duration')
        if scene.get('characters_present'):
            scene_data["characters_present"] = scene.get('characters_present')
        if scene.get('objects_present'):
            scene_data["objects_present"] = scene.get('objects_present')
        if scene.get('scene_images'):
            scene_data["scene_images"] = scene.get('scene_images')
        if scene.get('scene_frames'):
            scene_data["scene_frames"] = scene.get('scene_frames')
        
        # Add media paths if available
        if scene.get('image_path'):
            scene_data["image_path"] = scene.get('image_path')
        if scene.get('video_path'):
            scene_data["video_path"] = scene.get('video_path')
        
        return scene_data
