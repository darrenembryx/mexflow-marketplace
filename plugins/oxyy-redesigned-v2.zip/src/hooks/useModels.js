'use client';

// src/hooks/useModels.js - Models Data Hook

import useSWR from 'swr';
import { swrFetcher } from '@/lib/api';
import { CACHE_KEYS, REVALIDATE } from '@/lib/constants';

export function useModels(options = {}) {
  const { type, tier, search } = options;

  const { data, error, isLoading, mutate } = useSWR(
    CACHE_KEYS.MODELS,
    swrFetcher,
    {
      revalidateOnFocus: false,
      dedupingInterval: REVALIDATE.VERY_SLOW * 1000,
    }
  );

  // swrFetcher returns data.data from the API response
  // The models endpoint returns { object: 'list', data: [...] }
  // swrFetcher does: data.data || data, so we get { object: 'list', data: [...] }
  // Then we need to extract the data array from that
  let models = [];
  
  if (data) {
    // Handle both OpenAI format {object: 'list', data: [...]} and direct array
    if (Array.isArray(data)) {
      models = data;
    } else if (data.data && Array.isArray(data.data)) {
      models = data.data;
    } else if (Array.isArray(data)) {
      models = data;
    }
  }
  
  if (type) {
    models = models.filter((m) => m.type === type);
  }
  
  if (tier) {
    models = models.filter((m) => m.tier === tier);
  }
  
  if (search) {
    const searchLower = search.toLowerCase();
    models = models.filter((m) => 
      m.id?.toLowerCase().includes(searchLower) ||
      m.modelId?.toLowerCase().includes(searchLower) ||
      m.displayName?.toLowerCase().includes(searchLower) ||
      m.owned_by?.toLowerCase().includes(searchLower)
    );
  }

  return {
    models,
    isLoading,
    loading: isLoading, // Alias for backward compatibility
    error,
    refresh: mutate,
  };
}

export default useModels;
