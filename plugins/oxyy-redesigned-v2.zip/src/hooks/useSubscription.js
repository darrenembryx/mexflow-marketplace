'use client';

// src/hooks/useSubscription.js - Subscription Data Hook

import useSWR from 'swr';
import { swrFetcher } from '@/lib/api';
import { CACHE_KEYS, REVALIDATE } from '@/lib/constants';

export function useSubscription() {
  const { data, error, isLoading, mutate } = useSWR(
    CACHE_KEYS.SUBSCRIPTION,
    swrFetcher,
    {
      revalidateOnFocus: false,
      dedupingInterval: REVALIDATE.NORMAL * 1000,
    }
  );

  const isActive = data?.status === 'ACTIVE';
  const isExpired = data?.status === 'EXPIRED';
  const isCancelled = data?.status === 'CANCELLED';

  return {
    subscription: data,
    package: data?.package,
    isActive,
    isExpired,
    isCancelled,
    loading: isLoading,
    isLoading,
    error,
    refresh: mutate,
  };
}

export default useSubscription;
