'use client';

// src/hooks/useUser.js - User Data Hook

import useSWR from 'swr';
import { swrFetcher } from '@/lib/api';
import { CACHE_KEYS, REVALIDATE } from '@/lib/constants';

export function useUser() {
  const { data, error, isLoading, mutate } = useSWR(
    CACHE_KEYS.USER,
    swrFetcher,
    {
      revalidateOnFocus: false,
      dedupingInterval: REVALIDATE.NORMAL * 1000,
    }
  );

  return {
    user: data,
    isLoading,
    error,
    refresh: mutate,
  };
}

export default useUser;
