'use client';

// src/hooks/useConcurrent.js - Concurrent Status Hook

import { useState, useEffect, useCallback } from 'react';
import { userApi } from '@/lib/api';

export function useConcurrent(pollInterval = 2000) {
  const [status, setStatus] = useState({
    current: 0,
    limit: 10,
    available: 10,
    activeRequests: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchStatus = useCallback(async () => {
    try {
      const response = await userApi.getConcurrent();
      if (response.success && response.data) {
        setStatus({
          current: response.data.current || 0,
          limit: response.data.limit || 10,
          available: response.data.available || 10,
          activeRequests: response.data.activeRequests || 0,
        });
        setError(null);
      }
    } catch (err) {
      // Silently fail - don't update status on error
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial fetch
  useEffect(() => {
    fetchStatus();
  }, [fetchStatus]);

  // Polling
  useEffect(() => {
    const interval = setInterval(fetchStatus, pollInterval);
    return () => clearInterval(interval);
  }, [fetchStatus, pollInterval]);

  const percentage = status.limit > 0 ? (status.current / status.limit) * 100 : 0;

  return {
    current: status.current,
    limit: status.limit,
    available: status.available,
    activeRequests: status.activeRequests,
    percentage,
    isAtLimit: status.current >= status.limit,
    isLoading,
    error,
    refresh: fetchStatus,
  };
}

export default useConcurrent;
