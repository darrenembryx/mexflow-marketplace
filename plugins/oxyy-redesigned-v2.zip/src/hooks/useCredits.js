'use client';

// src/hooks/useCredits.js - Credits Data Hook

import useSWR from 'swr';
import { swrFetcher } from '@/lib/api';
import { CACHE_KEYS, REVALIDATE } from '@/lib/constants';

export function useCredits() {
  const { data, error, isLoading, mutate } = useSWR(
    CACHE_KEYS.CREDITS,
    swrFetcher,
    {
      revalidateOnFocus: true,
      refreshInterval: REVALIDATE.FAST * 1000,
      dedupingInterval: REVALIDATE.FAST * 1000,
      onError: (err) => {
        console.error('[useCredits] Error fetching credits:', err);
      },
    }
  );

  // Debug logging
  if (process.env.NODE_ENV === 'development') {
    if (error) {
      console.warn('[useCredits] Error state:', error);
    }
    if (data) {
      console.log('[useCredits] Data received:', data);
    }
  }

  return {
    credits: data?.balance || 0,
    balance: data?.balance || 0,
    transactions: data?.recentTransactions || [],
    loading: isLoading,
    isLoading,
    error,
    refresh: mutate,
  };
}

export default useCredits;
