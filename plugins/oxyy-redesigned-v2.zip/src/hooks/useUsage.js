'use client';

// src/hooks/useUsage.js - Usage Data Hook

import useSWR from 'swr';
import { swrFetcher } from '@/lib/api';
import { REVALIDATE } from '@/lib/constants';

export function useUsage(params = {}) {
  const { startDate, endDate, modelId, days, page, limit } = params;
  
  const queryParams = new URLSearchParams();
  
  // Support days parameter by converting to startDate
  if (days) {
    const start = new Date();
    start.setDate(start.getDate() - days);
    queryParams.set('startDate', start.toISOString().split('T')[0]);
  } else if (startDate) {
    queryParams.set('startDate', startDate);
  }
  
  if (endDate) queryParams.set('endDate', endDate);
  if (modelId) queryParams.set('modelId', modelId);
  if (page) queryParams.set('page', page);
  if (limit) queryParams.set('limit', limit);
  
  const queryString = queryParams.toString();
  const url = `/user/usage${queryString ? `?${queryString}` : ''}`;

  const { data, error, isLoading, mutate } = useSWR(
    url,
    swrFetcher,
    {
      revalidateOnFocus: false,
      dedupingInterval: REVALIDATE.NORMAL * 1000,
    }
  );

  return {
    usage: data,
    records: data?.records || data?.summary || [],
    summary: data?.summary || [],
    daily: data?.daily || [],
    loading: isLoading,
    isLoading,
    error,
    refresh: mutate,
  };
}

export default useUsage;
