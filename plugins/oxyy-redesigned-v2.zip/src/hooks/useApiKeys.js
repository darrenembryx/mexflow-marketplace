'use client';

// src/hooks/useApiKeys.js - API Keys Data Hook

import useSWR from 'swr';
import { userApi, swrFetcher } from '@/lib/api';
import { CACHE_KEYS, REVALIDATE } from '@/lib/constants';
import { useState } from 'react';

export function useApiKeys() {
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState(null);

  const { data, error, isLoading, mutate } = useSWR(
    CACHE_KEYS.API_KEYS,
    swrFetcher,
    {
      revalidateOnFocus: false,
      dedupingInterval: REVALIDATE.FAST * 1000,
    }
  );

  const createKey = async (name, expiresIn) => {
    setCreating(true);
    try {
      const response = await userApi.createApiKey(name, expiresIn);
      await mutate();
      return response.data;
    } finally {
      setCreating(false);
    }
  };

  const deleteKey = async (keyId) => {
    setDeleting(keyId);
    try {
      await userApi.deleteApiKey(keyId);
      await mutate();
    } finally {
      setDeleting(null);
    }
  };

  const updateKey = async (keyId, data) => {
    try {
      await userApi.updateApiKey(keyId, data);
      await mutate();
    } catch (error) {
      throw error;
    }
  };

  return {
    apiKeys: data || [],
    loading: isLoading,
    isLoading,
    error,
    refresh: mutate,
    createKey,
    deleteKey,
    updateKey,
    creating,
    deleting,
  };
}

export default useApiKeys;
