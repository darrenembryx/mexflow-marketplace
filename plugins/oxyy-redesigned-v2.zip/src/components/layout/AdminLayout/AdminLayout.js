'use client';

// src/components/layout/AdminLayout/AdminLayout.js

import styles from './AdminLayout.module.css';
import { cn } from '@/lib/utils';
import { useSidebar } from '@/context/SidebarContext';
import AdminSidebar from '../AdminSidebar';
import DashboardHeader from '../DashboardHeader';

export default function AdminLayout({ children }) {
  const { isCollapsed } = useSidebar();

  return (
    <div className={styles.layout}>
      <AdminSidebar />
      <div
        className={cn(
          styles.main,
          isCollapsed && styles.collapsed
        )}
      >
        <DashboardHeader isAdmin />
        <main className={styles.content}>
          {children}
        </main>
      </div>
    </div>
  );
}
