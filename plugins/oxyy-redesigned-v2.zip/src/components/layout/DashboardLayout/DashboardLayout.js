// src/components/layout/DashboardLayout/DashboardLayout.js
'use client';

import { useSidebar } from '@/context/SidebarContext';
import Sidebar from '../Sidebar';
import DashboardHeader from '../DashboardHeader';
import styles from './DashboardLayout.module.css';
import { cn } from '@/lib/utils';

export default function DashboardLayout({ children }) {
  const { isCollapsed } = useSidebar();

  return (
    <div className={styles.layout}>
      <Sidebar />
      <div className={cn(styles.main, isCollapsed && styles.collapsed)}>
        <DashboardHeader />
        <main className={styles.content}>
          {children}
        </main>
      </div>
    </div>
  );
}
