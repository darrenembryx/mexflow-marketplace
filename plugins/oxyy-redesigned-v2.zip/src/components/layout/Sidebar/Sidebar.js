// src/components/layout/Sidebar/Sidebar.js
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import styles from './Sidebar.module.css';
import { cn } from '@/lib/utils';
import { useSidebar } from '@/context/SidebarContext';
import { useAuth } from '@/context/AuthContext';
import { ROUTES } from '@/lib/constants';
import {
  LayoutDashboard,
  Play,
  Key,
  BarChart2,
  CreditCard,
  Package,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  PanelLeftClose,
  PanelLeft,
} from 'lucide-react';

const menuItems = [
  { href: ROUTES.DASHBOARD, label: 'Dashboard', icon: LayoutDashboard },
  { href: ROUTES.PLAYGROUND, label: 'Playground', icon: Play },
  { href: ROUTES.API_KEYS, label: 'API Keys', icon: Key },
  { href: ROUTES.USAGE, label: 'Usage', icon: BarChart2 },
  { href: ROUTES.BILLING, label: 'Billing', icon: CreditCard },
  { href: ROUTES.SUBSCRIPTION, label: 'Plans', icon: Package },
  { href: ROUTES.SETTINGS, label: 'Settings', icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { isCollapsed, toggleSidebar, isMobileOpen, closeMobile } = useSidebar();
  const { user, logout } = useAuth();

  return (
    <>
      {/* Mobile overlay */}
      {isMobileOpen && (
        <div className={styles.overlay} onClick={closeMobile} />
      )}

      <aside
        className={cn(
          styles.sidebar,
          isCollapsed && styles.collapsed,
          isMobileOpen && styles.mobileOpen
        )}
      >
        <div className={styles.header}>
          <Link href={ROUTES.DASHBOARD} className={styles.logo}>
            <span className={styles.logoIcon}>O</span>
            {!isCollapsed && <span className={styles.logoText}>xyy.ai</span>}
          </Link>
          <button
            className={styles.collapseButton}
            onClick={toggleSidebar}
            aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>
        </div>

        <nav className={styles.nav}>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(styles.navItem, isActive && styles.active)}
                onClick={closeMobile}
                title={isCollapsed ? item.label : undefined}
              >
                <Icon size={20} className={styles.navIcon} />
                {!isCollapsed && <span className={styles.navLabel}>{item.label}</span>}
                {isActive && !isCollapsed && <span className={styles.activeIndicator} />}
              </Link>
            );
          })}
        </nav>

        <div className={styles.footer}>
          {user && !isCollapsed && (
            <div className={styles.userInfo}>
              <div className={styles.avatar}>
                {user.firstName?.[0] || user.email?.[0]?.toUpperCase() || '?'}
              </div>
              <div className={styles.userDetails}>
                <span className={styles.userName}>
                  {user.firstName || user.email?.split('@')[0] || 'User'}
                </span>
                <span className={styles.userEmail}>{user.email || ''}</span>
              </div>
            </div>
          )}
          <button
            className={styles.logoutButton}
            onClick={logout}
            title="Logout"
          >
            <LogOut size={18} />
            {!isCollapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>
    </>
  );
}
