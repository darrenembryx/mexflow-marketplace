// src/components/layout/Header/Header.js
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import styles from './Header.module.css';
import { cn } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { ROUTES } from '@/lib/constants';
import Button from '@/components/common/Button';
import { Menu, X, ArrowRight, Sun, Moon } from 'lucide-react';

const navLinks = [
  { href: ROUTES.PRICING, label: 'Pricing' },
  { href: ROUTES.MODELS, label: 'Models' },
  { href: ROUTES.DOCS, label: 'Docs' },
  { href: ROUTES.STATUS, label: 'Status' },
];

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const { isAuthenticated } = useAuth();
  const { isDark, toggleTheme } = useTheme();

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <div className={styles.left}>
          <Link href={ROUTES.HOME} className={styles.logo}>
            <span className={styles.logoIcon}>O</span>
            <span className={styles.logoText}>xyy.ai</span>
          </Link>
          <nav className={styles.nav}>
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  styles.navLink,
                  pathname === link.href && styles.active
                )}
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className={styles.right}>
          <button
            className={styles.themeToggle}
            onClick={toggleTheme}
            aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {isDark ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {isAuthenticated ? (
            <Link href={ROUTES.DASHBOARD}>
              <Button size="sm">
                Dashboard
              </Button>
            </Link>
          ) : (
            <div className={styles.authButtons}>
              <Link href={ROUTES.LOGIN}>
                <Button size="sm" variant="ghost">
                  Log in
                </Button>
              </Link>
              <Link href={ROUTES.REGISTER}>
                <Button size="sm" icon={<ArrowRight size={14} />} iconPosition="right">
                  Get Started
                </Button>
              </Link>
            </div>
          )}

          <button
            className={styles.mobileMenuButton}
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={cn(styles.mobileMenu, mobileMenuOpen && styles.mobileMenuOpen)}>
        <nav className={styles.mobileNav}>
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                styles.mobileNavLink,
                pathname === link.href && styles.active
              )}
              onClick={() => setMobileMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <div className={styles.mobileAuthButtons}>
          {isAuthenticated ? (
            <Link href={ROUTES.DASHBOARD} className={styles.fullWidth} onClick={() => setMobileMenuOpen(false)}>
              <Button fullWidth>Dashboard</Button>
            </Link>
          ) : (
            <>
              <Link href={ROUTES.LOGIN} className={styles.fullWidth} onClick={() => setMobileMenuOpen(false)}>
                <Button variant="outline" fullWidth>Log in</Button>
              </Link>
              <Link href={ROUTES.REGISTER} className={styles.fullWidth} onClick={() => setMobileMenuOpen(false)}>
                <Button fullWidth>Get Started</Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
