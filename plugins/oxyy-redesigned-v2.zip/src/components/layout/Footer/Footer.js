// src/components/layout/Footer/Footer.js

import Link from 'next/link';
import styles from './Footer.module.css';
import { ROUTES } from '@/lib/constants';

const footerLinks = [
  {
    title: 'Product',
    links: [
      { label: 'Pricing', href: ROUTES.PRICING },
      { label: 'Models', href: ROUTES.MODELS },
      { label: 'API Docs', href: ROUTES.DOCS },
      { label: 'Status', href: ROUTES.STATUS },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About', href: '/about' },
      { label: 'Blog', href: '/blog' },
      { label: 'Careers', href: '/careers' },
      { label: 'Contact', href: '/contact' },
    ],
  },
  {
    title: 'Legal',
    links: [
      { label: 'Privacy', href: '/privacy' },
      { label: 'Terms', href: '/terms' },
      { label: 'Security', href: '/security' },
    ],
  },
];

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.top}>
          <div className={styles.brand}>
            <Link href={ROUTES.HOME} className={styles.logo}>
              <span className={styles.logoIcon}>O</span>
              <span className={styles.logoText}>xyy.ai</span>
            </Link>
            <p className={styles.tagline}>
              Unified AI Gateway. One API for 100+ AI models.
            </p>
          </div>
          
          <div className={styles.linksGrid}>
            {footerLinks.map((section) => (
              <div key={section.title} className={styles.linkSection}>
                <h4 className={styles.sectionTitle}>{section.title}</h4>
                <ul className={styles.linkList}>
                  {section.links.map((link) => (
                    <li key={link.label}>
                      <Link href={link.href} className={styles.link}>
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className={styles.bottom}>
          <p className={styles.copyright}>
            © {new Date().getFullYear()} Oxyy.ai. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
