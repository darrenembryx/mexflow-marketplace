// src/components/layout/AdminSidebar/AdminSidebar.js
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import styles from './AdminSidebar.module.css';
import { cn } from '@/lib/utils';
import { useSidebar } from '@/context/SidebarContext';
import { useAuth } from '@/context/AuthContext';
import { ROUTES } from '@/lib/constants';
import {
  LayoutDashboard,
  Users,
  Package,
  Box,
  Puzzle,
  Ticket,
  Receipt,
  BarChart3,
  Settings,
  LogOut,
  Home,
  PanelLeftClose,
  PanelLeft,
} from 'lucide-react';

const menuItems = [
  { href: ROUTES.ADMIN_DASHBOARD, label: 'Dashboard', icon: LayoutDashboard },
  { href: ROUTES.ADMIN_USERS, label: 'Users', icon: Users },
  { href: ROUTES.ADMIN_PACKAGES, label: 'Packages', icon: Package },
  { href: ROUTES.ADMIN_MODELS, label: 'Models', icon: Box },
  { href: ROUTES.ADMIN_PLUGINS, label: 'Plugins', icon: Puzzle },
  { href: ROUTES.ADMIN_COUPONS, label: 'Coupons', icon: Ticket },
  { href: ROUTES.ADMIN_PAYMENTS, label: 'Payments', icon: Receipt },
  { href: ROUTES.ADMIN_ANALYTICS, label: 'Analytics', icon: BarChart3 },
  { href: ROUTES.ADMIN_SETTINGS, label: 'Settings', icon: Settings },
];

export default function AdminSidebar() {
  const pathname = usePathname();
  const { isCollapsed, toggleSidebar, isMobileOpen, closeMobile } = useSidebar();
  const { user, logout } = useAuth();

  return (
    <>
      {isMobileOpen && (
        <div className={styles.overlay} onClick={closeMobile} />
      )}

      <aside
        className={cn(
          styles.sidebar,
          isCollapsed && styles.collapsed,
          isMobileOpen && styles.mobileOpen
        )}
      >
        <div className={styles.header}>
          <Link href={ROUTES.ADMIN_DASHBOARD} className={styles.logo}>
            <span className={styles.logoIcon}>O</span>
            {!isCollapsed && (
              <>
                <span className={styles.logoText}>xyy.ai</span>
                <span className={styles.adminBadge}>Admin</span>
              </>
            )}
          </Link>
          <button
            className={styles.collapseButton}
            onClick={toggleSidebar}
            aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {isCollapsed ? <PanelLeft size={16} /> : <PanelLeftClose size={16} />}
          </button>
        </div>

        <nav className={styles.nav}>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href || 
              (item.href !== ROUTES.ADMIN_DASHBOARD && pathname.startsWith(item.href));

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(styles.navItem, isActive && styles.active)}
                onClick={closeMobile}
                title={isCollapsed ? item.label : undefined}
              >
                <Icon size={18} className={styles.navIcon} />
                {!isCollapsed && <span className={styles.navLabel}>{item.label}</span>}
                {isActive && <span className={styles.activeIndicator} />}
              </Link>
            );
          })}
        </nav>

        <div className={styles.footer}>
          <Link 
            href={ROUTES.DASHBOARD} 
            className={styles.backLink}
            title={isCollapsed ? 'Back to App' : undefined}
          >
            <Home size={16} />
            {!isCollapsed && <span>Back to App</span>}
          </Link>
          <button
            className={styles.logoutButton}
            onClick={logout}
            title="Logout"
          >
            <LogOut size={16} />
            {!isCollapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>
    </>
  );
}
