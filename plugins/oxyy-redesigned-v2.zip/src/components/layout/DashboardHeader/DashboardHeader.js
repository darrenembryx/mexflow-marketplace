// src/components/layout/DashboardHeader/DashboardHeader.js
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import styles from './DashboardHeader.module.css';
import { useSidebar } from '@/context/SidebarContext';
import { useAuth } from '@/context/AuthContext';
import { useCredits } from '@/hooks/useCredits';
import { formatCredits } from '@/lib/formatters';
import { ROUTES } from '@/lib/constants';
import Button from '@/components/common/Button';
import { Menu, Bell, CreditCard, Settings, LogOut, ChevronDown, ExternalLink } from 'lucide-react';

export default function DashboardHeader() {
  const pathname = usePathname();
  const { openMobile } = useSidebar();
  const { user, logout } = useAuth();
  const { credits } = useCredits();
  const [showUserMenu, setShowUserMenu] = useState(false);

  const getPageTitle = () => {
    if (pathname === '/dashboard') return 'Dashboard';
    if (pathname === '/playground') return 'Playground';
    if (pathname === '/api-keys') return 'API Keys';
    if (pathname === '/usage') return 'Usage';
    if (pathname === '/billing') return 'Billing';
    if (pathname === '/subscription') return 'Plans';
    if (pathname === '/settings') return 'Settings';
    return 'Dashboard';
  };

  return (
    <header className={styles.header}>
      <div className={styles.left}>
        <button
          className={styles.menuButton}
          onClick={openMobile}
          aria-label="Open menu"
        >
          <Menu size={18} />
        </button>
        <h1 className={styles.pageTitle}>{getPageTitle()}</h1>
      </div>

      <div className={styles.right}>
        <Link href={ROUTES.BILLING} className={styles.creditsBadge}>
          <CreditCard size={14} />
          <span>{formatCredits(credits)}</span>
        </Link>

        <Link href={ROUTES.DOCS} className={styles.docsLink}>
          <span>Docs</span>
          <ExternalLink size={12} />
        </Link>

        <div className={styles.userMenu}>
          <button 
            className={styles.userButton}
            onClick={() => setShowUserMenu(!showUserMenu)}
          >
            <div className={styles.avatar}>
              {user?.firstName?.[0] || user?.email?.[0]?.toUpperCase() || '?'}
            </div>
            <ChevronDown size={14} className={styles.chevron} />
          </button>

          {showUserMenu && (
            <>
              <div 
                className={styles.overlay} 
                onClick={() => setShowUserMenu(false)} 
              />
              <div className={styles.dropdown}>
                <div className={styles.userInfo}>
                  <span className={styles.userName}>
                    {user?.firstName || user?.email?.split('@')[0] || 'User'}
                  </span>
                  <span className={styles.userEmail}>{user?.email}</span>
                </div>
                <div className={styles.divider} />
                <Link 
                  href={ROUTES.SETTINGS} 
                  className={styles.dropdownItem}
                  onClick={() => setShowUserMenu(false)}
                >
                  <Settings size={14} />
                  <span>Settings</span>
                </Link>
                <button 
                  className={styles.dropdownItem}
                  onClick={() => {
                    setShowUserMenu(false);
                    logout();
                  }}
                >
                  <LogOut size={14} />
                  <span>Log out</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
