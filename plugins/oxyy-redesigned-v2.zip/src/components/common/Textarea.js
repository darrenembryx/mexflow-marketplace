'use client';

import { useState } from 'react';
import styles from './Textarea.module.css';

export default function Textarea({
  label,
  error,
  helperText,
  className = '',
  rows = 4,
  maxLength,
  showCount = false,
  ...props
}) {
  const [charCount, setCharCount] = useState(props.value?.length || 0);

  const handleChange = (e) => {
    setCharCount(e.target.value.length);
    props.onChange?.(e);
  };

  return (
    <div className={`${styles.wrapper} ${className}`}>
      {label && (
        <label className={styles.label}>
          {label}
          {props.required && <span className={styles.required}>*</span>}
        </label>
      )}
      <div className={styles.inputWrapper}>
        <textarea
          {...props}
          rows={rows}
          maxLength={maxLength}
          onChange={handleChange}
          className={`${styles.textarea} ${error ? styles.error : ''}`}
        />
        {showCount && maxLength && (
          <span className={styles.charCount}>
            {charCount}/{maxLength}
          </span>
        )}
      </div>
      {(error || helperText) && (
        <span className={`${styles.helperText} ${error ? styles.errorText : ''}`}>
          {error || helperText}
        </span>
      )}
    </div>
  );
}
