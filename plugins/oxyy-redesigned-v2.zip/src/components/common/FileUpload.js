'use client';

import { useState, useRef } from 'react';
import styles from './FileUpload.module.css';

export default function FileUpload({
  label,
  accept,
  multiple = false,
  maxSize = 10 * 1024 * 1024, // 10MB default
  onChange,
  error,
  helperText,
  className = '',
  ...props
}) {
  const [isDragging, setIsDragging] = useState(false);
  const [files, setFiles] = useState([]);
  const [uploadError, setUploadError] = useState(null);
  const inputRef = useRef(null);

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const validateFiles = (fileList) => {
    const validFiles = [];
    let errorMsg = null;

    for (const file of fileList) {
      if (file.size > maxSize) {
        errorMsg = `File ${file.name} exceeds maximum size of ${formatFileSize(maxSize)}`;
        continue;
      }
      if (accept) {
        const acceptedTypes = accept.split(',').map(t => t.trim());
        const isValid = acceptedTypes.some(type => {
          if (type.startsWith('.')) {
            return file.name.toLowerCase().endsWith(type.toLowerCase());
          }
          if (type.endsWith('/*')) {
            return file.type.startsWith(type.replace('/*', '/'));
          }
          return file.type === type;
        });
        if (!isValid) {
          errorMsg = `File ${file.name} is not an accepted file type`;
          continue;
        }
      }
      validFiles.push(file);
    }

    return { validFiles, errorMsg };
  };

  const handleFiles = (fileList) => {
    const { validFiles, errorMsg } = validateFiles(Array.from(fileList));
    setUploadError(errorMsg);
    
    if (validFiles.length > 0) {
      const newFiles = multiple ? [...files, ...validFiles] : validFiles;
      setFiles(newFiles);
      onChange?.(multiple ? newFiles : newFiles[0]);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const handleInputChange = (e) => {
    handleFiles(e.target.files);
  };

  const handleRemoveFile = (index) => {
    const newFiles = files.filter((_, i) => i !== index);
    setFiles(newFiles);
    onChange?.(multiple ? newFiles : null);
  };

  const handleClick = () => {
    inputRef.current?.click();
  };

  const displayError = error || uploadError;

  return (
    <div className={`${styles.wrapper} ${className}`}>
      {label && (
        <label className={styles.label}>
          {label}
          {props.required && <span className={styles.required}>*</span>}
        </label>
      )}
      <div
        className={`${styles.dropzone} ${isDragging ? styles.dragging : ''} ${displayError ? styles.error : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleClick}
      >
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          onChange={handleInputChange}
          className={styles.input}
          {...props}
        />
        <div className={styles.dropzoneContent}>
          <svg className={styles.icon} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          <p className={styles.dropzoneText}>
            <span className={styles.link}>Click to upload</span> or drag and drop
          </p>
          {accept && (
            <p className={styles.acceptedTypes}>{accept}</p>
          )}
          <p className={styles.maxSize}>Max file size: {formatFileSize(maxSize)}</p>
        </div>
      </div>
      {files.length > 0 && (
        <div className={styles.fileList}>
          {files.map((file, index) => (
            <div key={index} className={styles.fileItem}>
              <div className={styles.fileInfo}>
                <span className={styles.fileName}>{file.name}</span>
                <span className={styles.fileSize}>{formatFileSize(file.size)}</span>
              </div>
              <button
                type="button"
                className={styles.removeButton}
                onClick={(e) => {
                  e.stopPropagation();
                  handleRemoveFile(index);
                }}
              >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      )}
      {(displayError || helperText) && (
        <span className={`${styles.helperText} ${displayError ? styles.errorText : ''}`}>
          {displayError || helperText}
        </span>
      )}
    </div>
  );
}
