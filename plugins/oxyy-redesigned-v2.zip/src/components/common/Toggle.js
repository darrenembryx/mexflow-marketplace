'use client';

import styles from './Toggle.module.css';

export default function Toggle({
  label,
  checked = false,
  onChange,
  disabled = false,
  size = 'medium',
  className = '',
  ...props
}) {
  const handleChange = (e) => {
    if (!disabled) {
      onChange?.(e.target.checked);
    }
  };

  return (
    <label className={`${styles.wrapper} ${disabled ? styles.disabled : ''} ${className}`}>
      <div className={`${styles.toggle} ${styles[size]}`}>
        <input
          type="checkbox"
          checked={checked}
          onChange={handleChange}
          disabled={disabled}
          className={styles.input}
          {...props}
        />
        <span className={styles.slider} />
      </div>
      {label && <span className={styles.label}>{label}</span>}
    </label>
  );
}
