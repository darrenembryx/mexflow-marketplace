// src/components/common/Skeleton/Skeleton.js

import styles from './Skeleton.module.css';
import { cn } from '@/lib/utils';

export default function Skeleton({
  width,
  height,
  variant = 'rectangular',
  className,
  style,
  ...props
}) {
  return (
    <div
      className={cn(
        styles.skeleton,
        styles[variant],
        className
      )}
      style={{
        width,
        height,
        ...style,
      }}
      {...props}
    />
  );
}
