// src/components/common/Badge/Badge.js

import styles from './Badge.module.css';
import { cn } from '@/lib/utils';

export default function Badge({
  children,
  variant = 'default',
  size = 'md',
  dot = false,
  className,
  ...props
}) {
  return (
    <span
      className={cn(
        styles.badge,
        styles[variant],
        styles[size],
        dot && styles.withDot,
        className
      )}
      {...props}
    >
      {dot && <span className={styles.dot} />}
      {children}
    </span>
  );
}
