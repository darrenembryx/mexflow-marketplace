// src/components/common/Tabs/Tabs.js
'use client';

import styles from './Tabs.module.css';
import { cn } from '@/lib/utils';

export default function Tabs({
  tabs,
  activeTab,
  onChange,
  variant = 'default',
  size = 'md',
  className,
}) {
  const renderIcon = (icon) => {
    if (!icon) return null;
    
    // If icon is already a React element (JSX), render it directly
    if (typeof icon === 'object' && icon.$$typeof) {
      return <span className={styles.icon}>{icon}</span>;
    }
    
    // If icon is a component reference, instantiate it
    const Icon = icon;
    return <Icon size={size === 'sm' ? 14 : 16} className={styles.icon} />;
  };

  return (
    <div className={cn(styles.tabs, styles[variant], styles[size], className)}>
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        
        return (
          <button
            key={tab.id}
            className={cn(styles.tab, isActive && styles.active)}
            onClick={() => onChange(tab.id)}
            disabled={tab.disabled}
          >
            {renderIcon(tab.icon)}
            <span className={styles.label}>{tab.label}</span>
            {tab.count !== undefined && (
              <span className={styles.count}>{tab.count}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}
