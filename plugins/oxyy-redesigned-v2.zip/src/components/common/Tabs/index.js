export { default } from './Tabs';
