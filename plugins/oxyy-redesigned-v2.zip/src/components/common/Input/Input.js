// src/components/common/Input/Input.js
'use client';

import { forwardRef } from 'react';
import styles from './Input.module.css';
import { cn } from '@/lib/utils';

const Input = forwardRef(({
  label,
  error,
  hint,
  leftIcon,
  rightIcon,
  size = 'md',
  fullWidth = true,
  className,
  inputClassName,
  disabled,
  required,
  id,
  ...props
}, ref) => {
  const inputId = id || `input-${Math.random().toString(36).substr(2, 9)}`;

  return (
    <div className={cn(styles.wrapper, fullWidth && styles.fullWidth, className)}>
      {label && (
        <label htmlFor={inputId} className={styles.label}>
          {label}
          {required && <span className={styles.required}>*</span>}
        </label>
      )}
      <div className={cn(
        styles.inputWrapper,
        styles[size],
        error && styles.error,
        disabled && styles.disabled,
        leftIcon && styles.hasLeftIcon,
        rightIcon && styles.hasRightIcon
      )}>
        {leftIcon && <span className={styles.leftIcon}>{leftIcon}</span>}
        <input
          ref={ref}
          id={inputId}
          className={cn(styles.input, inputClassName)}
          disabled={disabled}
          required={required}
          {...props}
        />
        {rightIcon && <span className={styles.rightIcon}>{rightIcon}</span>}
      </div>
      {(error || hint) && (
        <span className={cn(styles.message, error && styles.errorMessage)}>
          {error || hint}
        </span>
      )}
    </div>
  );
});

Input.displayName = 'Input';

export default Input;
