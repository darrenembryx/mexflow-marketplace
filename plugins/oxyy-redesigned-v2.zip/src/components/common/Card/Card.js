// src/components/common/Card/Card.js

import styles from './Card.module.css';
import { cn } from '@/lib/utils';

export default function Card({
  children,
  title,
  description,
  actions,
  padding = 'md',
  hoverable = false,
  onClick,
  className,
  ...props
}) {
  const cardClasses = cn(
    styles.card,
    styles[`padding${padding.charAt(0).toUpperCase() + padding.slice(1)}`],
    hoverable && styles.hoverable,
    onClick && styles.clickable,
    className
  );

  const Component = onClick ? 'button' : 'div';

  return (
    <Component
      className={cardClasses}
      onClick={onClick}
      type={onClick ? 'button' : undefined}
      {...props}
    >
      {(title || actions) && (
        <div className={styles.header}>
          <div className={styles.headerText}>
            {title && <h3 className={styles.title}>{title}</h3>}
            {description && <p className={styles.description}>{description}</p>}
          </div>
          {actions && <div className={styles.actions}>{actions}</div>}
        </div>
      )}
      <div className={styles.body}>{children}</div>
    </Component>
  );
}

Card.Header = function CardHeader({ children, className }) {
  return <div className={cn(styles.header, className)}>{children}</div>;
};

Card.Body = function CardBody({ children, className }) {
  return <div className={cn(styles.body, className)}>{children}</div>;
};

Card.Footer = function CardFooter({ children, className }) {
  return <div className={cn(styles.footer, className)}>{children}</div>;
};
