// src/components/common/EmptyState/EmptyState.js

import styles from './EmptyState.module.css';
import { cn } from '@/lib/utils';
import Button from '../Button';

export default function EmptyState({
  icon,
  title,
  description,
  action,
  actionLabel,
  onAction,
  className,
}) {
  return (
    <div className={cn(styles.container, className)}>
      {icon && <div className={styles.icon}>{icon}</div>}
      {title && <h3 className={styles.title}>{title}</h3>}
      {description && <p className={styles.description}>{description}</p>}
      {action && (
        <div className={styles.action}>{action}</div>
      )}
      {!action && actionLabel && onAction && (
        <Button onClick={onAction} className={styles.actionButton}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
}
