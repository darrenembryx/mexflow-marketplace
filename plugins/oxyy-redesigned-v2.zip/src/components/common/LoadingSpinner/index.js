export { default } from './LoadingSpinner';
