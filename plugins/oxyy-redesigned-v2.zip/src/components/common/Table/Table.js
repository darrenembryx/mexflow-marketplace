// src/components/common/Table/Table.js
'use client';

import styles from './Table.module.css';
import { cn } from '@/lib/utils';

export default function Table({
  columns,
  data,
  onRowClick,
  emptyMessage = 'No data available',
  loading = false,
  hoverable = false,
  className,
}) {
  if (loading) {
    return (
      <div className={styles.wrapper}>
        <div className={styles.loading}>
          {[...Array(5)].map((_, i) => (
            <div key={i} className={styles.loadingRow} />
          ))}
        </div>
      </div>
    );
  }

  // Ensure data is always an array
  const tableData = Array.isArray(data) ? data : [];

  if (tableData.length === 0) {
    return (
      <div className={styles.wrapper}>
        <div className={styles.empty}>
          <p>{emptyMessage}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={cn(styles.wrapper, className)}>
      <table className={styles.table}>
        <thead className={styles.thead}>
          <tr>
            {columns.map((column) => (
              <th
                key={column.key}
                className={cn(
                  styles.th,
                  column.align === 'right' && styles.alignRight,
                  column.align === 'center' && styles.alignCenter
                )}
                style={{ width: column.width }}
              >
                {column.label || column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className={styles.tbody}>
          {tableData.map((row, rowIndex) => (
            <tr
              key={row.id || rowIndex}
              className={cn(
                styles.tr, 
                (onRowClick || hoverable) && styles.clickable
              )}
              onClick={() => onRowClick?.(row)}
            >
              {columns.map((column) => (
                <td
                  key={column.key}
                  className={cn(
                    styles.td,
                    column.align === 'right' && styles.alignRight,
                    column.align === 'center' && styles.alignCenter
                  )}
                >
                  {column.render
                    ? column.render(row[column.key], row)
                    : row[column.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
