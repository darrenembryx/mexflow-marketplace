export { default } from './Modal';
