// src/components/common/Select/Select.js
'use client';

import { forwardRef } from 'react';
import styles from './Select.module.css';
import { cn } from '@/lib/utils';
import { ChevronDown } from 'lucide-react';

const Select = forwardRef(({
  label,
  error,
  hint,
  options = [],
  placeholder = 'Select an option',
  size = 'md',
  fullWidth = true,
  className,
  disabled,
  required,
  id,
  value,
  onChange,
  ...props
}, ref) => {
  const selectId = id || `select-${Math.random().toString(36).substr(2, 9)}`;

  return (
    <div className={cn(styles.wrapper, fullWidth && styles.fullWidth, className)}>
      {label && (
        <label htmlFor={selectId} className={styles.label}>
          {label}
          {required && <span className={styles.required}>*</span>}
        </label>
      )}
      <div className={cn(
        styles.selectWrapper,
        styles[size],
        error && styles.error,
        disabled && styles.disabled
      )}>
        <select
          ref={ref}
          id={selectId}
          className={styles.select}
          disabled={disabled}
          required={required}
          value={value}
          onChange={onChange}
          {...props}
        >
          {placeholder && (
            <option value="" disabled>
              {placeholder}
            </option>
          )}
          {options.map((option) => (
            <option 
              key={option.value} 
              value={option.value}
              disabled={option.disabled}
            >
              {option.label}
            </option>
          ))}
        </select>
        <ChevronDown size={14} className={styles.chevron} />
      </div>
      {(error || hint) && (
        <span className={cn(styles.message, error && styles.errorMessage)}>
          {error || hint}
        </span>
      )}
    </div>
  );
});

Select.displayName = 'Select';

export default Select;
