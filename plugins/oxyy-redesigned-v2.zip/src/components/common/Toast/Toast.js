// src/components/common/Toast/Toast.js
'use client';

import { useEffect, useState } from 'react';
import styles from './Toast.module.css';
import { cn } from '@/lib/utils';
import { CheckCircle, AlertCircle, Info, AlertTriangle, X } from 'lucide-react';

const icons = {
  success: CheckCircle,
  error: AlertCircle,
  warning: AlertTriangle,
  info: Info,
};

export default function Toast({ 
  id, 
  message, 
  type = 'info', 
  duration = 4000, 
  onDismiss 
}) {
  const [isVisible, setIsVisible] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);
  const Icon = icons[type];

  useEffect(() => {
    requestAnimationFrame(() => setIsVisible(true));
    
    if (duration > 0) {
      const timer = setTimeout(() => handleDismiss(), duration);
      return () => clearTimeout(timer);
    }
  }, [duration]);

  const handleDismiss = () => {
    setIsLeaving(true);
    setTimeout(() => onDismiss?.(id), 200);
  };

  return (
    <div 
      className={cn(
        styles.toast, 
        styles[type],
        isVisible && !isLeaving && styles.visible,
        isLeaving && styles.leaving
      )}
      role="alert"
    >
      <Icon size={16} className={styles.icon} />
      <span className={styles.message}>{message}</span>
      <button 
        className={styles.closeButton} 
        onClick={handleDismiss}
        aria-label="Dismiss"
      >
        <X size={14} />
      </button>
    </div>
  );
}
