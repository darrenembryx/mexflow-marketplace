'use client';

import { formatDate } from '@/lib/formatters';
import Badge from '@/components/common/Badge';
import styles from './RecentActivity.module.css';

export default function RecentActivity({
  activities = [],
  loading = false,
  emptyMessage = 'No recent activity'
}) {
  const getActivityIcon = (type) => {
    switch (type) {
      case 'api_request':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
          </svg>
        );
      case 'payment':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
            <line x1="1" y1="10" x2="23" y2="10" />
          </svg>
        );
      case 'subscription':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
            <circle cx="12" cy="10" r="3" />
          </svg>
        );
      case 'api_key':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4" />
          </svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10" />
          </svg>
        );
    }
  };

  const getActivityColor = (type) => {
    switch (type) {
      case 'api_request': return 'blue';
      case 'payment': return 'green';
      case 'subscription': return 'purple';
      case 'api_key': return 'orange';
      default: return 'default';
    }
  };

  if (loading) {
    return (
      <div className={styles.container}>
        {[...Array(5)].map((_, idx) => (
          <div key={idx} className={styles.skeletonItem}>
            <div className={styles.skeletonIcon} />
            <div className={styles.skeletonContent}>
              <div className={styles.skeletonTitle} />
              <div className={styles.skeletonMeta} />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (activities.length === 0) {
    return (
      <div className={styles.empty}>
        <p>{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      {activities.map((activity, idx) => (
        <div key={activity.id || idx} className={styles.item}>
          <div className={styles.icon} data-color={getActivityColor(activity.type)}>
            {getActivityIcon(activity.type)}
          </div>
          <div className={styles.content}>
            <p className={styles.title}>{activity.title || activity.description}</p>
            <div className={styles.meta}>
              <span className={styles.time}>{formatDate(activity.createdAt)}</span>
              {activity.status && (
                <Badge 
                  variant={activity.status === 'success' ? 'success' : 
                           activity.status === 'failed' ? 'danger' : 'default'}
                  size="small"
                >
                  {activity.status}
                </Badge>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
