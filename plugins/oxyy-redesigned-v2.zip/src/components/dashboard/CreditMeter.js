'use client';

import { formatCredits, formatPercentage } from '@/lib/formatters';
import styles from './CreditMeter.module.css';

export default function CreditMeter({
  used = 0,
  total = 0,
  showDetails = true,
  size = 'medium',
  className = ''
}) {
  const percentage = total > 0 ? Math.min((used / total) * 100, 100) : 0;
  const remaining = Math.max(total - used, 0);

  const getStatusColor = () => {
    if (percentage >= 90) return 'danger';
    if (percentage >= 70) return 'warning';
    return 'success';
  };

  return (
    <div className={`${styles.container} ${styles[size]} ${className}`}>
      <div className={styles.header}>
        <span className={styles.label}>Credits Used</span>
        <span className={styles.value}>
          {formatCredits(used)} / {formatCredits(total)}
        </span>
      </div>
      <div className={styles.track}>
        <div 
          className={styles.fill}
          data-status={getStatusColor()}
          style={{ width: `${percentage}%` }}
        />
      </div>
      {showDetails && (
        <div className={styles.details}>
          <div className={styles.detail}>
            <span className={styles.detailLabel}>Remaining</span>
            <span className={styles.detailValue}>{formatCredits(remaining)}</span>
          </div>
          <div className={styles.detail}>
            <span className={styles.detailLabel}>Usage</span>
            <span className={styles.detailValue}>{formatPercentage(percentage)}</span>
          </div>
        </div>
      )}
    </div>
  );
}
