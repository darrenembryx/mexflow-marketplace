'use client';

import { useState } from 'react';
import { formatCredits } from '@/lib/formatters';
import Button from '@/components/common/Button';
import styles from './ApiKeyCard.module.css';

export default function ApiKeyCard({
  apiKey,
  onReveal,
  onCopy,
  onRevoke,
  onEdit,
  loading = false
}) {
  const [isRevealed, setIsRevealed] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const handleReveal = async () => {
    if (!isRevealed && onReveal) {
      await onReveal(apiKey.id);
    }
    setIsRevealed(!isRevealed);
  };

  const handleCopy = async () => {
    const keyToCopy = apiKey.fullKey || apiKey.key;
    if (keyToCopy) {
      await navigator.clipboard.writeText(keyToCopy);
      setIsCopied(true);
      onCopy?.();
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const maskKey = (key) => {
    if (!key) return '••••••••••••••••';
    if (key.length <= 8) return key;
    return key.slice(0, 8) + '••••••••' + key.slice(-4);
  };

  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div className={styles.nameWrapper}>
          <h3 className={styles.name}>{apiKey.name || 'Unnamed Key'}</h3>
          <span className={`${styles.status} ${apiKey.isActive ? styles.active : styles.inactive}`}>
            {apiKey.isActive ? 'Active' : 'Inactive'}
          </span>
        </div>
        <div className={styles.actions}>
          <Button variant="ghost" size="small" onClick={handleReveal}>
            {isRevealed ? 'Hide' : 'Reveal'}
          </Button>
          <Button variant="ghost" size="small" onClick={handleCopy}>
            {isCopied ? 'Copied!' : 'Copy'}
          </Button>
          {onEdit && (
            <Button variant="ghost" size="small" onClick={() => onEdit(apiKey)}>
              Edit
            </Button>
          )}
        </div>
      </div>

      <div className={styles.keyWrapper}>
        <code className={styles.key}>
          {isRevealed ? (apiKey.fullKey || apiKey.key) : maskKey(apiKey.key)}
        </code>
      </div>

      <div className={styles.meta}>
        <div className={styles.metaItem}>
          <span className={styles.metaLabel}>Created</span>
          <span className={styles.metaValue}>
            {new Date(apiKey.createdAt).toLocaleDateString()}
          </span>
        </div>
        <div className={styles.metaItem}>
          <span className={styles.metaLabel}>Last Used</span>
          <span className={styles.metaValue}>
            {apiKey.lastUsedAt 
              ? new Date(apiKey.lastUsedAt).toLocaleDateString()
              : 'Never'
            }
          </span>
        </div>
        <div className={styles.metaItem}>
          <span className={styles.metaLabel}>Usage</span>
          <span className={styles.metaValue}>
            {apiKey.requestCount || 0} requests
          </span>
        </div>
      </div>

      {onRevoke && (
        <div className={styles.footer}>
          <Button 
            variant="danger" 
            size="small" 
            onClick={() => onRevoke(apiKey.id)}
            isLoading={loading}
          >
            Revoke Key
          </Button>
        </div>
      )}
    </div>
  );
}
