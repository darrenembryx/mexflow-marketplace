'use client';

import styles from './StatsCard.module.css';

export default function StatsCard({
  title,
  value,
  change,
  changeLabel,
  icon,
  iconColor = 'blue',
  loading = false,
  className = ''
}) {
  if (loading) {
    return (
      <div className={`${styles.card} ${className}`}>
        <div className={styles.skeleton}>
          <div className={styles.skeletonIcon} />
          <div className={styles.skeletonContent}>
            <div className={styles.skeletonTitle} />
            <div className={styles.skeletonValue} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`${styles.card} ${className}`}>
      {icon && (
        <div className={styles.icon} data-color={iconColor}>
          {icon}
        </div>
      )}
      <div className={styles.content}>
        <span className={styles.title}>{title}</span>
        <span className={styles.value}>{value}</span>
        {(change !== undefined || changeLabel) && (
          <span 
            className={styles.change}
            data-positive={change >= 0}
          >
            {change !== undefined && (
              <>
                {change >= 0 ? '+' : ''}{change}%
              </>
            )}
            {changeLabel && ` ${changeLabel}`}
          </span>
        )}
      </div>
    </div>
  );
}
