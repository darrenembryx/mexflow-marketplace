// src/components/playground/ChatInput.js
'use client';

import { useState, useRef, useEffect } from 'react';
import styles from './ChatInput.module.css';
import { cn } from '@/lib/utils';
import { Send, Paperclip, Mic, Image, Sparkles, ChevronDown } from 'lucide-react';

const modelOptions = [
  { id: 'gpt-4o', name: 'GPT-4o', provider: 'OpenAI' },
  { id: 'claude-3-5-sonnet', name: 'Claude 3.5 Sonnet', provider: 'Anthropic' },
  { id: 'gemini-pro', name: 'Gemini Pro', provider: 'Google' },
  { id: 'llama-3-70b', name: 'Llama 3 70B', provider: 'Meta' },
];

export default function ChatInput({
  value = '',
  onChange,
  onSubmit,
  onModelChange,
  selectedModel = 'gpt-4o',
  placeholder = 'Ask anything...',
  disabled = false,
  loading = false,
  showModelSelector = true,
  size = 'lg',
  className,
}) {
  const [showModels, setShowModels] = useState(false);
  const textareaRef = useRef(null);
  const dropdownRef = useRef(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [value]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setShowModels(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (value.trim() && !loading && !disabled) {
        onSubmit?.(value);
      }
    }
  };

  const selectedModelData = modelOptions.find(m => m.id === selectedModel) || modelOptions[0];

  return (
    <div className={cn(styles.wrapper, styles[size], className)}>
      <div className={styles.inputContainer}>
        {showModelSelector && (
          <div className={styles.modelSelector} ref={dropdownRef}>
            <button
              type="button"
              className={styles.modelButton}
              onClick={() => setShowModels(!showModels)}
            >
              <Sparkles size={14} />
              <span>{selectedModelData.name}</span>
              <ChevronDown size={14} className={cn(styles.chevron, showModels && styles.open)} />
            </button>
            
            {showModels && (
              <div className={styles.modelDropdown}>
                {modelOptions.map((model) => (
                  <button
                    key={model.id}
                    type="button"
                    className={cn(styles.modelOption, selectedModel === model.id && styles.selected)}
                    onClick={() => {
                      onModelChange?.(model.id);
                      setShowModels(false);
                    }}
                  >
                    <span className={styles.modelName}>{model.name}</span>
                    <span className={styles.modelProvider}>{model.provider}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <textarea
          ref={textareaRef}
          className={styles.textarea}
          value={value}
          onChange={(e) => onChange?.(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled || loading}
          rows={1}
        />

        <div className={styles.actions}>
          <button type="button" className={styles.actionButton} disabled={disabled}>
            <Paperclip size={18} />
          </button>
          <button type="button" className={styles.actionButton} disabled={disabled}>
            <Image size={18} />
          </button>
          <button
            type="button"
            className={cn(styles.sendButton, (value.trim() && !loading) && styles.active)}
            onClick={() => value.trim() && !loading && onSubmit?.(value)}
            disabled={!value.trim() || loading || disabled}
          >
            {loading ? (
              <div className={styles.spinner} />
            ) : (
              <Send size={18} />
            )}
          </button>
        </div>
      </div>
      
      <p className={styles.hint}>
        Press <kbd>Enter</kbd> to send, <kbd>Shift + Enter</kbd> for new line
      </p>
    </div>
  );
}
