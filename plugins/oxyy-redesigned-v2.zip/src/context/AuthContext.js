'use client';

// src/context/AuthContext.js - Authentication Context

import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authApi, setAuthTokens, clearAuthTokens } from '@/lib/api';
import { ROUTES } from '@/lib/constants';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check authentication status on mount
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem('accessToken');
      if (!token) {
        setIsLoading(false);
        return;
      }

      const response = await authApi.getProfile();
      if (response.success && response.data) {
        setUser(response.data);
        setIsAuthenticated(true);
      }
    } catch (error) {
      clearAuthTokens();
      setUser(null);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  };

  const login = useCallback(async (email, password) => {
    const response = await authApi.login({ email, password });
    
    if (response.success && response.data) {
      const { accessToken, refreshToken, user: userData } = response.data;
      setAuthTokens(accessToken, refreshToken);
      setUser(userData);
      setIsAuthenticated(true);
      return { success: true, user: userData };
    }
    
    throw new Error(response.message || 'Login failed');
  }, []);

  const register = useCallback(async (data) => {
    const response = await authApi.register(data);
    
    if (response.success && response.data) {
      const { accessToken, refreshToken, user: userData } = response.data;
      if (accessToken) {
        setAuthTokens(accessToken, refreshToken);
        setUser(userData);
        setIsAuthenticated(true);
      }
      return { success: true, user: userData };
    }
    
    throw new Error(response.message || 'Registration failed');
  }, []);

  const logout = useCallback(async () => {
    try {
      await authApi.logout();
    } catch (error) {
      // Ignore logout errors
    } finally {
      clearAuthTokens();
      setUser(null);
      setIsAuthenticated(false);
      window.location.href = ROUTES.LOGIN;
    }
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const response = await authApi.getProfile();
      if (response.success && response.data) {
        setUser(response.data);
        return response.data;
      }
    } catch (error) {
      console.error('Failed to refresh user:', error);
    }
    return null;
  }, []);

  const forgotPassword = useCallback(async (email) => {
    const response = await authApi.forgotPassword(email);
    return response;
  }, []);

  const resetPassword = useCallback(async (token, password) => {
    const response = await authApi.resetPassword(token, password);
    return response;
  }, []);

  const verifyEmail = useCallback(async (token) => {
    const response = await authApi.verifyEmail(token);
    if (response.success) {
      await refreshUser();
    }
    return response;
  }, [refreshUser]);

  const changePassword = useCallback(async (currentPassword, newPassword) => {
    const response = await authApi.changePassword(currentPassword, newPassword);
    return response;
  }, []);

  const value = {
    user,
    isLoading,
    isAuthenticated,
    login,
    register,
    logout,
    refreshUser,
    forgotPassword,
    resetPassword,
    verifyEmail,
    changePassword,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export default AuthContext;
