// src/app/(public)/page.js - Homepage with AI Playground
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import styles from './page.module.css';
import { useAuth } from '@/context/AuthContext';
import { ROUTES } from '@/lib/constants';
import ChatInput from '@/components/playground/ChatInput';
import Button from '@/components/common/Button';
import { 
  ArrowRight, 
  Zap, 
  Shield, 
  DollarSign, 
  Code2, 
  Globe, 
  Cpu,
  Check,
  Sparkles,
  MessageSquare,
  Image,
  Video,
  Mic,
} from 'lucide-react';

const capabilities = [
  { icon: MessageSquare, label: 'Chat & Text', desc: 'GPT-4, Claude, Gemini' },
  { icon: Image, label: 'Image Generation', desc: 'DALL-E, Midjourney, SD' },
  { icon: Video, label: 'Video Creation', desc: 'Runway, Pika, Sora' },
  { icon: Mic, label: 'Audio & Speech', desc: 'TTS, STT, Voice Clone' },
];

const features = [
  {
    icon: Globe,
    title: 'One API, 100+ Models',
    description: 'Access every major AI provider through a single endpoint.',
  },
  {
    icon: Code2,
    title: 'OpenAI Compatible',
    description: 'Drop-in replacement. Change one line of code.',
  },
  {
    icon: DollarSign,
    title: 'Pay Per Use',
    description: 'No subscriptions. Pay only for what you use.',
  },
  {
    icon: Zap,
    title: 'Ultra Fast',
    description: 'Optimized routing for blazing fast responses.',
  },
  {
    icon: Shield,
    title: 'Enterprise Ready',
    description: 'SOC 2 compliant with full audit logs.',
  },
  {
    icon: Cpu,
    title: 'All Modalities',
    description: 'Text, images, audio, video — all in one place.',
  },
];

const stats = [
  { value: '100+', label: 'AI Models' },
  { value: '99.9%', label: 'Uptime' },
  { value: '<100ms', label: 'Latency' },
  { value: '10K+', label: 'Developers' },
];

export default function HomePage() {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [chatInput, setChatInput] = useState('');
  const [selectedModel, setSelectedModel] = useState('gpt-4o');

  const handleSubmit = (value) => {
    if (isAuthenticated) {
      // Redirect to dashboard playground with the message
      router.push(`/playground?prompt=${encodeURIComponent(value)}&model=${selectedModel}`);
    } else {
      // Redirect to login with redirect back to playground
      router.push(`/login?redirect=${encodeURIComponent(`/playground?prompt=${encodeURIComponent(value)}&model=${selectedModel}`)}`);
    }
  };

  return (
    <div className={styles.page}>
      {/* Hero Section with Chat */}
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <div className={styles.badge}>
            <Sparkles size={14} />
            <span>Universal AI Gateway</span>
          </div>
          
          <h1 className={styles.title}>
            One API for
            <span className={styles.gradient}> Every AI Model</span>
          </h1>
          
          <p className={styles.subtitle}>
            Access GPT-4, Claude, Gemini, Llama, DALL-E, and 100+ more models 
            through a single, unified API. Start building in seconds.
          </p>

          {/* Capabilities Pills */}
          <div className={styles.capabilities}>
            {capabilities.map((cap) => {
              const Icon = cap.icon;
              return (
                <div key={cap.label} className={styles.capabilityPill}>
                  <Icon size={14} />
                  <div>
                    <span className={styles.capLabel}>{cap.label}</span>
                    <span className={styles.capDesc}>{cap.desc}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chat Playground */}
        <div className={styles.playground}>
          <div className={styles.playgroundHeader}>
            <div className={styles.playgroundTitle}>
              <Sparkles size={18} className={styles.playgroundIcon} />
              <span>Try it now</span>
            </div>
            <span className={styles.playgroundHint}>No sign-up required</span>
          </div>
          
          <div className={styles.chatArea}>
            <div className={styles.welcomeMessage}>
              <p>👋 Hello! I'm powered by multiple AI models through Oxyy.ai.</p>
              <p>Try asking me anything — generate text, create images, or analyze data.</p>
            </div>
          </div>

          <ChatInput
            value={chatInput}
            onChange={setChatInput}
            onSubmit={handleSubmit}
            onModelChange={setSelectedModel}
            selectedModel={selectedModel}
            placeholder="Ask me anything... Generate an image, write code, analyze data..."
            size="lg"
          />
        </div>

        {/* Quick Stats */}
        <div className={styles.stats}>
          {stats.map((stat) => (
            <div key={stat.label} className={styles.stat}>
              <span className={styles.statValue}>{stat.value}</span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className={styles.features}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Why developers choose Oxyy</h2>
          <p className={styles.sectionSubtitle}>
            Everything you need to integrate AI into your products.
          </p>
        </div>
        
        <div className={styles.featuresGrid}>
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <div key={feature.title} className={styles.featureCard}>
                <div className={styles.featureIcon}>
                  <Icon size={20} />
                </div>
                <h3 className={styles.featureTitle}>{feature.title}</h3>
                <p className={styles.featureDesc}>{feature.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Code Example */}
      <section className={styles.codeSection}>
        <div className={styles.codeContent}>
          <h2 className={styles.codeTitle}>
            Start in seconds with familiar syntax
          </h2>
          <p className={styles.codeSubtitle}>
            Use your existing OpenAI code. Just change the base URL.
          </p>
          <div className={styles.codeButtons}>
            <Link href={ROUTES.REGISTER}>
              <Button icon={<ArrowRight size={16} />} iconPosition="right">
                Get API Key
              </Button>
            </Link>
            <Link href={ROUTES.DOCS}>
              <Button variant="outline">
                View Docs
              </Button>
            </Link>
          </div>
        </div>
        
        <div className={styles.codePreview}>
          <div className={styles.codeHeader}>
            <div className={styles.codeDots}>
              <span /><span /><span />
            </div>
            <span className={styles.codeFile}>example.js</span>
          </div>
          <pre className={styles.code}>
{`import OpenAI from 'openai';

const client = new OpenAI({
  apiKey: process.env.OXYY_API_KEY,
  baseURL: 'https://api.oxyy.ai/v1'
});

// Works with any model
const response = await client.chat.completions.create({
  model: 'claude-3-5-sonnet', // or gpt-4o, gemini-pro
  messages: [{ role: 'user', content: 'Hello!' }]
});`}
          </pre>
        </div>
      </section>

      {/* CTA Section */}
      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2 className={styles.ctaTitle}>Ready to simplify your AI stack?</h2>
          <p className={styles.ctaSubtitle}>
            Start with $5 free credits. No credit card required.
          </p>
          <div className={styles.ctaButtons}>
            <Link href={ROUTES.REGISTER}>
              <Button size="lg" icon={<ArrowRight size={16} />} iconPosition="right">
                Start Building Free
              </Button>
            </Link>
            <Link href={ROUTES.PRICING}>
              <Button size="lg" variant="outline">
                View Pricing
              </Button>
            </Link>
          </div>
          <div className={styles.ctaFeatures}>
            <span><Check size={14} /> No credit card</span>
            <span><Check size={14} /> $5 free credits</span>
            <span><Check size={14} /> Setup in 2 mins</span>
          </div>
        </div>
      </section>
    </div>
  );
}
