'use client';

// src/app/(public)/models/page.js

import { useState, useEffect } from 'react';
import styles from './page.module.css';
import { publicApi } from '@/lib/api';
import { MODEL_TYPES, MODEL_TIERS } from '@/lib/constants';
import { formatCredits } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Skeleton from '@/components/common/Skeleton';
import Badge from '@/components/common/Badge';
import Tabs from '@/components/common/Tabs';
import Input from '@/components/common/Input';
import { Search, Cpu, Image, Mic, Code, FileText } from 'lucide-react';

const typeIcons = {
  TEXT: Cpu,
  IMAGE_GENERATION: Image,
  AUDIO_TTS: Mic,
  AUDIO_STT: Mic,
  EMBEDDINGS: Code,
  VIDEO_GENERATION: FileText,
};

const tierColors = {
  FREE: 'success',
  FAST: 'info',
  SMART: 'warning',
  PREMIUM: 'error',
};

export default function ModelsPage() {
  const [models, setModels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    async function fetchModels() {
      try {
        const response = await publicApi.getModels();
        if (response.success) {
          setModels(response.data);
        }
      } catch (error) {
        console.error('Failed to fetch models:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchModels();
  }, []);

  const tabs = [
    { id: 'all', label: 'All Models' },
    { id: 'TEXT', label: 'Text' },
    { id: 'IMAGE_GENERATION', label: 'Image' },
    { id: 'AUDIO_TTS', label: 'Audio' },
    { id: 'EMBEDDINGS', label: 'Embeddings' },
  ];

  const filteredModels = models.filter((model) => {
    const matchesTab = activeTab === 'all' || model.type === activeTab;
    const matchesSearch =
      searchQuery === '' ||
      model.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      model.modelId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      model.provider?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  const groupedModels = filteredModels.reduce((acc, model) => {
    const provider = model.provider || 'Other';
    if (!acc[provider]) {
      acc[provider] = [];
    }
    acc[provider].push(model);
    return acc;
  }, {});

  const formatCost = (model) => {
    switch (model.pricingMode) {
      case 'PER_TOKEN_IO':
        return `${formatCredits(model.inputCostPer1M || 0)} / ${formatCredits(model.outputCostPer1M || 0)} per 1M tokens`;
      case 'PER_IMAGE_FLAT':
        return `${formatCredits(model.flatCostPerRequest || 0)} per image`;
      case 'PER_MINUTE':
        return `${formatCredits(model.costPerMinute || 0)} per minute`;
      default:
        return `${formatCredits(model.flatCostPerRequest || 0)} per request`;
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.container}>
        <div className={styles.header}>
          <h1 className={styles.title}>AI Models</h1>
          <p className={styles.subtitle}>
            Browse all available AI models. Access any model through our unified API.
          </p>
        </div>

        <div className={styles.filters}>
          <Tabs
            tabs={tabs}
            activeTab={activeTab}
            onChange={setActiveTab}
          />
          <div className={styles.search}>
            <Input
              placeholder="Search models..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              leftIcon={<Search size={16} />}
            />
          </div>
        </div>

        {loading ? (
          <div className={styles.skeleton}>
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <Skeleton height={100} />
              </Card>
            ))}
          </div>
        ) : filteredModels.length === 0 ? (
          <div className={styles.empty}>
            <p>No models found matching your criteria.</p>
          </div>
        ) : (
          <div className={styles.providers}>
            {Object.entries(groupedModels).map(([provider, providerModels]) => (
              <div key={provider} className={styles.providerSection}>
                <h2 className={styles.providerTitle}>{provider}</h2>
                <div className={styles.modelGrid}>
                  {providerModels.map((model) => {
                    const Icon = typeIcons[model.type] || Cpu;
                    return (
                      <Card key={model.id} className={styles.modelCard}>
                        <div className={styles.modelHeader}>
                          <div className={styles.modelIcon}>
                            <Icon size={20} />
                          </div>
                          <div className={styles.modelInfo}>
                            <h3 className={styles.modelName}>{model.name}</h3>
                            <code className={styles.modelId}>{model.modelId}</code>
                          </div>
                        </div>
                        
                        <div className={styles.modelMeta}>
                          <Badge variant={tierColors[model.tier] || 'default'} size="sm">
                            {model.tier}
                          </Badge>
                          <Badge variant="outline" size="sm">
                            {MODEL_TYPES[model.type] || model.type}
                          </Badge>
                        </div>

                        <div className={styles.modelCost}>
                          <span className={styles.costLabel}>Cost:</span>
                          <span className={styles.costValue}>{formatCost(model)}</span>
                        </div>

                        {model.contextWindow && (
                          <div className={styles.modelContext}>
                            <span className={styles.contextLabel}>Context:</span>
                            <span className={styles.contextValue}>
                              {(model.contextWindow / 1000).toFixed(0)}K tokens
                            </span>
                          </div>
                        )}
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
