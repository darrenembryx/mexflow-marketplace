// src/app/(public)/docs/page.js

import Link from 'next/link';
import styles from './page.module.css';
import { ROUTES } from '@/lib/constants';
import Button from '@/components/common/Button';
import Card from '@/components/common/Card';
import { Book, Code, Key, Zap, ArrowRight } from 'lucide-react';

const sections = [
  {
    icon: Zap,
    title: 'Quick Start',
    description: 'Get up and running with Oxyy.ai in just a few minutes.',
    link: '#quickstart',
  },
  {
    icon: Key,
    title: 'Authentication',
    description: 'Learn how to authenticate your API requests.',
    link: '#authentication',
  },
  {
    icon: Code,
    title: 'API Reference',
    description: 'Complete API documentation for all endpoints.',
    link: '#api-reference',
  },
  {
    icon: Book,
    title: 'Examples',
    description: 'Code examples in popular programming languages.',
    link: '#examples',
  },
];

export default function DocsPage() {
  return (
    <div className={styles.page}>
      <div className={styles.container}>
        <div className={styles.header}>
          <h1 className={styles.title}>Documentation</h1>
          <p className={styles.subtitle}>
            Everything you need to integrate Oxyy.ai into your application.
          </p>
        </div>

        <div className={styles.grid}>
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <Card key={section.title} hover>
                <div className={styles.cardIcon}>
                  <Icon size={24} />
                </div>
                <h2 className={styles.cardTitle}>{section.title}</h2>
                <p className={styles.cardDescription}>{section.description}</p>
              </Card>
            );
          })}
        </div>

        {/* Quick Start Section */}
        <section id="quickstart" className={styles.section}>
          <h2 className={styles.sectionTitle}>Quick Start</h2>
          
          <div className={styles.step}>
            <h3 className={styles.stepTitle}>1. Create an Account</h3>
            <p className={styles.stepText}>
              Sign up for a free account to get your API key.
            </p>
            <Link href={ROUTES.REGISTER}>
              <Button size="sm" variant="secondary">Create Account</Button>
            </Link>
          </div>

          <div className={styles.step}>
            <h3 className={styles.stepTitle}>2. Get Your API Key</h3>
            <p className={styles.stepText}>
              Generate an API key from your dashboard.
            </p>
          </div>

          <div className={styles.step}>
            <h3 className={styles.stepTitle}>3. Make Your First Request</h3>
            <p className={styles.stepText}>
              Use the OpenAI SDK with our base URL:
            </p>
            <div className={styles.codeBlock}>
              <pre className={styles.code}>
{`import OpenAI from 'openai';

const client = new OpenAI({
  apiKey: 'your-api-key',
  baseURL: 'https://api.oxyy.ai/v1',
});

const response = await client.chat.completions.create({
  model: 'gpt-4o',
  messages: [{ role: 'user', content: 'Hello!' }],
});`}
              </pre>
            </div>
          </div>
        </section>

        {/* Authentication Section */}
        <section id="authentication" className={styles.section}>
          <h2 className={styles.sectionTitle}>Authentication</h2>
          <p className={styles.sectionText}>
            All API requests require authentication using an API key. Include your API key
            in the <code>Authorization</code> header:
          </p>
          <div className={styles.codeBlock}>
            <pre className={styles.code}>
{`Authorization: Bearer your-api-key`}
            </pre>
          </div>
          <p className={styles.sectionText}>
            Keep your API keys secure and never expose them in client-side code.
          </p>
        </section>

        {/* API Reference Section */}
        <section id="api-reference" className={styles.section}>
          <h2 className={styles.sectionTitle}>API Reference</h2>
          
          <h3 className={styles.endpointTitle}>Chat Completions</h3>
          <p className={styles.sectionText}>
            Create a chat completion with streaming support.
          </p>
          <div className={styles.endpoint}>
            <code className={styles.method}>POST</code>
            <code className={styles.path}>/v1/chat/completions</code>
          </div>
          
          <h3 className={styles.endpointTitle}>Image Generation</h3>
          <p className={styles.sectionText}>
            Generate images using DALL-E or other image models.
          </p>
          <div className={styles.endpoint}>
            <code className={styles.method}>POST</code>
            <code className={styles.path}>/v1/images/generations</code>
          </div>
          
          <h3 className={styles.endpointTitle}>Audio Transcription</h3>
          <p className={styles.sectionText}>
            Transcribe audio to text using Whisper.
          </p>
          <div className={styles.endpoint}>
            <code className={styles.method}>POST</code>
            <code className={styles.path}>/v1/audio/transcriptions</code>
          </div>
          
          <h3 className={styles.endpointTitle}>Text-to-Speech</h3>
          <p className={styles.sectionText}>
            Convert text to speech audio.
          </p>
          <div className={styles.endpoint}>
            <code className={styles.method}>POST</code>
            <code className={styles.path}>/v1/audio/speech</code>
          </div>
          
          <h3 className={styles.endpointTitle}>Embeddings</h3>
          <p className={styles.sectionText}>
            Generate embeddings for text.
          </p>
          <div className={styles.endpoint}>
            <code className={styles.method}>POST</code>
            <code className={styles.path}>/v1/embeddings</code>
          </div>
        </section>

        {/* Examples Section */}
        <section id="examples" className={styles.section}>
          <h2 className={styles.sectionTitle}>Code Examples</h2>
          
          <h3 className={styles.exampleTitle}>Python</h3>
          <div className={styles.codeBlock}>
            <pre className={styles.code}>
{`from openai import OpenAI

client = OpenAI(
    api_key="your-api-key",
    base_url="https://api.oxyy.ai/v1"
)

response = client.chat.completions.create(
    model="claude-3-5-sonnet",
    messages=[{"role": "user", "content": "Hello!"}]
)

print(response.choices[0].message.content)`}
            </pre>
          </div>
          
          <h3 className={styles.exampleTitle}>cURL</h3>
          <div className={styles.codeBlock}>
            <pre className={styles.code}>
{`curl https://api.oxyy.ai/v1/chat/completions \\
  -H "Authorization: Bearer your-api-key" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "gpt-4o",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'`}
            </pre>
          </div>
        </section>
      </div>
    </div>
  );
}
