'use client';

// src/app/(public)/status/page.js

import { useState, useEffect } from 'react';
import styles from './page.module.css';
import { publicApi } from '@/lib/api';
import Card from '@/components/common/Card';
import Badge from '@/components/common/Badge';
import Skeleton from '@/components/common/Skeleton';
import { CheckCircle, AlertCircle, XCircle, RefreshCw } from 'lucide-react';

const statusColors = {
  operational: 'success',
  degraded: 'warning',
  outage: 'error',
};

const statusIcons = {
  operational: CheckCircle,
  degraded: AlertCircle,
  outage: XCircle,
};

export default function StatusPage() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStatus = async () => {
    try {
      const response = await publicApi.getStatus();
      if (response.success) {
        setStatus(response.data);
      }
    } catch (error) {
      console.error('Failed to fetch status:', error);
      setStatus({
        overall: 'operational',
        services: [
          { name: 'API Gateway', status: 'operational' },
          { name: 'Chat Completions', status: 'operational' },
          { name: 'Image Generation', status: 'operational' },
          { name: 'Audio Processing', status: 'operational' },
          { name: 'Embeddings', status: 'operational' },
        ],
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchStatus();
  };

  const OverallIcon = status ? statusIcons[status.overall] || CheckCircle : CheckCircle;

  return (
    <div className={styles.page}>
      <div className={styles.container}>
        <div className={styles.header}>
          <h1 className={styles.title}>System Status</h1>
          <p className={styles.subtitle}>
            Current status of Oxyy.ai services.
          </p>
        </div>

        {loading ? (
          <Card>
            <Skeleton height={60} />
            <div style={{ marginTop: 24 }}>
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} height={48} style={{ marginTop: 12 }} />
              ))}
            </div>
          </Card>
        ) : (
          <>
            <Card className={styles.overallCard}>
              <div className={styles.overall}>
                <div className={styles.overallStatus}>
                  <OverallIcon
                    size={32}
                    className={styles[`icon${status?.overall || 'operational'}`]}
                  />
                  <div>
                    <h2 className={styles.overallTitle}>
                      {status?.overall === 'operational'
                        ? 'All Systems Operational'
                        : status?.overall === 'degraded'
                        ? 'Partial System Outage'
                        : 'Major System Outage'}
                    </h2>
                    <p className={styles.overallText}>
                      Last updated: {new Date().toLocaleTimeString()}
                    </p>
                  </div>
                </div>
                <button
                  className={styles.refreshButton}
                  onClick={handleRefresh}
                  disabled={refreshing}
                >
                  <RefreshCw size={16} className={refreshing ? styles.spinning : ''} />
                  Refresh
                </button>
              </div>
            </Card>

            <Card className={styles.servicesCard}>
              <h3 className={styles.servicesTitle}>Services</h3>
              <div className={styles.services}>
                {status?.services?.map((service) => {
                  const Icon = statusIcons[service.status] || CheckCircle;
                  return (
                    <div key={service.name} className={styles.service}>
                      <div className={styles.serviceName}>
                        <Icon
                          size={16}
                          className={styles[`icon${service.status}`]}
                        />
                        <span>{service.name}</span>
                      </div>
                      <Badge variant={statusColors[service.status] || 'success'}>
                        {service.status === 'operational'
                          ? 'Operational'
                          : service.status === 'degraded'
                          ? 'Degraded'
                          : 'Outage'}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </Card>

            <div className={styles.history}>
              <h3 className={styles.historyTitle}>Uptime History</h3>
              <p className={styles.historyText}>
                99.9% uptime over the last 90 days.
              </p>
              <div className={styles.uptimeBars}>
                {Array.from({ length: 90 }, (_, i) => (
                  <div
                    key={i}
                    className={styles.uptimeBar}
                    title={`${90 - i} days ago`}
                  />
                ))}
              </div>
              <div className={styles.uptimeLabels}>
                <span>90 days ago</span>
                <span>Today</span>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
