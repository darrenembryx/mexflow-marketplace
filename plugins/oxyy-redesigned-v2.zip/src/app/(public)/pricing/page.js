// src/app/(public)/pricing/page.js

import Link from 'next/link';
import styles from './page.module.css';
import { ROUTES } from '@/lib/constants';
import Button from '@/components/common/Button';
import { Check, ArrowRight } from 'lucide-react';

const plans = [
  {
    name: 'Free',
    price: '$0',
    description: 'Perfect for testing and small projects',
    features: [
      '$5 free credits',
      'Access to all models',
      'OpenAI compatible API',
      'Basic support',
      '1,000 requests/day limit',
    ],
    cta: 'Get Started',
    href: ROUTES.REGISTER,
    featured: false,
  },
  {
    name: 'Pro',
    price: '$20',
    period: '/month',
    description: 'For growing teams and applications',
    features: [
      '$25 credits/month included',
      'Access to all models',
      'Priority API access',
      'Priority support',
      '50,000 requests/day limit',
      'Usage analytics',
      'Team management',
    ],
    cta: 'Start Pro Trial',
    href: ROUTES.REGISTER,
    featured: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    description: 'For large-scale deployments',
    features: [
      'Volume discounts',
      'Dedicated infrastructure',
      'SLA guarantee',
      'Dedicated support',
      'Unlimited requests',
      'Custom integrations',
      'On-premise options',
    ],
    cta: 'Contact Sales',
    href: '/contact',
    featured: false,
  },
];

export default function PricingPage() {
  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <h1 className={styles.title}>Simple, transparent pricing</h1>
        <p className={styles.subtitle}>
          Pay only for what you use. No hidden fees, no surprises.
        </p>
      </section>

      <section className={styles.plans}>
        {plans.map((plan) => (
          <div 
            key={plan.name} 
            className={`${styles.planCard} ${plan.featured ? styles.featured : ''}`}
          >
            {plan.featured && <span className={styles.badge}>Most Popular</span>}
            <div className={styles.planHeader}>
              <h2 className={styles.planName}>{plan.name}</h2>
              <div className={styles.planPrice}>
                <span className={styles.price}>{plan.price}</span>
                {plan.period && <span className={styles.period}>{plan.period}</span>}
              </div>
              <p className={styles.planDescription}>{plan.description}</p>
            </div>
            <ul className={styles.features}>
              {plan.features.map((feature) => (
                <li key={feature} className={styles.feature}>
                  <Check size={16} className={styles.checkIcon} />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <Link href={plan.href} className={styles.ctaLink}>
              <Button 
                fullWidth 
                variant={plan.featured ? 'primary' : 'outline'}
                icon={<ArrowRight size={14} />}
                iconPosition="right"
              >
                {plan.cta}
              </Button>
            </Link>
          </div>
        ))}
      </section>

      <section className={styles.faq}>
        <h2 className={styles.faqTitle}>Frequently asked questions</h2>
        <div className={styles.faqGrid}>
          <div className={styles.faqItem}>
            <h3>How do credits work?</h3>
            <p>Credits are deducted based on model usage. Different models have different rates per token. Check our docs for detailed pricing.</p>
          </div>
          <div className={styles.faqItem}>
            <h3>Can I change plans anytime?</h3>
            <p>Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately.</p>
          </div>
          <div className={styles.faqItem}>
            <h3>What payment methods do you accept?</h3>
            <p>We accept all major credit cards, PayPal, and cryptocurrency payments.</p>
          </div>
          <div className={styles.faqItem}>
            <h3>Is there a free trial?</h3>
            <p>Every new account gets $5 in free credits to test our platform. No credit card required.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
