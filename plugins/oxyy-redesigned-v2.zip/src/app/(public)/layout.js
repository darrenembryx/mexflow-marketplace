// src/app/(public)/layout.js

import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import styles from './layout.module.css';

export default function PublicLayout({ children }) {
  return (
    <div className={styles.layout}>
      <Header />
      <main className={styles.main}>
        {children}
      </main>
      <Footer />
    </div>
  );
}
