'use client';

import { useState, useEffect } from 'react';
import { adminApi } from '@/lib/api';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Input from '@/components/common/Input';
import Select from '@/components/common/Select';
import Tabs from '@/components/common/Tabs';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { useToast } from '@/context/ToastContext';
import styles from './page.module.css';

export default function AdminSettingsPage() {
  const { showToast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('general');
  
  // Credit multiplier state
  const [creditMultiplier, setCreditMultiplier] = useState(1000);
  const [isLoadingMultiplier, setIsLoadingMultiplier] = useState(false);
  const [isSavingMultiplier, setIsSavingMultiplier] = useState(false);
  
  // Media URL mode settings state
  const [mediaSettings, setMediaSettings] = useState({
    image: 'proxy',
    video: 'proxy',
    audio: 'proxy'
  });
  const [isLoadingMedia, setIsLoadingMedia] = useState(false);
  const [isSavingMedia, setIsSavingMedia] = useState(false);
  
  const [settings, setSettings] = useState({
    general: {
      siteName: '',
      siteUrl: '',
      supportEmail: '',
      defaultCredits: '',
      maintenanceMode: false
    },
    payment: {
      stripeEnabled: false,
      stripePublicKey: '',
      stripeSecretKey: '',
      cryptomusEnabled: false,
      cryptomusMerchantId: '',
      cryptomusApiKey: '',
      nowpaymentsEnabled: false,
      nowpaymentsApiKey: ''
    },
    email: {
      provider: 'smtp',
      smtpHost: '',
      smtpPort: '',
      smtpUser: '',
      smtpPassword: '',
      fromEmail: '',
      fromName: ''
    },
    security: {
      maxLoginAttempts: '',
      lockoutDuration: '',
      sessionTimeout: '',
      requireEmailVerification: true,
      allowRegistration: true
    }
  });

  useEffect(() => {
    loadSettings();
    loadCreditMultiplier();
    loadMediaSettings();
  }, []);

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const response = await adminApi.getSettings();
      if (response.data) {
        setSettings(prev => ({
          ...prev,
          ...response.data
        }));
      }
    } catch (error) {
      console.error('Failed to load settings:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const loadCreditMultiplier = async () => {
    setIsLoadingMultiplier(true);
    try {
      const response = await adminApi.getCreditMultiplier();
      if (response.data?.multiplier) {
        setCreditMultiplier(response.data.multiplier);
      }
    } catch (error) {
      console.error('Failed to load credit multiplier:', error);
    } finally {
      setIsLoadingMultiplier(false);
    }
  };
  
  const loadMediaSettings = async () => {
    setIsLoadingMedia(true);
    try {
      const response = await adminApi.getMediaSettings();
      if (response.data) {
        setMediaSettings({
          image: response.data.image || 'proxy',
          video: response.data.video || 'proxy',
          audio: response.data.audio || 'proxy'
        });
      }
    } catch (error) {
      console.error('Failed to load media settings:', error);
    } finally {
      setIsLoadingMedia(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await adminApi.updateSettings(settings);
      showToast('Settings saved successfully', 'success');
    } catch (error) {
      showToast(error.message || 'Failed to save settings', 'error');
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleSaveCreditMultiplier = async () => {
    if (!creditMultiplier || creditMultiplier < 1) {
      showToast('Credit multiplier must be at least 1', 'error');
      return;
    }
    
    setIsSavingMultiplier(true);
    try {
      await adminApi.updateCreditMultiplier(parseInt(creditMultiplier));
      showToast('Credit multiplier updated successfully', 'success');
    } catch (error) {
      showToast(error.message || 'Failed to update credit multiplier', 'error');
    } finally {
      setIsSavingMultiplier(false);
    }
  };
  
  const handleSaveMediaSettings = async () => {
    setIsSavingMedia(true);
    try {
      await adminApi.updateMediaSettings(mediaSettings);
      showToast('Media settings saved successfully', 'success');
    } catch (error) {
      showToast(error.message || 'Failed to save media settings', 'error');
    } finally {
      setIsSavingMedia(false);
    }
  };
  
  const updateMediaSetting = (type, value) => {
    setMediaSettings(prev => ({
      ...prev,
      [type]: value
    }));
  };

  const updateSetting = (category, key, value) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
  };

  const tabs = [
    { id: 'general', label: 'General' },
    { id: 'credits', label: 'Credits' },
    { id: 'media', label: 'Media' },
    { id: 'payment', label: 'Payment' },
    { id: 'email', label: 'Email' },
    { id: 'security', label: 'Security' }
  ];

  if (isLoading) {
    return (
      <div className={styles.loading}>
        <LoadingSpinner size="large" />
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Settings</h1>
          <p className={styles.subtitle}>Configure platform settings</p>
        </div>
        {activeTab !== 'credits' && activeTab !== 'media' && (
          <Button onClick={handleSave} isLoading={isSaving}>
            Save Changes
          </Button>
        )}
      </div>

      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {/* General Settings */}
      {activeTab === 'general' && (
        <Card className={styles.settingsCard}>
          <h2 className={styles.sectionTitle}>General Settings</h2>
          <div className={styles.settingsForm}>
            <Input
              label="Site Name"
              value={settings.general.siteName}
              onChange={(e) => updateSetting('general', 'siteName', e.target.value)}
              placeholder="Oxyy.ai"
            />
            <Input
              label="Site URL"
              value={settings.general.siteUrl}
              onChange={(e) => updateSetting('general', 'siteUrl', e.target.value)}
              placeholder="https://oxyy.ai"
            />
            <Input
              label="Support Email"
              type="email"
              value={settings.general.supportEmail}
              onChange={(e) => updateSetting('general', 'supportEmail', e.target.value)}
              placeholder="support@oxyy.ai"
            />
            <Input
              label="Default Credits for New Users"
              type="number"
              value={settings.general.defaultCredits}
              onChange={(e) => updateSetting('general', 'defaultCredits', e.target.value)}
              placeholder="100"
            />
            <label className={styles.checkbox}>
              <input
                type="checkbox"
                checked={settings.general.maintenanceMode}
                onChange={(e) => updateSetting('general', 'maintenanceMode', e.target.checked)}
              />
              <span>Maintenance Mode</span>
            </label>
          </div>
        </Card>
      )}
      
      {/* Credit Settings */}
      {activeTab === 'credits' && (
        <Card className={styles.settingsCard}>
          <h2 className={styles.sectionTitle}>Credit Multiplier</h2>
          <p className={styles.sectionDescription}>
            The credit multiplier determines how many credits equal $1 USD. This affects all pricing calculations.
          </p>
          
          {isLoadingMultiplier ? (
            <div className={styles.loading}>
              <LoadingSpinner />
            </div>
          ) : (
            <div className={styles.settingsForm}>
              <div className={styles.multiplierSection}>
                <Input
                  label="Credit Multiplier"
                  type="number"
                  min="1"
                  step="1"
                  value={creditMultiplier}
                  onChange={(e) => setCreditMultiplier(e.target.value)}
                  placeholder="1000"
                />
                <p className={styles.fieldHint}>
                  Current setting: <strong>{creditMultiplier} credits = $1 USD</strong>
                </p>
              </div>
              
              <div className={styles.multiplierExamples}>
                <h4>Common Values:</h4>
                <ul>
                  <li><strong>100</strong> - 100 credits = $1 (simple cents calculation)</li>
                  <li><strong>1000</strong> - 1000 credits = $1 (default, recommended)</li>
                  <li><strong>10000</strong> - 10,000 credits = $1 (more granular pricing)</li>
                </ul>
              </div>
              
              <div className={styles.warningBox}>
                <span className={styles.warningIcon}>⚠️</span>
                <div>
                  <strong>Warning:</strong> Changing this value will affect credit calculations for all future API calls. 
                  Existing user balances will not be automatically converted.
                </div>
              </div>
              
              <div className={styles.multiplierActions}>
                <Button 
                  onClick={handleSaveCreditMultiplier} 
                  isLoading={isSavingMultiplier}
                >
                  Update Credit Multiplier
                </Button>
              </div>
            </div>
          )}
        </Card>
      )}

      {/* Media URL Mode Settings */}
      {activeTab === 'media' && (
        <Card className={styles.settingsCard}>
          <h2 className={styles.sectionTitle}>Media URL Mode Settings</h2>
          <p className={styles.sectionDescription}>
            Configure how media files (images, videos, audio) are delivered to users after generation.
          </p>
          
          {isLoadingMedia ? (
            <div className={styles.loading}>
              <LoadingSpinner />
            </div>
          ) : (
            <div className={styles.settingsForm}>
              <div className={styles.multiplierExamples} style={{ marginBottom: '1.5rem' }}>
                <h4>URL Mode Options:</h4>
                <ul>
                  <li><strong>Proxy</strong> - Download files to your CDN storage (recommended). Provides permanent URLs and hides provider details.</li>
                  <li><strong>Cloak</strong> - Stream through your server without storage. Provides temporary URLs (24h) with lower storage usage.</li>
                  <li><strong>Direct</strong> - Return original provider URLs. Fastest response but exposes provider URLs.</li>
                </ul>
              </div>
              
              <Select
                label="Image URL Mode"
                value={mediaSettings.image}
                onChange={(e) => updateMediaSetting('image', e.target.value)}
                options={[
                  { value: 'proxy', label: 'Proxy (Download to CDN)' },
                  { value: 'cloak', label: 'Cloak (Streaming Proxy)' },
                  { value: 'direct', label: 'Direct (Provider URL)' }
                ]}
              />
              
              <Select
                label="Video URL Mode"
                value={mediaSettings.video}
                onChange={(e) => updateMediaSetting('video', e.target.value)}
                options={[
                  { value: 'proxy', label: 'Proxy (Download to CDN)' },
                  { value: 'cloak', label: 'Cloak (Streaming Proxy)' },
                  { value: 'direct', label: 'Direct (Provider URL)' }
                ]}
              />
              
              <Select
                label="Audio URL Mode"
                value={mediaSettings.audio}
                onChange={(e) => updateMediaSetting('audio', e.target.value)}
                options={[
                  { value: 'proxy', label: 'Proxy (Download to CDN)' },
                  { value: 'cloak', label: 'Cloak (Streaming Proxy)' },
                  { value: 'direct', label: 'Direct (Provider URL)' }
                ]}
              />
              
              <div className={styles.warningBox}>
                <span className={styles.warningIcon}>💡</span>
                <div>
                  <strong>Note:</strong> These are default settings. Individual models can override these settings in their model configuration.
                </div>
              </div>
              
              <div className={styles.multiplierActions}>
                <Button 
                  onClick={handleSaveMediaSettings} 
                  isLoading={isSavingMedia}
                >
                  Save Media Settings
                </Button>
              </div>
            </div>
          )}
        </Card>
      )}

      {/* Payment Settings */}
      {activeTab === 'payment' && (
        <Card className={styles.settingsCard}>
          <h2 className={styles.sectionTitle}>Payment Providers</h2>
          
          {/* Stripe */}
          <div className={styles.providerSection}>
            <div className={styles.providerHeader}>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  checked={settings.payment.stripeEnabled}
                  onChange={(e) => updateSetting('payment', 'stripeEnabled', e.target.checked)}
                />
                <span>Stripe</span>
              </label>
            </div>
            {settings.payment.stripeEnabled && (
              <div className={styles.providerForm}>
                <Input
                  label="Public Key"
                  value={settings.payment.stripePublicKey}
                  onChange={(e) => updateSetting('payment', 'stripePublicKey', e.target.value)}
                  placeholder="pk_..."
                />
                <Input
                  label="Secret Key"
                  type="password"
                  value={settings.payment.stripeSecretKey}
                  onChange={(e) => updateSetting('payment', 'stripeSecretKey', e.target.value)}
                  placeholder="sk_..."
                />
              </div>
            )}
          </div>

          {/* Cryptomus */}
          <div className={styles.providerSection}>
            <div className={styles.providerHeader}>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  checked={settings.payment.cryptomusEnabled}
                  onChange={(e) => updateSetting('payment', 'cryptomusEnabled', e.target.checked)}
                />
                <span>Cryptomus</span>
              </label>
            </div>
            {settings.payment.cryptomusEnabled && (
              <div className={styles.providerForm}>
                <Input
                  label="Merchant ID"
                  value={settings.payment.cryptomusMerchantId}
                  onChange={(e) => updateSetting('payment', 'cryptomusMerchantId', e.target.value)}
                />
                <Input
                  label="API Key"
                  type="password"
                  value={settings.payment.cryptomusApiKey}
                  onChange={(e) => updateSetting('payment', 'cryptomusApiKey', e.target.value)}
                />
              </div>
            )}
          </div>

          {/* NowPayments */}
          <div className={styles.providerSection}>
            <div className={styles.providerHeader}>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  checked={settings.payment.nowpaymentsEnabled}
                  onChange={(e) => updateSetting('payment', 'nowpaymentsEnabled', e.target.checked)}
                />
                <span>NowPayments</span>
              </label>
            </div>
            {settings.payment.nowpaymentsEnabled && (
              <div className={styles.providerForm}>
                <Input
                  label="API Key"
                  type="password"
                  value={settings.payment.nowpaymentsApiKey}
                  onChange={(e) => updateSetting('payment', 'nowpaymentsApiKey', e.target.value)}
                />
              </div>
            )}
          </div>
        </Card>
      )}

      {/* Email Settings */}
      {activeTab === 'email' && (
        <Card className={styles.settingsCard}>
          <h2 className={styles.sectionTitle}>Email Configuration</h2>
          <div className={styles.settingsForm}>
            <Select
              label="Email Provider"
              value={settings.email.provider}
              onChange={(e) => updateSetting('email', 'provider', e.target.value)}
              options={[
                { value: 'smtp', label: 'SMTP' },
                { value: 'sendgrid', label: 'SendGrid' },
                { value: 'mailgun', label: 'Mailgun' }
              ]}
            />
            <div className={styles.formRow}>
              <Input
                label="SMTP Host"
                value={settings.email.smtpHost}
                onChange={(e) => updateSetting('email', 'smtpHost', e.target.value)}
                placeholder="smtp.example.com"
              />
              <Input
                label="SMTP Port"
                value={settings.email.smtpPort}
                onChange={(e) => updateSetting('email', 'smtpPort', e.target.value)}
                placeholder="587"
              />
            </div>
            <div className={styles.formRow}>
              <Input
                label="SMTP Username"
                value={settings.email.smtpUser}
                onChange={(e) => updateSetting('email', 'smtpUser', e.target.value)}
              />
              <Input
                label="SMTP Password"
                type="password"
                value={settings.email.smtpPassword}
                onChange={(e) => updateSetting('email', 'smtpPassword', e.target.value)}
              />
            </div>
            <div className={styles.formRow}>
              <Input
                label="From Email"
                type="email"
                value={settings.email.fromEmail}
                onChange={(e) => updateSetting('email', 'fromEmail', e.target.value)}
                placeholder="noreply@oxyy.ai"
              />
              <Input
                label="From Name"
                value={settings.email.fromName}
                onChange={(e) => updateSetting('email', 'fromName', e.target.value)}
                placeholder="Oxyy.ai"
              />
            </div>
          </div>
        </Card>
      )}

      {/* Security Settings */}
      {activeTab === 'security' && (
        <Card className={styles.settingsCard}>
          <h2 className={styles.sectionTitle}>Security Settings</h2>
          <div className={styles.settingsForm}>
            <div className={styles.formRow}>
              <Input
                label="Max Login Attempts"
                type="number"
                value={settings.security.maxLoginAttempts}
                onChange={(e) => updateSetting('security', 'maxLoginAttempts', e.target.value)}
                placeholder="5"
              />
              <Input
                label="Lockout Duration (minutes)"
                type="number"
                value={settings.security.lockoutDuration}
                onChange={(e) => updateSetting('security', 'lockoutDuration', e.target.value)}
                placeholder="15"
              />
            </div>
            <Input
              label="Session Timeout (minutes)"
              type="number"
              value={settings.security.sessionTimeout}
              onChange={(e) => updateSetting('security', 'sessionTimeout', e.target.value)}
              placeholder="60"
            />
            <div className={styles.checkboxGroup}>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  checked={settings.security.requireEmailVerification}
                  onChange={(e) => updateSetting('security', 'requireEmailVerification', e.target.checked)}
                />
                <span>Require Email Verification</span>
              </label>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  checked={settings.security.allowRegistration}
                  onChange={(e) => updateSetting('security', 'allowRegistration', e.target.checked)}
                />
                <span>Allow New Registrations</span>
              </label>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
