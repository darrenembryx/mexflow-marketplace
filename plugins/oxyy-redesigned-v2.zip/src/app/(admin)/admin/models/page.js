'use client';

import { useState, useEffect, useCallback } from 'react';
import { adminApi } from '@/lib/api';
import { formatDate, formatCurrency } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Input from '@/components/common/Input';
import Select from '@/components/common/Select';
import Badge from '@/components/common/Badge';
import Table from '@/components/common/Table';
import Pagination from '@/components/common/Pagination';
import Modal from '@/components/common/Modal';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { useToast } from '@/context/ToastContext';
import styles from './page.module.css';

const MODEL_TYPES = [
  { value: 'TEXT', label: 'Text/Chat' },
  { value: 'IMAGE_GENERATION', label: 'Image Generation' },
  { value: 'AUDIO_TTS', label: 'Text-to-Speech' },
  { value: 'AUDIO_STT', label: 'Speech-to-Text' },
  { value: 'EMBEDDING', label: 'Embeddings' },
  { value: 'TEXT_TO_VIDEO', label: 'Text to Video' },
  { value: 'IMAGE_TO_VIDEO', label: 'Image to Video' }
];

const MODEL_TIERS = [
  { value: 'FREE', label: 'Free' },
  { value: 'FAST', label: 'Fast' },
  { value: 'SMART', label: 'Smart' },
  { value: 'PREMIUM', label: 'Premium' }
];

const PRICING_MODES = [
  { value: 'PER_TOKEN_IO', label: 'Per Token (Input/Output)' },
  { value: 'PER_TOKEN_SINGLE', label: 'Per Token (Single Rate)' },
  { value: 'PER_IMAGE_FLAT', label: 'Per Image (Flat)' },
  { value: 'PER_IMAGE_RESOLUTION', label: 'Per Image (Resolution)' },
  { value: 'PER_INPUT_CHARACTER', label: 'Per Character' },
  { value: 'PER_OUTPUT_DURATION', label: 'Per Duration' }
];

const URL_MODE_OPTIONS = [
  { value: '', label: 'Use Default' },
  { value: 'proxy', label: 'Proxy (Download to CDN)' },
  { value: 'cloak', label: 'Cloak (Streaming Proxy)' },
  { value: 'direct', label: 'Direct (Provider URL)' }
];

export default function ModelsPage() {
  const { showToast } = useToast();
  const [models, setModels] = useState([]);
  const [plugins, setPlugins] = useState([]);
  const [tokenCounters, setTokenCounters] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 50, total: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({ type: '', status: '', tier: '', provider: '' });
  const [selectedModel, setSelectedModel] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    modelId: '',
    displayName: '',
    provider: '',
    pluginId: '',
    type: 'TEXT',
    tier: 'SMART',
    description: '',
    pricingMode: 'PER_TOKEN_IO',
    inputCostPer1M: '',
    outputCostPer1M: '',
    costPer1kChars: '',
    contextWindow: '',
    maxTokens: '',
    tokenCounterId: '',
    urlMode: '',  // URL mode for media (image/video/audio) - empty means use default
    isActive: true
  });

  const loadModels = useCallback(async () => {
    setIsLoading(true);
    try {
      const queryParams = new URLSearchParams();
      queryParams.set('page', pagination.page);
      queryParams.set('limit', pagination.limit);
      if (searchQuery) queryParams.set('search', searchQuery);
      if (filters.type) queryParams.set('type', filters.type);
      if (filters.status) queryParams.set('status', filters.status);
      if (filters.tier) queryParams.set('tier', filters.tier);
      if (filters.provider) queryParams.set('provider', filters.provider);

      const [modelsRes, pluginsRes, countersRes] = await Promise.all([
        adminApi.getModels(queryParams.toString()),
        adminApi.getPlugins().catch(() => ({ data: [] })),
        adminApi.getTokenCounters().catch(() => ({ data: { counters: [] } }))
      ]);
      // Handle both array and object response
      const modelsData = modelsRes.data;
      if (Array.isArray(modelsData)) {
        setModels(modelsData);
        setPagination(prev => ({ ...prev, total: modelsData.length }));
      } else {
        setModels(modelsData.models || []);
        setPagination(prev => ({ 
          ...prev, 
          total: modelsData.total || modelsData.pagination?.total || modelsData.models?.length || 0 
        }));
      }
      setPlugins(pluginsRes.data || []);
      setTokenCounters(countersRes.data?.counters || []);
    } catch (error) {
      showToast('Failed to load models', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [showToast, pagination.page, pagination.limit, searchQuery, filters]);

  useEffect(() => {
    loadModels();
  }, [loadModels]);

  const handleSearch = (e) => {
    e.preventDefault();
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleAddModel = () => {
    setSelectedModel(null);
    setFormData({
      modelId: '',
      displayName: '',
      provider: '',
      pluginId: plugins[0]?.pluginId || '',
      type: 'TEXT',
      tier: 'SMART',
      description: '',
      tokenCounterId: '',
      pricingMode: 'PER_TOKEN_IO',
      inputCostPer1M: '',
      outputCostPer1M: '',
      costPer1kChars: '',
      contextWindow: '',
      maxTokens: '',
      isActive: true
    });
    setShowModal(true);
  };

  const handleEditModel = (model) => {
    setSelectedModel(model);
    setFormData({
      modelId: model.modelId,
      displayName: model.displayName || model.name,
      provider: model.provider || '',
      pluginId: model.pluginId || '',
      type: model.type,
      tier: model.tier || 'SMART',
      description: model.description || '',
      tokenCounterId: model.tokenCounterId || '',
      pricingMode: model.pricingMode,
      inputCostPer1M: model.inputCostPer1M?.toString() || '',
      outputCostPer1M: model.outputCostPer1M?.toString() || '',
      costPer1kChars: model.costPer1kChars?.toString() || '',
      contextWindow: model.contextWindow?.toString() || '',
      maxTokens: model.maxTokens?.toString() || '',
      urlMode: model.modelSettings?.urlMode || '',  // Load URL mode from modelSettings
      isActive: model.isActive ?? model.isEnabled ?? true
    });
    setShowModal(true);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      // Build modelSettings with urlMode if set
      const modelSettings = selectedModel?.modelSettings || {};
      if (formData.urlMode) {
        modelSettings.urlMode = formData.urlMode;
      } else {
        delete modelSettings.urlMode;  // Remove if set to default
      }
      
      const payload = {
        modelId: formData.modelId,
        displayName: formData.displayName,
        provider: formData.provider,
        pluginId: formData.pluginId,
        type: formData.type,
        tier: formData.tier,
        description: formData.description || null,
        tokenCounterId: formData.tokenCounterId || null,
        pricingMode: formData.pricingMode,
        inputCostPer1M: formData.inputCostPer1M ? parseFloat(formData.inputCostPer1M) : null,
        outputCostPer1M: formData.outputCostPer1M ? parseFloat(formData.outputCostPer1M) : null,
        costPer1kChars: formData.costPer1kChars ? parseFloat(formData.costPer1kChars) : null,
        contextWindow: formData.contextWindow ? parseInt(formData.contextWindow) : null,
        maxTokens: formData.maxTokens ? parseInt(formData.maxTokens) : null,
        modelSettings: Object.keys(modelSettings).length > 0 ? modelSettings : null,
        isActive: formData.isActive
      };

      if (selectedModel) {
        await adminApi.updateModel(selectedModel.modelId, payload);
        showToast('Model updated successfully', 'success');
      } else {
        await adminApi.createModel(payload);
        showToast('Model created successfully', 'success');
      }
      setShowModal(false);
      loadModels();
    } catch (error) {
      showToast(error.message || 'Failed to save model', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleActive = async (model) => {
    try {
      await adminApi.updateModel(model.modelId, { isEnabled: !model.isEnabled });
      showToast(`Model ${model.isEnabled ? 'disabled' : 'enabled'} successfully`, 'success');
      loadModels();
    } catch (error) {
      showToast(error.message || 'Failed to update model', 'error');
    }
  };

  const handleDeleteModel = async (model) => {
    if (!confirm(`Are you sure you want to delete ${model.displayName}?`)) return;
    try {
      await adminApi.deleteModel(model.modelId);
      showToast('Model deleted successfully', 'success');
      loadModels();
    } catch (error) {
      showToast(error.message || 'Failed to delete model', 'error');
    }
  };

  const columns = [
    {
      key: 'model',
      label: 'Model',
      render: (_, model) => (
        <div className={styles.modelCell}>
          <div className={styles.modelInfo}>
            <span className={styles.modelName}>{model.displayName}</span>
            <span className={styles.modelId}>{model.modelId}</span>
          </div>
        </div>
      )
    },
    {
      key: 'provider',
      label: 'Provider',
      render: (provider) => provider || '-'
    },
    {
      key: 'type',
      label: 'Type',
      render: (type) => (
        <Badge variant="default">
          {MODEL_TYPES.find(t => t.value === type)?.label || type}
        </Badge>
      )
    },
    {
      key: 'tier',
      label: 'Tier',
      render: (tier) => (
        <Badge variant={tier === 'PREMIUM' ? 'success' : tier === 'SMART' ? 'info' : tier === 'FAST' ? 'warning' : 'default'}>
          {MODEL_TIERS.find(t => t.value === tier)?.label || tier}
        </Badge>
      )
    },
    {
      key: 'pricing',
      label: 'Pricing (Provider / Credits)',
      render: (_, model) => {
        // Calculate credit cost using profit multiplier (default 1.2)
        const profitMultiplier = parseFloat(model.profitMultiplier) || 1.2;
        const creditMultiplier = 1000; // $1 = 1000 credits
        
        const formatCosts = (providerCost, unit) => {
          const cost = parseFloat(providerCost) || 0;
          const creditCost = (cost * profitMultiplier * creditMultiplier).toFixed(2);
          return (
            <div className={styles.costRow}>
              <span className={styles.providerCost}>${cost.toFixed(4)}</span>
              <span className={styles.creditCost}>{creditCost} cr</span>
              <span className={styles.costUnit}>/{unit}</span>
            </div>
          );
        };
        
        return (
          <div className={styles.pricingCell}>
            {(model.pricingMode === 'PER_TOKEN_IO' || model.pricingMode === 'PER_TOKEN_SINGLE') && (
              <>
                <div className={styles.costLine}>
                  <span className={styles.costLabel}>In:</span>
                  {formatCosts(model.inputCostPer1M || 0, '1M')}
                </div>
                <div className={styles.costLine}>
                  <span className={styles.costLabel}>Out:</span>
                  {formatCosts(model.outputCostPer1M || 0, '1M')}
                </div>
              </>
            )}
            {model.pricingMode === 'PER_INPUT_CHARACTER' && (
              <div className={styles.costLine}>
                {formatCosts(model.costPer1kChars || 0, '1K chars')}
              </div>
            )}
            {model.pricingMode === 'PER_IMAGE_RESOLUTION' && (
              <div className={styles.costLine}>
                {formatCosts(model.costPerImage || 0.035, 'image')}
              </div>
            )}
            {model.pricingMode === 'PER_SECOND_RESOLUTION' && (
              <div className={styles.costLine}>
                {formatCosts(model.costPerSecond || 0.10, 'sec')}
              </div>
            )}
            {!['PER_TOKEN_IO', 'PER_TOKEN_SINGLE', 'PER_INPUT_CHARACTER', 'PER_IMAGE_RESOLUTION', 'PER_SECOND_RESOLUTION'].includes(model.pricingMode) && (
              <span>{model.pricingMode?.replace(/_/g, ' ').toLowerCase()}</span>
            )}
          </div>
        );
      }
    },
    {
      key: 'tokenCounterId',
      label: 'Token Counter',
      render: (tokenCounterId, model) => (
        <span className={styles.tokenCounter}>
          {(model.type === 'TEXT' || model.type === 'EMBEDDING') 
            ? (tokenCounterId || 'Default')
            : '-'}
        </span>
      )
    },
    {
      key: 'isEnabled',
      label: 'Status',
      render: (isEnabled) => (
        <Badge variant={isEnabled ? 'success' : 'warning'}>
          {isEnabled ? 'Active' : 'Inactive'}
        </Badge>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, model) => (
        <div className={styles.actions}>
          <Button variant="ghost" size="small" onClick={() => handleEditModel(model)}>
            Edit
          </Button>
          <Button variant="ghost" size="small" onClick={() => handleToggleActive(model)}>
            {model.isEnabled ? 'Disable' : 'Enable'}
          </Button>
          <Button variant="ghost" size="small" onClick={() => handleDeleteModel(model)}>
            Delete
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>AI Models</h1>
          <p className={styles.subtitle}>Manage available AI models and pricing (models are loaded from plugins automatically)</p>
        </div>
      </div>

      <Card className={styles.filtersCard}>
        <form onSubmit={handleSearch} className={styles.searchForm}>
          <Input
            placeholder="Search models..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={styles.searchInput}
          />
          <Button type="submit">Search</Button>
        </form>
        <div className={styles.filters}>
          <Select
            value={filters.type}
            onChange={(e) => handleFilterChange('type', e.target.value)}
            options={[{ value: '', label: 'All Types' }, ...MODEL_TYPES]}
          />
          <Select
            value={filters.tier}
            onChange={(e) => handleFilterChange('tier', e.target.value)}
            options={[{ value: '', label: 'All Tiers' }, ...MODEL_TIERS]}
          />
          <Select
            value={filters.status}
            onChange={(e) => handleFilterChange('status', e.target.value)}
            options={[
              { value: '', label: 'All Status' },
              { value: 'active', label: 'Active' },
              { value: 'inactive', label: 'Inactive' }
            ]}
          />
          {filters.type || filters.tier || filters.status ? (
            <Button 
              variant="ghost" 
              size="small" 
              onClick={() => setFilters({ type: '', status: '', tier: '', provider: '' })}
            >
              Clear Filters
            </Button>
          ) : null}
        </div>
        <div className={styles.paginationInfo}>
          Showing {models.length} of {pagination.total} models (Page {pagination.page} of {Math.ceil(pagination.total / pagination.limit) || 1})
        </div>
      </Card>

      <Card className={styles.tableCard}>
        {isLoading ? (
          <div className={styles.loading}>
            <LoadingSpinner />
          </div>
        ) : (
          <>
            <Table columns={columns} data={models} emptyMessage="No models found" />
            {pagination.total > pagination.limit && (
              <Pagination
                currentPage={pagination.page}
                totalPages={Math.ceil(pagination.total / pagination.limit)}
                onPageChange={(page) => setPagination(prev => ({ ...prev, page }))}
              />
            )}
          </>
        )}
      </Card>

      {/* Add/Edit Model Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={selectedModel ? 'Edit Model' : 'Add Model'}
        size="large"
      >
        <div className={styles.modalForm}>
          <div className={styles.formRow}>
            <Input
              label="Model ID"
              value={formData.modelId}
              onChange={(e) => setFormData(prev => ({ ...prev, modelId: e.target.value }))}
              placeholder="e.g., gpt-4-turbo"
              required
            />
            <Input
              label="Display Name"
              value={formData.displayName}
              onChange={(e) => setFormData(prev => ({ ...prev, displayName: e.target.value }))}
              placeholder="e.g., GPT-4 Turbo"
              required
            />
          </div>
          <div className={styles.formRow}>
            <Input
              label="Provider"
              value={formData.provider}
              onChange={(e) => setFormData(prev => ({ ...prev, provider: e.target.value }))}
              placeholder="e.g., OpenAI"
            />
            <Select
              label="Plugin"
              value={formData.pluginId}
              onChange={(e) => setFormData(prev => ({ ...prev, pluginId: e.target.value }))}
              options={[
                { value: '', label: 'Select Plugin' },
                ...plugins.map(p => ({ value: p.id, label: p.name }))
              ]}
            />
          </div>
          <div className={styles.formRow}>
            <Select
              label="Type"
              value={formData.type}
              onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value }))}
              options={MODEL_TYPES}
            />
            <Select
              label="Tier"
              value={formData.tier}
              onChange={(e) => setFormData(prev => ({ ...prev, tier: e.target.value }))}
              options={MODEL_TIERS}
            />
          </div>
          <Input
            label="Description"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Brief description of the model"
          />
          {/* Token Counter only for text-based models */}
          {(formData.type === 'TEXT' || formData.type === 'EMBEDDING') && (
            <Select
              label="Token Counter"
              value={formData.tokenCounterId}
              onChange={(e) => setFormData(prev => ({ ...prev, tokenCounterId: e.target.value }))}
              options={[
                { value: '', label: 'Default (Simple Counter)' },
                ...tokenCounters.map(c => ({ value: c.counterId, label: `${c.name} (${c.counterId})` }))
              ]}
            />
          )}
          <div className={styles.formRow}>
            <Select
              label="Pricing Mode"
              value={formData.pricingMode}
              onChange={(e) => setFormData(prev => ({ ...prev, pricingMode: e.target.value }))}
              options={PRICING_MODES}
            />
          </div>
          {(formData.pricingMode === 'PER_TOKEN_IO' || formData.pricingMode === 'PER_TOKEN_SINGLE') && (
            <div className={styles.formRow}>
              <Input
                label="Input Cost (per 1M tokens)"
                type="number"
                step="0.01"
                value={formData.inputCostPer1M}
                onChange={(e) => setFormData(prev => ({ ...prev, inputCostPer1M: e.target.value }))}
              />
              <Input
                label="Output Cost (per 1M tokens)"
                type="number"
                step="0.01"
                value={formData.outputCostPer1M}
                onChange={(e) => setFormData(prev => ({ ...prev, outputCostPer1M: e.target.value }))}
              />
            </div>
          )}
          {formData.pricingMode === 'PER_INPUT_CHARACTER' && (
            <Input
              label="Cost per 1K Characters"
              type="number"
              step="0.01"
              value={formData.costPer1kChars}
              onChange={(e) => setFormData(prev => ({ ...prev, costPer1kChars: e.target.value }))}
            />
          )}
          <div className={styles.formRow}>
            <Input
              label="Context Window"
              type="number"
              value={formData.contextWindow}
              onChange={(e) => setFormData(prev => ({ ...prev, contextWindow: e.target.value }))}
              placeholder="e.g., 128000"
            />
            <Input
              label="Max Tokens"
              type="number"
              value={formData.maxTokens}
              onChange={(e) => setFormData(prev => ({ ...prev, maxTokens: e.target.value }))}
              placeholder="e.g., 4096"
            />
          </div>
          {/* URL Mode - only for media model types */}
          {['IMAGE_GENERATION', 'TEXT_TO_VIDEO', 'IMAGE_TO_VIDEO', 'VIDEO_TO_VIDEO', 'AUDIO_TTS'].includes(formData.type) && (
            <Select
              label="Media URL Mode"
              value={formData.urlMode}
              onChange={(e) => setFormData(prev => ({ ...prev, urlMode: e.target.value }))}
              options={URL_MODE_OPTIONS}
            />
          )}
          <div className={styles.checkboxes}>
            <label className={styles.checkbox}>
              <input
                type="checkbox"
                checked={formData.isActive}
                onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
              />
              <span>Active</span>
            </label>
          </div>
          <div className={styles.modalActions}>
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} isLoading={isSubmitting}>
              {selectedModel ? 'Save Changes' : 'Create Model'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
