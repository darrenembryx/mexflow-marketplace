'use client';

import { useState, useEffect, useCallback } from 'react';
import { adminApi } from '@/lib/api';
import { formatDate, formatNumber, formatCredits } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Input from '@/components/common/Input';
import Select from '@/components/common/Select';
import Badge from '@/components/common/Badge';
import Table from '@/components/common/Table';
import Pagination from '@/components/common/Pagination';
import Modal from '@/components/common/Modal';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { useToast } from '@/context/ToastContext';
import styles from './page.module.css';

export default function UsersPage() {
  const { showToast } = useToast();
  const [users, setUsers] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 20, total: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({ status: '', role: '' });
  const [selectedUser, setSelectedUser] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showCreditsModal, setShowCreditsModal] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [creditAmount, setCreditAmount] = useState('');
  const [creditAction, setCreditAction] = useState('add');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadUsers = useCallback(async () => {
    setIsLoading(true);
    try {
      const params = {
        page: pagination.page,
        limit: pagination.limit,
        ...(searchQuery && { search: searchQuery }),
        ...(filters.status && { status: filters.status }),
        ...(filters.role && { role: filters.role })
      };
      const response = await adminApi.getUsers(params);
      setUsers(response.data.users || []);
      setPagination(prev => ({ ...prev, total: response.data.total || 0 }));
    } catch (error) {
      showToast('Failed to load users', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [pagination.page, pagination.limit, searchQuery, filters, showToast]);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  const handleSearch = (e) => {
    e.preventDefault();
    setPagination(prev => ({ ...prev, page: 1 }));
    loadUsers();
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleEditUser = (user) => {
    setSelectedUser(user);
    setEditForm({
      name: user.name || '',
      email: user.email,
      status: user.status,
      role: user.role
    });
    setShowEditModal(true);
  };

  const handleSaveUser = async () => {
    if (!selectedUser) return;
    setIsSubmitting(true);
    try {
      await adminApi.updateUser(selectedUser.id, editForm);
      showToast('User updated successfully', 'success');
      setShowEditModal(false);
      loadUsers();
    } catch (error) {
      showToast(error.message || 'Failed to update user', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCreditsModal = (user) => {
    setSelectedUser(user);
    setCreditAmount('');
    setCreditAction('add');
    setShowCreditsModal(true);
  };

  const handleUpdateCredits = async () => {
    if (!selectedUser || !creditAmount) return;
    setIsSubmitting(true);
    try {
      const amount = parseFloat(creditAmount);
      await adminApi.updateUserCredits(selectedUser.id, {
        amount: creditAction === 'add' ? amount : -amount,
        reason: `Admin ${creditAction === 'add' ? 'added' : 'removed'} credits`
      });
      showToast('Credits updated successfully', 'success');
      setShowCreditsModal(false);
      loadUsers();
    } catch (error) {
      showToast(error.message || 'Failed to update credits', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteUser = async (user) => {
    if (!confirm(`Are you sure you want to delete ${user.email}? This action cannot be undone.`)) {
      return;
    }
    try {
      await adminApi.deleteUser(user.id);
      showToast('User deleted successfully', 'success');
      loadUsers();
    } catch (error) {
      showToast(error.message || 'Failed to delete user', 'error');
    }
  };

  const columns = [
    {
      key: 'user',
      label: 'User',
      render: (_, user) => (
        <div className={styles.userCell}>
          <div className={styles.userAvatar}>
            {user.name?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase()}
          </div>
          <div className={styles.userInfo}>
            <span className={styles.userName}>{user.name || 'No name'}</span>
            <span className={styles.userEmail}>{user.email}</span>
          </div>
        </div>
      )
    },
    {
      key: 'status',
      label: 'Status',
      render: (status) => (
        <Badge variant={status === 'active' ? 'success' : status === 'suspended' ? 'danger' : 'warning'}>
          {status}
        </Badge>
      )
    },
    {
      key: 'role',
      label: 'Role',
      render: (role) => (
        <Badge variant={role === 'admin' ? 'primary' : 'default'}>
          {role}
        </Badge>
      )
    },
    {
      key: 'creditBalance',
      label: 'Credits',
      render: (balance) => formatCredits(balance || 0)
    },
    {
      key: 'createdAt',
      label: 'Joined',
      render: (date) => formatDate(date)
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, user) => (
        <div className={styles.actions}>
          <Button variant="ghost" size="small" onClick={() => handleEditUser(user)}>
            Edit
          </Button>
          <Button variant="ghost" size="small" onClick={() => handleCreditsModal(user)}>
            Credits
          </Button>
          <Button variant="ghost" size="small" onClick={() => handleDeleteUser(user)}>
            Delete
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Users</h1>
          <p className={styles.subtitle}>Manage platform users</p>
        </div>
        <div className={styles.stats}>
          <div className={styles.stat}>
            <span className={styles.statValue}>{formatNumber(pagination.total)}</span>
            <span className={styles.statLabel}>Total Users</span>
          </div>
        </div>
      </div>

      <Card className={styles.filtersCard}>
        <form onSubmit={handleSearch} className={styles.searchForm}>
          <Input
            placeholder="Search by name or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={styles.searchInput}
          />
          <Button type="submit">Search</Button>
        </form>
        <div className={styles.filters}>
          <Select
            value={filters.status}
            onChange={(e) => handleFilterChange('status', e.target.value)}
            options={[
              { value: '', label: 'All Status' },
              { value: 'active', label: 'Active' },
              { value: 'inactive', label: 'Inactive' },
              { value: 'suspended', label: 'Suspended' }
            ]}
          />
          <Select
            value={filters.role}
            onChange={(e) => handleFilterChange('role', e.target.value)}
            options={[
              { value: '', label: 'All Roles' },
              { value: 'user', label: 'User' },
              { value: 'admin', label: 'Admin' }
            ]}
          />
        </div>
      </Card>

      <Card className={styles.tableCard}>
        {isLoading ? (
          <div className={styles.loading}>
            <LoadingSpinner />
          </div>
        ) : (
          <>
            <Table columns={columns} data={users} emptyMessage="No users found" />
            {pagination.total > pagination.limit && (
              <Pagination
                currentPage={pagination.page}
                totalPages={Math.ceil(pagination.total / pagination.limit)}
                onPageChange={(page) => setPagination(prev => ({ ...prev, page }))}
              />
            )}
          </>
        )}
      </Card>

      {/* Edit User Modal */}
      <Modal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        title="Edit User"
      >
        <div className={styles.modalForm}>
          <Input
            label="Name"
            value={editForm.name}
            onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
          />
          <Input
            label="Email"
            type="email"
            value={editForm.email}
            onChange={(e) => setEditForm(prev => ({ ...prev, email: e.target.value }))}
          />
          <Select
            label="Status"
            value={editForm.status}
            onChange={(e) => setEditForm(prev => ({ ...prev, status: e.target.value }))}
            options={[
              { value: 'active', label: 'Active' },
              { value: 'inactive', label: 'Inactive' },
              { value: 'suspended', label: 'Suspended' }
            ]}
          />
          <Select
            label="Role"
            value={editForm.role}
            onChange={(e) => setEditForm(prev => ({ ...prev, role: e.target.value }))}
            options={[
              { value: 'user', label: 'User' },
              { value: 'admin', label: 'Admin' }
            ]}
          />
          <div className={styles.modalActions}>
            <Button variant="outline" onClick={() => setShowEditModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveUser} isLoading={isSubmitting}>
              Save Changes
            </Button>
          </div>
        </div>
      </Modal>

      {/* Credits Modal */}
      <Modal
        isOpen={showCreditsModal}
        onClose={() => setShowCreditsModal(false)}
        title="Update Credits"
      >
        <div className={styles.modalForm}>
          <p className={styles.modalInfo}>
            Current balance: <strong>{formatCredits(selectedUser?.creditBalance || 0)}</strong>
          </p>
          <Select
            label="Action"
            value={creditAction}
            onChange={(e) => setCreditAction(e.target.value)}
            options={[
              { value: 'add', label: 'Add Credits' },
              { value: 'remove', label: 'Remove Credits' }
            ]}
          />
          <Input
            label="Amount"
            type="number"
            step="0.01"
            min="0"
            value={creditAmount}
            onChange={(e) => setCreditAmount(e.target.value)}
            placeholder="Enter credit amount"
          />
          <div className={styles.modalActions}>
            <Button variant="outline" onClick={() => setShowCreditsModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateCredits} isLoading={isSubmitting}>
              Update Credits
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
