'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { adminApi } from '@/lib/api';
import { formatNumber, formatCurrency, formatDate } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Select from '@/components/common/Select';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { useToast } from '@/context/ToastContext';
import styles from './page.module.css';

const TIME_RANGES = [
  { value: '7d', label: 'Last 7 Days' },
  { value: '30d', label: 'Last 30 Days' },
  { value: '90d', label: 'Last 90 Days' },
  { value: '1y', label: 'Last Year' }
];

export default function AnalyticsPage() {
  const { showToast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('30d');
  const [analytics, setAnalytics] = useState(null);

  const loadAnalytics = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await adminApi.getAnalytics({ range: timeRange });
      setAnalytics(response.data);
    } catch (error) {
      showToast('Failed to load analytics', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [timeRange, showToast]);

  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  // Process daily usage for charts
  const chartData = useMemo(() => {
    if (!analytics?.dailyUsage) {
      return { requestsByDay: [], revenueByDay: [], maxRequests: 1, maxRevenue: 1 };
    }
    
    const requestsByDay = analytics.dailyUsage.map(d => Number(d.requests) || 0);
    const revenueByDay = analytics.dailyUsage.map(d => Number(d.credits) || 0);
    const maxRequests = Math.max(...requestsByDay, 1);
    const maxRevenue = Math.max(...revenueByDay, 1);
    
    return { requestsByDay, revenueByDay, maxRequests, maxRevenue };
  }, [analytics?.dailyUsage]);

  // Get day labels for the last 7 entries
  const dayLabels = useMemo(() => {
    if (!analytics?.dailyUsage || analytics.dailyUsage.length === 0) {
      return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    }
    return analytics.dailyUsage.slice(-7).map(d => {
      const date = new Date(d.date);
      return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][date.getDay()];
    });
  }, [analytics?.dailyUsage]);

  if (isLoading) {
    return (
      <div className={styles.loading}>
        <LoadingSpinner size="large" />
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Analytics</h1>
          <p className={styles.subtitle}>Platform usage and performance metrics</p>
        </div>
        <div className={styles.headerActions}>
          <Select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            options={TIME_RANGES}
          />
          <Button variant="outline" onClick={loadAnalytics}>
            Refresh
          </Button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className={styles.statsGrid}>
        <Card className={styles.statCard}>
          <div className={styles.statIcon} data-color="blue">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statLabel}>Total Requests</span>
            <span className={styles.statValue}>
              {formatNumber(analytics?.totalRequests || 0)}
            </span>
          </div>
        </Card>

        <Card className={styles.statCard}>
          <div className={styles.statIcon} data-color="green">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="12" y1="1" x2="12" y2="23" />
              <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statLabel}>Revenue</span>
            <span className={styles.statValue}>
              {formatCurrency(analytics?.totalRevenue || 0)}
            </span>
          </div>
        </Card>

        <Card className={styles.statCard}>
          <div className={styles.statIcon} data-color="purple">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statLabel}>New Users</span>
            <span className={styles.statValue}>
              {formatNumber(analytics?.newUsers || 0)}
            </span>
          </div>
        </Card>

        <Card className={styles.statCard}>
          <div className={styles.statIcon} data-color="orange">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 2L2 7l10 5 10-5-10-5z" />
              <path d="M2 17l10 5 10-5M2 12l10 5 10-5" />
            </svg>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statLabel}>Tokens Used</span>
            <span className={styles.statValue}>
              {formatNumber(analytics?.totalTokens || 0)}
            </span>
          </div>
        </Card>
      </div>

      <div className={styles.grid}>
        {/* Request Chart Placeholder */}
        <Card className={styles.chartCard}>
          <h2 className={styles.sectionTitle}>API Requests (Last 7 Days)</h2>
          <div className={styles.chartPlaceholder}>
            <div className={styles.barChart}>
              {chartData.requestsByDay.slice(-7).map((value, idx) => (
                <div key={idx} className={styles.bar}>
                  <div 
                    className={styles.barFill} 
                    style={{ height: `${Math.min(100, (value / chartData.maxRequests) * 100)}%` }}
                  />
                  <span className={styles.barLabel}>
                    {dayLabels[idx] || ''}
                  </span>
                </div>
              ))}
              {chartData.requestsByDay.length === 0 && (
                <p className={styles.emptyText}>No request data available</p>
              )}
            </div>
          </div>
        </Card>

        {/* Revenue Chart Placeholder */}
        <Card className={styles.chartCard}>
          <h2 className={styles.sectionTitle}>Credits Used (Last 7 Days)</h2>
          <div className={styles.chartPlaceholder}>
            <div className={styles.barChart}>
              {chartData.revenueByDay.slice(-7).map((value, idx) => (
                <div key={idx} className={styles.bar}>
                  <div 
                    className={styles.barFill} 
                    data-color="green"
                    style={{ height: `${Math.min(100, (value / chartData.maxRevenue) * 100)}%` }}
                  />
                  <span className={styles.barLabel}>
                    {dayLabels[idx] || ''}
                  </span>
                </div>
              ))}
              {chartData.revenueByDay.length === 0 && (
                <p className={styles.emptyText}>No revenue data available</p>
              )}
            </div>
          </div>
        </Card>
      </div>

      <div className={styles.grid}>
        {/* Top Models */}
        <Card className={styles.listCard}>
          <h2 className={styles.sectionTitle}>Top Models</h2>
          <div className={styles.list}>
            {(analytics?.topModels || []).length === 0 ? (
              <p className={styles.emptyText}>No data available</p>
            ) : (
              analytics.topModels.map((model, idx) => (
                <div key={model.modelId || idx} className={styles.listItem}>
                  <div className={styles.listRank}>{idx + 1}</div>
                  <div className={styles.listInfo}>
                    <span className={styles.listName}>{model.modelId}</span>
                    <span className={styles.listSub}>{formatNumber(model._count || 0)} requests</span>
                  </div>
                  <div className={styles.listValue}>
                    {formatNumber(model._sum?.totalTokens || 0)} tokens
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Top Users */}
        <Card className={styles.listCard}>
          <h2 className={styles.sectionTitle}>Top Users</h2>
          <div className={styles.list}>
            {(analytics?.topUsers || []).length === 0 ? (
              <p className={styles.emptyText}>No data available</p>
            ) : (
              analytics.topUsers.map((user, idx) => (
                <div key={user.id || idx} className={styles.listItem}>
                  <div className={styles.listRank}>{idx + 1}</div>
                  <div className={styles.listInfo}>
                    <span className={styles.listName}>{user.name || user.email}</span>
                    <span className={styles.listSub}>{formatNumber(user.requests)} requests</span>
                  </div>
                  <div className={styles.listValue}>
                    {formatCurrency(user.spent)}
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>

      {/* Model Usage Breakdown */}
      <Card className={styles.breakdownCard}>
        <h2 className={styles.sectionTitle}>Usage by Model Type</h2>
        <div className={styles.breakdownGrid}>
          <div className={styles.breakdownItem}>
            <div className={styles.breakdownIcon} data-type="text">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
            </div>
            <div className={styles.breakdownInfo}>
              <span className={styles.breakdownLabel}>Text/Chat</span>
              <span className={styles.breakdownValue}>
                {formatNumber(analytics?.usageByType?.text || 0)}
              </span>
            </div>
          </div>
          <div className={styles.breakdownItem}>
            <div className={styles.breakdownIcon} data-type="image">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                <circle cx="8.5" cy="8.5" r="1.5" />
                <polyline points="21 15 16 10 5 21" />
              </svg>
            </div>
            <div className={styles.breakdownInfo}>
              <span className={styles.breakdownLabel}>Images</span>
              <span className={styles.breakdownValue}>
                {formatNumber(analytics?.usageByType?.image || 0)}
              </span>
            </div>
          </div>
          <div className={styles.breakdownItem}>
            <div className={styles.breakdownIcon} data-type="audio">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
              </svg>
            </div>
            <div className={styles.breakdownInfo}>
              <span className={styles.breakdownLabel}>Audio</span>
              <span className={styles.breakdownValue}>
                {formatNumber(analytics?.usageByType?.audio || 0)}
              </span>
            </div>
          </div>
          <div className={styles.breakdownItem}>
            <div className={styles.breakdownIcon} data-type="embedding">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
              </svg>
            </div>
            <div className={styles.breakdownInfo}>
              <span className={styles.breakdownLabel}>Embeddings</span>
              <span className={styles.breakdownValue}>
                {formatNumber(analytics?.usageByType?.embedding || 0)}
              </span>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
