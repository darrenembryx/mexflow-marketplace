'use client';

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { adminApi } from '@/lib/api';
import { formatDate } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Input from '@/components/common/Input';
import Select from '@/components/common/Select';
import Badge from '@/components/common/Badge';
import Table from '@/components/common/Table';
import Modal from '@/components/common/Modal';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { useToast } from '@/context/ToastContext';
import styles from './page.module.css';
import { Plus, Trash2, Key, AlertTriangle, Clock } from 'lucide-react';

const PLUGIN_TYPES = [
  { value: '', label: 'All Types' },
  { value: 'TEXT', label: 'Text Generation' },
  { value: 'IMAGE', label: 'Image Generation' },
  { value: 'AUDIO', label: 'Audio' },
  { value: 'VIDEO', label: 'Video' },
  { value: 'EMBEDDING', label: 'Embedding' }
];

const PLUGIN_STATUS = [
  { value: '', label: 'All Status' },
  { value: 'active', label: 'Active' },
  { value: 'inactive', label: 'Inactive' }
];

export default function PluginsPage() {
  const { showToast } = useToast();
  const [plugins, setPlugins] = useState([]);
  const [availablePlugins, setAvailablePlugins] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPlugin, setSelectedPlugin] = useState(null);
  const [showInstallModal, setShowInstallModal] = useState(false);
  const [showApiKeyModal, setShowApiKeyModal] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [pluginConfig, setPluginConfig] = useState(null);
  const [configLoading, setConfigLoading] = useState(false);
  const [configFormData, setConfigFormData] = useState({});
  const [isSavingConfig, setIsSavingConfig] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [isInstalling, setIsInstalling] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [apiKeysList, setApiKeysList] = useState([{ key: '', concurrentLimit: 100 }]);
  const [existingApiKeys, setExistingApiKeys] = useState([]);
  const [pluginTokenCounter, setPluginTokenCounter] = useState('');
  const [isSavingTokenCounter, setIsSavingTokenCounter] = useState(false);
  const fileInputRef = useRef(null);
  
  // Token Counters state
  const [tokenCounters, setTokenCounters] = useState({ counters: [], available: [] });
  const [isLoadingCounters, setIsLoadingCounters] = useState(false);
  const [isInstallingCounter, setIsInstallingCounter] = useState(null);
  const [isUploadingCounter, setIsUploadingCounter] = useState(false);
  const [showCounterTestModal, setShowCounterTestModal] = useState(false);
  const [selectedCounter, setSelectedCounter] = useState(null);
  const [testText, setTestText] = useState('Hello, this is a test message to count tokens.');
  const [testResult, setTestResult] = useState(null);
  const [isTesting, setIsTesting] = useState(false);
  const counterFileInputRef = useRef(null);
  
  // Combine installed and available counters into single list
  const allTokenCounters = useMemo(() => {
    const installed = (tokenCounters.counters || []).map(c => ({ ...c, isInstalled: true }));
    const available = (tokenCounters.available || []).map(c => ({ ...c, isInstalled: false }));
    return [...installed, ...available];
  }, [tokenCounters]);
  
  // Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({ type: '', status: '' });

  const loadPlugins = useCallback(async () => {
    setIsLoading(true);
    try {
      const [installedRes, availableRes] = await Promise.all([
        adminApi.getPlugins(),
        adminApi.getAvailablePlugins().catch(() => ({ data: [] }))
      ]);
      setPlugins(installedRes.data || []);
      setAvailablePlugins(availableRes.data || []);
    } catch (error) {
      showToast('Failed to load plugins', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [showToast]);

  const loadTokenCounters = useCallback(async () => {
    setIsLoadingCounters(true);
    try {
      const response = await adminApi.getTokenCounters();
      setTokenCounters(response.data || { counters: [], available: [] });
    } catch (error) {
      console.error('Failed to load token counters:', error);
    } finally {
      setIsLoadingCounters(false);
    }
  }, []);

  useEffect(() => {
    loadPlugins();
    loadTokenCounters();
  }, [loadPlugins, loadTokenCounters]);
  
  // Token Counter functions
  const handleInstallCounter = async (counterId) => {
    setIsInstallingCounter(counterId);
    try {
      await adminApi.installTokenCounter(counterId);
      showToast('Token counter installed successfully', 'success');
      loadTokenCounters();
    } catch (error) {
      showToast(error.message || 'Failed to install token counter', 'error');
    } finally {
      setIsInstallingCounter(null);
    }
  };

  const handleUninstallCounter = async (counterId) => {
    if (!confirm('Are you sure you want to uninstall this token counter?')) return;
    
    try {
      await adminApi.uninstallTokenCounter(counterId);
      showToast('Token counter uninstalled successfully', 'success');
      loadTokenCounters();
    } catch (error) {
      showToast(error.message || 'Failed to uninstall token counter', 'error');
    }
  };

  const handleTestCounter = (counter) => {
    setSelectedCounter(counter);
    setTestResult(null);
    setTestText('Hello, this is a test message to count tokens. The quick brown fox jumps over the lazy dog.');
    setShowCounterTestModal(true);
  };

  const handleRunTest = async () => {
    if (!selectedCounter || !testText.trim()) return;
    
    setIsTesting(true);
    try {
      const response = await adminApi.testTokenCounter(selectedCounter.counterId, testText);
      setTestResult(response.data);
    } catch (error) {
      showToast(error.message || 'Failed to test token counter', 'error');
    } finally {
      setIsTesting(false);
    }
  };

  const handleCounterFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.zip')) {
      showToast('Please select a .zip file', 'error');
      return;
    }

    setIsUploadingCounter(true);
    try {
      const response = await adminApi.uploadTokenCounter(file);
      showToast(response.data?.message || 'Token counter uploaded successfully', 'success');
      loadTokenCounters();
    } catch (error) {
      showToast(error.message || 'Failed to upload token counter', 'error');
    } finally {
      setIsUploadingCounter(false);
      // Reset file input
      if (counterFileInputRef.current) {
        counterFileInputRef.current.value = '';
      }
    }
  };

  const handleTogglePlugin = async (plugin) => {
    try {
      await adminApi.updatePlugin(plugin.id, { isActive: !plugin.isActive });
      showToast(`Plugin ${plugin.isActive ? 'disabled' : 'enabled'} successfully`, 'success');
      loadPlugins();
    } catch (error) {
      showToast(error.message || 'Failed to update plugin', 'error');
    }
  };

  const [isUninstalling, setIsUninstalling] = useState(null);
  const [showUninstallConfirm, setShowUninstallConfirm] = useState(null);

  const handleUninstallPlugin = async (plugin) => {
    setIsUninstalling(plugin.id);
    try {
      await adminApi.uninstallPlugin(plugin.pluginId || plugin.id);
      showToast('Plugin uninstalled successfully', 'success');
      setShowUninstallConfirm(null);
      loadPlugins();
    } catch (error) {
      showToast(error.message || 'Failed to uninstall plugin', 'error');
    } finally {
      setIsUninstalling(null);
    }
  };

  const handleInstallPlugin = async (pluginId) => {
    setIsInstalling(true);
    try {
      await adminApi.installPlugin(pluginId);
      showToast('Plugin installed successfully', 'success');
      setShowInstallModal(false);
      loadPlugins();
    } catch (error) {
      showToast(error.message || 'Failed to install plugin', 'error');
    } finally {
      setIsInstalling(false);
    }
  };

  const handleAddApiKey = (plugin) => {
    setSelectedPlugin(plugin);
    setApiKeyInput('');
    setShowApiKeyModal(true);
  };

  const handleSaveApiKey = async () => {
    if (!selectedPlugin || !apiKeyInput) {
      showToast('Please enter an API key', 'error');
      return;
    }
    try {
      await adminApi.addPluginApiKey(selectedPlugin.pluginId, apiKeyInput);
      showToast('API key added successfully', 'success');
      setShowApiKeyModal(false);
      setApiKeyInput('');
      loadPlugins();
    } catch (error) {
      showToast(error.message || 'Failed to add API key', 'error');
    }
  };

  // Handle Configure Plugin
  const handleConfigurePlugin = async (plugin) => {
    setSelectedPlugin(plugin);
    setConfigLoading(true);
    setShowConfigModal(true);
    setConfigFormData({});
    setApiKeysList([{ key: '', concurrentLimit: 100 }]);
    setExistingApiKeys([]);
    setPluginTokenCounter('');
    
    try {
      const res = await adminApi.getPluginConfig(plugin.pluginId || plugin.id);
      setPluginConfig(res.data);
      // Initialize form data from API key fields
      const initialData = {};
      if (res.data?.apiKeyFields) {
        res.data.apiKeyFields.forEach(field => {
          initialData[field.name] = '';
        });
      }
      setConfigFormData(initialData);
      
      // Load existing API keys for this plugin
      if (res.data?.existingApiKeys) {
        setExistingApiKeys(res.data.existingApiKeys);
      }
      
      // Set current token counter if models have one
      if (res.data?.models && res.data.models.length > 0) {
        const firstModelWithCounter = res.data.models.find(m => m.tokenCounterId);
        if (firstModelWithCounter) {
          setPluginTokenCounter(firstModelWithCounter.tokenCounterId);
        }
      }
    } catch (error) {
      showToast(error.message || 'Failed to load plugin configuration', 'error');
      setShowConfigModal(false);
    } finally {
      setConfigLoading(false);
    }
  };

  const handleSavePluginConfig = async () => {
    if (!selectedPlugin || !pluginConfig) return;
    
    // Filter out empty API keys
    const validApiKeys = apiKeysList.filter(item => item.key.trim() !== '');
    
    setIsSavingConfig(true);
    try {
      await adminApi.savePluginConfig(selectedPlugin.pluginId || selectedPlugin.id, {
        apiKeys: validApiKeys,
        settings: {}
      });
      showToast('Plugin configuration saved successfully', 'success');
      setShowConfigModal(false);
      loadPlugins();
    } catch (error) {
      showToast(error.message || 'Failed to save configuration', 'error');
    } finally {
      setIsSavingConfig(false);
    }
  };

  // Handle saving token counter for all models in plugin
  const handleSavePluginTokenCounter = async () => {
    if (!selectedPlugin) return;
    
    setIsSavingTokenCounter(true);
    try {
      await adminApi.updatePluginModelsTokenCounter(
        selectedPlugin.pluginId || selectedPlugin.id, 
        pluginTokenCounter || null
      );
      showToast('Token counter updated for all models in this plugin', 'success');
    } catch (error) {
      showToast(error.message || 'Failed to update token counter', 'error');
    } finally {
      setIsSavingTokenCounter(false);
    }
  };

  // Add new API key input field
  const handleAddApiKeyField = () => {
    setApiKeysList(prev => [...prev, { key: '', concurrentLimit: 100 }]);
  };

  // Remove API key input field
  const handleRemoveApiKeyField = (index) => {
    setApiKeysList(prev => prev.filter((_, i) => i !== index));
  };

  // Update API key in the list
  const handleApiKeyChange = (index, field, value) => {
    setApiKeysList(prev => prev.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    ));
  };

  // Delete existing API key
  const handleDeleteExistingApiKey = async (keyId) => {
    try {
      await adminApi.deletePluginApiKey(selectedPlugin.pluginId || selectedPlugin.id, keyId);
      showToast('API key deleted successfully', 'success');
      setExistingApiKeys(prev => prev.filter(k => k.id !== keyId));
    } catch (error) {
      showToast(error.message || 'Failed to delete API key', 'error');
    }
  };

  const handleConfigFieldChange = (fieldName, value) => {
    setConfigFormData(prev => ({
      ...prev,
      [fieldName]: value
    }));
  };

  const handleFileUpload = async (file) => {
    if (!file) return;
    if (!file.name.endsWith('.zip')) {
      showToast('Please upload a ZIP file', 'error');
      return;
    }
    
    setIsUploading(true);
    try {
      await adminApi.uploadPlugin(file);
      showToast('Plugin uploaded successfully! You can now install it.', 'success');
      loadPlugins();
    } catch (error) {
      showToast(error.message || 'Failed to upload plugin', 'error');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    handleFileUpload(file);
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    handleFileUpload(file);
    e.target.value = ''; // Reset input
  };

  const installedColumns = [
    {
      key: 'name',
      label: 'Plugin',
      render: (name, plugin) => (
        <div className={styles.pluginCell}>
          <div className={styles.pluginIcon}>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="4" y="4" width="16" height="16" rx="2" ry="2" />
              <rect x="9" y="9" width="6" height="6" />
              <line x1="9" y1="1" x2="9" y2="4" />
              <line x1="15" y1="1" x2="15" y2="4" />
              <line x1="9" y1="20" x2="9" y2="23" />
              <line x1="15" y1="20" x2="15" y2="23" />
            </svg>
          </div>
          <div className={styles.pluginInfo}>
            <span className={styles.pluginName}>{name}</span>
            <span className={styles.pluginVersion}>v{plugin.version || '1.0.0'}</span>
          </div>
        </div>
      )
    },
    {
      key: 'description',
      label: 'Description',
      render: (desc) => desc || '-'
    },
    {
      key: 'type',
      label: 'Type',
      render: (type) => (
        <Badge variant="default">{type || 'General'}</Badge>
      )
    },
    {
      key: '_count',
      label: 'Models',
      render: (count) => count?.models || 0
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive, plugin) => (
        <div className={styles.statusCell}>
          {plugin.filesMissing ? (
            <Badge variant="danger" title={plugin.missingError}>
              <AlertTriangle size={12} style={{ marginRight: 4 }} />
              Missing
            </Badge>
          ) : (
            <Badge variant={isActive ? 'success' : 'warning'}>
              {isActive ? 'Active' : 'Inactive'}
            </Badge>
          )}
          {plugin.missingError && (
            <span className={styles.missingError}>{plugin.missingError}</span>
          )}
        </div>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, plugin) => (
        <div className={styles.actions}>
          {plugin.filesMissing ? (
            <>
              <Button 
                variant="danger" 
                size="small" 
                onClick={() => setShowUninstallConfirm(plugin)}
                disabled={isUninstalling === plugin.id}
              >
                {isUninstalling === plugin.id ? 'Removing...' : 'Remove'}
              </Button>
            </>
          ) : (
            <>
              <Button variant="primary" size="small" onClick={() => handleConfigurePlugin(plugin)}>
                Configure
              </Button>
              <Button variant="ghost" size="small" onClick={() => handleTogglePlugin(plugin)}>
                {plugin.isActive ? 'Disable' : 'Enable'}
              </Button>
              <Button 
                variant="danger" 
                size="small" 
                onClick={() => setShowUninstallConfirm(plugin)}
                title="Uninstall plugin"
              >
                <Trash2 size={14} />
              </Button>
            </>
          )}
        </div>
      )
    }
  ];

  // Filter only uninstalled plugins for the available list
  const uninstalledPlugins = availablePlugins.filter(p => !p.installed);

  // Filter installed plugins based on search and filters
  const filteredPlugins = useMemo(() => {
    return plugins.filter(plugin => {
      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesSearch = 
          plugin.name?.toLowerCase().includes(query) ||
          plugin.description?.toLowerCase().includes(query) ||
          plugin.pluginId?.toLowerCase().includes(query);
        if (!matchesSearch) return false;
      }
      
      // Type filter
      if (filters.type && plugin.type !== filters.type) {
        return false;
      }
      
      // Status filter
      if (filters.status === 'active' && !plugin.isActive) {
        return false;
      }
      if (filters.status === 'inactive' && plugin.isActive) {
        return false;
      }
      
      return true;
    });
  }, [plugins, searchQuery, filters]);

  const handleClearFilters = () => {
    setSearchQuery('');
    setFilters({ type: '', status: '' });
  };

  const hasActiveFilters = searchQuery || filters.type || filters.status;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Plugins</h1>
          <p className={styles.subtitle}>Manage AI model plugins and extensions</p>
        </div>
        <Button onClick={() => setShowInstallModal(true)}>
          Install Plugin
        </Button>
      </div>

      {/* Filters Card */}
      <Card className={styles.filtersCard}>
        <div className={styles.searchForm}>
          <Input
            placeholder="Search plugins..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={styles.searchInput}
          />
        </div>
        <div className={styles.filters}>
          <Select
            value={filters.type}
            onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
            options={PLUGIN_TYPES}
          />
          <Select
            value={filters.status}
            onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
            options={PLUGIN_STATUS}
          />
          {hasActiveFilters && (
            <Button variant="ghost" size="small" onClick={handleClearFilters}>
              Clear Filters
            </Button>
          )}
        </div>
        {hasActiveFilters && (
          <div className={styles.filterInfo}>
            Showing {filteredPlugins.length} of {plugins.length} plugins
          </div>
        )}
      </Card>

      <Card className={styles.tableCard}>
        <h2 className={styles.sectionTitle}>Installed Plugins</h2>
        {isLoading ? (
          <div className={styles.loading}>
            <LoadingSpinner />
          </div>
        ) : (
          <Table columns={installedColumns} data={filteredPlugins} emptyMessage="No plugins found" />
        )}
      </Card>

      {/* Token Counters Section */}
      <Card className={styles.tableCard}>
        <div className={styles.sectionHeader}>
          <div>
            <h2 className={styles.sectionTitle}>Token Counters</h2>
            <p className={styles.sectionDescription}>
              Token counters estimate token usage for text generation models. Used for accurate billing calculations.
            </p>
          </div>
          <div className={styles.sectionActions}>
            <input
              type="file"
              accept=".zip"
              ref={counterFileInputRef}
              onChange={handleCounterFileSelect}
              style={{ display: 'none' }}
            />
            <Button 
              variant="outline" 
              onClick={() => counterFileInputRef.current?.click()}
              disabled={isUploadingCounter}
            >
              {isUploadingCounter ? 'Uploading...' : 'Upload Custom Counter'}
            </Button>
          </div>
        </div>
        
        {isLoadingCounters ? (
          <div className={styles.loading}>
            <LoadingSpinner />
          </div>
        ) : (
          <Table
            columns={[
              {
                key: 'name',
                label: 'Counter',
                render: (name, counter) => (
                  <div className={styles.counterCell}>
                    <span className={styles.counterCellName}>{name}</span>
                    <span className={styles.counterCellId}>{counter.counterId}</span>
                  </div>
                )
              },
              {
                key: 'description',
                label: 'Description',
                render: (desc) => (
                  <span className={styles.counterCellDesc}>{desc || '-'}</span>
                )
              },
              {
                key: 'supportedPatterns',
                label: 'Supported Models',
                render: (patterns) => (
                  <div className={styles.patternTags}>
                    {patterns?.map((pattern, i) => (
                      <Badge key={i} variant="outline" size="sm">{pattern}</Badge>
                    )) || <span>-</span>}
                  </div>
                )
              },
              {
                key: 'status',
                label: 'Status',
                render: (_, counter) => (
                  <Badge variant={counter.isInstalled ? 'success' : 'default'}>
                    {counter.isInstalled ? 'Installed' : 'Available'}
                  </Badge>
                )
              },
              {
                key: 'actions',
                label: 'Actions',
                render: (_, counter) => (
                  <div className={styles.actions}>
                    {counter.isInstalled ? (
                      <>
                        <Button 
                          variant="ghost" 
                          size="small" 
                          onClick={() => handleTestCounter(counter)}
                        >
                          Test
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="small" 
                          onClick={() => handleUninstallCounter(counter.counterId)}
                        >
                          Uninstall
                        </Button>
                      </>
                    ) : (
                      <Button 
                        variant="primary" 
                        size="small" 
                        onClick={() => handleInstallCounter(counter.counterId)}
                        disabled={isInstallingCounter === counter.counterId}
                      >
                        {isInstallingCounter === counter.counterId ? 'Installing...' : 'Install'}
                      </Button>
                    )}
                  </div>
                )
              }
            ]}
            data={allTokenCounters}
            emptyMessage="No token counters found. Add token counter plugins to the token-counters/installed directory."
          />
        )}
      </Card>

      {/* Plugin Info Cards */}
      <div className={styles.pluginCards}>
        <Card className={styles.infoCard}>
          <div className={styles.infoIcon}>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="16" x2="12" y2="12" />
              <line x1="12" y1="8" x2="12.01" y2="8" />
            </svg>
          </div>
          <div className={styles.infoContent}>
            <h3>About Plugins</h3>
            <p>Plugins extend the functionality of Oxyy by adding AI model providers. Each plugin can provide multiple models. Add API keys to activate model access.</p>
          </div>
        </Card>

        <Card className={styles.infoCard}>
          <div className={styles.infoIcon}>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4" />
            </svg>
          </div>
          <div className={styles.infoContent}>
            <h3>API Keys</h3>
            <p>Each plugin requires provider API keys to function. Add your API keys using the "Add API Key" button. Keys are encrypted and stored securely.</p>
          </div>
        </Card>
      </div>

      {/* Install Plugin Modal */}
      <Modal
        isOpen={showInstallModal}
        onClose={() => setShowInstallModal(false)}
        title="Install Plugin"
        size="large"
      >
        <div className={styles.modalForm}>
          {/* File Upload Zone */}
          <div 
            className={`${styles.uploadZone} ${isDragging ? styles.uploadZoneDragging : ''} ${isUploading ? styles.uploadZoneUploading : ''}`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => !isUploading && fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".zip"
              onChange={handleFileSelect}
              style={{ display: 'none' }}
            />
            <div className={styles.uploadIcon}>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17,8 12,3 7,8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
            </div>
            {isUploading ? (
              <p>Uploading plugin...</p>
            ) : (
              <>
                <p className={styles.uploadText}>
                  <strong>Drag and drop</strong> your plugin ZIP file here, or <strong>click to browse</strong>
                </p>
                <p className={styles.uploadHint}>Only .zip files are accepted</p>
              </>
            )}
          </div>

          {/* Available Plugins List */}
          <div className={styles.divider}>
            <span>Or install from available plugins</span>
          </div>
          
          {uninstalledPlugins.length === 0 ? (
            <p className={styles.noPlugins}>All available plugins are already installed.</p>
          ) : (
            <div className={styles.pluginList}>
              {uninstalledPlugins.map(plugin => (
                <div key={plugin.pluginId} className={styles.pluginItem}>
                  <div className={styles.pluginItemInfo}>
                    <span className={styles.pluginItemName}>{plugin.name}</span>
                    <span className={styles.pluginItemDesc}>{plugin.description}</span>
                    <Badge variant="default">{plugin.type}</Badge>
                  </div>
                  <Button 
                    size="small" 
                    onClick={() => handleInstallPlugin(plugin.pluginId)}
                    disabled={isInstalling}
                  >
                    {isInstalling ? 'Installing...' : 'Install'}
                  </Button>
                </div>
              ))}
            </div>
          )}
          
          <div className={styles.modalActions}>
            <Button variant="outline" onClick={() => setShowInstallModal(false)}>
              Close
            </Button>
          </div>
        </div>
      </Modal>

      {/* Add API Key Modal */}
      <Modal
        isOpen={showApiKeyModal}
        onClose={() => setShowApiKeyModal(false)}
        title={`Add API Key for ${selectedPlugin?.name || 'Plugin'}`}
      >
        <div className={styles.modalForm}>
          <p className={styles.modalDescription}>
            Enter your API key for {selectedPlugin?.name}. This key will be encrypted and used for all models in this plugin.
          </p>
          
          <Input
            label="API Key"
            type="password"
            value={apiKeyInput}
            onChange={(e) => setApiKeyInput(e.target.value)}
            placeholder="Enter your API key"
          />
          
          <div className={styles.modalActions}>
            <Button variant="outline" onClick={() => setShowApiKeyModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveApiKey}>
              Save API Key
            </Button>
          </div>
        </div>
      </Modal>

      {/* Configure Plugin Modal */}
      <Modal
        isOpen={showConfigModal}
        onClose={() => setShowConfigModal(false)}
        title={`Configure ${selectedPlugin?.name || 'Plugin'}`}
        size="large"
      >
        <div className={styles.modalForm}>
          {configLoading ? (
            <div className={styles.configLoading}>
              <LoadingSpinner />
              <p>Loading plugin configuration...</p>
            </div>
          ) : pluginConfig ? (
            <>
              {/* Plugin Info */}
              <div className={styles.configSection}>
                <h3 className={styles.configSectionTitle}>Plugin Information</h3>
                <div className={styles.configInfo}>
                  <div className={styles.configInfoItem}>
                    <span className={styles.configInfoLabel}>Name:</span>
                    <span>{pluginConfig.plugin?.name}</span>
                  </div>
                  <div className={styles.configInfoItem}>
                    <span className={styles.configInfoLabel}>Version:</span>
                    <span>{pluginConfig.plugin?.version || '1.0.0'}</span>
                  </div>
                  <div className={styles.configInfoItem}>
                    <span className={styles.configInfoLabel}>Type:</span>
                    <Badge variant="default">{pluginConfig.plugin?.type}</Badge>
                  </div>
                  <div className={styles.configInfoItem}>
                    <span className={styles.configInfoLabel}>Status:</span>
                    <Badge variant={pluginConfig.plugin?.isActive ? 'success' : 'warning'}>
                      {pluginConfig.plugin?.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div className={styles.configInfoItem}>
                    <span className={styles.configInfoLabel}>API Keys:</span>
                    <span>{pluginConfig.apiKeyCount || 0} configured</span>
                  </div>
                </div>
              </div>

              {/* Token Counter Section - Only for TEXT type plugins */}
              {selectedPlugin?.type === 'TEXT' && (
                <div className={styles.configSection}>
                  <h3 className={styles.configSectionTitle}>Token Counter</h3>
                  <p className={styles.configDescription}>
                    Select a token counter to use for all models in this plugin. This helps calculate accurate token usage and credits.
                  </p>
                  <div className={styles.tokenCounterRow}>
                    <Select
                      label="Token Counter for All Models"
                      value={pluginTokenCounter}
                      onChange={(e) => setPluginTokenCounter(e.target.value)}
                      options={[
                        { value: '', label: 'Default (Simple Counter)' },
                        ...tokenCounters.counters.map(c => ({ 
                          value: c.counterId, 
                          label: `${c.name} (${c.counterId})` 
                        }))
                      ]}
                    />
                    <Button
                      variant="outline"
                      onClick={() => {
                        if (pluginTokenCounter) {
                          const counter = tokenCounters.counters.find(c => c.counterId === pluginTokenCounter);
                          if (counter) handleTestCounter(counter);
                        } else {
                          showToast('Select a token counter to test', 'info');
                        }
                      }}
                      className={styles.tokenCounterButton}
                    >
                      Test Counter
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={handleSavePluginTokenCounter}
                      disabled={isSavingTokenCounter}
                      className={styles.tokenCounterButton}
                    >
                      {isSavingTokenCounter ? 'Applying...' : 'Apply to All Models'}
                    </Button>
                  </div>
                </div>
              )}

              {/* API Keys Section */}
              <div className={styles.configSection}>
                <h3 className={styles.configSectionTitle}>API Keys</h3>
                <p className={styles.configDescription}>
                  Configure multiple API keys for load balancing and failover. Each key can have its own concurrent limit.
                </p>
                
                {/* Existing API Keys */}
                {existingApiKeys.length > 0 && (
                  <div className={styles.existingApiKeys}>
                    <h4 className={styles.subSectionTitle}>Current API Keys</h4>
                    {existingApiKeys.map((apiKey) => (
                      <div key={apiKey.id} className={styles.existingApiKeyItem}>
                        <div className={styles.apiKeyInfo}>
                          <Key size={14} />
                          <span className={styles.apiKeyPrefix}>{apiKey.keyPrefix}...</span>
                          <Badge variant={apiKey.isValid ? 'success' : 'error'}>
                            {apiKey.isValid ? 'Valid' : 'Invalid'}
                          </Badge>
                          <span className={styles.apiKeyConcurrent}>
                            Limit: {apiKey.concurrentLimit}
                          </span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          icon={<Trash2 size={14} />}
                          onClick={() => handleDeleteExistingApiKey(apiKey.id)}
                        />
                      </div>
                    ))}
                  </div>
                )}

                {/* Add New API Keys */}
                <div className={styles.newApiKeysSection}>
                  <h4 className={styles.subSectionTitle}>Add New API Keys</h4>
                  {apiKeysList.map((item, index) => (
                    <div key={index} className={styles.apiKeyInputRow}>
                      <div className={styles.apiKeyInputMain}>
                        <Input
                          placeholder="Enter API key..."
                          type="password"
                          value={item.key}
                          onChange={(e) => handleApiKeyChange(index, 'key', e.target.value)}
                        />
                      </div>
                      <div className={styles.apiKeyInputLimit}>
                        <Input
                          type="number"
                          placeholder="Concurrent limit"
                          value={item.concurrentLimit}
                          onChange={(e) => handleApiKeyChange(index, 'concurrentLimit', parseInt(e.target.value) || 100)}
                          min={1}
                          max={1000}
                        />
                      </div>
                      {apiKeysList.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          icon={<Trash2 size={14} />}
                          onClick={() => handleRemoveApiKeyField(index)}
                        />
                      )}
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    icon={<Plus size={14} />}
                    onClick={handleAddApiKeyField}
                    className={styles.addApiKeyButton}
                  >
                    Add Another Key
                  </Button>
                </div>
              </div>

              {/* Models Section */}
              {pluginConfig.models && pluginConfig.models.length > 0 && (
                <div className={styles.configSection}>
                  <h3 className={styles.configSectionTitle}>Available Models</h3>
                  <div className={styles.modelsList}>
                    {pluginConfig.models.map((model, index) => (
                      <div key={index} className={styles.modelItem}>
                        <div className={styles.modelItemInfo}>
                          <span className={styles.modelItemName}>{model.displayName}</span>
                          <span className={styles.modelItemId}>{model.modelId}</span>
                        </div>
                        <div className={styles.modelItemMeta}>
                          <Badge variant="outline">{model.tier}</Badge>
                          <Badge variant={model.isEnabled ? 'success' : 'default'}>
                            {model.isEnabled ? 'Enabled' : 'Disabled'}
                          </Badge>
                          {model.apiKeyCount > 0 && (
                            <Badge variant="info">{model.apiKeyCount} key(s)</Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className={styles.modalActions}>
                <Button variant="outline" onClick={() => setShowConfigModal(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleSavePluginConfig} 
                  disabled={isSavingConfig}
                >
                  {isSavingConfig ? 'Saving...' : 'Save Configuration'}
                </Button>
              </div>
            </>
          ) : (
            <p>Failed to load plugin configuration.</p>
          )}
        </div>
      </Modal>

      {/* Uninstall Confirmation Modal */}
      <Modal
        isOpen={!!showUninstallConfirm}
        onClose={() => setShowUninstallConfirm(null)}
        title="Uninstall Plugin"
      >
        <div className={styles.modalContent}>
          <div className={styles.uninstallWarning}>
            <AlertTriangle size={48} color="var(--color-danger)" />
            <h3>Are you sure you want to uninstall this plugin?</h3>
            <p>
              <strong>{showUninstallConfirm?.name}</strong> and all associated models will be removed. 
              This action cannot be undone.
            </p>
            {showUninstallConfirm?.filesMissing && (
              <p className={styles.missingNote}>
                Note: This plugin&apos;s files are missing. Removing will clean up the database records.
              </p>
            )}
          </div>
          <div className={styles.modalActions}>
            <Button variant="outline" onClick={() => setShowUninstallConfirm(null)}>
              Cancel
            </Button>
            <Button 
              variant="danger"
              onClick={() => handleUninstallPlugin(showUninstallConfirm)}
              disabled={isUninstalling === showUninstallConfirm?.id}
            >
              {isUninstalling === showUninstallConfirm?.id ? 'Uninstalling...' : 'Yes, Uninstall'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Token Counter Test Modal */}
      <Modal
        isOpen={showCounterTestModal}
        onClose={() => {
          setShowCounterTestModal(false);
          setSelectedCounter(null);
          setTestResult(null);
        }}
        title={`Test Token Counter: ${selectedCounter?.name || ''}`}
      >
        <div className={styles.modalContent}>
          <div className={styles.counterTestSection}>
            <p className={styles.counterTestDescription}>
              Enter text below to test how many tokens this counter calculates.
            </p>
            <div className={styles.formField}>
              <label>Test Text</label>
              <textarea
                className={styles.testTextarea}
                value={testText}
                onChange={(e) => setTestText(e.target.value)}
                rows={5}
                placeholder="Enter text to count tokens..."
              />
            </div>
            {testResult && (
              <div className={styles.testResultBox}>
                <div className={styles.testResultHeader}>
                  <span>Token Count Result</span>
                </div>
                <div className={styles.testResultContent}>
                  <div className={styles.testResultItem}>
                    <span className={styles.testResultLabel}>Total Tokens:</span>
                    <span className={styles.testResultValue}>{testResult.tokens}</span>
                  </div>
                  <div className={styles.testResultItem}>
                    <span className={styles.testResultLabel}>Characters:</span>
                    <span className={styles.testResultValue}>{testResult.characters}</span>
                  </div>
                  <div className={styles.testResultItem}>
                    <span className={styles.testResultLabel}>Chars per Token:</span>
                    <span className={styles.testResultValue}>
                      {testResult.tokens > 0 ? (testResult.characters / testResult.tokens).toFixed(2) : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div className={styles.modalActions}>
            <Button 
              variant="outline" 
              onClick={() => {
                setShowCounterTestModal(false);
                setSelectedCounter(null);
                setTestResult(null);
              }}
            >
              Close
            </Button>
            <Button 
              onClick={handleRunTest}
              disabled={isTesting || !testText.trim()}
            >
              {isTesting ? 'Testing...' : 'Count Tokens'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
