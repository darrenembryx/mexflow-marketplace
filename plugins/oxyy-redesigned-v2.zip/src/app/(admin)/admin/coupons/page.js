'use client';

import { useState, useEffect, useCallback } from 'react';
import { adminApi } from '@/lib/api';
import { formatDate, formatCurrency, formatNumber } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Input from '@/components/common/Input';
import Select from '@/components/common/Select';
import Badge from '@/components/common/Badge';
import Table from '@/components/common/Table';
import Pagination from '@/components/common/Pagination';
import Modal from '@/components/common/Modal';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { useToast } from '@/context/ToastContext';
import styles from './page.module.css';

const DISCOUNT_TYPES = [
  { value: 'percentage', label: 'Percentage' },
  { value: 'fixed', label: 'Fixed Amount' }
];

export default function CouponsPage() {
  const { showToast } = useToast();
  const [coupons, setCoupons] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 20, total: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCoupon, setSelectedCoupon] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    code: '',
    discountType: 'percentage',
    discountValue: '',
    maxUses: '',
    minPurchase: '',
    expiresAt: '',
    isActive: true,
    applicablePackages: []
  });

  const loadCoupons = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await adminApi.getCoupons({
        page: pagination.page,
        limit: pagination.limit
      });
      setCoupons(response.data.coupons || response.data || []);
      setPagination(prev => ({ ...prev, total: response.data.total || 0 }));
    } catch (error) {
      showToast('Failed to load coupons', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [pagination.page, pagination.limit, showToast]);

  useEffect(() => {
    loadCoupons();
  }, [loadCoupons]);

  const generateCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setFormData(prev => ({ ...prev, code }));
  };

  const handleAddCoupon = () => {
    setSelectedCoupon(null);
    setFormData({
      code: '',
      discountType: 'percentage',
      discountValue: '',
      maxUses: '',
      minPurchase: '',
      expiresAt: '',
      isActive: true,
      applicablePackages: []
    });
    setShowModal(true);
  };

  const handleEditCoupon = (coupon) => {
    setSelectedCoupon(coupon);
    setFormData({
      code: coupon.code,
      discountType: coupon.discountType,
      discountValue: coupon.discountValue?.toString() || '',
      maxUses: coupon.maxUses?.toString() || '',
      minPurchase: coupon.minPurchase?.toString() || '',
      expiresAt: coupon.expiresAt ? new Date(coupon.expiresAt).toISOString().split('T')[0] : '',
      isActive: coupon.isActive,
      applicablePackages: coupon.applicablePackages || []
    });
    setShowModal(true);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const payload = {
        ...formData,
        discountValue: parseFloat(formData.discountValue),
        maxUses: formData.maxUses ? parseInt(formData.maxUses) : null,
        minPurchase: formData.minPurchase ? parseFloat(formData.minPurchase) : null,
        expiresAt: formData.expiresAt ? new Date(formData.expiresAt).toISOString() : null
      };

      if (selectedCoupon) {
        await adminApi.updateCoupon(selectedCoupon.id, payload);
        showToast('Coupon updated successfully', 'success');
      } else {
        await adminApi.createCoupon(payload);
        showToast('Coupon created successfully', 'success');
      }
      setShowModal(false);
      loadCoupons();
    } catch (error) {
      showToast(error.message || 'Failed to save coupon', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleActive = async (coupon) => {
    try {
      await adminApi.updateCoupon(coupon.id, { isActive: !coupon.isActive });
      showToast(`Coupon ${coupon.isActive ? 'disabled' : 'enabled'} successfully`, 'success');
      loadCoupons();
    } catch (error) {
      showToast(error.message || 'Failed to update coupon', 'error');
    }
  };

  const handleDeleteCoupon = async (coupon) => {
    if (!confirm(`Are you sure you want to delete coupon "${coupon.code}"?`)) return;
    try {
      await adminApi.deleteCoupon(coupon.id);
      showToast('Coupon deleted successfully', 'success');
      loadCoupons();
    } catch (error) {
      showToast(error.message || 'Failed to delete coupon', 'error');
    }
  };

  const columns = [
    {
      key: 'code',
      label: 'Code',
      render: (code) => (
        <span className={styles.couponCode}>{code}</span>
      )
    },
    {
      key: 'discount',
      label: 'Discount',
      render: (_, coupon) => (
        <span className={styles.discount}>
          {coupon.discountType === 'percentage' 
            ? `${coupon.discountValue}%`
            : formatCurrency(coupon.discountValue)
          }
        </span>
      )
    },
    {
      key: 'usage',
      label: 'Usage',
      render: (_, coupon) => (
        <span>
          {coupon.usedCount || 0}
          {coupon.maxUses ? ` / ${coupon.maxUses}` : ''}
        </span>
      )
    },
    {
      key: 'expiresAt',
      label: 'Expires',
      render: (date) => date ? formatDate(date) : 'Never'
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive, coupon) => {
        const isExpired = coupon.expiresAt && new Date(coupon.expiresAt) < new Date();
        const isMaxed = coupon.maxUses && (coupon.usedCount || 0) >= coupon.maxUses;
        return (
          <Badge variant={
            isExpired ? 'danger' :
            isMaxed ? 'warning' :
            isActive ? 'success' : 'warning'
          }>
            {isExpired ? 'Expired' : isMaxed ? 'Maxed' : isActive ? 'Active' : 'Inactive'}
          </Badge>
        );
      }
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, coupon) => (
        <div className={styles.actions}>
          <Button variant="ghost" size="small" onClick={() => handleEditCoupon(coupon)}>
            Edit
          </Button>
          <Button variant="ghost" size="small" onClick={() => handleToggleActive(coupon)}>
            {coupon.isActive ? 'Disable' : 'Enable'}
          </Button>
          <Button variant="ghost" size="small" onClick={() => handleDeleteCoupon(coupon)}>
            Delete
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Coupons</h1>
          <p className={styles.subtitle}>Manage discount codes and promotions</p>
        </div>
        <Button onClick={handleAddCoupon}>Create Coupon</Button>
      </div>

      <Card className={styles.tableCard}>
        {isLoading ? (
          <div className={styles.loading}>
            <LoadingSpinner />
          </div>
        ) : (
          <>
            <Table columns={columns} data={coupons} emptyMessage="No coupons found" />
            {pagination.total > pagination.limit && (
              <Pagination
                currentPage={pagination.page}
                totalPages={Math.ceil(pagination.total / pagination.limit)}
                onPageChange={(page) => setPagination(prev => ({ ...prev, page }))}
              />
            )}
          </>
        )}
      </Card>

      {/* Add/Edit Coupon Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={selectedCoupon ? 'Edit Coupon' : 'Create Coupon'}
      >
        <div className={styles.modalForm}>
          <div className={styles.codeRow}>
            <Input
              label="Coupon Code"
              value={formData.code}
              onChange={(e) => setFormData(prev => ({ ...prev, code: e.target.value.toUpperCase() }))}
              placeholder="e.g., SAVE20"
              required
            />
            <Button variant="outline" onClick={generateCode}>Generate</Button>
          </div>
          <div className={styles.formRow}>
            <Select
              label="Discount Type"
              value={formData.discountType}
              onChange={(e) => setFormData(prev => ({ ...prev, discountType: e.target.value }))}
              options={DISCOUNT_TYPES}
            />
            <Input
              label={formData.discountType === 'percentage' ? 'Discount (%)' : 'Discount Amount ($)'}
              type="number"
              step="0.01"
              value={formData.discountValue}
              onChange={(e) => setFormData(prev => ({ ...prev, discountValue: e.target.value }))}
              required
            />
          </div>
          <div className={styles.formRow}>
            <Input
              label="Max Uses (optional)"
              type="number"
              value={formData.maxUses}
              onChange={(e) => setFormData(prev => ({ ...prev, maxUses: e.target.value }))}
              placeholder="Unlimited"
            />
            <Input
              label="Min Purchase ($)"
              type="number"
              step="0.01"
              value={formData.minPurchase}
              onChange={(e) => setFormData(prev => ({ ...prev, minPurchase: e.target.value }))}
              placeholder="No minimum"
            />
          </div>
          <Input
            label="Expires At"
            type="date"
            value={formData.expiresAt}
            onChange={(e) => setFormData(prev => ({ ...prev, expiresAt: e.target.value }))}
          />
          <label className={styles.checkbox}>
            <input
              type="checkbox"
              checked={formData.isActive}
              onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
            />
            <span>Active</span>
          </label>
          <div className={styles.modalActions}>
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} isLoading={isSubmitting}>
              {selectedCoupon ? 'Save Changes' : 'Create Coupon'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
