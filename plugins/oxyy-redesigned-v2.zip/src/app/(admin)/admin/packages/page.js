'use client';

import { useState, useEffect, useCallback } from 'react';
import { adminApi } from '@/lib/api';
import { formatDate, formatCurrency, formatNumber } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Input from '@/components/common/Input';
import Select from '@/components/common/Select';
import Badge from '@/components/common/Badge';
import Table from '@/components/common/Table';
import Pagination from '@/components/common/Pagination';
import Modal from '@/components/common/Modal';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { useToast } from '@/context/ToastContext';
import styles from './page.module.css';

const BILLING_CYCLES = [
  { value: 'monthly', label: 'Monthly' },
  { value: 'yearly', label: 'Yearly' },
  { value: 'lifetime', label: 'Lifetime' }
];

const CREDIT_RESET_TYPES = [
  { value: 'MONTHLY', label: 'Monthly (Every 30 days)' },
  { value: 'WEEKLY', label: 'Weekly (Every 7 days)' },
  { value: 'DAILY', label: 'Daily (Every 24 hours)' },
  { value: 'CUSTOM', label: 'Custom (Specify hours)' },
  { value: 'NEVER', label: 'Never (One-time credits)' }
];

export default function PackagesPage() {
  const { showToast } = useToast();
  const [packages, setPackages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    credits: '',
    billingCycle: 'monthly',
    creditResetType: 'MONTHLY',
    creditResetHours: '',
    rpmLimit: '60',
    concurrentLimit: '10',
    features: '',
    isActive: true,
    isFeatured: false,
    sortOrder: '0'
  });

  const loadPackages = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await adminApi.getPackages();
      setPackages(response.data.packages || response.data || []);
    } catch (error) {
      showToast('Failed to load packages', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    loadPackages();
  }, [loadPackages]);

  const handleAddPackage = () => {
    setSelectedPackage(null);
    setFormData({
      name: '',
      description: '',
      price: '',
      credits: '',
      billingCycle: 'monthly',
      creditResetType: 'MONTHLY',
      creditResetHours: '',
      rpmLimit: '60',
      concurrentLimit: '10',
      features: '',
      isActive: true,
      isFeatured: false,
      sortOrder: '0'
    });
    setShowModal(true);
  };

  const handleEditPackage = (pkg) => {
    setSelectedPackage(pkg);
    setFormData({
      name: pkg.name,
      description: pkg.description || '',
      price: pkg.price?.toString() || '',
      credits: pkg.credits?.toString() || '',
      billingCycle: pkg.billingCycle || 'monthly',
      creditResetType: pkg.creditResetType || 'MONTHLY',
      creditResetHours: pkg.creditResetHours?.toString() || '',
      rpmLimit: pkg.rpmLimit?.toString() || '60',
      concurrentLimit: pkg.concurrentLimit?.toString() || '10',
      features: Array.isArray(pkg.features) ? pkg.features.join('\n') : '',
      isActive: pkg.isActive,
      isFeatured: pkg.isFeatured || false,
      sortOrder: pkg.sortOrder?.toString() || '0'
    });
    setShowModal(true);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const payload = {
        ...formData,
        price: parseFloat(formData.price),
        credits: parseFloat(formData.credits),
        rpmLimit: parseInt(formData.rpmLimit) || 60,
        concurrentLimit: parseInt(formData.concurrentLimit) || 10,
        features: formData.features.split('\n').filter(f => f.trim()),
        sortOrder: parseInt(formData.sortOrder) || 0,
        creditResetType: formData.creditResetType,
        creditResetHours: formData.creditResetType === 'CUSTOM' && formData.creditResetHours 
          ? parseInt(formData.creditResetHours) 
          : null
      };

      if (selectedPackage) {
        await adminApi.updatePackage(selectedPackage.id, payload);
        showToast('Package updated successfully', 'success');
      } else {
        await adminApi.createPackage(payload);
        showToast('Package created successfully', 'success');
      }
      setShowModal(false);
      loadPackages();
    } catch (error) {
      showToast(error.message || 'Failed to save package', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleActive = async (pkg) => {
    try {
      await adminApi.updatePackage(pkg.id, { isActive: !pkg.isActive });
      showToast(`Package ${pkg.isActive ? 'disabled' : 'enabled'} successfully`, 'success');
      loadPackages();
    } catch (error) {
      showToast(error.message || 'Failed to update package', 'error');
    }
  };

  const handleDeletePackage = async (pkg) => {
    if (!confirm(`Are you sure you want to delete "${pkg.name}"?`)) return;
    try {
      await adminApi.deletePackage(pkg.id);
      showToast('Package deleted successfully', 'success');
      loadPackages();
    } catch (error) {
      showToast(error.message || 'Failed to delete package', 'error');
    }
  };

  const columns = [
    {
      key: 'name',
      label: 'Package',
      render: (name, pkg) => (
        <div className={styles.packageCell}>
          <span className={styles.packageName}>{name}</span>
          {pkg.isFeatured && <Badge variant="primary">Featured</Badge>}
        </div>
      )
    },
    {
      key: 'price',
      label: 'Price',
      render: (price, pkg) => (
        <div className={styles.priceCell}>
          <span className={styles.price}>{formatCurrency(price)}</span>
          <span className={styles.cycle}>/{pkg.billingCycle}</span>
        </div>
      )
    },
    {
      key: 'credits',
      label: 'Credits',
      render: (credits) => formatNumber(credits)
    },
    {
      key: 'limits',
      label: 'Rate Limits',
      render: (_, pkg) => (
        <div className={styles.limitsCell}>
          <span className={styles.limitItem}>
            <strong>{pkg.rpmLimit || 60}</strong> RPM
          </span>
          <span className={styles.limitItem}>
            <strong>{pkg.concurrentLimit || 10}</strong> Concurrent
          </span>
        </div>
      )
    },
    {
      key: 'billingCycle',
      label: 'Cycle',
      render: (cycle) => (
        <Badge variant="default">
          {BILLING_CYCLES.find(c => c.value === cycle)?.label || cycle}
        </Badge>
      )
    },
    {
      key: 'creditResetType',
      label: 'Credit Reset',
      render: (resetType, pkg) => (
        <div className={styles.resetCell}>
          <Badge variant="info">
            {resetType || 'MONTHLY'}
          </Badge>
          {resetType === 'CUSTOM' && pkg.creditResetHours && (
            <span className={styles.resetHours}>{pkg.creditResetHours}h</span>
          )}
        </div>
      )
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive) => (
        <Badge variant={isActive ? 'success' : 'warning'}>
          {isActive ? 'Active' : 'Inactive'}
        </Badge>
      )
    },
    {
      key: 'sortOrder',
      label: 'Order',
      render: (order) => order || 0
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, pkg) => (
        <div className={styles.actions}>
          <Button variant="ghost" size="small" onClick={() => handleEditPackage(pkg)}>
            Edit
          </Button>
          <Button variant="ghost" size="small" onClick={() => handleToggleActive(pkg)}>
            {pkg.isActive ? 'Disable' : 'Enable'}
          </Button>
          <Button variant="ghost" size="small" onClick={() => handleDeletePackage(pkg)}>
            Delete
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Packages</h1>
          <p className={styles.subtitle}>Manage subscription packages and pricing</p>
        </div>
        <Button onClick={handleAddPackage}>Add Package</Button>
      </div>

      <Card className={styles.tableCard}>
        {isLoading ? (
          <div className={styles.loading}>
            <LoadingSpinner />
          </div>
        ) : (
          <Table columns={columns} data={packages} emptyMessage="No packages found" />
        )}
      </Card>

      {/* Add/Edit Package Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={selectedPackage ? 'Edit Package' : 'Add Package'}
        size="large"
      >
        <div className={styles.modalForm}>
          <Input
            label="Package Name"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            placeholder="e.g., Pro Plan"
            required
          />
          <Input
            label="Description"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Brief description"
          />
          <div className={styles.formRow}>
            <Input
              label="Price ($)"
              type="number"
              step="0.01"
              value={formData.price}
              onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
              required
            />
            <Input
              label="Credits"
              type="number"
              value={formData.credits}
              onChange={(e) => setFormData(prev => ({ ...prev, credits: e.target.value }))}
              required
            />
          </div>
          <div className={styles.formRow}>
            <Input
              label="RPM Limit (Requests per Minute)"
              type="number"
              value={formData.rpmLimit}
              onChange={(e) => setFormData(prev => ({ ...prev, rpmLimit: e.target.value }))}
              placeholder="60"
              min="1"
            />
            <Input
              label="Concurrent Limit"
              type="number"
              value={formData.concurrentLimit}
              onChange={(e) => setFormData(prev => ({ ...prev, concurrentLimit: e.target.value }))}
              placeholder="10"
              min="1"
            />
          </div>
          <div className={styles.formRow}>
            <Select
              label="Billing Cycle"
              value={formData.billingCycle}
              onChange={(e) => setFormData(prev => ({ ...prev, billingCycle: e.target.value }))}
              options={BILLING_CYCLES}
            />
            <Input
              label="Sort Order"
              type="number"
              value={formData.sortOrder}
              onChange={(e) => setFormData(prev => ({ ...prev, sortOrder: e.target.value }))}
            />
          </div>
          <div className={styles.formRow}>
            <Select
              label="Credit Reset Type"
              value={formData.creditResetType}
              onChange={(e) => setFormData(prev => ({ ...prev, creditResetType: e.target.value }))}
              options={CREDIT_RESET_TYPES}
            />
            {formData.creditResetType === 'CUSTOM' && (
              <Input
                label="Reset Hours"
                type="number"
                value={formData.creditResetHours}
                onChange={(e) => setFormData(prev => ({ ...prev, creditResetHours: e.target.value }))}
                placeholder="e.g., 48 for every 2 days"
                min="1"
              />
            )}
          </div>
          {formData.creditResetType !== 'NEVER' && (
            <div className={styles.resetInfo}>
              <span className={styles.resetInfoIcon}>ℹ️</span>
              <span>
                Credits will reset {formData.creditResetType === 'CUSTOM' && formData.creditResetHours 
                  ? `every ${formData.creditResetHours} hours` 
                  : CREDIT_RESET_TYPES.find(t => t.value === formData.creditResetType)?.label.toLowerCase().replace(/\(.*\)/, '').trim()}
              </span>
            </div>
          )}
          <div className={styles.textareaWrapper}>
            <label className={styles.textareaLabel}>Features (one per line)</label>
            <textarea
              className={styles.textarea}
              value={formData.features}
              onChange={(e) => setFormData(prev => ({ ...prev, features: e.target.value }))}
              placeholder="100,000 API credits&#10;Priority support&#10;All AI models"
              rows={5}
            />
          </div>
          <div className={styles.checkboxes}>
            <label className={styles.checkbox}>
              <input
                type="checkbox"
                checked={formData.isActive}
                onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
              />
              <span>Active</span>
            </label>
            <label className={styles.checkbox}>
              <input
                type="checkbox"
                checked={formData.isFeatured}
                onChange={(e) => setFormData(prev => ({ ...prev, isFeatured: e.target.checked }))}
              />
              <span>Featured</span>
            </label>
          </div>
          <div className={styles.modalActions}>
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} isLoading={isSubmitting}>
              {selectedPackage ? 'Save Changes' : 'Create Package'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
