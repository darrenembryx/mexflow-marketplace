// src/app/(admin)/admin/page.js
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { adminApi } from '@/lib/api';
import { formatCurrency, formatNumber, formatDate } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Badge from '@/components/common/Badge';
import Button from '@/components/common/Button';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import styles from './page.module.css';
import { 
  Users, 
  DollarSign, 
  Activity, 
  CreditCard,
  UserPlus,
  Box,
  Package,
  Ticket,
  ArrowRight,
  TrendingUp
} from 'lucide-react';

export default function AdminDashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState(null);
  const [recentUsers, setRecentUsers] = useState([]);
  const [recentPayments, setRecentPayments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const dashboardRes = await adminApi.getDashboard();
      const data = dashboardRes.data;
      
      setStats(data.stats);
      setRecentUsers(data.recentUsers || []);
      
      try {
        const paymentsRes = await adminApi.getPayments({ limit: 5, sortBy: 'createdAt', sortOrder: 'desc' });
        setRecentPayments(paymentsRes.data.payments || []);
      } catch {
        setRecentPayments([]);
      }
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className={styles.loading}>
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  const statCards = [
    {
      icon: Users,
      label: 'Total Users',
      value: formatNumber(stats?.totalUsers || 0),
      change: `+${stats?.newUsersToday || 0} today`,
      color: 'blue'
    },
    {
      icon: DollarSign,
      label: 'Total Revenue',
      value: formatCurrency(stats?.totalRevenue || 0),
      change: `+${formatCurrency(stats?.revenueToday || 0)} today`,
      color: 'green'
    },
    {
      icon: Activity,
      label: 'API Requests',
      value: formatNumber(stats?.totalRequests || 0),
      change: `${formatNumber(stats?.requestsToday || 0)} today`,
      color: 'purple'
    },
    {
      icon: CreditCard,
      label: 'Active Subs',
      value: formatNumber(stats?.activeSubscriptions || 0),
      change: `${formatNumber(stats?.subscriptionsThisMonth || 0)} this month`,
      color: 'orange'
    },
  ];

  const quickActions = [
    { icon: UserPlus, label: 'Add User', href: '/admin/users' },
    { icon: Box, label: 'Add Model', href: '/admin/models' },
    { icon: Package, label: 'Add Package', href: '/admin/packages' },
    { icon: Ticket, label: 'Create Coupon', href: '/admin/coupons' },
  ];

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Admin Dashboard</h1>
          <p className={styles.subtitle}>Platform overview and management</p>
        </div>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => router.push('/admin/analytics')}
          icon={<TrendingUp size={14} />}
        >
          Analytics
        </Button>
      </div>

      {/* Stats Grid */}
      <div className={styles.statsGrid}>
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className={styles.statCard}>
              <div className={styles.statIcon} data-color={stat.color}>
                <Icon size={18} />
              </div>
              <div className={styles.statContent}>
                <span className={styles.statLabel}>{stat.label}</span>
                <span className={styles.statValue}>{stat.value}</span>
                <span className={styles.statChange}>{stat.change}</span>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card className={styles.actionsCard}>
        <h2 className={styles.sectionTitle}>Quick Actions</h2>
        <div className={styles.actionsGrid}>
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button 
                key={action.label}
                className={styles.actionButton}
                onClick={() => router.push(action.href)}
              >
                <Icon size={18} />
                <span>{action.label}</span>
              </button>
            );
          })}
        </div>
      </Card>

      <div className={styles.grid}>
        {/* Recent Users */}
        <Card className={styles.listCard}>
          <div className={styles.listHeader}>
            <h2 className={styles.sectionTitle}>Recent Users</h2>
            <Button variant="ghost" size="xs" onClick={() => router.push('/admin/users')}>
              View All <ArrowRight size={12} />
            </Button>
          </div>
          <div className={styles.list}>
            {recentUsers.length === 0 ? (
              <p className={styles.emptyText}>No users yet</p>
            ) : (
              recentUsers.map((user) => (
                <div key={user.id} className={styles.listItem}>
                  <div className={styles.userAvatar}>
                    {user.name?.charAt(0).toUpperCase() || user.email?.charAt(0).toUpperCase()}
                  </div>
                  <div className={styles.userInfo}>
                    <span className={styles.userName}>{user.name || 'No name'}</span>
                    <span className={styles.userEmail}>{user.email}</span>
                  </div>
                  <div className={styles.userMeta}>
                    <Badge variant={user.status === 'active' ? 'success' : 'warning'} size="sm">
                      {user.status}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Recent Payments */}
        <Card className={styles.listCard}>
          <div className={styles.listHeader}>
            <h2 className={styles.sectionTitle}>Recent Payments</h2>
            <Button variant="ghost" size="xs" onClick={() => router.push('/admin/payments')}>
              View All <ArrowRight size={12} />
            </Button>
          </div>
          <div className={styles.list}>
            {recentPayments.length === 0 ? (
              <p className={styles.emptyText}>No payments yet</p>
            ) : (
              recentPayments.map((payment) => (
                <div key={payment.id} className={styles.listItem}>
                  <div className={styles.paymentInfo}>
                    <span className={styles.paymentAmount}>{formatCurrency(payment.amount)}</span>
                    <span className={styles.paymentUser}>{payment.user?.email || 'Unknown'}</span>
                  </div>
                  <Badge 
                    variant={
                      payment.status === 'completed' ? 'success' :
                      payment.status === 'pending' ? 'warning' : 'danger'
                    } 
                    size="sm"
                  >
                    {payment.status}
                  </Badge>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>

      {/* System Status */}
      <Card className={styles.statusCard}>
        <h2 className={styles.sectionTitle}>System Status</h2>
        <div className={styles.statusGrid}>
          {[
            { name: 'API Server', status: 'Operational' },
            { name: 'Database', status: 'Connected' },
            { name: 'Redis Cache', status: 'Active' },
            { name: 'Queue Workers', status: 'Running' },
          ].map((item) => (
            <div key={item.name} className={styles.statusItem}>
              <span className={styles.statusDot} />
              <div className={styles.statusInfo}>
                <span className={styles.statusName}>{item.name}</span>
                <span className={styles.statusValue}>{item.status}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
