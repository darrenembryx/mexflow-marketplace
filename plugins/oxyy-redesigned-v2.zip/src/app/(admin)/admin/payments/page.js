'use client';

import { useState, useEffect, useCallback } from 'react';
import { adminApi } from '@/lib/api';
import { formatDate, formatCurrency } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Input from '@/components/common/Input';
import Select from '@/components/common/Select';
import Badge from '@/components/common/Badge';
import Table from '@/components/common/Table';
import Pagination from '@/components/common/Pagination';
import Modal from '@/components/common/Modal';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { useToast } from '@/context/ToastContext';
import styles from './page.module.css';

const PAYMENT_STATUSES = [
  { value: '', label: 'All Status' },
  { value: 'pending', label: 'Pending' },
  { value: 'completed', label: 'Completed' },
  { value: 'failed', label: 'Failed' },
  { value: 'refunded', label: 'Refunded' }
];

const PAYMENT_PROVIDERS = [
  { value: '', label: 'All Providers' },
  { value: 'STRIPE', label: 'Stripe' },
  { value: 'CRYPTOMUS', label: 'Cryptomus' },
  { value: 'NOWPAYMENTS', label: 'NowPayments' }
];

export default function PaymentsPage() {
  const { showToast } = useToast();
  const [payments, setPayments] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 20, total: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState({ status: '', provider: '' });
  const [dateRange, setDateRange] = useState({ from: '', to: '' });
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const loadPayments = useCallback(async () => {
    setIsLoading(true);
    try {
      const params = {
        page: pagination.page,
        limit: pagination.limit,
        ...(filters.status && { status: filters.status }),
        ...(filters.provider && { provider: filters.provider }),
        ...(dateRange.from && { from: dateRange.from }),
        ...(dateRange.to && { to: dateRange.to })
      };
      const response = await adminApi.getPayments(params);
      setPayments(response.data.payments || []);
      setPagination(prev => ({ ...prev, total: response.data.total || 0 }));
    } catch (error) {
      showToast('Failed to load payments', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [pagination.page, pagination.limit, filters, dateRange, showToast]);

  useEffect(() => {
    loadPayments();
  }, [loadPayments]);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleViewDetails = (payment) => {
    setSelectedPayment(payment);
    setShowDetailsModal(true);
  };

  const handleRefund = async (payment) => {
    if (!confirm(`Are you sure you want to refund this payment of ${formatCurrency(payment.amount)}?`)) {
      return;
    }
    try {
      await adminApi.refundPayment(payment.id);
      showToast('Payment refunded successfully', 'success');
      loadPayments();
    } catch (error) {
      showToast(error.message || 'Failed to refund payment', 'error');
    }
  };

  const getStatusVariant = (status) => {
    switch (status) {
      case 'completed': return 'success';
      case 'pending': return 'warning';
      case 'failed': return 'danger';
      case 'refunded': return 'default';
      default: return 'default';
    }
  };

  const columns = [
    {
      key: 'id',
      label: 'Transaction ID',
      render: (id) => (
        <span className={styles.transactionId}>{id.slice(0, 12)}...</span>
      )
    },
    {
      key: 'user',
      label: 'User',
      render: (user) => (
        <div className={styles.userCell}>
          <span className={styles.userName}>{user?.name || user?.email || 'Unknown'}</span>
          {user?.email && <span className={styles.userEmail}>{user.email}</span>}
        </div>
      )
    },
    {
      key: 'amount',
      label: 'Amount',
      render: (amount) => (
        <span className={styles.amount}>{formatCurrency(amount)}</span>
      )
    },
    {
      key: 'provider',
      label: 'Provider',
      render: (provider) => (
        <Badge variant="default">{provider || 'Unknown'}</Badge>
      )
    },
    {
      key: 'status',
      label: 'Status',
      render: (status) => (
        <Badge variant={getStatusVariant(status)}>{status}</Badge>
      )
    },
    {
      key: 'createdAt',
      label: 'Date',
      render: (date) => formatDate(date)
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, payment) => (
        <div className={styles.actions}>
          <Button variant="ghost" size="small" onClick={() => handleViewDetails(payment)}>
            Details
          </Button>
          {payment.status === 'completed' && (
            <Button variant="ghost" size="small" onClick={() => handleRefund(payment)}>
              Refund
            </Button>
          )}
        </div>
      )
    }
  ];

  // Calculate stats
  const stats = {
    total: payments.length,
    completed: payments.filter(p => p.status === 'completed').length,
    pending: payments.filter(p => p.status === 'pending').length,
    totalAmount: payments.filter(p => p.status === 'completed').reduce((sum, p) => sum + (p.amount || 0), 0)
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Payments</h1>
          <p className={styles.subtitle}>View and manage payment transactions</p>
        </div>
      </div>

      {/* Stats */}
      <div className={styles.statsGrid}>
        <Card className={styles.statCard}>
          <span className={styles.statLabel}>Total Revenue</span>
          <span className={styles.statValue}>{formatCurrency(stats.totalAmount)}</span>
        </Card>
        <Card className={styles.statCard}>
          <span className={styles.statLabel}>Completed</span>
          <span className={styles.statValue}>{stats.completed}</span>
        </Card>
        <Card className={styles.statCard}>
          <span className={styles.statLabel}>Pending</span>
          <span className={styles.statValue}>{stats.pending}</span>
        </Card>
        <Card className={styles.statCard}>
          <span className={styles.statLabel}>Total Transactions</span>
          <span className={styles.statValue}>{pagination.total}</span>
        </Card>
      </div>

      {/* Filters */}
      <Card className={styles.filtersCard}>
        <div className={styles.filters}>
          <Select
            value={filters.status}
            onChange={(e) => handleFilterChange('status', e.target.value)}
            options={PAYMENT_STATUSES}
          />
          <Select
            value={filters.provider}
            onChange={(e) => handleFilterChange('provider', e.target.value)}
            options={PAYMENT_PROVIDERS}
          />
          <Input
            type="date"
            value={dateRange.from}
            onChange={(e) => setDateRange(prev => ({ ...prev, from: e.target.value }))}
            placeholder="From date"
          />
          <Input
            type="date"
            value={dateRange.to}
            onChange={(e) => setDateRange(prev => ({ ...prev, to: e.target.value }))}
            placeholder="To date"
          />
        </div>
      </Card>

      <Card className={styles.tableCard}>
        {isLoading ? (
          <div className={styles.loading}>
            <LoadingSpinner />
          </div>
        ) : (
          <>
            <Table columns={columns} data={payments} emptyMessage="No payments found" />
            {pagination.total > pagination.limit && (
              <Pagination
                currentPage={pagination.page}
                totalPages={Math.ceil(pagination.total / pagination.limit)}
                onPageChange={(page) => setPagination(prev => ({ ...prev, page }))}
              />
            )}
          </>
        )}
      </Card>

      {/* Payment Details Modal */}
      <Modal
        isOpen={showDetailsModal}
        onClose={() => setShowDetailsModal(false)}
        title="Payment Details"
      >
        {selectedPayment && (
          <div className={styles.detailsModal}>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Transaction ID</span>
              <span className={styles.detailValue}>{selectedPayment.id}</span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>User</span>
              <span className={styles.detailValue}>
                {selectedPayment.user?.email || 'Unknown'}
              </span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Amount</span>
              <span className={styles.detailValue}>{formatCurrency(selectedPayment.amount)}</span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Status</span>
              <Badge variant={getStatusVariant(selectedPayment.status)}>
                {selectedPayment.status}
              </Badge>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Provider</span>
              <span className={styles.detailValue}>{selectedPayment.provider}</span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Provider ID</span>
              <span className={styles.detailValue}>{selectedPayment.providerId || '-'}</span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Package</span>
              <span className={styles.detailValue}>{selectedPayment.package?.name || '-'}</span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Credits</span>
              <span className={styles.detailValue}>{selectedPayment.credits || '-'}</span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Created</span>
              <span className={styles.detailValue}>{formatDate(selectedPayment.createdAt)}</span>
            </div>
            {selectedPayment.completedAt && (
              <div className={styles.detailRow}>
                <span className={styles.detailLabel}>Completed</span>
                <span className={styles.detailValue}>{formatDate(selectedPayment.completedAt)}</span>
              </div>
            )}
            <div className={styles.modalActions}>
              <Button variant="outline" onClick={() => setShowDetailsModal(false)}>
                Close
              </Button>
              {selectedPayment.status === 'completed' && (
                <Button variant="danger" onClick={() => handleRefund(selectedPayment)}>
                  Refund
                </Button>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
