'use client';

// src/app/(auth)/reset-password/page.js

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import styles from '../auth.module.css';
import { authApi } from '@/lib/api';
import { useToast } from '@/context/ToastContext';
import { ROUTES } from '@/lib/constants';
import Card from '@/components/common/Card';
import Input from '@/components/common/Input';
import Button from '@/components/common/Button';
import { Lock, Eye, EyeOff, ArrowLeft, CheckCircle } from 'lucide-react';

export default function ResetPasswordPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');
  const { showToast } = useToast();
  
  const [formData, setFormData] = useState({
    password: '',
    confirmPassword: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState({});

  if (!token) {
    return (
      <Card className={styles.card}>
        <div className={styles.header}>
          <h1 className={styles.title}>Invalid Link</h1>
          <p className={styles.subtitle}>
            This password reset link is invalid or has expired.
          </p>
        </div>
        <div className={styles.footer}>
          <Link href={ROUTES.FORGOT_PASSWORD} className={styles.backLink}>
            <ArrowLeft size={16} />
            Request a new link
          </Link>
        </div>
      </Card>
    );
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const newErrors = {};
    
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    }
    
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      await authApi.resetPassword(token, formData.password);
      setSuccess(true);
    } catch (error) {
      showToast(error.message || 'Failed to reset password', 'error');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <Card className={styles.card}>
        <div className={styles.successIcon}>
          <CheckCircle size={48} />
        </div>
        <div className={styles.header}>
          <h1 className={styles.title}>Password reset!</h1>
          <p className={styles.subtitle}>
            Your password has been reset successfully.
          </p>
        </div>
        <Button fullWidth onClick={() => router.push(ROUTES.LOGIN)}>
          Sign in
        </Button>
      </Card>
    );
  }

  return (
    <Card className={styles.card}>
      <div className={styles.header}>
        <h1 className={styles.title}>Reset password</h1>
        <p className={styles.subtitle}>Enter your new password</p>
      </div>

      <form onSubmit={handleSubmit} className={styles.form}>
        <Input
          label="New password"
          type={showPassword ? 'text' : 'password'}
          name="password"
          placeholder="••••••••"
          value={formData.password}
          onChange={handleChange}
          error={errors.password}
          hint="Must be at least 8 characters"
          leftIcon={<Lock size={16} />}
          rightIcon={
            <button
              type="button"
              className={styles.passwordToggle}
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          }
          autoComplete="new-password"
        />

        <Input
          label="Confirm password"
          type={showPassword ? 'text' : 'password'}
          name="confirmPassword"
          placeholder="••••••••"
          value={formData.confirmPassword}
          onChange={handleChange}
          error={errors.confirmPassword}
          leftIcon={<Lock size={16} />}
          autoComplete="new-password"
        />

        <Button type="submit" fullWidth loading={loading}>
          Reset password
        </Button>
      </form>

      <div className={styles.footer}>
        <Link href={ROUTES.LOGIN} className={styles.backLink}>
          <ArrowLeft size={16} />
          Back to sign in
        </Link>
      </div>
    </Card>
  );
}
