'use client';

// src/app/(auth)/verify-email/page.js

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import styles from '../auth.module.css';
import { authApi } from '@/lib/api';
import { ROUTES } from '@/lib/constants';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { CheckCircle, XCircle, ArrowLeft } from 'lucide-react';

export default function VerifyEmailPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');
  
  const [status, setStatus] = useState('loading'); // loading, success, error
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!token) {
      setStatus('error');
      setMessage('Invalid verification link');
      return;
    }

    const verify = async () => {
      try {
        await authApi.verifyEmail(token);
        setStatus('success');
        setMessage('Your email has been verified successfully!');
      } catch (error) {
        setStatus('error');
        setMessage(error.message || 'Failed to verify email');
      }
    };

    verify();
  }, [token]);

  if (status === 'loading') {
    return (
      <Card className={styles.card}>
        <div className={styles.loadingContainer}>
          <LoadingSpinner size="lg" />
          <p className={styles.loadingText}>Verifying your email...</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className={styles.card}>
      <div className={status === 'success' ? styles.successIcon : styles.errorIcon}>
        {status === 'success' ? (
          <CheckCircle size={48} />
        ) : (
          <XCircle size={48} />
        )}
      </div>
      
      <div className={styles.header}>
        <h1 className={styles.title}>
          {status === 'success' ? 'Email Verified!' : 'Verification Failed'}
        </h1>
        <p className={styles.subtitle}>{message}</p>
      </div>

      {status === 'success' ? (
        <Button fullWidth onClick={() => router.push(ROUTES.LOGIN)}>
          Sign in to your account
        </Button>
      ) : (
        <div className={styles.footer}>
          <Link href={ROUTES.LOGIN} className={styles.backLink}>
            <ArrowLeft size={16} />
            Back to sign in
          </Link>
        </div>
      )}
    </Card>
  );
}
