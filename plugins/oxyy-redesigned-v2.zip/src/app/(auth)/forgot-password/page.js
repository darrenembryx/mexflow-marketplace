'use client';

// src/app/(auth)/forgot-password/page.js

import { useState } from 'react';
import Link from 'next/link';
import styles from '../auth.module.css';
import { authApi } from '@/lib/api';
import { useToast } from '@/context/ToastContext';
import { ROUTES } from '@/lib/constants';
import Card from '@/components/common/Card';
import Input from '@/components/common/Input';
import Button from '@/components/common/Button';
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react';

export default function ForgotPasswordPage() {
  const { showToast } = useToast();
  
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email) {
      setError('Email is required');
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      setError('Invalid email address');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      await authApi.forgotPassword(email);
      setSent(true);
    } catch (err) {
      showToast(err.message || 'Failed to send reset email', 'error');
    } finally {
      setLoading(false);
    }
  };

  if (sent) {
    return (
      <Card className={styles.card}>
        <div className={styles.successIcon}>
          <CheckCircle size={48} />
        </div>
        <div className={styles.header}>
          <h1 className={styles.title}>Check your email</h1>
          <p className={styles.subtitle}>
            We've sent a password reset link to <strong>{email}</strong>
          </p>
        </div>
        <div className={styles.footer}>
          <Link href={ROUTES.LOGIN} className={styles.backLink}>
            <ArrowLeft size={16} />
            Back to sign in
          </Link>
        </div>
      </Card>
    );
  }

  return (
    <Card className={styles.card}>
      <div className={styles.header}>
        <h1 className={styles.title}>Forgot password?</h1>
        <p className={styles.subtitle}>
          Enter your email and we'll send you a reset link
        </p>
      </div>

      <form onSubmit={handleSubmit} className={styles.form}>
        <Input
          label="Email"
          type="email"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            setError('');
          }}
          error={error}
          leftIcon={<Mail size={16} />}
          autoComplete="email"
        />

        <Button type="submit" fullWidth loading={loading}>
          Send reset link
        </Button>
      </form>

      <div className={styles.footer}>
        <Link href={ROUTES.LOGIN} className={styles.backLink}>
          <ArrowLeft size={16} />
          Back to sign in
        </Link>
      </div>
    </Card>
  );
}
