// src/app/(auth)/layout.js

import styles from './layout.module.css';
import { Sparkles, Zap, Shield, Globe } from 'lucide-react';

const features = [
  { icon: Sparkles, text: '100+ AI models in one API' },
  { icon: Zap, text: 'Ultra-fast response times' },
  { icon: Shield, text: 'Enterprise-grade security' },
  { icon: Globe, text: 'Global infrastructure' },
];

export default function AuthLayout({ children }) {
  return (
    <div className={styles.container}>
      {/* Left Side - Branding */}
      <div className={styles.brandSide}>
        <div className={styles.brandContent}>
          <div className={styles.logo}>
            <span className={styles.logoIcon}>O</span>
            <span className={styles.logoText}>xyy.ai</span>
          </div>
          
          <h1 className={styles.headline}>
            The Universal API for
            <span className={styles.gradient}> AI Models</span>
          </h1>
          
          <p className={styles.tagline}>
            Access GPT-4, Claude, Gemini, and 100+ more models through a single, 
            unified API. Ship faster, scale easier.
          </p>

          <div className={styles.features}>
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className={styles.feature}>
                  <Icon size={18} className={styles.featureIcon} />
                  <span>{feature.text}</span>
                </div>
              );
            })}
          </div>

          <div className={styles.testimonial}>
            <p className={styles.quote}>
              "Oxyy.ai simplified our entire AI stack. We went from managing 5 different 
              APIs to just one. Game changer."
            </p>
            <div className={styles.author}>
              <div className={styles.avatar}>JD</div>
              <div>
                <span className={styles.authorName}>John Doe</span>
                <span className={styles.authorRole}>CTO at TechCorp</span>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className={styles.decoration}>
          <div className={styles.glow} />
          <div className={styles.grid} />
        </div>
      </div>

      {/* Right Side - Form */}
      <div className={styles.formSide}>
        <div className={styles.formContent}>
          {children}
        </div>
      </div>
    </div>
  );
}
