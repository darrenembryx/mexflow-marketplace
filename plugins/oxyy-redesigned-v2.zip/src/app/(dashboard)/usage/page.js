'use client';

// src/app/(dashboard)/usage/page.js

import { useState } from 'react';
import styles from './page.module.css';
import { useUsage } from '@/hooks/useUsage';
import { formatDate, formatNumber, formatCredits } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Select from '@/components/common/Select';
import Table from '@/components/common/Table';
import Pagination from '@/components/common/Pagination';
import Badge from '@/components/common/Badge';
import Skeleton from '@/components/common/Skeleton';
import EmptyState from '@/components/common/EmptyState';
import { BarChart2, TrendingUp, TrendingDown, Clock } from 'lucide-react';

const periodOptions = [
  { value: '7', label: 'Last 7 days' },
  { value: '30', label: 'Last 30 days' },
  { value: '90', label: 'Last 90 days' },
];

export default function UsagePage() {
  const [period, setPeriod] = useState('30');
  const [page, setPage] = useState(1);
  const limit = 20;
  
  const { usage, loading, error } = useUsage({ 
    days: parseInt(period), 
    page, 
    limit 
  });

  // Calculate totals
  const totals = usage?.records?.reduce(
    (acc, record) => ({
      requests: acc.requests + 1,
      inputTokens: acc.inputTokens + (record.inputTokens || 0),
      outputTokens: acc.outputTokens + (record.outputTokens || 0),
      credits: acc.credits + (record.creditsUsed || 0),
    }),
    { requests: 0, inputTokens: 0, outputTokens: 0, credits: 0 }
  ) || { requests: 0, inputTokens: 0, outputTokens: 0, credits: 0 };

  const columns = [
    {
      key: 'createdAt',
      header: 'Time',
      render: (value) => (
        <span className={styles.timeCell}>
          <Clock size={12} />
          {formatDate(value, 'datetime')}
        </span>
      ),
    },
    {
      key: 'model',
      header: 'Model',
      render: (value) => <code className={styles.modelCell}>{value}</code>,
    },
    {
      key: 'type',
      header: 'Type',
      render: (value) => (
        <Badge variant="outline" size="sm">
          {value}
        </Badge>
      ),
    },
    {
      key: 'tokens',
      header: 'Tokens',
      render: (_, row) => (
        <div className={styles.tokensCell}>
          {row.inputTokens && (
            <span className={styles.tokenBadge}>
              <TrendingUp size={12} />
              {formatNumber(row.inputTokens)}
            </span>
          )}
          {row.outputTokens && (
            <span className={styles.tokenBadge}>
              <TrendingDown size={12} />
              {formatNumber(row.outputTokens)}
            </span>
          )}
        </div>
      ),
    },
    {
      key: 'creditsUsed',
      header: 'Credits',
      render: (value) => (
        <span className={styles.creditsCell}>-{formatCredits(value)}</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (value) => (
        <Badge
          variant={value === 'SUCCESS' ? 'success' : 'error'}
          size="sm"
        >
          {value}
        </Badge>
      ),
    },
  ];

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Usage</h1>
          <p className={styles.subtitle}>
            Track your API usage and credit consumption.
          </p>
        </div>
        <div className={styles.periodSelect}>
          <Select
            options={periodOptions}
            value={period}
            onChange={(e) => {
              setPeriod(e.target.value);
              setPage(1);
            }}
          />
        </div>
      </div>

      {/* Stats */}
      <div className={styles.statsGrid}>
        <Card className={styles.statCard}>
          <span className={styles.statLabel}>Total Requests</span>
          {loading ? (
            <Skeleton width={80} height={28} />
          ) : (
            <span className={styles.statValue}>{formatNumber(totals.requests)}</span>
          )}
        </Card>
        <Card className={styles.statCard}>
          <span className={styles.statLabel}>Input Tokens</span>
          {loading ? (
            <Skeleton width={80} height={28} />
          ) : (
            <span className={styles.statValue}>{formatNumber(totals.inputTokens)}</span>
          )}
        </Card>
        <Card className={styles.statCard}>
          <span className={styles.statLabel}>Output Tokens</span>
          {loading ? (
            <Skeleton width={80} height={28} />
          ) : (
            <span className={styles.statValue}>{formatNumber(totals.outputTokens)}</span>
          )}
        </Card>
        <Card className={styles.statCard}>
          <span className={styles.statLabel}>Credits Used</span>
          {loading ? (
            <Skeleton width={80} height={28} />
          ) : (
            <span className={styles.statValue}>{formatCredits(totals.credits)}</span>
          )}
        </Card>
      </div>

      {/* Usage Table */}
      <Card>
        {loading ? (
          <div className={styles.skeleton}>
            <Skeleton height={40} style={{ marginBottom: 12 }} />
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} height={48} style={{ marginBottom: 8 }} />
            ))}
          </div>
        ) : error ? (
          <EmptyState
            icon={BarChart2}
            title="Failed to load usage data"
            description={error.message || "Something went wrong while loading your usage data."}
          />
        ) : !usage?.records?.length ? (
          <EmptyState
            icon={BarChart2}
            title="No usage data"
            description="Start using the API to see your usage history."
          />
        ) : (
          <>
            <Table
              columns={columns}
              data={usage.records}
              hoverable
            />
            {usage.pagination && (
              <div className={styles.pagination}>
                <Pagination
                  currentPage={page}
                  totalPages={Math.ceil(usage.pagination.total / limit)}
                  onPageChange={setPage}
                />
              </div>
            )}
          </>
        )}
      </Card>
    </div>
  );
}
