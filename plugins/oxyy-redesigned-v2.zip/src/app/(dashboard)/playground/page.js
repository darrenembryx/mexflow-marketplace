'use client';

// src/app/(dashboard)/playground/page.js

import { useState, useRef, useEffect, useCallback } from 'react';
import styles from './page.module.css';
import { useModels } from '@/hooks/useModels';
import { useApiKeys } from '@/hooks/useApiKeys';
import { useCredits } from '@/hooks/useCredits';
import { useConcurrent } from '@/hooks/useConcurrent';
import { useToast } from '@/context/ToastContext';
import { playgroundApi, assetsApi } from '@/lib/api';
import { formatCredits } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Select from '@/components/common/Select';
import Input from '@/components/common/Input';
import Badge from '@/components/common/Badge';
import Skeleton from '@/components/common/Skeleton';
import Tabs from '@/components/common/Tabs';
import {
  Send,
  Trash2,
  Settings,
  Copy,
  Check,
  Loader2,
  Image as ImageIcon,
  Mic,
  MessageSquare,
  Code,
  Key,
  Download,
  Video,
  Upload,
  X,
  Activity,
} from 'lucide-react';

const tabs = [
  { id: 'chat', label: 'Chat', icon: MessageSquare },
  { id: 'image', label: 'Image', icon: ImageIcon },
  { id: 'video', label: 'Video', icon: Video },
  { id: 'audio', label: 'Audio', icon: Mic },
  { id: 'embeddings', label: 'Embeddings', icon: Code },
];

export default function PlaygroundPage() {
  const { models, isLoading: modelsLoading } = useModels();
  const { apiKeys, isLoading: apiKeysLoading } = useApiKeys();
  const { refresh: refreshCredits } = useCredits();
  const { current: concurrentCurrent, limit: concurrentLimit, isAtLimit } = useConcurrent(1000);
  const { showToast } = useToast();
  
  const [activeTab, setActiveTab] = useState('chat');
  const [selectedModel, setSelectedModel] = useState('');
  const [selectedApiKey, setSelectedApiKey] = useState('');
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [copiedId, setCopiedId] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [inputImage, setInputImage] = useState(null);
  const [inputImagePreview, setInputImagePreview] = useState(null);
  const [uploadedAssetUrl, setUploadedAssetUrl] = useState(null);
  
  // Job polling state
  const [currentJobId, setCurrentJobId] = useState(null);
  const [jobProgress, setJobProgress] = useState(0);
  const [jobStatus, setJobStatus] = useState(null);
  
  // Settings
  const [settings, setSettings] = useState({
    temperature: 0.7,
    maxTokens: 16384,  // Default to 16K tokens for longer responses
    topP: 1,
    stream: true,
    voice: 'alloy',
    videoDuration: 4,
    videoResolution: '1080p',
  });

  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);

  // Filter models by type
  const filteredModels = models.filter((model) => {
    switch (activeTab) {
      case 'chat':
        return model.type === 'TEXT';
      case 'image':
        return model.type === 'IMAGE_GENERATION';
      case 'video':
        return model.type === 'TEXT_TO_VIDEO' || model.type === 'IMAGE_TO_VIDEO' || model.type === 'VIDEO_TO_VIDEO';
      case 'audio':
        return model.type === 'AUDIO_TTS' || model.type === 'AUDIO_STT';
      case 'embeddings':
        return model.type === 'EMBEDDING';
      default:
        return true;
    }
  });

  // Set default model when models load
  useEffect(() => {
    if (filteredModels.length > 0 && !selectedModel) {
      setSelectedModel(filteredModels[0].modelId || filteredModels[0].id);
    }
  }, [filteredModels, selectedModel]);

  // Reset model when tab changes
  useEffect(() => {
    setSelectedModel('');
    setMessages([]);
    setAudioUrl(null);
  }, [activeTab]);

  // Set default API key when loaded
  useEffect(() => {
    if (apiKeys.length > 0 && !selectedApiKey) {
      setSelectedApiKey(apiKeys[0].id);
    }
  }, [apiKeys, selectedApiKey]);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !selectedModel) return;

    // Require API key to use playground
    if (!selectedApiKey) {
      showToast('Please create and select an API key to use the playground', 'error');
      return;
    }

    const userMessage = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      if (activeTab === 'chat') {
        if (settings.stream) {
          // Streaming mode - add an empty assistant message that we'll update
          const streamingMessageId = Date.now();
          setMessages((prev) => [...prev, { 
            role: 'assistant', 
            content: '', 
            isStreaming: true,
            id: streamingMessageId 
          }]);

          await playgroundApi.chatStream(
            {
              model: selectedModel,
              messages: [...messages, userMessage],
              temperature: settings.temperature,
              max_tokens: settings.maxTokens,
              top_p: settings.topP,
            },
            {
              onChunk: (chunk, fullContent) => {
                // Update the streaming message with accumulated content
                setMessages((prev) => 
                  prev.map((msg) => 
                    msg.id === streamingMessageId 
                      ? { ...msg, content: fullContent }
                      : msg
                  )
                );
              },
              onDone: ({ content, usage }) => {
                // Finalize the message
                setMessages((prev) => 
                  prev.map((msg) => 
                    msg.id === streamingMessageId 
                      ? { ...msg, content, usage, isStreaming: false }
                      : msg
                  )
                );
                // Refresh credits after successful request
                refreshCredits();
              },
              onError: (error) => {
                // Remove failed streaming message
                setMessages((prev) => prev.filter((msg) => msg.id !== streamingMessageId));
                showToast(error.message || 'Streaming failed', 'error');
              },
            }
          );
        } else {
          // Non-streaming mode
          const response = await playgroundApi.chat({
            model: selectedModel,
            messages: [...messages, userMessage],
            temperature: settings.temperature,
            max_tokens: settings.maxTokens,
            top_p: settings.topP,
            stream: false,
          });

          // Response is OpenAI-format directly (no 'success' wrapper)
          // Check if we have choices array (OpenAI format)
          if (response?.choices?.[0]?.message?.content) {
            const assistantMessage = {
              role: 'assistant',
              content: response.choices[0].message.content,
              usage: response.usage,
            };
            setMessages((prev) => [...prev, assistantMessage]);
            // Refresh credits after successful request
            refreshCredits();
          } else if (response?.data?.choices?.[0]?.message?.content) {
            // Fallback: wrapped response format
            const assistantMessage = {
              role: 'assistant',
              content: response.data.choices[0].message.content,
              usage: response.data.usage,
            };
            setMessages((prev) => [...prev, assistantMessage]);
            refreshCredits();
          } else {
            showToast('Failed to get response from model', 'error');
          }
        }
      } else if (activeTab === 'image') {
        // Build image generation params
        const imageParams = {
          model: selectedModel,
          prompt: input,
          n: 1,
          size: settings.imageResolution || modelOptions?.resolutions?.[0]?.value || '1024x1024',
        };

        // Include input image for image-to-image models
        if (modelOptions?.supportsImageInput && inputImage) {
          // Upload to CDN first to get a public URL
          setUploading(true);
          try {
            const uploadResponse = await assetsApi.upload(inputImage);
            // Response is directly the asset data: { asset_id, url, expires_at, ... }
            imageParams.image = uploadResponse.url;
            setUploadedAssetUrl(uploadResponse.url);
          } catch (uploadError) {
            showToast(`Failed to upload image: ${uploadError.message}`, 'error');
            setUploading(false);
            setLoading(false);
            return;
          }
          setUploading(false);
        }

        const response = await playgroundApi.generateImage(imageParams);

        // Check for OpenAI format directly or wrapped format
        const imageData = response?.data?.[0] || response?.data?.data?.[0];
        if (imageData) {
          const assistantMessage = {
            role: 'assistant',
            content: imageData.url || imageData.b64_json,
            type: 'image',
          };
          setMessages((prev) => [...prev, assistantMessage]);
          // Refresh credits after successful request
          refreshCredits();
        } else {
          showToast('Failed to generate image', 'error');
        }
      } else if (activeTab === 'video') {
        // Build video generation params
        const videoParams = {
          model: selectedModel,
          prompt: input,
          duration: settings.videoDuration || 4,
          resolution: settings.videoResolution || '1080p',
        };

        // Include input image for image-to-video
        if (settings.videoInputType === 'image' && inputImage) {
          // Upload to CDN first to get a public URL
          setUploading(true);
          try {
            const uploadResponse = await assetsApi.upload(inputImage);
            videoParams.image = uploadResponse.url;
            setUploadedAssetUrl(uploadResponse.url);
          } catch (uploadError) {
            showToast(`Failed to upload image: ${uploadError.message}`, 'error');
            setUploading(false);
            setLoading(false);
            return;
          }
          setUploading(false);
        }

        // Add a generating message
        const generatingMessageId = Date.now();
        setMessages((prev) => [...prev, { 
          role: 'assistant', 
          content: 'Generating video...', 
          type: 'video-pending',
          id: generatingMessageId 
        }]);

        try {
          // Use async generation with polling
          const result = await playgroundApi.generateVideoAsync(videoParams, {
            onJobCreated: (job) => {
              setCurrentJobId(job.id);
              setJobStatus('queued');
              setJobProgress(0);
              // Update message to show job started
              setMessages((prev) => prev.map((msg) => 
                msg.id === generatingMessageId 
                  ? { ...msg, content: 'Video generation started...' }
                  : msg
              ));
            },
            onProgress: ({ status, progress }) => {
              setJobStatus(status);
              setJobProgress(progress || 0);
              // Update message with progress
              const statusText = status === 'processing' 
                ? `Generating video... ${progress || 0}%` 
                : `Video ${status}...`;
              setMessages((prev) => prev.map((msg) => 
                msg.id === generatingMessageId 
                  ? { ...msg, content: statusText }
                  : msg
              ));
            },
            onComplete: (job) => {
              setCurrentJobId(null);
              setJobStatus('completed');
              setJobProgress(100);
            },
            onError: (error) => {
              setCurrentJobId(null);
              setJobStatus('failed');
              // Remove the pending message
              setMessages((prev) => prev.filter((msg) => msg.id !== generatingMessageId));
              showToast(error.message || 'Video generation failed', 'error');
            },
          });

          // Extract video data from completed result
          const videoData = result?.result?.data?.[0] || result?.result?.data?.[0] || result?.result;
          const videoUrl = videoData?.url || result?.result?.url;
          
          if (videoUrl) {
            // Update the generating message with the actual video
            setMessages((prev) => prev.map((msg) => 
              msg.id === generatingMessageId 
                ? {
                    role: 'assistant',
                    content: videoUrl,
                    type: 'video',
                    duration: videoData?.duration || settings.videoDuration,
                    resolution: videoData?.resolution || settings.videoResolution,
                    id: generatingMessageId,
                  }
                : msg
            ));
            refreshCredits();
          } else {
            // Remove the pending message
            setMessages((prev) => prev.filter((msg) => msg.id !== generatingMessageId));
            showToast('Failed to generate video', 'error');
          }
        } catch (videoError) {
          // Error already handled in onError callback, just clean up
          setCurrentJobId(null);
          setJobStatus(null);
        }
      } else if (activeTab === 'audio') {
        // Determine the voice to use - if custom, use the customVoiceId
        const voiceToUse = settings.voice === 'custom' 
          ? (settings.customVoiceId || 'alloy') 
          : (settings.voice || 'alloy');

        const response = await playgroundApi.textToSpeech({
          model: selectedModel,
          input: input,
          voice: voiceToUse,
        });

        if (response.success && response.data) {
          // Create audio URL from blob response
          const audioBlob = response.data;
          const url = URL.createObjectURL(audioBlob);
          setAudioUrl(url);
          
          const assistantMessage = {
            role: 'assistant',
            content: url,
            type: 'audio',
          };
          setMessages((prev) => [...prev, assistantMessage]);
          showToast('Audio generated successfully', 'success');
          // Refresh credits after successful request
          refreshCredits();
        } else {
          showToast('Audio generation failed', 'error');
        }
      } else if (activeTab === 'embeddings') {
        const response = await playgroundApi.embeddings({
          model: selectedModel,
          input: input,
        });

        // Check for OpenAI format directly or wrapped format
        const embeddingData = response?.data?.[0] || response?.data?.data?.[0];
        const usage = response?.usage || response?.data?.usage;
        if (embeddingData?.embedding) {
          const assistantMessage = {
            role: 'assistant',
            content: JSON.stringify(embeddingData.embedding.slice(0, 10), null, 2) + '\n... (' + embeddingData.embedding.length + ' dimensions)',
            type: 'embedding',
            usage: usage,
          };
          setMessages((prev) => [...prev, assistantMessage]);
          // Refresh credits after successful request
          refreshCredits();
        } else {
          showToast('Failed to generate embeddings', 'error');
        }
      }
    } catch (error) {
      showToast(error.message || 'Request failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setMessages([]);
  };

  const copyToClipboard = async (text, id) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (error) {
      showToast('Failed to copy', 'error');
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const selectedModelData = models.find((m) => (m.modelId || m.id) === selectedModel);

  // Get model-specific options from the selected model
  const getModelOptions = useCallback(() => {
    if (!selectedModelData) return null;
    
    // Model options can come from options, modelSettings, or inputFields
    const options = selectedModelData.options || {};
    const modelSettings = selectedModelData.modelSettings || {};
    const inputFields = selectedModelData.inputFields || [];
    const inputTypes = selectedModelData.inputTypes || [];
    const capabilities = selectedModelData.capabilities || [];
    
    // Extract options from inputFields if needed
    let voices = options.voices || modelSettings.voices || [];
    let resolutions = options.resolutions || modelSettings.resolutions || [];
    let durations = options.durations || modelSettings.durations || [];
    let outputFormats = options.outputFormats || modelSettings.outputFormats || [];

    // Check inputFields for dropdown options
    if (Array.isArray(inputFields)) {
      inputFields.forEach(field => {
        if (field.key === 'voice' && field.options && !voices.length) {
          voices = field.options;
        }
        if (field.key === 'resolution' && field.options && !resolutions.length) {
          resolutions = field.options;
        }
        if (field.key === 'duration' && field.options && !durations.length) {
          durations = field.options;
        }
      });
    }
    
    // Determine if model supports image input
    const supportsImageInput = 
      inputTypes.includes('image') || 
      capabilities.includes('image-to-image') || 
      capabilities.includes('image-to-video') ||
      selectedModelData.type === 'IMAGE_TO_VIDEO' ||
      selectedModelData.type === 'IMAGE_TO_IMAGE';
    
    return {
      voices,
      resolutions,
      durations,
      outputFormats,
      inputTypes,
      capabilities,
      supportsImageInput,
      fps: options.fps || modelSettings.fps || 24,
    };
  }, [selectedModelData]);

  const modelOptions = getModelOptions();

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Playground</h1>
          <p className={styles.subtitle}>
            Test AI models in real-time.
          </p>
        </div>
        <div className={styles.concurrentStatus}>
          <Activity size={16} className={isAtLimit ? styles.concurrentAtLimit : ''} />
          <span className={isAtLimit ? styles.concurrentAtLimit : ''}>
            {concurrentCurrent}/{concurrentLimit} concurrent
          </span>
        </div>
      </div>

      <Tabs
        tabs={tabs.map((tab) => ({
          id: tab.id,
          label: tab.label,
          icon: <tab.icon size={16} />,
        }))}
        activeTab={activeTab}
        onChange={setActiveTab}
      />

      {/* API Key Warning */}
      {!apiKeysLoading && apiKeys.length === 0 && (
        <div className={styles.apiKeyWarning}>
          <Key size={16} />
          <span>You need to create an API key before using the playground.</span>
          <a href="/api-keys" className={styles.createKeyLink}>Create API Key</a>
        </div>
      )}

      <div className={styles.container}>
        {/* Main Chat Area */}
        <div className={styles.main}>
          <Card className={styles.chatCard}>
            {/* Model and API Key Selector */}
            <div className={styles.modelBar}>
              <div className={styles.modelSelect}>
                {modelsLoading ? (
                  <Skeleton width={200} height={32} />
                ) : (
                  <Select
                    options={filteredModels.map((model) => ({
                      value: model.modelId || model.id,
                      label: `${model.displayName || model.name || model.id} (${model.modelId || model.id})`,
                    }))}
                    value={selectedModel}
                    onChange={(e) => setSelectedModel(e.target.value)}
                    placeholder="Select a model..."
                  />
                )}
                {selectedModelData && (
                  <Badge variant="outline" size="sm">
                    {selectedModelData.tier}
                  </Badge>
                )}
              </div>
              
              {/* API Key Selector */}
              <div className={styles.apiKeySelect}>
                <Key size={14} className={styles.keyIcon} />
                {apiKeysLoading ? (
                  <Skeleton width={150} height={32} />
                ) : (
                  <Select
                    options={apiKeys.map((key) => ({
                      value: key.id,
                      label: `${key.name} (${key.keyPrefix}...)`,
                    }))}
                    value={selectedApiKey}
                    onChange={(e) => setSelectedApiKey(e.target.value)}
                    placeholder="Select API Key..."
                  />
                )}
              </div>
              
              <div className={styles.modelActions}>
                <Button
                  size="sm"
                  variant="ghost"
                  icon={<Trash2 size={14} />}
                  onClick={handleClear}
                  disabled={messages.length === 0}
                >
                  Clear
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  icon={<Settings size={14} />}
                  onClick={() => setShowSettings(!showSettings)}
                >
                  Settings
                </Button>
              </div>
            </div>

            {/* Settings Panel */}
            {showSettings && (
              <div className={styles.settingsPanel}>
                {activeTab === 'chat' && (
                  <>
                    <div className={styles.settingItem}>
                      <label>Temperature: {settings.temperature}</label>
                      <input
                        type="range"
                        min="0"
                        max="2"
                        step="0.1"
                        value={settings.temperature}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            temperature: parseFloat(e.target.value),
                          }))
                        }
                      />
                    </div>
                    <div className={styles.settingItem}>
                      <label>Max Tokens: {settings.maxTokens.toLocaleString()}</label>
                      <input
                        type="range"
                        min="1024"
                        max="65536"
                        step="1024"
                        value={settings.maxTokens}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            maxTokens: parseInt(e.target.value),
                          }))
                        }
                      />
                      <div className={styles.settingHint}>
                        Higher values allow longer responses (1K-65K tokens)
                      </div>
                    </div>
                  </>
                )}
                {activeTab === 'audio' && (
                  <>
                    <div className={styles.settingItem}>
                      <label>Voice</label>
                      <Select
                        options={
                          modelOptions?.voices?.length > 0
                            ? modelOptions.voices.map((v) => ({
                                value: v.id || v.value,
                                label: v.name || v.label,
                              }))
                            : [
                                { value: 'alloy', label: 'Alloy' },
                                { value: 'echo', label: 'Echo' },
                                { value: 'fable', label: 'Fable' },
                                { value: 'onyx', label: 'Onyx' },
                                { value: 'nova', label: 'Nova' },
                                { value: 'shimmer', label: 'Shimmer' },
                                { value: 'custom', label: '🔧 Custom Voice ID' },
                              ]
                        }
                        value={settings.voice}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            voice: e.target.value,
                          }))
                        }
                      />
                    </div>
                    {/* Custom Voice ID Input */}
                    {settings.voice === 'custom' && (
                      <div className={styles.settingItem}>
                        <label>Custom Voice ID</label>
                        <Input
                          type="text"
                          placeholder="Enter your custom voice ID..."
                          value={settings.customVoiceId || ''}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              customVoiceId: e.target.value,
                            }))
                          }
                        />
                      </div>
                    )}
                  </>
                )}
                {activeTab === 'image' && (
                  <>
                    {/* Resolution selector for image models */}
                    {modelOptions?.resolutions?.length > 0 && (
                      <div className={styles.settingItem}>
                        <label>Resolution</label>
                        <Select
                          options={modelOptions.resolutions.map((r) => ({
                            value: r.value,
                            label: r.label,
                          }))}
                          value={settings.imageResolution || modelOptions.resolutions[0]?.value}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              imageResolution: e.target.value,
                            }))
                          }
                        />
                      </div>
                    )}
                    {/* Image upload for image-to-image models */}
                    {modelOptions?.supportsImageInput && (
                      <div className={styles.settingItem}>
                        <label>Input Image (for image-to-image)</label>
                        {inputImagePreview ? (
                          <div className={styles.imagePreviewContainer}>
                            <img 
                              src={inputImagePreview} 
                              alt="Input preview" 
                              className={styles.imagePreview}
                            />
                            <button
                              className={styles.removeImageBtn}
                              onClick={() => {
                                setInputImage(null);
                                setInputImagePreview(null);
                                setUploadedAssetUrl(null);
                              }}
                            >
                              <X size={16} />
                            </button>
                            {uploadedAssetUrl && (
                              <span className={styles.uploadedBadge}>✓ Uploaded</span>
                            )}
                          </div>
                        ) : (
                          <label className={styles.imageUploadLabel}>
                            <input
                              type="file"
                              accept="image/*"
                              className={styles.imageUploadInput}
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  setInputImage(file);
                                  const reader = new FileReader();
                                  reader.onload = (ev) => {
                                    setInputImagePreview(ev.target?.result);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                            <div className={styles.imageUploadPlaceholder}>
                              <Upload size={24} />
                              <span>Click to upload source image</span>
                            </div>
                          </label>
                        )}
                      </div>
                    )}
                  </>
                )}
                {activeTab === 'video' && (
                  <>
                    {/* Duration selector for video models */}
                    {modelOptions?.durations?.length > 0 && (
                      <div className={styles.settingItem}>
                        <label>Duration</label>
                        <Select
                          options={modelOptions.durations.map((d) => ({
                            value: d.value,
                            label: d.label,
                          }))}
                          value={settings.videoDuration || modelOptions.durations[0]?.value}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              videoDuration: parseInt(e.target.value),
                            }))
                          }
                        />
                      </div>
                    )}
                    {/* Resolution selector for video models */}
                    {modelOptions?.resolutions?.length > 0 && (
                      <div className={styles.settingItem}>
                        <label>Resolution</label>
                        <Select
                          options={modelOptions.resolutions.map((r) => ({
                            value: r.value,
                            label: r.label,
                          }))}
                          value={settings.videoResolution || modelOptions.resolutions[0]?.value}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              videoResolution: e.target.value,
                            }))
                          }
                        />
                      </div>
                    )}
                    {/* Input type selector for models that support both text and image */}
                    {modelOptions?.supportsImageInput && (
                      <div className={styles.settingItem}>
                        <label>Input Type</label>
                        <Select
                          options={[
                            { value: 'text', label: 'Text to Video' },
                            { value: 'image', label: 'Image to Video' },
                          ]}
                          value={settings.videoInputType || 'text'}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              videoInputType: e.target.value,
                            }))
                          }
                        />
                      </div>
                    )}
                    {/* Show image upload when image input type is selected */}
                    {settings.videoInputType === 'image' && (
                      <div className={styles.settingItem}>
                        <label>Input Image</label>
                        {inputImagePreview ? (
                          <div className={styles.imagePreviewContainer}>
                            <img 
                              src={inputImagePreview} 
                              alt="Input preview" 
                              className={styles.imagePreview}
                            />
                            <button
                              className={styles.removeImageBtn}
                              onClick={() => {
                                setInputImage(null);
                                setInputImagePreview(null);
                                setUploadedAssetUrl(null);
                              }}
                            >
                              <X size={16} />
                            </button>
                            {uploadedAssetUrl && (
                              <span className={styles.uploadedBadge}>✓ Uploaded</span>
                            )}
                          </div>
                        ) : (
                          <label className={styles.imageUploadLabel}>
                            <input
                              type="file"
                              accept="image/*"
                              className={styles.imageUploadInput}
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  setInputImage(file);
                                  const reader = new FileReader();
                                  reader.onload = (ev) => {
                                    setInputImagePreview(ev.target?.result);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                            <div className={styles.imageUploadPlaceholder}>
                              <Upload size={24} />
                              <span>Click to upload image</span>
                            </div>
                          </label>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            {/* Messages */}
            <div className={styles.messages} ref={messagesContainerRef}>
              {messages.length === 0 ? (
                <div className={styles.emptyChat}>
                  <MessageSquare size={48} />
                  <p>Start a conversation</p>
                  <span>Select a model and type a message to begin.</span>
                </div>
              ) : (
                messages.map((message, index) => (
                  <div
                    key={index}
                    className={`${styles.message} ${
                      message.role === 'user' ? styles.userMessage : styles.assistantMessage
                    }`}
                  >
                    <div className={styles.messageHeader}>
                      <span className={styles.messageRole}>
                        {message.role === 'user' ? 'You' : selectedModelData?.name || 'Assistant'}
                      </span>
                      {message.usage && (
                        <span className={styles.messageUsage}>
                          {message.usage.prompt_tokens} + {message.usage.completion_tokens} tokens
                        </span>
                      )}
                    </div>
                    <div className={styles.messageContent}>
                      {message.type === 'image' ? (
                        <img
                          src={message.content}
                          alt="Generated"
                          className={styles.generatedImage}
                        />
                      ) : message.type === 'video' ? (
                        <div className={styles.videoPlayer}>
                          <video 
                            controls 
                            src={message.content} 
                            className={styles.generatedVideo}
                          >
                            Your browser does not support the video element.
                          </video>
                          <div className={styles.videoInfo}>
                            <span>{message.duration}s • {message.resolution}</span>
                            <a 
                              href={message.content} 
                              download="generated-video.mp4"
                              className={styles.downloadLink}
                            >
                              <Download size={14} /> Download
                            </a>
                          </div>
                        </div>
                      ) : message.type === 'video-pending' ? (
                        <div className={styles.videoPending}>
                          <div className={styles.pendingContent}>
                            <Loader2 size={20} className={styles.loadingIcon} />
                            <span>{message.content}</span>
                          </div>
                          {jobProgress > 0 && (
                            <div className={styles.progressBar}>
                              <div 
                                className={styles.progressFill} 
                                style={{ width: `${jobProgress}%` }}
                              />
                            </div>
                          )}
                          {currentJobId && (
                            <button 
                              className={styles.cancelButton}
                              onClick={async () => {
                                try {
                                  await playgroundApi.cancelVideoJob(currentJobId);
                                  setMessages((prev) => prev.filter((m) => m.type !== 'video-pending'));
                                  setCurrentJobId(null);
                                  setJobStatus(null);
                                  setLoading(false);
                                  showToast('Video generation cancelled', 'info');
                                } catch (e) {
                                  showToast('Failed to cancel generation', 'error');
                                }
                              }}
                            >
                              <X size={14} /> Cancel
                            </button>
                          )}
                        </div>
                      ) : message.type === 'audio' ? (
                        <div className={styles.audioPlayer}>
                          <audio controls src={message.content}>
                            Your browser does not support the audio element.
                          </audio>
                          <a 
                            href={message.content} 
                            download="generated-audio.mp3"
                            className={styles.downloadLink}
                          >
                            <Download size={14} /> Download
                          </a>
                        </div>
                      ) : message.type === 'embedding' ? (
                        <pre className={styles.embeddingOutput}>{message.content}</pre>
                      ) : (
                        <p>
                          {message.content}
                          {message.isStreaming && <span className={styles.streamingCursor} />}
                        </p>
                      )}
                    </div>
                    <button
                      className={styles.copyButton}
                      onClick={() => copyToClipboard(message.content, index)}
                    >
                      {copiedId === index ? <Check size={14} /> : <Copy size={14} />}
                    </button>
                  </div>
                ))
              )}
              {loading && !messages.some(m => m.isStreaming) && (
                <div className={`${styles.message} ${styles.assistantMessage}`}>
                  <div className={styles.messageContent}>
                    <Loader2 size={16} className={styles.loadingIcon} />
                    <span>Thinking...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className={styles.inputArea}>
              <textarea
                className={styles.input}
                placeholder={
                  activeTab === 'chat'
                    ? 'Type your message...'
                    : activeTab === 'image'
                    ? 'Describe the image you want to generate...'
                    : activeTab === 'video'
                    ? 'Describe the video you want to generate...'
                    : 'Enter your prompt...'
                }
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={1}
                disabled={loading || uploading || !selectedModel}
              />
              <Button
                icon={(loading || uploading) ? <Loader2 size={16} className={styles.loadingIcon} /> : <Send size={16} />}
                onClick={handleSend}
                disabled={loading || uploading || !input.trim() || !selectedModel}
              >
                {uploading ? 'Uploading...' : loading ? 'Generating...' : 'Send'}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}