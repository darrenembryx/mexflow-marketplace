'use client';

// src/app/(dashboard)/subscription/page.js

import { useState, useEffect } from 'react';
import styles from './page.module.css';
import { useSubscription } from '@/hooks/useSubscription';
import { publicApi, userApi } from '@/lib/api';
import { useToast } from '@/context/ToastContext';
import { formatPrice, formatCredits, formatDate } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Badge from '@/components/common/Badge';
import Skeleton from '@/components/common/Skeleton';
import Modal from '@/components/common/Modal';
import { Package, Check, Zap, ArrowRight } from 'lucide-react';

export default function SubscriptionPage() {
  const { subscription, loading: subscriptionLoading, refresh } = useSubscription();
  const { showToast } = useToast();
  
  const [packages, setPackages] = useState([]);
  const [loadingPackages, setLoadingPackages] = useState(true);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    fetchPackages();
  }, []);

  const fetchPackages = async () => {
    try {
      const response = await publicApi.getPackages();
      if (response.success) {
        setPackages(response.data.filter(pkg => pkg.type === 'SUBSCRIPTION'));
      }
    } catch (error) {
      console.error('Failed to fetch packages:', error);
    } finally {
      setLoadingPackages(false);
    }
  };

  const handleUpgrade = async () => {
    if (!selectedPackage) return;

    setProcessing(true);
    try {
      // This would call the subscription API
      showToast('Redirecting to payment...', 'info');
      setTimeout(() => {
        showToast('Subscription upgrade initiated.', 'success');
        setUpgradeModalOpen(false);
        setProcessing(false);
        refresh();
      }, 1000);
    } catch (error) {
      showToast(error.message || 'Failed to upgrade subscription', 'error');
      setProcessing(false);
    }
  };

  const currentPackage = subscription?.package;

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Subscription</h1>
          <p className={styles.subtitle}>
            Manage your subscription plan.
          </p>
        </div>
      </div>

      {/* Current Plan */}
      <Card className={styles.currentPlan}>
        <div className={styles.planHeader}>
          <h2 className={styles.planTitle}>Current Plan</h2>
          {subscription?.status && (
            <Badge 
              variant={subscription.status === 'ACTIVE' ? 'success' : 'warning'}
            >
              {subscription.status}
            </Badge>
          )}
        </div>

        {subscriptionLoading ? (
          <div className={styles.skeleton}>
            <Skeleton width={120} height={32} />
            <Skeleton width="80%" height={16} style={{ marginTop: 12 }} />
          </div>
        ) : currentPackage ? (
          <div className={styles.planContent}>
            <div className={styles.planInfo}>
              <span className={styles.planName}>{currentPackage.name}</span>
              <span className={styles.planPrice}>
                {formatPrice(currentPackage.price)}/month
              </span>
            </div>
            <div className={styles.planMeta}>
              <span>
                {formatCredits(subscription.currentCredits)} / {formatCredits(currentPackage.credits)} credits
              </span>
              {subscription.periodEnd && (
                <span>Renews on {formatDate(subscription.periodEnd, 'short')}</span>
              )}
            </div>
          </div>
        ) : (
          <div className={styles.noPlan}>
            <Package size={32} className={styles.noPlanIcon} />
            <span>No active subscription</span>
            <p>Choose a plan below to get started</p>
          </div>
        )}
      </Card>

      {/* Available Plans */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>Available Plans</h2>
        
        {loadingPackages ? (
          <div className={styles.packagesGrid}>
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <Skeleton height={200} />
              </Card>
            ))}
          </div>
        ) : (
          <div className={styles.packagesGrid}>
            {packages.map((pkg) => {
              const isCurrent = currentPackage?.id === pkg.id;
              const isUpgrade = currentPackage && pkg.price > currentPackage.price;
              
              return (
                <Card 
                  key={pkg.id}
                  className={`${styles.packageCard} ${isCurrent ? styles.currentPackage : ''}`}
                >
                  <div className={styles.packageHeader}>
                    <h3 className={styles.packageName}>{pkg.name}</h3>
                    {isCurrent && (
                      <Badge variant="primary" size="sm">Current</Badge>
                    )}
                  </div>
                  
                  <div className={styles.packagePrice}>
                    <span className={styles.priceAmount}>{formatPrice(pkg.price)}</span>
                    <span className={styles.pricePeriod}>/month</span>
                  </div>
                  
                  <p className={styles.packageCredits}>
                    {formatCredits(pkg.credits)} credits/month
                  </p>

                  <ul className={styles.packageFeatures}>
                    <li>
                      <Check size={16} />
                      <span>{pkg.rateLimitPerMin || 60} requests/minute</span>
                    </li>
                    <li>
                      <Check size={16} />
                      <span>{pkg.maxConcurrentRequests || 5} concurrent requests</span>
                    </li>
                    <li>
                      <Check size={16} />
                      <span>Access to {pkg.allowedModelTiers?.join(', ') || 'all'} tiers</span>
                    </li>
                    <li>
                      <Check size={16} />
                      <span>Priority support</span>
                    </li>
                  </ul>

                  <Button
                    fullWidth
                    variant={isCurrent ? 'secondary' : 'primary'}
                    disabled={isCurrent}
                    onClick={() => {
                      setSelectedPackage(pkg);
                      setUpgradeModalOpen(true);
                    }}
                  >
                    {isCurrent ? 'Current Plan' : isUpgrade ? 'Upgrade' : 'Select'}
                  </Button>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Upgrade Modal */}
      <Modal
        isOpen={upgradeModalOpen}
        onClose={() => setUpgradeModalOpen(false)}
        title={`Upgrade to ${selectedPackage?.name}`}
      >
        {selectedPackage && (
          <div className={styles.upgradeModal}>
            <div className={styles.upgradeInfo}>
              <div className={styles.upgradePackage}>
                <span className={styles.upgradeName}>{selectedPackage.name}</span>
                <span className={styles.upgradePrice}>
                  {formatPrice(selectedPackage.price)}/month
                </span>
              </div>
              <ul className={styles.upgradeFeatures}>
                <li>
                  <Check size={16} />
                  <span>{formatCredits(selectedPackage.credits)} credits/month</span>
                </li>
                <li>
                  <Check size={16} />
                  <span>{selectedPackage.rateLimitPerMin || 60} requests/minute</span>
                </li>
                <li>
                  <Check size={16} />
                  <span>{selectedPackage.maxConcurrentRequests || 5} concurrent requests</span>
                </li>
              </ul>
            </div>

            <div className={styles.modalActions}>
              <Button variant="secondary" onClick={() => setUpgradeModalOpen(false)}>
                Cancel
              </Button>
              <Button loading={processing} onClick={handleUpgrade}>
                Confirm Upgrade
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
