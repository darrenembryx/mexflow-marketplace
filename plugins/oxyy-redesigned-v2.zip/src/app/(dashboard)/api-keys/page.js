'use client';

// src/app/(dashboard)/api-keys/page.js

import { useState } from 'react';
import styles from './page.module.css';
import { useApiKeys } from '@/hooks/useApiKeys';
import { useToast } from '@/context/ToastContext';
import { userApi } from '@/lib/api';
import { formatDate } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Input from '@/components/common/Input';
import Modal from '@/components/common/Modal';
import Badge from '@/components/common/Badge';
import Skeleton from '@/components/common/Skeleton';
import EmptyState from '@/components/common/EmptyState';
import { Key, Plus, Copy, Trash2, Eye, EyeOff, Check } from 'lucide-react';

export default function ApiKeysPage() {
  const { apiKeys, loading, error, refresh } = useApiKeys();
  const { showToast } = useToast();
  
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [selectedKey, setSelectedKey] = useState(null);
  const [newKeyName, setNewKeyName] = useState('');
  const [newKey, setNewKey] = useState(null);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [copiedId, setCopiedId] = useState(null);
  const [visibleKeys, setVisibleKeys] = useState({});

  const handleCreate = async () => {
    if (!newKeyName.trim()) {
      showToast('Please enter a name for the API key', 'error');
      return;
    }

    setCreating(true);
    try {
      const response = await userApi.createApiKey({ name: newKeyName });
      if (response.success) {
        setNewKey(response.data.key);
        refresh();
        showToast('API key created successfully', 'success');
      }
    } catch (error) {
      showToast(error.message || 'Failed to create API key', 'error');
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedKey) return;

    setDeleting(true);
    try {
      const response = await userApi.deleteApiKey(selectedKey.id);
      if (response.success) {
        refresh();
        showToast('API key deleted successfully', 'success');
        setDeleteModalOpen(false);
        setSelectedKey(null);
      }
    } catch (error) {
      showToast(error.message || 'Failed to delete API key', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const copyToClipboard = async (text, id) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (error) {
      showToast('Failed to copy to clipboard', 'error');
    }
  };

  const toggleKeyVisibility = (id) => {
    setVisibleKeys((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const closeCreateModal = () => {
    setCreateModalOpen(false);
    setNewKeyName('');
    setNewKey(null);
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>API Keys</h1>
          <p className={styles.subtitle}>
            Manage your API keys for accessing the Oxyy.ai API.
          </p>
        </div>
        <Button 
          icon={<Plus size={16} />}
          onClick={() => setCreateModalOpen(true)}
        >
          Create Key
        </Button>
      </div>

      <Card>
        {loading ? (
          <div className={styles.skeleton}>
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} height={72} style={{ marginBottom: 12 }} />
            ))}
          </div>
        ) : error ? (
          <EmptyState
            icon={Key}
            title="Failed to load API keys"
            description={error.message || "Something went wrong while loading your API keys."}
            action={
              <Button 
                variant="secondary"
                onClick={() => refresh()}
              >
                Try Again
              </Button>
            }
          />
        ) : apiKeys.length === 0 ? (
          <EmptyState
            icon={Key}
            title="No API keys yet"
            description="Create an API key to start using the Oxyy.ai API."
            action={
              <Button 
                icon={<Plus size={16} />}
                onClick={() => setCreateModalOpen(true)}
              >
                Create Key
              </Button>
            }
          />
        ) : (
          <div className={styles.keyList}>
            {apiKeys.map((key) => (
              <div key={key.id} className={styles.keyItem}>
                <div className={styles.keyInfo}>
                  <div className={styles.keyName}>
                    <Key size={16} />
                    <span>{key.name}</span>
                    <Badge 
                      variant={key.status === 'ACTIVE' ? 'success' : 'error'}
                      size="sm"
                    >
                      {key.status}
                    </Badge>
                  </div>
                  <div className={styles.keyMeta}>
                    <code className={styles.keyPrefix}>
                      {visibleKeys[key.id] ? `${key.keyPrefix}...` : `${key.keyPrefix}${'•'.repeat(24)}`}
                    </code>
                    <span className={styles.keyDate}>
                      Created {formatDate(key.createdAt, 'relative')}
                    </span>
                    {key.lastUsedAt && (
                      <span className={styles.keyDate}>
                        Last used {formatDate(key.lastUsedAt, 'relative')}
                      </span>
                    )}
                  </div>
                </div>
                <div className={styles.keyActions}>
                  <button
                    className={styles.iconButton}
                    onClick={() => toggleKeyVisibility(key.id)}
                    title={visibleKeys[key.id] ? 'Hide' : 'Show'}
                  >
                    {visibleKeys[key.id] ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                  <button
                    className={styles.iconButton}
                    onClick={() => copyToClipboard(key.keyPrefix, key.id)}
                    title="Copy prefix"
                  >
                    {copiedId === key.id ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                  <button
                    className={styles.iconButtonDanger}
                    onClick={() => {
                      setSelectedKey(key);
                      setDeleteModalOpen(true);
                    }}
                    title="Delete"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Create Key Modal */}
      <Modal
        isOpen={createModalOpen}
        onClose={closeCreateModal}
        title={newKey ? 'API Key Created' : 'Create API Key'}
      >
        {newKey ? (
          <div className={styles.newKeyModal}>
            <p className={styles.newKeyWarning}>
              Make sure to copy your API key now. You won't be able to see it again!
            </p>
            <div className={styles.newKeyBox}>
              <code className={styles.newKeyValue}>{newKey}</code>
              <Button
                size="sm"
                variant="secondary"
                icon={copiedId === 'new' ? <Check size={14} /> : <Copy size={14} />}
                onClick={() => copyToClipboard(newKey, 'new')}
              >
                {copiedId === 'new' ? 'Copied!' : 'Copy'}
              </Button>
            </div>
            <Button fullWidth onClick={closeCreateModal}>
              Done
            </Button>
          </div>
        ) : (
          <div className={styles.createForm}>
            <Input
              label="Key Name"
              placeholder="e.g., Production, Development"
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              autoFocus
            />
            <div className={styles.modalActions}>
              <Button variant="secondary" onClick={closeCreateModal}>
                Cancel
              </Button>
              <Button loading={creating} onClick={handleCreate}>
                Create Key
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        title="Delete API Key"
      >
        <div className={styles.deleteModal}>
          <p>
            Are you sure you want to delete the API key <strong>{selectedKey?.name}</strong>?
            This action cannot be undone.
          </p>
          <div className={styles.modalActions}>
            <Button variant="secondary" onClick={() => setDeleteModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="danger" loading={deleting} onClick={handleDelete}>
              Delete Key
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
