'use client';

// src/app/(dashboard)/settings/page.js

import { useState } from 'react';
import styles from './page.module.css';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/context/ToastContext';
import { userApi, authApi } from '@/lib/api';
import Card from '@/components/common/Card';
import Input from '@/components/common/Input';
import Select from '@/components/common/Select';
import Button from '@/components/common/Button';
import Tabs from '@/components/common/Tabs';
import { User, Lock, Bell, Palette, Shield } from 'lucide-react';

const tabs = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'security', label: 'Security', icon: Lock },
  { id: 'appearance', label: 'Appearance', icon: Palette },
];

const themeOptions = [
  { value: 'system', label: 'System' },
  { value: 'light', label: 'Light' },
  { value: 'dark', label: 'Dark' },
];

export default function SettingsPage() {
  const { user, updateProfile, refreshUser } = useAuth();
  const { theme, setTheme } = useTheme();
  const { showToast } = useToast();
  
  const [activeTab, setActiveTab] = useState('profile');
  const [saving, setSaving] = useState(false);
  
  // Profile form
  const [profileData, setProfileData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
  });
  
  // Password form
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [passwordErrors, setPasswordErrors] = useState({});

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfileData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordData((prev) => ({ ...prev, [name]: value }));
    if (passwordErrors[name]) {
      setPasswordErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      await updateProfile({
        firstName: profileData.firstName,
        lastName: profileData.lastName,
      });
      showToast('Profile updated successfully', 'success');
    } catch (error) {
      showToast(error.message || 'Failed to update profile', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    
    const errors = {};
    if (!passwordData.currentPassword) {
      errors.currentPassword = 'Current password is required';
    }
    if (!passwordData.newPassword) {
      errors.newPassword = 'New password is required';
    } else if (passwordData.newPassword.length < 8) {
      errors.newPassword = 'Password must be at least 8 characters';
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }
    
    if (Object.keys(errors).length > 0) {
      setPasswordErrors(errors);
      return;
    }

    setSaving(true);
    try {
      await authApi.changePassword(passwordData.currentPassword, passwordData.newPassword);
      showToast('Password changed successfully', 'success');
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (error) {
      showToast(error.message || 'Failed to change password', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>Settings</h1>
        <p className={styles.subtitle}>
          Manage your account settings and preferences.
        </p>
      </div>

      <Tabs
        tabs={tabs.map((tab) => ({
          id: tab.id,
          label: tab.label,
          icon: <tab.icon size={16} />,
        }))}
        activeTab={activeTab}
        onChange={setActiveTab}
      />

      <div className={styles.content}>
        {activeTab === 'profile' && (
          <Card>
            <h2 className={styles.cardTitle}>Profile Information</h2>
            <p className={styles.cardDescription}>
              Update your personal information.
            </p>
            
            <form onSubmit={handleProfileSubmit} className={styles.form}>
              <div className={styles.row}>
                <Input
                  label="First name"
                  name="firstName"
                  value={profileData.firstName}
                  onChange={handleProfileChange}
                  placeholder="John"
                />
                <Input
                  label="Last name"
                  name="lastName"
                  value={profileData.lastName}
                  onChange={handleProfileChange}
                  placeholder="Doe"
                />
              </div>
              
              <Input
                label="Email"
                name="email"
                type="email"
                value={profileData.email}
                disabled
                hint="Email cannot be changed"
              />

              <div className={styles.formActions}>
                <Button type="submit" loading={saving}>
                  Save Changes
                </Button>
              </div>
            </form>
          </Card>
        )}

        {activeTab === 'security' && (
          <Card>
            <h2 className={styles.cardTitle}>Change Password</h2>
            <p className={styles.cardDescription}>
              Update your password to keep your account secure.
            </p>
            
            <form onSubmit={handlePasswordSubmit} className={styles.form}>
              <Input
                label="Current password"
                name="currentPassword"
                type="password"
                value={passwordData.currentPassword}
                onChange={handlePasswordChange}
                error={passwordErrors.currentPassword}
                placeholder="••••••••"
              />
              
              <Input
                label="New password"
                name="newPassword"
                type="password"
                value={passwordData.newPassword}
                onChange={handlePasswordChange}
                error={passwordErrors.newPassword}
                hint="Must be at least 8 characters"
                placeholder="••••••••"
              />
              
              <Input
                label="Confirm new password"
                name="confirmPassword"
                type="password"
                value={passwordData.confirmPassword}
                onChange={handlePasswordChange}
                error={passwordErrors.confirmPassword}
                placeholder="••••••••"
              />

              <div className={styles.formActions}>
                <Button type="submit" loading={saving}>
                  Change Password
                </Button>
              </div>
            </form>
          </Card>
        )}

        {activeTab === 'appearance' && (
          <Card>
            <h2 className={styles.cardTitle}>Appearance</h2>
            <p className={styles.cardDescription}>
              Customize how Oxyy.ai looks on your device.
            </p>
            
            <div className={styles.form}>
              <div className={styles.setting}>
                <div className={styles.settingInfo}>
                  <span className={styles.settingLabel}>Theme</span>
                  <span className={styles.settingDescription}>
                    Select your preferred color theme
                  </span>
                </div>
                <div className={styles.settingControl}>
                  <Select
                    options={themeOptions}
                    value={theme}
                    onChange={(e) => setTheme(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
