'use client';

// src/app/(dashboard)/billing/page.js

import { useState, useEffect } from 'react';
import styles from './page.module.css';
import { userApi } from '@/lib/api';
import { useCredits } from '@/hooks/useCredits';
import { useToast } from '@/context/ToastContext';
import { formatPrice, formatCredits, formatDate } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Input from '@/components/common/Input';
import Modal from '@/components/common/Modal';
import Badge from '@/components/common/Badge';
import Table from '@/components/common/Table';
import Skeleton from '@/components/common/Skeleton';
import EmptyState from '@/components/common/EmptyState';
import { CreditCard, Plus, DollarSign, Zap, Bitcoin, Clock } from 'lucide-react';

const creditPackages = [
  { credits: 100000, price: 5, popular: false },
  { credits: 500000, price: 20, popular: true },
  { credits: 1000000, price: 35, popular: false },
  { credits: 5000000, price: 150, popular: false },
];

const paymentMethods = [
  { id: 'stripe', name: 'Credit Card', icon: CreditCard, description: 'Pay with Visa, Mastercard, etc.' },
  { id: 'crypto', name: 'Cryptocurrency', icon: Bitcoin, description: 'Pay with BTC, ETH, USDT, etc.' },
];

export default function BillingPage() {
  const { credits, loading: creditsLoading } = useCredits();
  const { showToast } = useToast();
  
  const [transactions, setTransactions] = useState([]);
  const [loadingTransactions, setLoadingTransactions] = useState(true);
  const [topUpModalOpen, setTopUpModalOpen] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('stripe');
  const [customAmount, setCustomAmount] = useState('');
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    try {
      const response = await userApi.getTransactions();
      if (response.success) {
        setTransactions(response.data);
      }
    } catch (error) {
      console.error('Failed to fetch transactions:', error);
    } finally {
      setLoadingTransactions(false);
    }
  };

  const handleTopUp = async () => {
    const packageToUse = selectedPackage || {
      credits: parseInt(customAmount) * 20000, // ~20k credits per dollar
      price: parseInt(customAmount),
    };

    if (!packageToUse.price || packageToUse.price < 5) {
      showToast('Minimum top-up amount is $5', 'error');
      return;
    }

    setProcessing(true);
    try {
      // This would call the payment API
      showToast('Redirecting to payment...', 'info');
      // For demo, just show success
      setTimeout(() => {
        showToast('Payment initiated. Complete the payment to receive credits.', 'success');
        setTopUpModalOpen(false);
        setProcessing(false);
      }, 1000);
    } catch (error) {
      showToast(error.message || 'Failed to initiate payment', 'error');
      setProcessing(false);
    }
  };

  const transactionColumns = [
    {
      key: 'createdAt',
      header: 'Date',
      render: (value) => (
        <span className={styles.dateCell}>
          <Clock size={12} />
          {formatDate(value, 'datetime')}
        </span>
      ),
    },
    {
      key: 'type',
      header: 'Type',
      render: (value) => (
        <Badge 
          variant={value === 'CREDIT' ? 'success' : value === 'DEBIT' ? 'error' : 'info'}
          size="sm"
        >
          {value}
        </Badge>
      ),
    },
    {
      key: 'description',
      header: 'Description',
    },
    {
      key: 'amount',
      header: 'Amount',
      render: (value, row) => (
        <span className={row.type === 'CREDIT' ? styles.creditAmount : styles.debitAmount}>
          {row.type === 'CREDIT' ? '+' : '-'}{formatCredits(Math.abs(value))}
        </span>
      ),
    },
    {
      key: 'balance',
      header: 'Balance',
      render: (value) => formatCredits(value),
    },
  ];

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Billing</h1>
          <p className={styles.subtitle}>
            Manage your credits and view transaction history.
          </p>
        </div>
      </div>

      {/* Credits Card */}
      <Card className={styles.creditsCard}>
        <div className={styles.creditsInfo}>
          <div className={styles.creditsIcon}>
            <Zap size={32} />
          </div>
          <div className={styles.creditsContent}>
            <span className={styles.creditsLabel}>Available Credits</span>
            {creditsLoading ? (
              <Skeleton width={120} height={36} />
            ) : (
              <span className={styles.creditsValue}>{formatCredits(credits)}</span>
            )}
          </div>
        </div>
        <Button 
          icon={<Plus size={16} />}
          onClick={() => setTopUpModalOpen(true)}
        >
          Add Credits
        </Button>
      </Card>

      {/* Transaction History */}
      <Card>
        <div className={styles.cardHeader}>
          <h2 className={styles.cardTitle}>Transaction History</h2>
        </div>
        
        {loadingTransactions ? (
          <div className={styles.skeleton}>
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} height={48} style={{ marginBottom: 8 }} />
            ))}
          </div>
        ) : transactions.length === 0 ? (
          <EmptyState
            icon={CreditCard}
            title="No transactions yet"
            description="Your transaction history will appear here."
          />
        ) : (
          <Table
            columns={transactionColumns}
            data={transactions}
            hoverable
          />
        )}
      </Card>

      {/* Top Up Modal */}
      <Modal
        isOpen={topUpModalOpen}
        onClose={() => {
          setTopUpModalOpen(false);
          setSelectedPackage(null);
          setCustomAmount('');
        }}
        title="Add Credits"
        size="lg"
      >
        <div className={styles.topUpModal}>
          <div className={styles.packageGrid}>
            {creditPackages.map((pkg) => (
              <button
                key={pkg.credits}
                className={`${styles.packageCard} ${selectedPackage?.credits === pkg.credits ? styles.selected : ''}`}
                onClick={() => {
                  setSelectedPackage(pkg);
                  setCustomAmount('');
                }}
              >
                {pkg.popular && <span className={styles.popularBadge}>Popular</span>}
                <span className={styles.packageCredits}>{formatCredits(pkg.credits)}</span>
                <span className={styles.packagePrice}>{formatPrice(pkg.price)}</span>
              </button>
            ))}
          </div>

          <div className={styles.customAmount}>
            <span className={styles.customLabel}>Or enter custom amount</span>
            <div className={styles.customInput}>
              <span className={styles.currencyPrefix}>$</span>
              <Input
                type="number"
                placeholder="0"
                value={customAmount}
                onChange={(e) => {
                  setCustomAmount(e.target.value);
                  setSelectedPackage(null);
                }}
                min={5}
              />
            </div>
          </div>

          <div className={styles.paymentMethods}>
            <span className={styles.paymentLabel}>Payment Method</span>
            <div className={styles.paymentGrid}>
              {paymentMethods.map((method) => {
                const Icon = method.icon;
                return (
                  <button
                    key={method.id}
                    className={`${styles.paymentCard} ${selectedPaymentMethod === method.id ? styles.selected : ''}`}
                    onClick={() => setSelectedPaymentMethod(method.id)}
                  >
                    <Icon size={24} />
                    <span className={styles.paymentName}>{method.name}</span>
                    <span className={styles.paymentDesc}>{method.description}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className={styles.modalActions}>
            <Button
              variant="secondary"
              onClick={() => setTopUpModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              loading={processing}
              onClick={handleTopUp}
              disabled={!selectedPackage && (!customAmount || parseInt(customAmount) < 5)}
            >
              Pay {selectedPackage ? formatPrice(selectedPackage.price) : customAmount ? formatPrice(parseInt(customAmount)) : ''}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
