// src/app/(dashboard)/dashboard/page.js
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import styles from './page.module.css';
import { useAuth } from '@/context/AuthContext';
import { useCredits } from '@/hooks/useCredits';
import { useUsage } from '@/hooks/useUsage';
import { useApiKeys } from '@/hooks/useApiKeys';
import { useSubscription } from '@/hooks/useSubscription';
import { ROUTES } from '@/lib/constants';
import { formatCredits, formatNumber, formatDate } from '@/lib/formatters';
import Card from '@/components/common/Card';
import Button from '@/components/common/Button';
import Badge from '@/components/common/Badge';
import Skeleton from '@/components/common/Skeleton';
import { 
  CreditCard, 
  Key, 
  BarChart2, 
  Package, 
  ArrowRight,
  TrendingUp,
  TrendingDown,
  Zap,
  Clock,
  ExternalLink
} from 'lucide-react';

export default function DashboardPage() {
  const { user } = useAuth();
  const { credits, loading: creditsLoading } = useCredits();
  const { usage, loading: usageLoading } = useUsage({ limit: 5 });
  const { apiKeys, loading: apiKeysLoading } = useApiKeys();
  const { subscription, loading: subscriptionLoading } = useSubscription();

  const todayUsage = usage?.records?.filter(record => {
    const recordDate = new Date(record.createdAt);
    const today = new Date();
    return recordDate.toDateString() === today.toDateString();
  }) || [];

  const totalRequestsToday = todayUsage.length;

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>
            Welcome back{user?.firstName ? `, ${user.firstName}` : ''}
          </h1>
          <p className={styles.subtitle}>
            Here's an overview of your account
          </p>
        </div>
        <Link href={ROUTES.PLAYGROUND}>
          <Button size="sm" icon={<Zap size={14} />}>
            Playground
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className={styles.statsGrid}>
        <Card className={styles.statCard}>
          <div className={styles.statHeader}>
            <div className={styles.statIcon}>
              <CreditCard size={16} />
            </div>
            <Link href={ROUTES.BILLING} className={styles.statLink}>
              <ArrowRight size={14} />
            </Link>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statLabel}>Credits</span>
            {creditsLoading ? (
              <Skeleton width={80} height={24} />
            ) : (
              <span className={styles.statValue}>{formatCredits(credits)}</span>
            )}
          </div>
        </Card>

        <Card className={styles.statCard}>
          <div className={styles.statHeader}>
            <div className={styles.statIcon}>
              <Key size={16} />
            </div>
            <Link href={ROUTES.API_KEYS} className={styles.statLink}>
              <ArrowRight size={14} />
            </Link>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statLabel}>API Keys</span>
            {apiKeysLoading ? (
              <Skeleton width={40} height={24} />
            ) : (
              <span className={styles.statValue}>{apiKeys?.length || 0}</span>
            )}
          </div>
        </Card>

        <Card className={styles.statCard}>
          <div className={styles.statHeader}>
            <div className={styles.statIcon}>
              <BarChart2 size={16} />
            </div>
            <Link href={ROUTES.USAGE} className={styles.statLink}>
              <ArrowRight size={14} />
            </Link>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statLabel}>Requests Today</span>
            {usageLoading ? (
              <Skeleton width={40} height={24} />
            ) : (
              <span className={styles.statValue}>{formatNumber(totalRequestsToday)}</span>
            )}
          </div>
        </Card>

        <Card className={styles.statCard}>
          <div className={styles.statHeader}>
            <div className={styles.statIcon}>
              <Package size={16} />
            </div>
            <Link href={ROUTES.SUBSCRIPTION} className={styles.statLink}>
              <ArrowRight size={14} />
            </Link>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statLabel}>Plan</span>
            {subscriptionLoading ? (
              <Skeleton width={60} height={24} />
            ) : (
              <span className={styles.statValue}>
                {subscription?.package?.name || 'Free'}
              </span>
            )}
          </div>
        </Card>
      </div>

      <div className={styles.grid}>
        {/* Recent Activity */}
        <Card className={styles.activityCard}>
          <div className={styles.cardHeader}>
            <h2 className={styles.cardTitle}>Recent Activity</h2>
            <Link href={ROUTES.USAGE}>
              <Button size="xs" variant="ghost">
                View all <ArrowRight size={12} />
              </Button>
            </Link>
          </div>
          
          {usageLoading ? (
            <div className={styles.activityList}>
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} height={44} style={{ marginBottom: 8 }} />
              ))}
            </div>
          ) : usage?.records?.length > 0 ? (
            <div className={styles.activityList}>
              {usage.records.slice(0, 5).map((record) => (
                <div key={record.id} className={styles.activityItem}>
                  <div className={styles.activityInfo}>
                    <span className={styles.activityModel}>{record.model}</span>
                    <span className={styles.activityTime}>
                      <Clock size={10} />
                      {formatDate(record.createdAt, 'relative')}
                    </span>
                  </div>
                  <div className={styles.activityMeta}>
                    {record.inputTokens && (
                      <span className={styles.tokenBadge}>
                        <TrendingUp size={10} />
                        {formatNumber(record.inputTokens)}
                      </span>
                    )}
                    {record.outputTokens && (
                      <span className={styles.tokenBadge}>
                        <TrendingDown size={10} />
                        {formatNumber(record.outputTokens)}
                      </span>
                    )}
                    <Badge variant="outline" size="sm">
                      -{formatCredits(record.creditsUsed)}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className={styles.emptyState}>
              <p>No recent activity</p>
              <Link href={ROUTES.PLAYGROUND}>
                <Button size="sm" variant="outline">Start using API</Button>
              </Link>
            </div>
          )}
        </Card>

        {/* Quick Actions */}
        <Card className={styles.actionsCard}>
          <h2 className={styles.cardTitle}>Quick Actions</h2>
          
          <div className={styles.actionList}>
            <Link href={ROUTES.PLAYGROUND} className={styles.actionItem}>
              <div className={styles.actionIcon}>
                <Zap size={16} />
              </div>
              <div className={styles.actionContent}>
                <span className={styles.actionTitle}>AI Playground</span>
                <span className={styles.actionDesc}>Test models in real-time</span>
              </div>
              <ExternalLink size={14} className={styles.actionArrow} />
            </Link>

            <Link href={ROUTES.API_KEYS} className={styles.actionItem}>
              <div className={styles.actionIcon}>
                <Key size={16} />
              </div>
              <div className={styles.actionContent}>
                <span className={styles.actionTitle}>Create API Key</span>
                <span className={styles.actionDesc}>Generate a new key</span>
              </div>
              <ExternalLink size={14} className={styles.actionArrow} />
            </Link>

            <Link href={ROUTES.DOCS} className={styles.actionItem}>
              <div className={styles.actionIcon}>
                <BarChart2 size={16} />
              </div>
              <div className={styles.actionContent}>
                <span className={styles.actionTitle}>Documentation</span>
                <span className={styles.actionDesc}>Learn how to integrate</span>
              </div>
              <ExternalLink size={14} className={styles.actionArrow} />
            </Link>

            <Link href={ROUTES.BILLING} className={styles.actionItem}>
              <div className={styles.actionIcon}>
                <CreditCard size={16} />
              </div>
              <div className={styles.actionContent}>
                <span className={styles.actionTitle}>Add Credits</span>
                <span className={styles.actionDesc}>Top up your balance</span>
              </div>
              <ExternalLink size={14} className={styles.actionArrow} />
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
