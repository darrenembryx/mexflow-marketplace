// src/app/layout.js

import './globals.css';
import { AuthProvider } from '@/context/AuthContext';
import { ThemeProvider } from '@/context/ThemeContext';
import { ToastProvider } from '@/context/ToastContext';
import { SidebarProvider } from '@/context/SidebarContext';
import ToastContainer from '@/components/common/Toast/Toast';

export const metadata = {
  title: 'Oxyy.ai - Unified AI Gateway',
  description: 'Access all major AI models through one unified API. OpenAI SDK compatible. Pay-as-you-go with credit-based pricing.',
  keywords: 'AI, API, GPT, Claude, Gemini, Llama, AI Gateway, OpenAI compatible',
  authors: [{ name: 'Oxyy.ai' }],
  openGraph: {
    title: 'Oxyy.ai - Unified AI Gateway',
    description: 'Access all major AI models through one unified API.',
    type: 'website',
    locale: 'en_US',
    siteName: 'Oxyy.ai',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Oxyy.ai - Unified AI Gateway',
    description: 'Access all major AI models through one unified API.',
  },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#0a0a0a' },
  ],
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
      </head>
      <body>
        <ThemeProvider>
          <AuthProvider>
            <ToastProvider>
              <SidebarProvider>
                {children}
                <ToastContainer />
              </SidebarProvider>
            </ToastProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
