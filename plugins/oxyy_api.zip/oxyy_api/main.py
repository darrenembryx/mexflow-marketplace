"""
OpenAI Compatible Plugin - Universal multi-type plugin for OpenAI SDK compatible APIs
======================================================================================

This plugin supports multiple service types through a single API:
- ai_provider: Text/chat completions (GPT-4, GPT-3.5, etc.)
- image_generator: Image generation (DALL-E, etc.)
- video_generator: Video generation (Sora, etc.)
- audio_generator: Text-to-speech (TTS-1, etc.)
- subtitle_generator: Speech-to-text transcription (Whisper, etc.)

Works with any OpenAI SDK compatible endpoint:
- OpenAI, Azure OpenAI, Together AI, Groq, Fireworks, Ollama, LM Studio, etc.
"""

import json
import logging
import time
import base64
import os
from typing import Dict, Any, Optional

logger = logging.getLogger("mexflow.plugins.openai_compatible")


class OpenAICompatiblePlugin:
    """
    Universal plugin for OpenAI SDK compatible APIs.
    Supports multiple plugin types (ai_provider, image_generator, 
    video_generator, audio_generator, subtitle_generator) through
    a single API key and endpoint.
    """

    def __init__(self, context=None):
        """Initialize the plugin with context."""
        self._context = context
        self._settings = {}
        self._api_key = ""
        self._base_url = "https://oxy.ytubetools.com/v1"
        self._default_model = "gemini-2.5-flash"
        self._organization = ""
        self._timeout = 300
        
        if context:
            self._settings = context.get_settings()
            self._api_key = self._settings.get("api_key", "")
            self._base_url = self._settings.get("base_url", "https://api.openai.com/v1").rstrip("/")
            self._default_model = self._settings.get("default_model", "gpt-4o-mini")
            self._organization = self._settings.get("organization", "")
            self._timeout = int(self._settings.get("request_timeout", 300))

    def _get_headers(self) -> Dict[str, str]:
        """Get API request headers."""
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json"
        }
        if self._organization:
            headers["OpenAI-Organization"] = self._organization
        return headers

    def _get_active_type(self, inputs: Dict[str, Any]) -> str:
        """Determine which plugin type is being executed."""
        # Check context for active_type (set by multi-type system)
        if self._context and hasattr(self._context, '_extra_context'):
            active_type = self._context._extra_context.get("active_type", "")
            if active_type:
                return active_type
        
        # Fallback: infer from inputs
        if "text" in inputs and "voice" in inputs:
            return "audio_generator"
        if "language" in inputs and ("stt_model" in inputs or "response_format_stt" in inputs):
            return "subtitle_generator"
        if "image_model" in inputs or "image_size" in inputs:
            return "image_generator"
        if "video_model" in inputs or "video_duration" in inputs:
            return "video_generator"
        
        return "ai_provider"

    async def execute(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the plugin based on the active type.
        Routes to the appropriate handler method.
        """
        import httpx
        
        if not self._api_key:
            return {
                "success": False,
                "error": "API key is not configured. Please set your API key in plugin settings."
            }

        active_type = self._get_active_type(inputs)
        logger.info(f"OpenAI Compatible Plugin executing as: {active_type}")
        
        if self._context:
            await self._context.report_progress(
                stage="Initializing",
                progress=5,
                message=f"Executing as {active_type}..."
            )

        try:
            if active_type == "ai_provider":
                return await self._execute_text_generation(inputs)
            elif active_type == "image_generator":
                return await self._execute_image_generation(inputs)
            elif active_type == "video_generator":
                return await self._execute_video_generation(inputs)
            elif active_type == "audio_generator":
                return await self._execute_audio_generation(inputs)
            elif active_type == "subtitle_generator":
                return await self._execute_subtitle_generation(inputs)
            else:
                return {
                    "success": False,
                    "error": f"Unknown active type: {active_type}"
                }
        except httpx.HTTPStatusError as e:
            error_body = ""
            try:
                error_body = e.response.json()
                error_msg = error_body.get("error", {}).get("message", str(e))
            except Exception:
                error_msg = str(e)
            logger.error(f"API error: {error_msg}")
            return {
                "success": False,
                "error": f"API Error ({e.response.status_code}): {error_msg}"
            }
        except httpx.ConnectError as e:
            return {
                "success": False,
                "error": f"Connection error: Could not connect to {self._base_url}. Please check the API Base URL in settings."
            }
        except httpx.TimeoutException:
            return {
                "success": False,
                "error": f"Request timed out after {self._timeout} seconds. Try increasing the timeout in settings."
            }
        except Exception as e:
            logger.error(f"Plugin execution error: {e}", exc_info=True)
            return {
                "success": False,
                "error": f"Execution error: {str(e)}"
            }

    # ==================== AI Provider (Text Generation) ====================
    
    async def _execute_text_generation(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Handle text/chat completion requests with streaming support."""
        import httpx
        
        # Determine model
        model = inputs.get("model", "") or self._default_model
        if model == "custom":
            model = inputs.get("custom_model", self._default_model)
        if not model:
            model = self._default_model

        temperature = float(inputs.get("temperature", 0.7))
        max_tokens = int(inputs.get("max_tokens", 64000))
        
        # Get prompt from inputs (can come from various sources)
        prompt = inputs.get("prompt", "")
        system_prompt = inputs.get("system_prompt", "")
        
        # Build messages
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        if prompt:
            messages.append({"role": "user", "content": prompt})
        
        if not messages:
            return {"success": False, "error": "No prompt provided"}

        if self._context:
            await self._context.report_progress(
                stage="Generating",
                progress=20,
                message=f"Calling {model} (streaming)..."
            )

        url = f"{self._base_url}/chat/completions"
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True  # Enable streaming by default
        }

        # Streaming timeout: use generous connect timeout but long read timeout
        # since streaming keeps connection alive with chunks
        timeout_config = httpx.Timeout(
            connect=30.0,   # 30s to establish connection
            read=300.0,     # 300s max between chunks (generous for slow models)
            write=30.0,     # 30s to send request
            pool=30.0       # 30s to get connection from pool
        )

        content = ""
        finish_reason = ""
        usage = {}
        chunk_count = 0
        
        try:
            print(f"\n📡 [STREAM START] Model: {model}, max_tokens: {max_tokens}")
            print("-" * 60)
            async with httpx.AsyncClient(timeout=timeout_config) as client:
                async with client.stream("POST", url, json=payload, headers=self._get_headers()) as response:
                    response.raise_for_status()
                    
                    # Process SSE stream
                    async for line in response.aiter_lines():
                        if not line:
                            continue
                        
                        # SSE format: "data: {...}" or "data: [DONE]"
                        if not line.startswith("data: "):
                            continue
                        
                        data_str = line[6:]  # Remove "data: " prefix
                        
                        if data_str.strip() == "[DONE]":
                            break
                        
                        try:
                            chunk_data = json.loads(data_str)
                            
                            # Extract delta content from the chunk
                            choices = chunk_data.get("choices", [])
                            if choices:
                                delta = choices[0].get("delta", {})
                                chunk_text = delta.get("content", "")
                                chunk_finish = choices[0].get("finish_reason")
                                
                                if chunk_text:
                                    content += chunk_text
                                    chunk_count += 1
                                    
                                    # Stream chunk to frontend via context
                                    if self._context:
                                        self._context.stream_chunk(chunk_text)
                                    
                                    # Print actual live streaming data to console
                                    print(chunk_text, end="", flush=True)
                                
                                if chunk_finish:
                                    finish_reason = chunk_finish
                            
                            # Some APIs include usage in the final chunk
                            if "usage" in chunk_data:
                                usage = chunk_data["usage"]
                                
                        except (ValueError, KeyError) as parse_err:
                            # Skip malformed chunks
                            continue
            
            print(f"\n{'-' * 60}")
            print(f"✅ [STREAM COMPLETE] {chunk_count} chunks, {len(content)} chars total")
        
        except (httpx.HTTPStatusError, httpx.ConnectError) as stream_err:
            # If streaming fails with HTTP error, try non-streaming fallback
            error_code = getattr(getattr(stream_err, 'response', None), 'status_code', 0)
            print(f"⚠️ [STREAM] Streaming failed (HTTP {error_code}), falling back to non-streaming...")
            
            # Remove stream flag and retry without streaming
            payload.pop("stream", None)
            effective_timeout = min(600, max(self._timeout, self._timeout + max_tokens // 200))
            
            async with httpx.AsyncClient(timeout=effective_timeout) as client:
                response = await client.post(url, json=payload, headers=self._get_headers())
                response.raise_for_status()
                data = response.json()
            
            # Extract from non-streaming response
            if "choices" in data and len(data["choices"]) > 0:
                content = data["choices"][0].get("message", {}).get("content", "")
                finish_reason = data["choices"][0].get("finish_reason", "")
            usage = data.get("usage", {})
            print(f"✅ [FALLBACK] Non-streaming response: {len(content)} chars")

        if self._context:
            await self._context.report_progress(
                stage="Complete",
                progress=100,
                message=f"Text generation complete ({len(content)} chars)"
            )

        return {
            "success": True,
            "data": {
                "raw_content": content,
                "text": content,
                "model": model,
                "usage": usage,
                "finish_reason": finish_reason,
                "streamed": chunk_count > 0,
                "chunk_count": chunk_count
            }
        }

    # ==================== Image Generation ====================
    
    async def _execute_image_generation(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Handle image generation requests. Downloads generated images to local disk."""
        import httpx
        import uuid
        from datetime import datetime
        
        # Check for batch mode (scene image generation sends multiple scenes)
        batch_mode = inputs.get("batch_mode", False)
        scenes = inputs.get("scenes", [])
        
        # Diagnostic logging - helps trace issues where batch_mode or scenes are unexpected
        logger.info(f"🖼️ _execute_image_generation called: batch_mode={batch_mode} (type={type(batch_mode).__name__}), scenes_len={len(scenes) if isinstance(scenes, list) else 'N/A'} (type={type(scenes).__name__})")
        if scenes and isinstance(scenes, list) and len(scenes) > 0:
            first = scenes[0]
            logger.info(f"🖼️ First scene: type={type(first).__name__}, keys={list(first.keys()) if isinstance(first, dict) else 'N/A'}")
        
        # Ensure scenes is a list of dicts (not IDs or other format)
        if scenes and isinstance(scenes, list) and isinstance(scenes[0], dict):
            valid_scenes = True
        else:
            valid_scenes = False
        
        logger.info(f"🖼️ valid_scenes={valid_scenes}")
        
        # Get images_dir from context for saving downloaded images
        images_dir = ""
        if self._context and hasattr(self._context, '_extra_context'):
            images_dir = self._context._extra_context.get("images_dir", "")
        
        if not images_dir:
            # Fallback to plugin storage
            if self._context:
                images_dir = self._context.get_storage_path("images")
            else:
                images_dir = os.path.join(os.path.dirname(__file__), "generated_images")
        
        os.makedirs(images_dir, exist_ok=True)
        
        # ---- Batch mode: generate images for multiple scenes ----
        if batch_mode and valid_scenes:
            return await self._execute_batch_image_generation(inputs, scenes, images_dir)
        
        # ---- Recovery: batch_mode is True but scenes was invalid ----
        # This can happen if scenes data was corrupted/overwritten during dict merging
        if batch_mode and not valid_scenes and scenes:
            logger.warning(f"🖼️ RECOVERY: batch_mode=True but valid_scenes=False. Attempting to recover. scenes type={type(scenes).__name__}, len={len(scenes) if isinstance(scenes, list) else 'N/A'}")
            # Try to convert scenes if they're strings (e.g., JSON serialized)
            recovered_scenes = []
            if isinstance(scenes, list):
                for s in scenes:
                    if isinstance(s, dict):
                        recovered_scenes.append(s)
                    elif isinstance(s, str):
                        try:
                            import json as json_mod
                            parsed = json_mod.loads(s)
                            if isinstance(parsed, dict):
                                recovered_scenes.append(parsed)
                        except:
                            pass
            if recovered_scenes:
                logger.info(f"🖼️ RECOVERY SUCCESS: Recovered {len(recovered_scenes)} scenes from corrupted data")
                return await self._execute_batch_image_generation(inputs, recovered_scenes, images_dir)
            else:
                logger.error(f"🖼️ RECOVERY FAILED: Could not recover scene data. First item type: {type(scenes[0]).__name__ if isinstance(scenes, list) and scenes else 'N/A'}")
        
        # ---- Single image mode (character/object/single scene) ----
        prompt = (
            inputs.get("prompt", "") or 
            inputs.get("image_prompt", "") or 
            inputs.get("scene_description", "") or
            inputs.get("scene_prompt", "") or
            inputs.get("scene_details_text", "") or
            inputs.get("character_prompt", "") or
            inputs.get("object_prompt", "")
        )
        if not prompt:
            # If batch_mode was requested but scenes were invalid/empty, give a more helpful error
            if batch_mode:
                logger.error(f"🖼️ ERROR: Batch mode but no scenes. Input keys: {list(inputs.keys())}")
                return {"success": False, "error": f"Batch mode requested but no valid scene data received. Scenes: {type(scenes).__name__}({len(scenes) if isinstance(scenes, list) else 'N/A'})"}
            # Log full diagnostic info for debugging persistent "Image prompt is required" errors
            logger.error(f"🖼️ ERROR: No prompt found in inputs. batch_mode={batch_mode}, scenes_len={len(scenes) if isinstance(scenes, list) else 'N/A'}, input_keys={list(inputs.keys())}")
            return {"success": False, "error": "Image prompt is required"}
        
        model = inputs.get("image_model", "dall-e-3")
        if model == "custom":
            model = inputs.get("custom_image_model", "dall-e-3")
        
        size = inputs.get("image_size", "1024x1024")
        quality = inputs.get("image_quality", "standard")
        style = inputs.get("image_style", "vivid")
        n = int(inputs.get("num_images", 1))

        if self._context:
            await self._context.report_progress(
                stage="Generating Images",
                progress=20,
                message=f"Generating {n} image(s) with {model}..."
            )

        url = f"{self._base_url}/images/generations"
        payload = {
            "model": model,
            "prompt": prompt,
            "n": n,
            "size": size,
            "quality": quality,
            "style": style,
            "response_format": "url"
        }

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
            data = response.json()

        if self._context:
            await self._context.report_progress(
                stage="Downloading",
                progress=60,
                message="Downloading generated images..."
            )

        # Extract image URLs and download to disk
        local_paths = []
        revised_prompt = ""
        
        for i, img_data in enumerate(data.get("data", [])):
            image_url = img_data.get("url", "")
            b64_data = img_data.get("b64_json", "")
            revised_prompt = img_data.get("revised_prompt", prompt)
            
            # Generate unique filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            unique_id = uuid.uuid4().hex[:8]
            
            # Determine generation type from context
            gen_type = "image"
            if self._context and hasattr(self._context, '_extra_context'):
                ctx = self._context._extra_context
                if ctx.get("generation_type") == "character":
                    char_name = ctx.get("character_name", "unknown").replace(" ", "_")
                    gen_type = f"char_{char_name}"
                elif ctx.get("generation_type") == "object":
                    obj_name = ctx.get("object_name", "unknown").replace(" ", "_")
                    gen_type = f"obj_{obj_name}"
            
            filename = f"{gen_type}_{timestamp}_{unique_id}.png"
            file_path = os.path.join(images_dir, filename)
            
            try:
                if image_url:
                    # Download from URL
                    async with httpx.AsyncClient(timeout=120) as dl_client:
                        dl_response = await dl_client.get(image_url)
                        dl_response.raise_for_status()
                        with open(file_path, "wb") as f:
                            f.write(dl_response.content)
                        logger.info(f"🖼️ Downloaded image to {file_path} ({len(dl_response.content)} bytes)")
                elif b64_data:
                    # Decode base64
                    img_bytes = base64.b64decode(b64_data)
                    with open(file_path, "wb") as f:
                        f.write(img_bytes)
                    logger.info(f"🖼️ Saved base64 image to {file_path} ({len(img_bytes)} bytes)")
                else:
                    continue
                
                local_paths.append(file_path)
            except Exception as e:
                logger.error(f"🖼️ Failed to save image {i}: {e}")
                # If download fails, keep the URL as fallback
                if image_url:
                    local_paths.append(image_url)

        if self._context:
            await self._context.report_progress(
                stage="Complete",
                progress=100,
                message=f"Image generation complete ({len(local_paths)} images saved)"
            )

        return {
            "success": True,
            "data": {
                "images": local_paths,
                "image_url": local_paths[0] if local_paths else "",
                "model": model,
                "revised_prompt": revised_prompt
            },
            "outputs": local_paths
        }

    async def _execute_batch_image_generation(
        self, inputs: Dict[str, Any], scenes: list, images_dir: str
    ) -> Dict[str, Any]:
        """Handle batch image generation for multiple scenes."""
        import httpx
        import uuid
        from datetime import datetime
        
        model = inputs.get("image_model", "dall-e-3")
        if model == "custom":
            model = inputs.get("custom_image_model", "dall-e-3")
        
        size = inputs.get("image_size", "1024x1024")
        quality = inputs.get("image_quality", "standard")
        style = inputs.get("image_style", "vivid")
        
        results = []
        total = len(scenes)
        
        for idx, scene in enumerate(scenes):
            scene_id = scene.get("id", "")
            scene_id_str = scene.get("scene_id_str", f"scene_{idx}")
            
            # Get prompt from scene data
            prompt = (
                scene.get("image_prompt", "") or
                scene.get("scene_description", "") or
                scene.get("scene_prompt", "") or
                scene.get("scene_details_text", "")
            )
            
            if not prompt:
                results.append({
                    "scene_id": scene_id,
                    "scene_id_str": scene_id_str,
                    "error": "No image prompt available",
                    "scene_images": [],
                    "scene_frames": {}
                })
                continue
            
            progress_pct = int(10 + (idx / total) * 80)
            if self._context:
                await self._context.report_progress(
                    stage="Generating",
                    progress=progress_pct,
                    message=f"Generating image for scene {scene_id_str} ({idx+1}/{total})..."
                )
            
            try:
                url = f"{self._base_url}/images/generations"
                payload = {
                    "model": model,
                    "prompt": prompt,
                    "n": 1,
                    "size": size,
                    "quality": quality,
                    "style": style,
                    "response_format": "url"
                }
                
                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    response = await client.post(url, json=payload, headers=self._get_headers())
                    response.raise_for_status()
                    data = response.json()
                
                # Download the generated image
                scene_images = []
                for img_data in data.get("data", []):
                    image_url = img_data.get("url", "")
                    b64_data = img_data.get("b64_json", "")
                    
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    unique_id = uuid.uuid4().hex[:8]
                    filename = f"scene_{scene_id_str}_{timestamp}_{unique_id}.png"
                    file_path = os.path.join(images_dir, filename)
                    
                    if image_url:
                        async with httpx.AsyncClient(timeout=120) as dl_client:
                            dl_response = await dl_client.get(image_url)
                            dl_response.raise_for_status()
                            with open(file_path, "wb") as f:
                                f.write(dl_response.content)
                            logger.info(f"🖼️ Scene {scene_id_str}: Downloaded image to {file_path}")
                    elif b64_data:
                        img_bytes = base64.b64decode(b64_data)
                        with open(file_path, "wb") as f:
                            f.write(img_bytes)
                    else:
                        continue
                    
                    scene_images.append(file_path)
                
                results.append({
                    "scene_id": scene_id,
                    "scene_id_str": scene_id_str,
                    "scene_images": scene_images,
                    "scene_frames": {}
                })
                
            except Exception as e:
                logger.error(f"🖼️ Scene {scene_id_str} image generation failed: {e}")
                results.append({
                    "scene_id": scene_id,
                    "scene_id_str": scene_id_str,
                    "error": str(e),
                    "scene_images": [],
                    "scene_frames": {}
                })
        
        if self._context:
            await self._context.report_progress(
                stage="Complete",
                progress=100,
                message=f"Batch image generation complete ({len(results)} scenes processed)"
            )
        
        success_count = sum(1 for r in results if r.get("scene_images"))
        
        return {
            "success": success_count > 0,
            "data": {
                "results": results,
                "total": total,
                "success_count": success_count,
                "failed_count": total - success_count
            }
        }

    # ==================== Video Generation ====================
    
    async def _execute_video_generation(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Handle video generation requests."""
        import httpx
        
        # Prompt is auto-passed by runtime (scene prompt or image_prompt)
        prompt = inputs.get("prompt", "") or inputs.get("image_prompt", "") or inputs.get("scene_description", "")
        if not prompt:
            return {"success": False, "error": "Video prompt is required"}
        
        model = inputs.get("video_model", "sora")
        if model == "custom":
            model = inputs.get("custom_video_model", "sora")
        
        duration = int(inputs.get("video_duration", 5))
        resolution = inputs.get("video_size", "1080p")

        if self._context:
            await self._context.report_progress(
                stage="Generating Video",
                progress=10,
                message=f"Requesting video generation with {model}..."
            )

        # OpenAI Sora-style API (may vary by provider)
        url = f"{self._base_url}/videos/generations"
        payload = {
            "model": model,
            "prompt": prompt,
            "duration": duration,
            "resolution": resolution
        }

        async with httpx.AsyncClient(timeout=max(self._timeout, 300)) as client:
            response = await client.post(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
            data = response.json()

        # Handle async generation (polling)
        if "id" in data and "status" in data:
            generation_id = data["id"]
            status = data.get("status", "processing")
            
            poll_url = f"{self._base_url}/videos/generations/{generation_id}"
            poll_count = 0
            max_polls = 120  # 10 minutes max
            
            while status in ["processing", "pending", "in_progress"] and poll_count < max_polls:
                poll_count += 1
                progress = min(90, 10 + (poll_count / max_polls * 80))
                
                if self._context:
                    await self._context.report_progress(
                        stage="Processing Video",
                        progress=progress,
                        message=f"Video is being generated... ({poll_count * 5}s elapsed)"
                    )
                
                import asyncio
                await asyncio.sleep(5)
                
                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    poll_response = await client.get(poll_url, headers=self._get_headers())
                    poll_response.raise_for_status()
                    data = poll_response.json()
                    status = data.get("status", "completed")
            
            if status == "failed":
                return {
                    "success": False,
                    "error": data.get("error", "Video generation failed")
                }

        if self._context:
            await self._context.report_progress(
                stage="Complete",
                progress=100,
                message="Video generation complete"
            )

        # Extract video URL
        video_url = ""
        if "data" in data and isinstance(data["data"], list) and len(data["data"]) > 0:
            video_url = data["data"][0].get("url", "")
        elif "url" in data:
            video_url = data["url"]
        elif "video_url" in data:
            video_url = data["video_url"]

        return {
            "success": True,
            "data": {
                "video_url": video_url,
                "model": model,
                "duration": duration,
                "resolution": resolution
            },
            "outputs": [video_url] if video_url else []
        }

    # ==================== Audio Generation (TTS) ====================
    
    async def _execute_audio_generation(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Handle text-to-speech requests."""
        import httpx
        
        # Text is auto-passed by runtime (script_text from audio script)
        text = inputs.get("text", "") or inputs.get("script_text", "") or inputs.get("input", "")
        if not text:
            return {"success": False, "error": "Text is required for speech generation"}
        
        model = inputs.get("tts_model", "tts-1")
        if model == "custom":
            model = inputs.get("custom_tts_model", "tts-1")
        
        # Support custom voice ID: if voice is "custom", use custom_voice_id
        voice = inputs.get("voice", "alloy")
        if voice == "custom":
            voice = inputs.get("custom_voice_id", "alloy")
        
        speed = float(inputs.get("audio_speed", inputs.get("speaking_rate", 1.0)))
        response_format = inputs.get("response_format", "mp3")

        if self._context:
            await self._context.report_progress(
                stage="Generating Audio",
                progress=20,
                message=f"Converting text to speech with {model} ({voice})..."
            )

        url = f"{self._base_url}/audio/speech"
        payload = {
            "model": model,
            "input": text,
            "voice": voice,
            "speed": speed,
            "response_format": response_format
        }

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
            audio_data = response.content

        # Save audio file — use the output_path provided by the route if available
        output_path = inputs.get("output_path", "")
        if output_path:
            # Ensure directory exists
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            with open(output_path, "wb") as f:
                f.write(audio_data)
        elif self._context:
            # Fallback: save to plugin storage
            storage_path = self._context.get_storage_path("audio_output")
            filename = f"tts_{int(time.time())}.{response_format}"
            output_path = os.path.join(storage_path, filename)
            with open(output_path, "wb") as f:
                f.write(audio_data)
        
        if self._context:
            await self._context.report_progress(
                stage="Complete",
                progress=100,
                message="Audio generation complete"
            )

        return {
            "success": True,
            "data": {
                "output_path": output_path,
                "audio_path": output_path,
                "audio_size": len(audio_data),
                "file_size": len(audio_data),
                "format": response_format,
                "model": model,
                "voice": voice,
                "text_length": len(text),
                "duration_seconds": 0,
                "provider": "openai_compatible"
            },
            "outputs": [output_path] if output_path else []
        }

    # ==================== Subtitle Generation (STT) ====================
    
    async def _execute_subtitle_generation(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Handle speech-to-text transcription requests."""
        import httpx
        
        model = inputs.get("stt_model", "whisper-1")
        if model == "custom":
            model = inputs.get("custom_stt_model", "whisper-1")
        
        language = inputs.get("language", "auto")
        if language == "auto":
            language = None
        
        # Default to json (widely supported) instead of verbose_json
        response_format = inputs.get("response_format_stt", "json")
        prompt_hint = inputs.get("prompt", "")
        
        # Get audio file from context (passed by audio.py route)
        audio_file_path = None
        if self._context and hasattr(self._context, '_extra_context'):
            audio_file_path = self._context._extra_context.get("audio_file_path", "")
            if not audio_file_path:
                audio_file_path = self._context._extra_context.get("audio_path", "")
        
        if not audio_file_path:
            audio_file_path = inputs.get("audio_file_path", "") or inputs.get("audio_path", "")
        
        if not audio_file_path:
            return {
                "success": False,
                "error": "No audio file path provided. Please generate audio first."
            }
        
        if not os.path.exists(audio_file_path):
            return {
                "success": False,
                "error": f"Audio file not found at: {audio_file_path}"
            }

        if self._context:
            await self._context.report_progress(
                stage="Transcribing",
                progress=20,
                message=f"Transcribing audio with {model}..."
            )

        url = f"{self._base_url}/audio/transcriptions"
        
        # Build multipart form data
        form_data = {
            "model": model,
            "response_format": response_format
        }
        if language:
            form_data["language"] = language
        if prompt_hint:
            form_data["prompt"] = prompt_hint
        # Request word-level timestamps for verbose_json
        if response_format == "verbose_json":
            form_data["timestamp_granularities[]"] = "word"

        # Send audio file — NO Content-Type header (httpx sets multipart boundary)
        headers = {"Authorization": f"Bearer {self._api_key}"}
        if self._organization:
            headers["OpenAI-Organization"] = self._organization

        # Detect MIME type from extension
        ext = os.path.splitext(audio_file_path)[1].lower()
        mime_map = {
            ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4",
            ".ogg": "audio/ogg", ".flac": "audio/flac", ".webm": "audio/webm",
            ".mp4": "audio/mp4", ".mpeg": "audio/mpeg", ".mpga": "audio/mpeg"
        }
        mime_type = mime_map.get(ext, "audio/mpeg")

        try:
            async with httpx.AsyncClient(timeout=max(self._timeout, 300)) as client:
                with open(audio_file_path, "rb") as audio_file:
                    files = {"file": (os.path.basename(audio_file_path), audio_file, mime_type)}
                    response = await client.post(
                        url,
                        data=form_data,
                        files=files,
                        headers=headers
                    )
                    
                    if response.status_code != 200:
                        error_detail = ""
                        try:
                            err_json = response.json()
                            error_detail = err_json.get("error", {}).get("message", "") or str(err_json)
                        except Exception:
                            error_detail = response.text[:500]
                        
                        # If verbose_json failed, retry with plain json
                        if response_format == "verbose_json":
                            logger.warning(f"verbose_json failed ({response.status_code}), retrying with json format...")
                            form_data["response_format"] = "json"
                            response_format = "json"
                            
                            with open(audio_file_path, "rb") as audio_file_retry:
                                files_retry = {"file": (os.path.basename(audio_file_path), audio_file_retry, mime_type)}
                                response = await client.post(
                                    url,
                                    data=form_data,
                                    files=files_retry,
                                    headers=headers
                                )
                                if response.status_code != 200:
                                    return {
                                        "success": False,
                                        "error": f"STT API error ({response.status_code}): {error_detail}"
                                    }
                        else:
                            return {
                                "success": False,
                                "error": f"STT API error ({response.status_code}): {error_detail}"
                            }
        except httpx.ConnectError:
            return {
                "success": False,
                "error": f"Could not connect to STT service at {self._base_url}. Please check API Base URL."
            }
        except httpx.TimeoutException:
            return {
                "success": False,
                "error": f"STT request timed out after {max(self._timeout, 300)} seconds."
            }

        if self._context:
            await self._context.report_progress(
                stage="Processing",
                progress=80,
                message="Processing transcription results..."
            )

        # Parse response based on format and auto-convert to word-level data
        words = []
        segments = []
        text = ""
        duration_val = 0
        language_val = language or "unknown"
        
        try:
            if response_format in ["verbose_json", "json"]:
                data = response.json()
                if isinstance(data, dict):
                    text = data.get("text", "")
                    words = data.get("words", [])
                    segments = data.get("segments", [])
                    duration_val = data.get("duration", 0)
                    language_val = data.get("language", language_val)
                    
                    # If top-level words is empty, extract from segments
                    if not words and segments:
                        for seg in segments:
                            seg_words = seg.get("words", [])
                            if seg_words:
                                words.extend(seg_words)
                        if words:
                            logger.info(f"Extracted {len(words)} words from {len(segments)} segments")
                    
                    # If still no words but we have segments with timestamps, build word-level from segments
                    if not words and segments:
                        words = self._segments_to_words(segments)
                        if words:
                            logger.info(f"Built {len(words)} word entries from {len(segments)} segments")
                    
                    # Last resort: if we have text and duration, estimate word timings
                    if not words and text and duration_val > 0:
                        words = self._estimate_word_timings(text, duration_val)
                        if words:
                            logger.info(f"Estimated timings for {len(words)} words from text")
                            
                elif isinstance(data, str):
                    text = data
            elif response_format == "srt":
                raw_srt = response.text
                text, words = self._parse_srt(raw_srt)
                logger.info(f"Parsed SRT: {len(words)} word entries from subtitle blocks")
            elif response_format == "vtt":
                raw_vtt = response.text
                text, words = self._parse_vtt(raw_vtt)
                logger.info(f"Parsed VTT: {len(words)} word entries from subtitle cues")
            else:
                # Plain text format - no timestamps available
                text = response.text
        except Exception as e:
            text = response.text
            logger.warning(f"Failed to parse STT response: {e}")
        
        # Auto-detect: if text looks like SRT/VTT even when format was json/text
        if not words and text:
            if self._looks_like_srt(text):
                logger.info("Auto-detected SRT format in response text")
                text, words = self._parse_srt(text)
            elif self._looks_like_vtt(text):
                logger.info("Auto-detected VTT format in response text")
                text, words = self._parse_vtt(text)
        
        # Final fallback: estimate timings from text + duration
        if not words and text and duration_val > 0:
            words = self._estimate_word_timings(text, duration_val)
            if words:
                logger.info(f"Final fallback: estimated timings for {len(words)} words")

        if self._context:
            await self._context.report_progress(
                stage="Complete",
                progress=100,
                message="Transcription complete"
            )

        return {
            "success": True,
            "data": {
                "text": text,
                "words": words,
                "segments": segments,
                "language": language_val,
                "duration": duration_val,
                "model": model
            }
        }

    # ─── Subtitle format parsing helpers ───────────────────────────────

    def _parse_srt(self, raw_srt: str):
        """Parse SRT subtitle format into (full_text, words_list).
        
        SRT format:
        1
        00:00:01,000 --> 00:00:03,500
        Hello world this is a test
        
        2
        00:00:04,000 --> 00:00:06,200
        Second subtitle block
        """
        import re
        words = []
        text_parts = []
        
        try:
            # Split into blocks (separated by blank lines)
            blocks = re.split(r'\n\s*\n', raw_srt.strip())
            
            for block in blocks:
                lines = block.strip().split('\n')
                if len(lines) < 3:
                    continue
                
                # Line 0: sequence number (skip)
                # Line 1: timestamp line  "00:00:01,000 --> 00:00:03,500"
                # Lines 2+: subtitle text
                timestamp_line = lines[1].strip()
                subtitle_text = ' '.join(line.strip() for line in lines[2:] if line.strip())
                
                if not subtitle_text:
                    continue
                
                text_parts.append(subtitle_text)
                
                # Parse timestamps
                ts_match = re.match(
                    r'(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})',
                    timestamp_line
                )
                if not ts_match:
                    continue
                
                g = ts_match.groups()
                start_sec = int(g[0]) * 3600 + int(g[1]) * 60 + int(g[2]) + int(g[3]) / 1000
                end_sec = int(g[4]) * 3600 + int(g[5]) * 60 + int(g[6]) + int(g[7]) / 1000
                
                # Distribute timing evenly across words in this block
                block_words = subtitle_text.split()
                if block_words:
                    duration = end_sec - start_sec
                    word_duration = duration / len(block_words) if len(block_words) > 0 else duration
                    for i, w in enumerate(block_words):
                        words.append({
                            "word": w,
                            "start": round(start_sec + i * word_duration, 3),
                            "end": round(start_sec + (i + 1) * word_duration, 3)
                        })
            
            full_text = ' '.join(text_parts)
        except Exception as e:
            logger.warning(f"SRT parse error: {e}")
            full_text = raw_srt
            words = []
        
        return full_text, words

    def _parse_vtt(self, raw_vtt: str):
        """Parse WebVTT subtitle format into (full_text, words_list).
        
        VTT format:
        WEBVTT
        
        00:00:01.000 --> 00:00:03.500
        Hello world this is a test
        
        00:00:04.000 --> 00:00:06.200
        Second subtitle cue
        """
        import re
        words = []
        text_parts = []
        
        try:
            # Remove WEBVTT header and any metadata
            content = raw_vtt.strip()
            if content.startswith('WEBVTT'):
                # Remove header line (and optional metadata lines before first blank line)
                header_end = content.find('\n\n')
                if header_end != -1:
                    content = content[header_end:].strip()
                else:
                    content = re.sub(r'^WEBVTT[^\n]*\n?', '', content).strip()
            
            # Split into cue blocks
            blocks = re.split(r'\n\s*\n', content.strip())
            
            for block in blocks:
                lines = block.strip().split('\n')
                if not lines:
                    continue
                
                # Find the timestamp line (could be first or second line if cue ID exists)
                ts_line_idx = -1
                for idx, line in enumerate(lines):
                    if '-->' in line:
                        ts_line_idx = idx
                        break
                
                if ts_line_idx == -1:
                    continue
                
                timestamp_line = lines[ts_line_idx].strip()
                subtitle_text = ' '.join(
                    re.sub(r'<[^>]+>', '', line.strip())  # Strip HTML/VTT tags like <v>, <c>, etc.
                    for line in lines[ts_line_idx + 1:]
                    if line.strip()
                )
                
                if not subtitle_text:
                    continue
                
                text_parts.append(subtitle_text)
                
                # Parse timestamps (VTT uses . for milliseconds, may omit hours)
                # Patterns: "00:00:01.000 --> 00:00:03.500" or "00:01.000 --> 00:03.500"
                ts_match = re.match(
                    r'(?:(\d{2}):)?(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(?:(\d{2}):)?(\d{2}):(\d{2})[.,](\d{3})',
                    timestamp_line
                )
                if not ts_match:
                    continue
                
                g = ts_match.groups()
                start_h = int(g[0]) if g[0] else 0
                start_sec = start_h * 3600 + int(g[1]) * 60 + int(g[2]) + int(g[3]) / 1000
                end_h = int(g[4]) if g[4] else 0
                end_sec = end_h * 3600 + int(g[5]) * 60 + int(g[6]) + int(g[7]) / 1000
                
                # Distribute timing across words
                block_words = subtitle_text.split()
                if block_words:
                    duration = end_sec - start_sec
                    word_duration = duration / len(block_words) if len(block_words) > 0 else duration
                    for i, w in enumerate(block_words):
                        words.append({
                            "word": w,
                            "start": round(start_sec + i * word_duration, 3),
                            "end": round(start_sec + (i + 1) * word_duration, 3)
                        })
            
            full_text = ' '.join(text_parts)
        except Exception as e:
            logger.warning(f"VTT parse error: {e}")
            full_text = raw_vtt
            words = []
        
        return full_text, words

    def _segments_to_words(self, segments: list) -> list:
        """Convert segment-level data to word-level data.
        
        Each segment has {text, start, end}. We split the text into words
        and distribute timing evenly across them within each segment.
        """
        words = []
        try:
            for seg in segments:
                seg_text = seg.get("text", "").strip()
                seg_start = float(seg.get("start", 0))
                seg_end = float(seg.get("end", seg_start))
                
                if not seg_text:
                    continue
                
                seg_words = seg_text.split()
                if not seg_words:
                    continue
                
                duration = seg_end - seg_start
                word_duration = duration / len(seg_words) if len(seg_words) > 0 else duration
                
                for i, w in enumerate(seg_words):
                    words.append({
                        "word": w,
                        "start": round(seg_start + i * word_duration, 3),
                        "end": round(seg_start + (i + 1) * word_duration, 3)
                    })
        except Exception as e:
            logger.warning(f"Segments to words conversion error: {e}")
        
        return words

    def _estimate_word_timings(self, text: str, duration: float) -> list:
        """Estimate word-level timings by distributing evenly across the total duration.
        
        This is the final fallback when no real timing data is available.
        """
        words = []
        try:
            text_words = text.split()
            if not text_words or duration <= 0:
                return words
            
            word_duration = duration / len(text_words)
            
            for i, w in enumerate(text_words):
                words.append({
                    "word": w,
                    "start": round(i * word_duration, 3),
                    "end": round((i + 1) * word_duration, 3)
                })
        except Exception as e:
            logger.warning(f"Word timing estimation error: {e}")
        
        return words

    def _looks_like_srt(self, text: str) -> bool:
        """Check if text appears to be SRT format."""
        import re
        try:
            # SRT has numbered blocks with "HH:MM:SS,mmm --> HH:MM:SS,mmm"
            return bool(re.search(
                r'\d+\s*\n\s*\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[,.]\d{3}',
                text
            ))
        except Exception:
            return False

    def _looks_like_vtt(self, text: str) -> bool:
        """Check if text appears to be WebVTT format."""
        import re
        try:
            text_stripped = text.strip()
            if text_stripped.startswith('WEBVTT'):
                return True
            # VTT cues without header: "MM:SS.mmm --> MM:SS.mmm" or "HH:MM:SS.mmm --> HH:MM:SS.mmm"
            return bool(re.search(
                r'(?:\d{2}:)?\d{2}:\d{2}\.\d{3}\s*-->\s*(?:\d{2}:)?\d{2}:\d{2}\.\d{3}',
                text
            ))
        except Exception:
            return False
