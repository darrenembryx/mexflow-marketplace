# Oxyy.ai — API Documentation

> **Version:** 2.0.0 | **Last Updated:** June 2025 | **Status:** Final Reference
>
> **Base URL:** `https://api.oxyy.ai` (Production) / `http://localhost:3000` (Development)

---

## Table of Contents

1. [Authentication](#1-authentication)
2. [Error Handling](#2-error-handling)
3. [Rate Limits & Concurrency](#3-rate-limits--concurrency)
4. [Chat Completions](#4-chat-completions)
5. [Image Generation](#5-image-generation)
6. [Audio — Text-to-Speech](#6-audio--text-to-speech)
7. [Audio — Transcription & Translation](#7-audio--transcription--translation)
8. [Video Generation](#8-video-generation)
9. [Models](#9-models)
10. [Async Jobs](#10-async-jobs)
11. [Auth Endpoints](#11-auth-endpoints) (includes 2FA, Trusted Devices, Backup Codes)
12. [User Endpoints](#12-user-endpoints) (includes API Key Limits)
13. [Public Endpoints](#13-public-endpoints)
14. [Webhooks](#14-webhooks)
15. [SDK Compatibility](#15-sdk-compatibility)

---

## 1. Authentication

All API endpoints (except public and auth routes) require authentication via the `Authorization` header.

### API Key Authentication

```
Authorization: Bearer oxyy_a1b2c3d4e5f6...
```

API keys use the prefix `oxyy_` or `sk-` and are at least 20 characters long. Keys are SHA-256 hashed and never stored in plain text. You can create and manage API keys from your dashboard.

### JWT Authentication

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

JWT tokens are obtained via login/register endpoints. Access tokens expire in **15 minutes**; refresh tokens last **30 days**.

### Auto-Detection

The middleware automatically detects the auth type based on the token prefix:

| Token Prefix | Auth Method |
|-------------|-------------|
| `oxyy_...` or `sk-...` | API Key lookup (SHA-256 hash) |
| JWT format | JWT verification |

### Example — cURL

```bash
curl -X POST https://api.oxyy.ai/v1/chat/completions \
  -H "Authorization: Bearer oxyy_your_api_key_here" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemini-2.5-flash",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

### Example — OpenAI SDK (Python)

```python
from openai import OpenAI

client = OpenAI(
    api_key="oxyy_your_api_key_here",
    base_url="https://api.oxyy.ai/v1"
)

response = client.chat.completions.create(
    model="gemini-2.5-flash",
    messages=[{"role": "user", "content": "Hello!"}]
)
print(response.choices[0].message.content)
```

### Example — OpenAI SDK (Node.js)

```javascript
import OpenAI from 'openai';

const client = new OpenAI({
  apiKey: 'oxyy_your_api_key_here',
  baseURL: 'https://api.oxyy.ai/v1'
});

const response = await client.chat.completions.create({
  model: 'gemini-2.5-flash',
  messages: [{ role: 'user', content: 'Hello!' }]
});
console.log(response.choices[0].message.content);
```

---

## 2. Error Handling

All errors follow a consistent format:

```json
{
  "error": {
    "message": "Human-readable error description",
    "type": "error_type",
    "code": "specific_error_code",
    "param": "field_name_if_applicable"
  }
}
```

### Error Types

| HTTP Status | Type | Description |
|-------------|------|-------------|
| 400 | `invalid_request_error` | Validation failed, missing/invalid parameters |
| 401 | `authentication_error` | Missing or invalid authentication |
| 402 | `insufficient_credits` | Account balance too low |
| 403 | `permission_error` | Access denied to resource/model |
| 404 | `not_found` | Resource not found |
| 429 | `rate_limit_exceeded` | RPM or concurrency limit reached |
| 500 | `server_error` | Internal server error |
| 501 | `not_implemented` | Feature not available |
| 502 | `provider_error` | Upstream AI provider error |
| 503 | `service_unavailable` | Model/plugin not available |

### Common Error Codes

| Code | When |
|------|------|
| `invalid_request` | Bad request body |
| `model_not_found` | Requested model doesn't exist or is disabled |
| `model_unavailable` | Plugin not loaded for this model |
| `concurrency_limit_exceeded` | Too many simultaneous requests |
| `provider_capacity_exceeded` | All provider API keys at max capacity |
| `streaming_not_supported` | Model doesn't support streaming |
| `generation_failed` | Provider returned an error |
| `job_not_found` | Async job ID doesn't exist |

---

## 3. Rate Limits & Concurrency

### Rate Limit Headers

Every response includes:

```
X-RateLimit-Limit: 60           # Requests per minute allowed
X-RateLimit-Remaining: 55       # Remaining requests this window
X-RateLimit-Reset: 1700000060   # Unix timestamp when window resets
```

### Concurrency Tracking

The platform tracks concurrent requests at 3 levels:
- **Per-user** — Based on subscription's `concurrentLimit`
- **Per-model** — Based on provider API key capacity
- **Per-user-per-model** — Combined tracking

When your concurrency limit is reached, you receive:

```json
{
  "error": {
    "message": "Concurrent request limit exceeded. You have 10/10 requests in progress.",
    "type": "rate_limit_exceeded",
    "code": "concurrency_limit_exceeded"
  }
}
```

### Rate Limit (429) Response

```json
{
  "error": {
    "message": "Rate limit exceeded",
    "type": "rate_limit_exceeded",
    "code": "rate_limit_exceeded",
    "retry_after": 42
  }
}
```

---

## 4. Chat Completions

### `POST /v1/chat/completions`

Create a chat completion — compatible with the OpenAI Chat Completions API.

**Request Body:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model` | string | ✅ | Model ID (e.g., `gemini-2.5-flash`, `gemini-2.5-pro`) |
| `messages` | array | ✅ | Array of message objects |
| `messages[].role` | string | ✅ | `system`, `user`, `assistant`, `function`, or `tool` |
| `messages[].content` | string / array | ✅ | Message content (string or multimodal content array) |
| `stream` | boolean | ❌ | Enable Server-Sent Events streaming (default: `false`) |
| `temperature` | number | ❌ | Sampling temperature 0–2 (default: 1) |
| `max_tokens` | integer | ❌ | Maximum output tokens (≥ 1) |
| `top_p` | number | ❌ | Nucleus sampling 0–1 |
| `frequency_penalty` | number | ❌ | -2 to 2 |
| `presence_penalty` | number | ❌ | -2 to 2 |
| `n` | integer | ❌ | Number of completions 1–128 |
| `stop` | string / array | ❌ | Stop sequences |
| `user` | string | ❌ | End-user identifier |

**Multimodal Content (Vision):**

```json
{
  "messages": [{
    "role": "user",
    "content": [
      { "type": "text", "text": "What's in this image?" },
      { "type": "image_url", "image_url": { "url": "https://example.com/image.jpg" } }
    ]
  }]
}
```

### Non-Streaming Response

```json
{
  "id": "chatcmpl-abc123",
  "object": "chat.completion",
  "created": 1700000000,
  "model": "gemini-2.5-flash",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "Hello! How can I help you today?"
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 12,
    "completion_tokens": 10,
    "total_tokens": 22
  }
}
```

### Streaming Response

When `stream: true`, the response is a Server-Sent Events stream:

**Headers:**
```
Content-Type: text/event-stream
Cache-Control: no-cache, no-transform
Connection: keep-alive
X-Accel-Buffering: no
```

**Event Stream:**
```
data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1700000000,"model":"gemini-2.5-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}]}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1700000000,"model":"gemini-2.5-flash","choices":[{"index":0,"delta":{"content":"Hello"},"finish_reason":null}]}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1700000000,"model":"gemini-2.5-flash","choices":[{"index":0,"delta":{"content":"!"},"finish_reason":"stop"}]}

data: [DONE]
```

**Heartbeat:** A `: ping` comment is sent every 15 seconds during idle periods.

### cURL Example — Streaming

```bash
curl -X POST https://api.oxyy.ai/v1/chat/completions \
  -H "Authorization: Bearer oxyy_your_key" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemini-2.5-flash",
    "messages": [{"role": "user", "content": "Write a haiku"}],
    "stream": true
  }'
```

---

## 5. Image Generation

### `POST /v1/images/generations`

Generate images from text prompts.

**Request Body:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model` | string | ✅ | Model ID (e.g., `pollinations-flux`) |
| `prompt` | string | ✅ | Image description (max 32,000 chars) |
| `n` | integer | ❌ | Number of images 1–10 (default: 1) |
| `size` | string | ❌ | Resolution: `WIDTHxHEIGHT` or `"auto"` (default: model-specific) |
| `quality` | string | ❌ | `auto`, `high`, `medium`, `low`, `hd`, `standard` |
| `style` | string | ❌ | `vivid`, `natural` |
| `response_format` | string | ❌ | `url` (default) or `b64_json` |
| `background` | string | ❌ | `transparent`, `opaque`, `auto` |
| `output_format` | string | ❌ | `png`, `jpeg`, `webp` |
| `async` | boolean | ❌ | If `true`, returns async job (202) |
| `negative_prompt` | string | ❌ | Negative prompt (model-specific) |
| `seed` | integer | ❌ | Reproducibility seed |
| `user` | string | ❌ | End-user identifier |

### Synchronous Response (200)

```json
{
  "created": 1700000000,
  "data": [
    {
      "url": "https://cdn.oxyy.ai/images/abc123.png"
    }
  ]
}
```

### Async Response (202)

When `async: true`:

```json
{
  "id": "job_abc123",
  "object": "generation.job",
  "status": "pending",
  "type": "image",
  "model": "pollinations-flux",
  "created_at": "2025-01-15T12:00:00.000Z",
  "expires_at": "2025-01-15T13:00:00.000Z",
  "_links": {
    "self": "/v1/images/generations/job_abc123",
    "cancel": "/v1/images/generations/job_abc123"
  }
}
```

### Check Job Status

```
GET /v1/images/generations/:jobId
```

**Completed Job Response:**
```json
{
  "id": "job_abc123",
  "object": "generation.job",
  "status": "completed",
  "result": { "data": [{ "url": "https://..." }] },
  "created_at": "...",
  "completed_at": "..."
}
```

### Cancel Job

```
DELETE /v1/images/generations/:jobId
```

### List Image Jobs

```
GET /v1/images/generations?limit=20&offset=0&status=completed
```

### cURL Example

```bash
curl -X POST https://api.oxyy.ai/v1/images/generations \
  -H "Authorization: Bearer oxyy_your_key" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "pollinations-flux",
    "prompt": "A futuristic city at sunset, digital art",
    "size": "1024x1024",
    "n": 1
  }'
```

### Image Editing

```
POST /v1/images/edits
```

Same middleware and concurrency pattern. Accepts `image` (input image) and `prompt` parameters.

### Image Variations

```
POST /v1/images/variations
```

Same pattern. Accepts `image` parameter to generate variations.

---

## 6. Audio — Text-to-Speech

### `POST /v1/audio/speech`

Convert text to speech audio.

**Request Body:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model` | string | ✅ | Model ID (e.g., `eleven_v3`, `eleven_turbo_v2_5`) |
| `input` | string | ✅ | Text to convert (max 4,096 chars) |
| `voice` | string | ✅ | Voice ID (e.g., `Rachel`, `21m00Tcm4TlvDq8ikWAM`) |
| `response_format` | string | ❌ | `mp3` (default), `opus`, `aac`, `flac`, `wav`, `pcm` |
| `speed` | number | ❌ | Playback speed 0.25–4.0 |
| `output_format` | string | ❌ | Detailed format (e.g., `mp3_44100_128`, `pcm_16000`) |
| `instructions` | string | ❌ | Voice style instructions (GPT-4o TTS) |
| `async` | boolean | ❌ | Return async job (202) instead of audio data |
| `return_url` | boolean | ❌ | If `true`, returns JSON with `url` instead of binary |

### Synchronous Response (200)

Returns **binary audio data** directly with appropriate `Content-Type` header:

```
Content-Type: audio/mpeg
Content-Disposition: attachment; filename="speech.mp3"
```

**If `return_url: true`:**
```json
{
  "url": "https://cdn.oxyy.ai/audio/speech_abc123.mp3",
  "content_type": "audio/mpeg",
  "size": 45678
}
```

### Output Format Mapping

| `response_format` | Extension | Content-Type |
|-------------------|-----------|-------------|
| `mp3` | .mp3 | audio/mpeg |
| `opus` | .opus | audio/opus |
| `aac` | .aac | audio/aac |
| `flac` | .flac | audio/flac |
| `wav` | .wav | audio/wav |
| `pcm` | .pcm | audio/pcm |

### Available Voices (ElevenLabs)

The model's `options.voices` array lists all available voices. Use `GET /v1/models` to see the full list, or use these common ones:

| Voice ID | Name | Description |
|----------|------|-------------|
| `21m00Tcm4TlvDq8ikWAM` | Rachel | Calm American female |
| `29vD33N1CtxCmqQRPOHJ` | Drew | American male, well-rounded |
| `2EiwWnXFnvU5JabPnv8n` | Clyde | American male, middle-aged |
| `D38z5RcWu1voky8WS1ja` | Fin | Irish male, sharp |
| `EXAVITQu4vr4xnSDxMaL` | Bella | American female, soft |
| (42 built-in voices total) | ... | See `GET /v1/models` for full list |
| `custom` | Custom | Enter any ElevenLabs voice ID |

### cURL Example

```bash
curl -X POST https://api.oxyy.ai/v1/audio/speech \
  -H "Authorization: Bearer oxyy_your_key" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "eleven_turbo_v2_5",
    "input": "Hello, welcome to Oxyy AI!",
    "voice": "Rachel"
  }' \
  --output speech.mp3
```

---

## 7. Audio — Transcription & Translation (Speech-to-Text)

### Overview

Oxyy.ai provides OpenAI SDK-compatible speech-to-text transcription powered by ElevenLabs Scribe models. Upload an audio file and receive a text transcription in multiple output formats.

### Available STT Models

| Model ID | Display Name | Tier | Languages | Pricing |
|----------|-------------|------|-----------|---------|
| `scribe_v2` | Scribe v2 (Speech-to-Text) | SMART | 30 languages | ~$0.40/hr of audio |
| `scribe_v1` | Scribe v1 (Speech-to-Text) | FAST | 16 languages | ~$0.20/hr of audio |

> **Pricing Mode:** `PER_INPUT_HOUR` — credits are calculated based on audio duration.

### `POST /v1/audio/transcriptions`

Convert speech to text. Compatible with `client.audio.transcriptions.create()` from the OpenAI SDK.

**Request Body (multipart/form-data):**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model` | string | ✅ | Model ID (`scribe_v1` or `scribe_v2`) |
| `file` | file | ✅ | Audio file upload |
| `response_format` | string | ❌ | Output format (default: `json`) |
| `language` | string | ❌ | Language code for transcription (default: auto-detect) |
| `diarize` | boolean | ❌ | Enable speaker diarization (Scribe v2 only) |
| `num_speakers` | integer | ❌ | Expected number of speakers (with diarize) |
| `timestamps_granularity` | string | ❌ | `word` or `segment` |

**Supported Audio Formats:**

`mp3`, `mp4`, `mpeg`, `mpga`, `m4a`, `wav`, `webm`, `ogg`, `flac`, `aac`, `mov`, `avi`

**Response Formats:**

| Format | Content-Type | Description |
|--------|-------------|-------------|
| `json` | `application/json` | Simple JSON with `text` field (default) |
| `verbose_json` | `application/json` | Full JSON with text, segments, words, duration, language |
| `text` | `text/plain` | Plain text transcription only |
| `srt` | `text/plain` | SubRip subtitle format with timestamps |
| `vtt` | `text/vtt` | WebVTT subtitle format with timestamps |

**Supported Languages (Scribe v2):**

`auto` (Auto-detect), `eng`, `spa`, `fra`, `deu`, `ita`, `por`, `nld`, `jpn`, `zho`, `kor`, `hin`, `ara`, `rus`, `tur`, `pol`, `swe`, `dan`, `nor`, `fin`, `ces`, `ron`, `ell`, `heb`, `tha`, `vie`, `ind`, `msa`, `fil`, `ukr`

### Response Examples

**`json` (default):**
```json
{
  "text": "Hello, this is a transcription test."
}
```

**`verbose_json`:**
```json
{
  "task": "transcribe",
  "language": "eng",
  "duration": 5.2,
  "text": "Hello, this is a transcription test.",
  "segments": [
    {
      "start": 0.0,
      "end": 2.4,
      "text": "Hello, this is a",
      "speaker": "speaker_0"
    },
    {
      "start": 2.4,
      "end": 5.2,
      "text": "transcription test.",
      "speaker": "speaker_0"
    }
  ],
  "words": [
    { "text": "Hello,", "start": 0.0, "end": 0.5, "type": "word" },
    { "text": "this", "start": 0.6, "end": 0.8, "type": "word" },
    { "text": "is", "start": 0.9, "end": 1.0, "type": "word" },
    { "text": "a", "start": 1.1, "end": 1.2, "type": "word" },
    { "text": "transcription", "start": 2.4, "end": 3.8, "type": "word" },
    { "text": "test.", "start": 3.9, "end": 5.2, "type": "word" }
  ]
}
```

**`text`:**
```
Hello, this is a transcription test.
```

**`srt`:**
```
1
00:00:00,000 --> 00:00:02,400
Hello, this is a

2
00:00:02,400 --> 00:00:05,200
transcription test.
```

**`vtt`:**
```
WEBVTT

00:00:00.000 --> 00:00:02.400
Hello, this is a

00:00:02.400 --> 00:00:05.200
transcription test.
```

### SDK Examples

**Python (OpenAI SDK):**
```python
from openai import OpenAI
from pathlib import Path

client = OpenAI(
    api_key="oxyy_your_api_key_here",
    base_url="https://api.oxyy.ai/v1"
)

audio_file = Path("audio.mp3")

# Simple transcription
response = client.audio.transcriptions.create(
    model="scribe_v2",
    file=audio_file,
    response_format="verbose_json"
)

print(response.text)
print(f"Language: {response.language}")
print(f"Duration: {response.duration}s")

# Print segments if available
if hasattr(response, 'segments'):
    for seg in response.segments:
        print(f"[{seg.start:.1f}s - {seg.end:.1f}s] {seg.text}")
```

**Node.js (OpenAI SDK):**
```javascript
import OpenAI from 'openai';
import fs from 'fs';

const client = new OpenAI({
  apiKey: 'oxyy_your_api_key_here',
  baseURL: 'https://api.oxyy.ai/v1'
});

const response = await client.audio.transcriptions.create({
  model: 'scribe_v2',
  file: fs.createReadStream('audio.mp3'),
  response_format: 'verbose_json'
});

console.log(response.text);
console.log('Language:', response.language);
console.log('Duration:', response.duration, 's');
```

**Python (requests):**
```python
import requests

API_KEY = "oxyy_your_api_key_here"
BASE_URL = "https://api.oxyy.ai/v1"

with open("audio.mp3", "rb") as f:
    response = requests.post(
        f"{BASE_URL}/audio/transcriptions",
        headers={"Authorization": f"Bearer {API_KEY}"},
        files={"file": ("audio.mp3", f, "audio/mpeg")},
        data={
            "model": "scribe_v2",
            "response_format": "verbose_json"
        }
    )

result = response.json()
print(result["text"])
print(f"Duration: {result.get('duration')}s")
```

**cURL:**
```bash
curl -X POST https://api.oxyy.ai/v1/audio/transcriptions \
  -H "Authorization: Bearer oxyy_your_api_key_here" \
  -F "model=scribe_v2" \
  -F "file=@audio.mp3" \
  -F "response_format=verbose_json"
```

**PHP:**
```php
<?php
$client = OpenAI::factory()
    ->withApiKey('oxyy_your_api_key_here')
    ->withBaseUri('https://api.oxyy.ai/v1')
    ->make();

$response = $client->audio()->transcribe([
    'model' => 'scribe_v2',
    'file' => fopen('audio.mp3', 'r'),
    'response_format' => 'verbose_json',
]);

echo $response->text;
echo "Language: " . $response->language;
echo "Duration: " . $response->duration . "s";
```

### Error Responses

| Status | Code | Description |
|--------|------|-------------|
| 400 | `missing_model` | Model parameter not provided |
| 400 | `missing_file` | No audio file uploaded |
| 404 | `model_not_found` | Model doesn't exist or is disabled |
| 402 | `insufficient_credits` | Not enough credits |
| 429 | `concurrency_limit_exceeded` | Too many concurrent requests |
| 503 | `not_supported` | Model plugin doesn't support transcription |

### `POST /v1/audio/translations`

Translate audio to English text. Same parameters as transcriptions (except `language` — output is always English).

---

## 8. Video Generation

### `POST /v1/videos/generations`

Generate videos from text prompts or images. **Videos are async by default** (unlike images/audio which are sync by default).

**Request Body:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model` | string | ✅ | Model ID (e.g., `pollinations-veo`, `pollinations-seedance`) |
| `prompt` | string | ✅* | Text prompt (required unless `image` provided) |
| `image` | string | ✅* | Input image URL or base64 (required for image-to-video) |
| `duration` | string/number | ❌ | Duration: `"4"`, `"8"`, `"12"` or seconds 1–60 |
| `resolution` | string | ❌ | `480p`, `720p`, `1080p`, `4k` |
| `size` | string | ❌ | `WIDTHxHEIGHT` format |
| `aspect_ratio` | string | ❌ | e.g., `16:9`, `9:16`, `1:1` |
| `n` | integer | ❌ | Number of videos |
| `sync` | boolean | ❌ | `true` = wait for completion (default: `false` = async) |
| `user` | string | ❌ | End-user identifier |

### Async Response (202) — Default

```json
{
  "id": "job_vid_123",
  "object": "generation.job",
  "status": "pending",
  "type": "video",
  "model": "pollinations-veo",
  "created_at": "2025-01-15T12:00:00.000Z",
  "expires_at": "2025-01-15T13:00:00.000Z",
  "_links": {
    "self": "/v1/videos/generations/job_vid_123",
    "cancel": "/v1/videos/generations/job_vid_123"
  }
}
```

### Sync Response (200) — When `sync: true`

```json
{
  "created": 1700000000,
  "data": [
    {
      "url": "https://cdn.oxyy.ai/videos/abc123.mp4",
      "duration": 4,
      "resolution": "1080p"
    }
  ],
  "usage": {
    "credits_consumed": 150
  }
}
```

### Image-to-Video

```
POST /v1/videos/image-to-video
```

Requires `image` in the request body. Same response patterns.

### Check Video Job Status

```
GET /v1/videos/generations/:jobId
```

### Cancel Video Job

```
DELETE /v1/videos/generations/:jobId
```

### List Video Jobs

```
GET /v1/videos/generations?limit=20&offset=0&status=pending
```

### List Video Models

```
GET /v1/videos/models
```

Returns models with types `TEXT_TO_VIDEO`, `IMAGE_TO_VIDEO`, `VIDEO_TO_VIDEO`.

### cURL Example — Async Video

```bash
# Start generation
curl -X POST https://api.oxyy.ai/v1/videos/generations \
  -H "Authorization: Bearer oxyy_your_key" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "pollinations-veo",
    "prompt": "A drone flying over a mountain landscape",
    "resolution": "1080p",
    "duration": "4"
  }'

# Check status
curl https://api.oxyy.ai/v1/videos/generations/job_vid_123 \
  -H "Authorization: Bearer oxyy_your_key"
```

---

## 9. Models

### `GET /v1/models`

List all available models. Results are filtered by your subscription's allowed models and tiers.

**Response:**

```json
{
  "object": "list",
  "data": [
    {
      "id": "gemini-2.5-flash",
      "object": "model",
      "created": 1700000000,
      "owned_by": "google",
      "type": "TEXT",
      "tier": "FAST",
      "displayName": "Gemini 2.5 Flash",
      "description": "Fast and efficient Gemini model",
      "contextWindow": 1000000,
      "maxTokens": 65536,
      "capabilities": ["chat", "completion", "vision", "embeddings"],
      "inputTypes": ["text"],
      "options": {},
      "pricing": {
        "mode": "PER_TOKEN_IO",
        "inputCreditsPerMillion": 180.0,
        "outputCreditsPerMillion": 720.0
      },
      "oxyy": {
        "modelId": "gemini-2.5-flash",
        "type": "TEXT",
        "tier": "FAST",
        "pricing": {
          "mode": "PER_TOKEN_IO",
          "creditsPerInputToken": 0.00000018,
          "creditsPerOutputToken": 0.00000072,
          "inputCreditsPerMillion": 180.0,
          "outputCreditsPerMillion": 720.0
        }
      }
    }
  ]
}
```

> **Note:** Pricing is expressed in **credits only**. Raw USD provider costs are never exposed.

### `GET /v1/models/:modelId`

Get details for a specific model. Returns the same format as a single item from the list response.

```bash
curl https://api.oxyy.ai/v1/models/gemini-2.5-flash \
  -H "Authorization: Bearer oxyy_your_key"
```

### `DELETE /v1/models/:modelId`

Always returns **405 Method Not Allowed**. Models cannot be deleted via the public API.

---

## 10. Async Jobs

For long-running operations (video generation, large image batches), requests can return asynchronous job references.

### Job Lifecycle

```
PENDING → PROCESSING → COMPLETED / FAILED
                      ↘ CANCELLED (via DELETE)
```

### Job Object

```json
{
  "id": "job_abc123",
  "object": "generation.job",
  "status": "pending",
  "type": "image | video | audio",
  "model": "model_id",
  "created_at": "2025-01-15T12:00:00.000Z",
  "expires_at": "2025-01-15T13:00:00.000Z",
  "completed_at": null,
  "result": null,
  "error": null,
  "_links": {
    "self": "/v1/{type}/generations/{id}",
    "cancel": "/v1/{type}/generations/{id}"
  }
}
```

### Default Behavior by Endpoint

| Endpoint | Default Mode | Async Flag |
|----------|-------------|------------|
| `POST /v1/chat/completions` | Sync | — (always sync) |
| `POST /v1/images/generations` | **Sync** | `"async": true` → 202 |
| `POST /v1/audio/speech` | **Sync** | `"async": true` → 202 |
| `POST /v1/videos/generations` | **Async** | `"sync": true` → 200 |

### Polling Pattern

```bash
# 1. Create async job
JOB=$(curl -s -X POST https://api.oxyy.ai/v1/images/generations \
  -H "Authorization: Bearer oxyy_key" \
  -H "Content-Type: application/json" \
  -d '{"model":"pollinations-flux","prompt":"A cat","async":true}' \
  | jq -r '.id')

# 2. Poll for status
while true; do
  STATUS=$(curl -s https://api.oxyy.ai/v1/images/generations/$JOB \
    -H "Authorization: Bearer oxyy_key" | jq -r '.status')
  
  echo "Status: $STATUS"
  [ "$STATUS" = "completed" ] && break
  [ "$STATUS" = "failed" ] && break
  sleep 2
done

# 3. Get result
curl -s https://api.oxyy.ai/v1/images/generations/$JOB \
  -H "Authorization: Bearer oxyy_key" | jq '.result'
```

---

## 11. Auth Endpoints

### Register

```
POST /v1/auth/register
```

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `email` | string | ✅ | Valid email address |
| `password` | string | ✅ | 8–100 characters |
| `firstName` | string | ❌ | 2–100 characters |
| `lastName` | string | ❌ | 1–50 characters |
| `recaptchaToken` | string | ❌ | Required if reCAPTCHA enabled |

**Response (201):**
```json
{
  "success": true,
  "data": {
    "user": { "id": "...", "email": "..." },
    "accessToken": "eyJ...",
    "refreshToken": "..."
  }
}
```

### Login

```
POST /v1/auth/login
```

| Parameter | Type | Required |
|-----------|------|----------|
| `email` | string | ✅ |
| `password` | string | ✅ |
| `recaptchaToken` | string | ❌ |

**Response (200):** Same structure as register.

### Logout

```
POST /v1/auth/logout
```

No body required. Requires authentication.

### Refresh Token

```
POST /v1/auth/refresh
```

| Parameter | Type | Required |
|-----------|------|----------|
| `refreshToken` | string | ✅ |

**Response:** `{ "accessToken": "...", "refreshToken": "..." }`

### Forgot Password

```
POST /v1/auth/forgot-password
```

| Parameter | Type | Required |
|-----------|------|----------|
| `email` | string | ✅ |

### Reset Password

```
POST /v1/auth/reset-password
```

| Parameter | Type | Required |
|-----------|------|----------|
| `token` | string | ✅ |
| `password` | string | ✅ |

### Change Password

```
POST /v1/auth/change-password
```

Requires authentication.

| Parameter | Type | Required |
|-----------|------|----------|
| `currentPassword` | string | ✅ |
| `newPassword` | string | ✅ |

### Email Verification

```
POST /v1/auth/verify-email         — Verify via token link
POST /v1/auth/verify-email-code    — Verify via 6-digit code
POST /v1/auth/resend-verification  — Resend verification email
```

### OAuth

```
GET /v1/auth/oauth/google           — Redirect to Google OAuth
GET /v1/auth/oauth/google/callback   — Google callback
GET /v1/auth/oauth/github           — Redirect to GitHub OAuth
GET /v1/auth/oauth/github/callback   — GitHub callback
GET /v1/auth/oauth/discord          — Redirect to Discord OAuth
GET /v1/auth/oauth/discord/callback  — Discord callback
GET /v1/auth/oauth/providers         — List enabled providers
```

### Session Management

```
GET    /v1/auth/sessions            — List active sessions
DELETE /v1/auth/sessions/:id        — Revoke specific session
DELETE /v1/auth/sessions/all        — Revoke all except current
GET    /v1/auth/me                  — Get current user profile
```

### Two-Factor Authentication (2FA)

Oxyy.ai supports TOTP-based two-factor authentication with backup codes and trusted device management.

#### Get 2FA Status

```
GET /v1/auth/2fa/status
```

Requires JWT authentication. Returns whether 2FA is enabled for the account.

**Response (200):**
```json
{
  "success": true,
  "data": {
    "enabled": false,
    "hasBackupCodes": false
  }
}
```

#### Setup 2FA

```
POST /v1/auth/2fa/setup
```

Requires JWT authentication. Generates a TOTP secret and QR code for authenticator app setup.

**Response (200):**
```json
{
  "success": true,
  "data": {
    "secret": "JBSWY3DPEHPK3PXP",
    "qrCode": "data:image/png;base64,...",
    "otpAuthUrl": "otpauth://totp/Oxyy.ai:user@example.com?secret=..."
  }
}
```

#### Verify & Enable 2FA

```
POST /v1/auth/2fa/verify
```

Requires JWT authentication. Verifies a TOTP token from the authenticator app and enables 2FA. Returns one-time backup codes.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `token` | string | ✅ | 6-digit TOTP code from authenticator |

**Response (200):**
```json
{
  "success": true,
  "data": {
    "enabled": true,
    "backupCodes": [
      "a1b2c3d4", "e5f6g7h8", "i9j0k1l2",
      "m3n4o5p6", "q7r8s9t0", "u1v2w3x4",
      "y5z6a7b8", "c9d0e1f2"
    ]
  },
  "message": "2FA enabled. Save your backup codes securely."
}
```

> ⚠️ **Important:** Backup codes are shown only once. Store them securely.

#### Verify 2FA During Login

```
POST /v1/auth/2fa/verify-login
```

When a user with 2FA enabled logs in, the login endpoint returns a `tempToken` instead of access tokens. Use this endpoint to complete authentication.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `tempToken` | string | ✅ | Temporary token from login response |
| `token` | string | ✅ | 6-digit TOTP code or backup code |
| `trustDevice` | boolean | ❌ | Trust this browser for 30 days |

**Login response when 2FA is enabled:**
```json
{
  "success": true,
  "data": {
    "requires2FA": true,
    "tempToken": "temp_eyJ..."
  }
}
```

**2FA Verify Login Response (200):**
```json
{
  "success": true,
  "data": {
    "user": { "id": "...", "email": "..." },
    "accessToken": "eyJ...",
    "refreshToken": "...",
    "deviceToken": "dt_a1b2c3..."
  }
}
```

The `deviceToken` is only returned when `trustDevice: true`. Send it as the `X-Device-Token` header on subsequent login requests to skip 2FA on that browser.

#### Disable 2FA

```
POST /v1/auth/2fa/disable
```

Requires JWT authentication.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `token` | string | ✅ | 6-digit TOTP code to confirm |

#### Regenerate Backup Codes

```
POST /v1/auth/2fa/backup-codes/regenerate
```

Requires JWT authentication. Invalidates old backup codes and generates new ones.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `token` | string | ✅ | 6-digit TOTP code to confirm |

**Response (200):**
```json
{
  "success": true,
  "data": {
    "backupCodes": ["a1b2c3d4", "e5f6g7h8", "..."]
  },
  "message": "New backup codes generated. Old codes are now invalid."
}
```

#### Trusted Devices

```
GET    /v1/auth/2fa/trusted-devices              — List trusted devices/browsers
DELETE /v1/auth/2fa/trusted-devices/:deviceId     — Remove a specific trusted device
DELETE /v1/auth/2fa/trusted-devices               — Remove all trusted devices
```

All require JWT authentication.

**List Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": "dev_abc123",
      "browser": "Chrome 120",
      "os": "Windows 10",
      "lastUsed": "2025-06-15T10:30:00.000Z",
      "createdAt": "2025-06-01T08:00:00.000Z"
    }
  ]
}

---

## 12. User Endpoints

All require authentication.

### Profile

```
GET /v1/user/profile              — Get user profile
PUT /v1/user/profile              — Update profile (firstName, lastName, avatar)
```

### Credits & Balance

```
GET /v1/user/credits              — Get credit balance & live concurrent status
```

**Response:**
```json
{
  "success": true,
  "data": {
    "creditBalance": "1500.0000",
    "concurrent": {
      "current": 2,
      "limit": 10,
      "available": 8
    }
  }
}
```

### API Keys

```
GET    /v1/user/api-keys              — List all API keys (prefix only, never full key)
POST   /v1/user/api-keys              — Create new API key (returns full key ONCE)
GET    /v1/user/api-keys/:id          — Get API key details
PUT    /v1/user/api-keys/:id          — Update API key (name, permissions)
DELETE /v1/user/api-keys/:id          — Revoke API key
POST   /v1/user/api-keys/:id/regenerate — Regenerate key (old key revoked)
```

API key creation is limited by your subscription package. The `maxApiKeys` field on your package determines how many active (non-revoked) keys you can have. Default limit is 5.

**Create API Key Response (200):**
```json
{
  "success": true,
  "data": {
    "id": "key_abc123",
    "name": "My App Key",
    "key": "oxyy_a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6",
    "keyPrefix": "oxyy_a1b2c3d4",
    "created_at": "2025-01-15T12:00:00.000Z",
    "limit": {
      "current": 2,
      "max": 5
    }
  },
  "message": "Store this key securely — it will not be shown again."
}
```

**Error — Limit Reached (403):**
```json
{
  "success": false,
  "error": {
    "message": "API key limit reached. Your plan allows a maximum of 5 API keys.",
    "code": "API_KEY_LIMIT_REACHED"
  }
}
```

### Usage

```
GET /v1/user/usage                — Paginated usage history
GET /v1/user/usage/chart          — 30-day chart data
GET /v1/user/usage/by-endpoint    — Usage grouped by endpoint
```

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `page` | integer | 1 | Page number |
| `limit` | integer | 20 | Items per page (max 100) |
| `startDate` | string | — | ISO date filter start |
| `endDate` | string | — | ISO date filter end |
| `model` | string | — | Filter by model ID |

### Subscriptions

```
GET  /v1/user/subscription            — Get active subscription
POST /v1/user/subscription/free       — Activate free package
POST /v1/user/subscription/activate   — Activate with coupon
POST /v1/user/subscription/cancel     — Cancel subscription
```

### Transactions & Payments

```
GET  /v1/user/transactions            — Credit transaction history
GET  /v1/user/payments                — Payment history
POST /v1/user/payments/initiate       — Start payment (returns provider URL)
POST /v1/user/credits/topup           — Top up credits (20k credits = $1)
```

### Credit Purchases & Priority

```
GET  /v1/user/credit-purchases              — List all credit purchases with expiry & priority
PUT  /v1/user/credit-purchases/:id/priority — Update credit consumption priority (re-normalizes all priorities)
POST /v1/user/credit-purchases/reorder      — Move a credit purchase up or down in priority order
```

> **Priority-Based Deduction:** Credits are deducted in priority order. Subscription credits are always consumed first, then purchased credits are consumed by priority number (lower = first). Each purchase tracks `creditsUsed` and `creditsRemaining`.

#### GET /v1/user/credit-purchases

Returns all `CREDIT_ADD` transactions (purchases, admin-added, subscription credits) enriched with payment source info, expiry status, and consumption priority.

**Response fields per entry:**

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Transaction UUID |
| `credits` | number | Credits added |
| `creditsUsed` | number | Credits consumed from this purchase so far |
| `creditsRemaining` | number | Credits remaining (`credits - creditsUsed`) |
| `description` | string | Human-readable description |
| `paymentMethod` | string\|null | Display: `Card (Stripe)`, `Crypto (Cryptomus)`, `Subscription`, `Admin Added` |
| `paymentProvider` | string\|null | Raw: `STRIPE`, `CRYPTOMUS`, `NOWPAYMENTS`, `SUBSCRIPTION`, `ADMIN` |
| `priority` | integer | Consumption order (0 = auto, 1 = highest) |
| `expiresAt` | ISO date\|null | When credits expire (`null` = never) |
| `daysRemaining` | integer\|null | Days until expiry |
| `isExpired` | boolean | Whether credits have expired |
| `createdAt` | ISO datetime | Full datetime (date + time) when the purchase was made |

**Sort:** `priority ASC`, then `createdAt DESC`.

#### PUT /v1/user/credit-purchases/:id/priority

Update the consumption priority of a credit purchase. Lower numbers are consumed first. After updating, all priorities are **re-normalized** to sequential numbers (1, 2, 3...) to prevent duplicates.

**Request:**
```json
{ "priority": 1 }
```

**Validation:** Non-negative integer, transaction must belong to user and be `CREDIT_ADD` type.

**Response:**
```json
{
  "success": true,
  "data": { "id": "txn_abc123", "priority": 1, "message": "Priority updated" }
}
```

#### POST /v1/user/credit-purchases/reorder

Move a credit purchase up or down in priority order. Re-normalizes all priorities to sequential numbers (1, 2, 3...).

**Request:**
```json
{
  "sourceId": "txn_abc123",
  "direction": "up"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `sourceId` | string | ✅ | Transaction UUID to move |
| `direction` | string | ✅ | `"up"` (higher priority / lower number) or `"down"` (lower priority / higher number) |

**Response:**
```json
{
  "success": true,
  "data": {
    "message": "Priority reordered",
    "purchases": [
      { "id": "txn_abc123", "priority": 1 },
      { "id": "txn_def456", "priority": 2 },
      { "id": "txn_ghi789", "priority": 3 }
    ]
  }
}
```

**Initiate Payment Request:**
```json
{
  "packageId": "pkg_abc123",
  "provider": "stripe",
  "couponCode": "SAVE20"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "paymentId": "pay_abc123",
    "url": "https://checkout.stripe.com/c/pay/...",
    "provider": "stripe"
  }
}
```

---

## 13. Public Endpoints

These endpoints require no authentication.

```
GET /v1/public/packages               — List public pricing packages
GET /v1/public/packages/:id           — Get package details
GET /v1/public/models                 — List available models (pricing info)
GET /v1/public/models/:modelId        — Get model pricing details
POST /v1/public/coupon/validate       — Validate a coupon code
GET /v1/public/status                 — API health status
GET /v1/public/payment-providers      — List enabled payment providers
GET /v1/public/credit-packages        — List active credit top-up packages
GET /v1/public/credit-system-status   — Check if credit system is enabled
GET /v1/public/custom-credit-settings — Get custom credit configuration
```

### GET /v1/public/credit-packages

Returns active credit top-up packages.

```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "name": "Starter Pack",
      "credits": 100000,
      "price": 5.00,
      "currency": "USD",
      "bonusCredits": 5000,
      "description": "Best for trying out",
      "popular": false,
      "expiryDays": 30,
      "creditsPerDollar": null,
      "bonusTiers": null
    }
  ]
}
```

### GET /v1/public/credit-system-status

Returns whether the credit system is enabled.

```json
{
  "success": true,
  "data": { "enabled": true }
}
```

### GET /v1/public/custom-credit-settings

Returns the custom credit top-up configuration (user-facing). Used by frontends to display custom amount input with dynamic bonus tiers.

```json
{
  "success": true,
  "data": {
    "enabled": true,
    "creditsPerDollar": 20000,
    "minAmount": 5,
    "maxAmount": 10000,
    "bonusTiers": [
      { "minAmount": 100, "bonusPercent": 5 },
      { "minAmount": 500, "bonusPercent": 10 },
      { "minAmount": 1000, "bonusPercent": 15 }
    ]
  }
}
```

**Bonus Tier Logic:** When a user tops up a custom dollar amount, the highest matching tier is applied. For example, a $600 top-up at 20,000 credits/dollar with the above tiers yields: 12,000,000 base credits + 10% bonus = 13,200,000 total credits.

---

## 14. Webhooks

Payment provider webhooks (not user-facing):

```
POST /v1/webhooks/stripe              — Stripe webhook (signature verified)
POST /v1/webhooks/cryptomus           — Cryptomus webhook (MD5 + IP whitelist)
POST /v1/webhooks/nowpayments         — NOWPayments webhook (HMAC-SHA512)
```

---

## 15. Admin Credit & Settings Endpoints

All admin endpoints require JWT authentication with `ADMIN`, `SUPER_ADMIN`, or `DEVELOPER` role.

### Credit Packages CRUD

```
GET    /v1/admin/credit-packages           — List all credit packages
POST   /v1/admin/credit-packages           — Create a credit package
PUT    /v1/admin/credit-packages/:id       — Update a credit package
DELETE /v1/admin/credit-packages/:id       — Delete a credit package
```

#### POST /v1/admin/credit-packages

**Request Body:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| name | string | ✓ | Package display name |
| credits | number | ✓ | Base credits in package |
| price | number | ✓ | Price in USD |
| currency | string | — | Currency code (default: `USD`) |
| bonusCredits | number | — | Bonus credits included (default: `0`) |
| description | string | — | Description text |
| isPopular | boolean | — | Show "Popular" badge (default: `false`) |
| isActive | boolean | — | Active/visible (default: `true`) |
| sortOrder | number | — | Display order (default: `0`) |
| expiryDays | number | — | Credit expiry in days (default: `30`) |
| creditsPerDollar | number | — | Override credits/dollar for this package |
| bonusTiers | array | — | Package-specific bonus tiers (JSON) |

### Custom Credit Settings

Allows admins to configure a custom credit top-up system where users enter any dollar amount.

```
GET /v1/admin/settings/custom-credit       — Get custom credit configuration
PUT /v1/admin/settings/custom-credit       — Update custom credit configuration
```

#### PUT /v1/admin/settings/custom-credit

**Request Body:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| enabled | boolean | — | Enable custom credit input (default: `false`) |
| creditsPerDollar | number | — | Credits per $1 (default: `20000`) |
| minAmount | number | — | Minimum dollar amount (default: `5`) |
| maxAmount | number | — | Maximum dollar amount (default: `10000`) |
| bonusTiers | array | — | Volume bonus tiers |

**bonusTiers array item:**

| Field | Type | Description |
|-------|------|-------------|
| minAmount | number | Minimum dollar amount to trigger this tier |
| bonusPercent | number | Bonus percentage applied to base credits |

**Example Request:**

```json
{
  "enabled": true,
  "creditsPerDollar": 20000,
  "minAmount": 5,
  "maxAmount": 10000,
  "bonusTiers": [
    { "minAmount": 100, "bonusPercent": 5 },
    { "minAmount": 500, "bonusPercent": 10 },
    { "minAmount": 1000, "bonusPercent": 15 }
  ]
}
```

### Credit System Toggle (Developer Only)

```
GET /v1/admin/settings/credit-system       — Get credit system on/off status
PUT /v1/admin/settings/credit-system       — Toggle credit system on/off
```

Only `DEVELOPER` role can access these endpoints. When disabled, credits are not deducted for API requests.

### Admin 2FA Reset

```
POST /v1/admin/users/:userId/reset-2fa    — Reset (disable) 2FA for a user
```

Only `SUPER_ADMIN` and `DEVELOPER` can reset 2FA. The target user must have 2FA enabled. `SUPER_ADMIN` cannot reset `DEVELOPER` 2FA. The user list endpoint now includes `twoFactorEnabled` field for each user.

---

## 16. SDK Compatibility

Oxyy.ai is designed to be a **drop-in replacement** for the OpenAI API. You can use any OpenAI-compatible SDK by changing the base URL:

### Python

```python
from openai import OpenAI
client = OpenAI(api_key="oxyy_...", base_url="https://api.oxyy.ai/v1")
```

### Node.js

```javascript
import OpenAI from 'openai';
const client = new OpenAI({ apiKey: 'oxyy_...', baseURL: 'https://api.oxyy.ai/v1' });
```

### cURL

```bash
export OPENAI_API_KEY="oxyy_your_key"
export OPENAI_BASE_URL="https://api.oxyy.ai/v1"
```

### Python (requests)

```python
import requests

headers = {"Authorization": "Bearer oxyy_your_key"}
response = requests.post(
    "https://api.oxyy.ai/v1/chat/completions",
    headers=headers,
    json={
        "model": "gemini-2.5-flash",
        "messages": [{"role": "user", "content": "Hello!"}]
    }
)
print(response.json()["choices"][0]["message"]["content"])
```

### Credit System

- **1000 credits = $1.00 USD** (configurable by platform admin)
- Credits are deducted in real-time after each API call
- Use `GET /v1/user/credits` to check your balance
- Pricing per model is available in `GET /v1/models` response

### Differences from OpenAI

| Feature | OpenAI | Oxyy.ai |
|---------|--------|---------|
| Base URL | `api.openai.com` | `api.oxyy.ai` |
| API Key Prefix | `sk-` | `oxyy_` or `sk-` |
| Billing | USD directly | Credits (1000 = $1) |
| Models | OpenAI only | Multi-provider (Google, ElevenLabs, Pollinations, etc.) |
| Video generation | Not available | `POST /v1/videos/generations` |
| Speech-to-Text | Whisper only | ElevenLabs Scribe v1/v2 (via same SDK interface) |
| Async jobs | Not available | 202 responses with job polling |
| Model metadata | Basic | Extended `oxyy` object with pricing, options, capabilities |
