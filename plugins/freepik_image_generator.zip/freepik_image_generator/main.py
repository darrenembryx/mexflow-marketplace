"""
Freepik AI Image Generator Plugin
=================================

Generate high-quality AI images using Freepik's Mystic AI API.
Supports scene images, frames, and various styles.

API Documentation: https://docs.freepik.com/ai-image-generation
"""

import os
import json
import httpx
import asyncio
import base64
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path
import uuid

# Plugin SDK import - will be available when plugin is executed
try:
    from mexflow_plugin import plugin, PluginResult
except ImportError:
    # For standalone testing
    plugin = None
    PluginResult = None


# =============================================================================
# Freepik API Configuration
# =============================================================================

FREEPIK_API_URL = "https://api.freepik.com/v1/ai/text-to-image"
FREEPIK_MYSTIC_URL = "https://api.freepik.com/v1/ai/mystic"

# Aspect ratio to dimension mapping
ASPECT_RATIOS = {
    "1:1": {"width": 1024, "height": 1024},
    "16:9": {"width": 1344, "height": 768},
    "9:16": {"width": 768, "height": 1344},
    "4:3": {"width": 1152, "height": 896},
    "3:4": {"width": 896, "height": 1152},
    "21:9": {"width": 1536, "height": 640},
}

# Style presets for prompt enhancement
STYLE_PROMPTS = {
    "photo": ", ultra realistic photography, high resolution, sharp focus, professional lighting, 8k",
    "digital_art": ", digital art, detailed illustration, vibrant colors, trending on artstation",
    "anime": ", anime style, studio ghibli inspired, cel shaded, vibrant, detailed",
    "3d_render": ", 3D render, octane render, highly detailed, raytracing, photorealistic",
    "cinematic": ", cinematic shot, movie still, anamorphic lens, dramatic lighting, 35mm film",
    "fantasy": ", fantasy art, epic, magical, detailed environment, dramatic atmosphere",
    "oil_painting": ", oil painting style, classical art, brush strokes visible, rich colors",
}


# =============================================================================
# Helper Functions
# =============================================================================

def enhance_prompt(prompt: str, style: str = "photo", auto_enhance: bool = True) -> str:
    """Enhance the prompt with style modifiers"""
    if not auto_enhance:
        return prompt
    
    style_suffix = STYLE_PROMPTS.get(style, "")
    return prompt.strip() + style_suffix


def get_output_path(images_dir: str, project_id: str, scene_id: str = None, image_type: str = "scene", subfolder: str = None) -> str:
    """
    Generate output path for the image using provided images_dir
    
    Args:
        images_dir: Base directory for images (from config.IMAGES_DIR)
        project_id: Project ID
        scene_id: Scene ID
        image_type: Type of image (scene, frame_first, character, object, etc.)
        subfolder: Optional subfolder (e.g., 'characters', 'objects')
    """
    import os
    from datetime import datetime
    import uuid
    
    # Use provided images_dir as base
    base_dir = images_dir
    
    # Add project_id subfolder
    if project_id:
        base_dir = os.path.join(base_dir, project_id)
    
    # Add optional subfolder (e.g., 'characters', 'objects')
    if subfolder:
        base_dir = os.path.join(base_dir, subfolder)
    
    os.makedirs(base_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{image_type}_{scene_id or 'unknown'}_{timestamp}_{uuid.uuid4().hex[:8]}.png"
    
    return os.path.join(base_dir, filename)


async def download_image(url: str, output_path: str) -> str:
    """Download image from URL and save to disk"""
    import logging
    logger = logging.getLogger("mexflow.freepik")
    
    logger.info(f"🖼️ Freepik: Downloading image from {url}")
    logger.info(f"🖼️ Freepik: Saving to {output_path}")
    
    # Ensure directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.get(url)
        logger.info(f"🖼️ Freepik: Download response status: {response.status_code}")
        response.raise_for_status()
        
        content_length = len(response.content)
        logger.info(f"🖼️ Freepik: Downloaded {content_length} bytes")
        
        with open(output_path, "wb") as f:
            f.write(response.content)
        
        # Verify file was created
        if os.path.exists(output_path):
            file_size = os.path.getsize(output_path)
            logger.info(f"🖼️ Freepik: ✅ File saved successfully! Size: {file_size} bytes")
        else:
            logger.error(f"🖼️ Freepik: ❌ File NOT created at {output_path}")
    
    return output_path


async def save_base64_image(base64_data: str, output_path: str) -> str:
    """Save base64 encoded image to disk"""
    import logging
    logger = logging.getLogger("mexflow.freepik")
    
    logger.info(f"🖼️ Freepik: Saving base64 image to {output_path}")
    
    # Ensure directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # Remove data URL prefix if present
    if "," in base64_data:
        base64_data = base64_data.split(",", 1)[1]
    
    image_data = base64.b64decode(base64_data)
    logger.info(f"🖼️ Freepik: Base64 decoded to {len(image_data)} bytes")
    
    with open(output_path, "wb") as f:
        f.write(image_data)
    
    # Verify file was created
    if os.path.exists(output_path):
        file_size = os.path.getsize(output_path)
        logger.info(f"🖼️ Freepik: ✅ Base64 file saved! Size: {file_size} bytes")
    else:
        logger.error(f"🖼️ Freepik: ❌ Base64 file NOT created at {output_path}")
    
    return output_path


# =============================================================================
# Freepik API Client
# =============================================================================

class FreepikClient:
    """Freepik AI Image Generation Client"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.headers = {
            "x-freepik-api-key": api_key,
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
    
    async def generate_image(
        self,
        prompt: str,
        negative_prompt: str = "",
        width: int = 1024,
        height: int = 1024,
        num_images: int = 1,
        guidance_scale: float = 7.5,
        num_inference_steps: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Generate images using Freepik Mystic API
        
        Mystic API is ASYNCHRONOUS:
        1. POST request returns a task_id with status "IN_PROGRESS" or "CREATED"
        2. Must poll GET /v1/ai/mystic/{task_id} until status becomes "COMPLETED"
        3. Completed response contains "generated" array with image URLs
        
        Returns:
            List of generated image data (URLs or base64)
        """
        import logging
        logger = logging.getLogger("mexflow.freepik")
        
        payload = {
            "prompt": prompt,
            "negative_prompt": negative_prompt or "blurry, low quality, distorted, deformed",
            "image": {
                "size": f"{width}x{height}"
            },
            "num_images": num_images,
            "guidance_scale": guidance_scale,
            "num_inference_steps": num_inference_steps
        }
        
        logger.info(f"🖼️ Freepik: Sending request to {FREEPIK_MYSTIC_URL}")
        logger.info(f"🖼️ Freepik: Payload size: {width}x{height}, num_images: {num_images}")
        
        async with httpx.AsyncClient(timeout=120) as client:
            response = await client.post(
                FREEPIK_MYSTIC_URL,
                headers=self.headers,
                json=payload
            )
            
            logger.info(f"🖼️ Freepik: Response status: {response.status_code}")
            
            if response.status_code == 401:
                raise ValueError("Invalid API key. Please check your Freepik API credentials.")
            elif response.status_code == 429:
                raise ValueError("Rate limit exceeded. Please wait and try again.")
            
            response.raise_for_status()
            
            data = response.json()
            logger.info(f"🖼️ Freepik: Initial response: {json.dumps(data, indent=2)[:500]}")
            
            # Mystic API returns async response - need to poll for completion
            # Response format: {"data": {"task_id": "...", "status": "IN_PROGRESS", "generated": []}}
            response_data = data.get("data", data)
            
            task_id = response_data.get("task_id")
            status = response_data.get("status", "").upper()
            
            logger.info(f"🖼️ Freepik: task_id={task_id}, status={status}")
            
            # If status is IN_PROGRESS, CREATED, or PENDING - need to poll
            if task_id and status in ["IN_PROGRESS", "CREATED", "PENDING", "PROCESSING"]:
                logger.info(f"🖼️ Freepik: Task is async, polling for completion...")
                result = await self.poll_for_result(task_id, max_wait=300)
                
                # Extract generated images from completed result
                generated = result.get("data", result).get("generated", [])
                if not generated:
                    # Try alternative formats
                    generated = result.get("generated", [])
                    if not generated:
                        generated = result.get("images", [])
                        if not generated:
                            generated = result.get("data", {}).get("images", [])
                
                logger.info(f"🖼️ Freepik: Got {len(generated)} generated images from poll")
                return generated
            
            # If status is COMPLETED or images are already present
            if status == "COMPLETED" or response_data.get("generated"):
                generated = response_data.get("generated", [])
                logger.info(f"🖼️ Freepik: Immediate response with {len(generated)} images")
                return generated
            
            # Fallback for different response formats
            if "data" in data:
                return data["data"] if isinstance(data["data"], list) else [data["data"]]
            elif "images" in data:
                return data["images"]
            else:
                return [data]
    
    async def poll_for_result(self, task_id: str, max_wait: int = 300) -> Dict[str, Any]:
        """
        Poll for generation result from Mystic async task
        Uses GET /v1/ai/mystic/{task_id} endpoint
        """
        import logging
        logger = logging.getLogger("mexflow.freepik")
        
        # Mystic poll endpoint
        poll_url = f"https://api.freepik.com/v1/ai/mystic/{task_id}"
        logger.info(f"🖼️ Freepik: Polling URL: {poll_url}")
        
        start_time = asyncio.get_event_loop().time()
        poll_count = 0
        
        async with httpx.AsyncClient(timeout=30) as client:
            while True:
                poll_count += 1
                elapsed = asyncio.get_event_loop().time() - start_time
                
                if elapsed > max_wait:
                    raise TimeoutError(f"Image generation timed out after {max_wait} seconds")
                
                logger.info(f"🖼️ Freepik: Poll #{poll_count} (elapsed: {elapsed:.1f}s)")
                
                response = await client.get(poll_url, headers=self.headers)
                
                if response.status_code == 404:
                    logger.warning(f"🖼️ Freepik: Task not found yet, waiting...")
                    await asyncio.sleep(2)
                    continue
                    
                response.raise_for_status()
                
                data = response.json()
                logger.info(f"🖼️ Freepik: Poll response: {json.dumps(data, indent=2)[:500]}")
                
                # Get status from response
                response_data = data.get("data", data)
                status = response_data.get("status", "").upper()
                
                logger.info(f"🖼️ Freepik: Status = {status}")
                
                if status == "COMPLETED":
                    logger.info(f"🖼️ Freepik: Task completed successfully!")
                    return data
                elif status in ["FAILED", "ERROR"]:
                    error_msg = response_data.get("error", response_data.get("message", "Unknown error"))
                    raise ValueError(f"Generation failed: {error_msg}")
                elif status in ["IN_PROGRESS", "CREATED", "PENDING", "PROCESSING"]:
                    # Still processing, wait and poll again
                    await asyncio.sleep(3)
                else:
                    # Unknown status - check if images are present anyway
                    generated = response_data.get("generated", [])
                    if generated:
                        logger.info(f"🖼️ Freepik: Found {len(generated)} images despite status {status}")
                        return data
                    await asyncio.sleep(2)


# =============================================================================
# Main Plugin Class
# =============================================================================

class FreepikImageGenerator:
    """Main plugin class for Freepik image generation"""
    
    def __init__(self):
        self.client: Optional[FreepikClient] = None
        self.project_id: str = ""
        self.api_key: str = ""  # Store API key for reuse in internal methods
        self.images_dir: str = ""  # Store images_dir from context
    
    async def execute(self, inputs: Dict[str, Any], context: Dict[str, Any] = None) -> PluginResult:
        """
        Execute image generation.
        
        Args:
            inputs: Plugin inputs from manifest
            context: Execution context (project_id, scene_id, images_dir, etc.)
        
        Returns:
            PluginResult with generated image paths
        """
        context = context or {}
        self.project_id = context.get("project_id", "")
        self.images_dir = context.get("images_dir", "")  # Get images_dir from context
        
        import logging
        logger = logging.getLogger("mexflow.freepik")
        logger.info(f"🖼️ Freepik execute(): project_id='{self.project_id}', images_dir='{self.images_dir}'")
        logger.info(f"🖼️ Freepik execute(): context keys={list(context.keys())}")
        
        # Fallback if images_dir not provided (shouldn't happen in production)
        if not self.images_dir:
            import os
            self.images_dir = os.path.join(os.path.expanduser("~"), "Documents", "MexFlow", "images")
            logger.warning(f"⚠️ images_dir not in context, using fallback: {self.images_dir}")
        
        # Get API key - PRIORITY: inputs first (passed by plugin executor), then plugin.settings
        # Plugin executor passes settings via inputs, so check inputs first
        api_key = inputs.get("freepik_api_key")
        
        # Debug: Log what we received
        import logging
        logger = logging.getLogger("mexflow.freepik")
        logger.info(f"🖼️ Freepik Plugin: Checking API key in inputs: {'found' if api_key else 'not found'}")
        logger.info(f"🖼️ Freepik Plugin: Available input keys: {list(inputs.keys())}")
        
        if not api_key and plugin and hasattr(plugin, 'settings'):
            api_key = plugin.settings.get("freepik_api_key")
            logger.info(f"🖼️ Freepik Plugin: Fallback to plugin.settings: {'found' if api_key else 'not found'}")
        
        if not api_key:
            logger.error("🖼️ Freepik Plugin: No API key found in inputs or settings!")
            return PluginResult(
                success=False,
                error="Freepik API key not configured. Please set it in plugin settings."
            )
        
        logger.info(f"🖼️ Freepik Plugin: API key found (length: {len(api_key)})")
        
        # Store API key and create client
        self.api_key = api_key
        self.client = FreepikClient(api_key)
        
        # Check for batch mode
        batch_mode = inputs.get("batch_mode", False)
        logger.info(f"🖼️ Freepik Plugin: batch_mode={batch_mode}, scenes count={len(inputs.get('scenes', []))}")
        
        if batch_mode:
            scenes = inputs.get("scenes", [])
            generate_frames = inputs.get("generate_frames", False)
            concurrent_processes = int(inputs.get("concurrent_processes", 3))
            
            if not scenes:
                return PluginResult(success=False, error="No scenes provided for batch generation")
            
            results = await self.generate_batch_images(scenes, self.project_id, generate_frames, concurrent_processes)
            return PluginResult(
                success=True,
                data={"results": results, "scene_count": len(scenes)},
                # message=f"Generated images for {len(scenes)} scene(s)"
            )
        
        # Get input parameters for single image mode
        prompt = inputs.get("prompt", "")
        negative_prompt = inputs.get("negative_prompt", "")
        aspect_ratio = inputs.get("aspect_ratio", "16:9")
        style = inputs.get("style", "photo")
        num_images = int(inputs.get("num_images", 1))
        
        if not prompt:
            return PluginResult(
                success=False,
                error="Prompt is required for image generation."
            )
        
        # Get settings
        auto_enhance = plugin.settings.get("auto_enhance", True) if plugin else True
        save_to_project = plugin.settings.get("save_to_project", True) if plugin else True
        
        # Enhance prompt with style
        enhanced_prompt = enhance_prompt(prompt, style, auto_enhance)
        
        # Get dimensions from aspect ratio
        dimensions = ASPECT_RATIOS.get(aspect_ratio, ASPECT_RATIOS["16:9"])
        width = dimensions["width"]
        height = dimensions["height"]
        
        # Update progress
        if plugin:
            plugin.progress.set_stages([
                "Preparing Request",
                "Generating Image",
                "Downloading",
                "Saving"
            ])
            plugin.progress.update(10, "Preparing image generation request...")
        
        try:
            # Generate image
            if plugin:
                plugin.progress.update(20, f"Generating {num_images} image(s)...")
                plugin.progress.next_stage("Starting AI image generation...")
            
            import logging
            logger = logging.getLogger("mexflow.freepik")
            
            result = await self.client.generate_image(
                prompt=enhanced_prompt,
                negative_prompt=negative_prompt,
                width=width,
                height=height,
                num_images=num_images
            )
            
            logger.info(f"🖼️ Freepik Execute: Result type: {type(result)}, length: {len(result) if result else 0}")
            logger.info(f"🖼️ Freepik Execute: Result preview: {str(result)[:300] if result else 'None'}")
            
            if not result:
                logger.error("🖼️ Freepik Execute: ❌ No images returned from API!")
                return PluginResult(
                    success=False,
                    error="No images returned from Freepik API"
                )
            
            if plugin:
                plugin.progress.update(60, "Image generated, downloading...")
                plugin.progress.next_stage("Downloading generated images...")
            
            # Process and save results
            generated_images = []
            scene_id = context.get("scene_id", "unknown")
            image_type = context.get("image_type", "scene")  # scene, frame_first, frame_middle, frame_last
            generation_type = context.get("generation_type")  # character, object, or None for scenes
            
            # Determine subfolder based on generation type
            subfolder = None
            if generation_type == "character":
                subfolder = "characters"
                image_type = context.get("character_name", "character")
            elif generation_type == "object":
                subfolder = "objects"
                image_type = context.get("object_name", "object")
            
            for i, img_data in enumerate(result):
                if plugin:
                    plugin.progress.update(60 + (30 * (i + 1) / len(result)), f"Processing image {i + 1}/{len(result)}...")
                
                # Generate output path with optional subfolder
                output_path = get_output_path(self.images_dir, self.project_id, scene_id, f"{image_type}_{i}", subfolder=subfolder)
                
                # Handle different response formats
                if isinstance(img_data, dict):
                    if "url" in img_data:
                        await download_image(img_data["url"], output_path)
                    elif "base64" in img_data:
                        await save_base64_image(img_data["base64"], output_path)
                    elif "image" in img_data:
                        # Could be URL or base64
                        img_content = img_data["image"]
                        if img_content.startswith("http"):
                            await download_image(img_content, output_path)
                        else:
                            await save_base64_image(img_content, output_path)
                elif isinstance(img_data, str):
                    if img_data.startswith("http"):
                        await download_image(img_data, output_path)
                    else:
                        await save_base64_image(img_data, output_path)
                
                generated_images.append(output_path)
            
            if plugin:
                plugin.progress.complete(f"Successfully generated {len(generated_images)} image(s)")
            
            return PluginResult(
                success=True,
                data={
                    "images": generated_images,
                    "prompt": enhanced_prompt,
                    "aspect_ratio": aspect_ratio,
                    "style": style,
                    "dimensions": f"{width}x{height}"
                },
                outputs=generated_images
            )
        
        except httpx.HTTPStatusError as e:
            error_msg = f"API error: {e.response.status_code} - {e.response.text}"
            if plugin:
                plugin.progress.error(error_msg)
            return PluginResult(success=False, error=error_msg)
        
        except Exception as e:
            error_msg = f"Image generation failed: {str(e)}"
            if plugin:
                plugin.progress.error(error_msg)
            return PluginResult(success=False, error=error_msg)
    
    async def _generate_single_image(
        self,
        prompt: str,
        scene_id: str,
        image_type: str = "scene",
        aspect_ratio: str = "16:9",
        style: str = "cinematic"
    ) -> Optional[str]:
        """
        Internal method to generate a single image.
        Uses the already-configured self.client.
        
        Returns:
            Path to saved image or None on failure
        """
        import logging
        logger = logging.getLogger("mexflow.freepik")
        
        if not self.client:
            logger.error("🖼️ Freepik: Client not initialized!")
            return None
        
        try:
            # Enhance prompt
            enhanced_prompt = enhance_prompt(prompt, style, True)
            
            # Get dimensions
            dimensions = ASPECT_RATIOS.get(aspect_ratio, ASPECT_RATIOS["16:9"])
            
            logger.info(f"🖼️ Freepik: Generating image for scene {scene_id}, type: {image_type}")
            logger.info(f"🖼️ Freepik: Prompt (first 100 chars): {enhanced_prompt[:100]}...")
            
            # Generate image via API
            result = await self.client.generate_image(
                prompt=enhanced_prompt,
                negative_prompt="",
                width=dimensions["width"],
                height=dimensions["height"],
                num_images=1
            )
            
            logger.info(f"🖼️ Freepik _generate_single: Result type: {type(result)}, length: {len(result) if result else 0}")
            logger.info(f"🖼️ Freepik _generate_single: Result preview: {str(result)[:300] if result else 'None'}")
            
            if not result:
                logger.error("🖼️ Freepik: No result from API")
                return None
            
            # Save the first image
            img_data = result[0] if isinstance(result, list) else result
            
            logger.info(f"🖼️ Freepik: Saving image - images_dir={self.images_dir}, project_id={self.project_id}, scene_id={scene_id}")
            output_path = get_output_path(self.images_dir, self.project_id, scene_id, image_type)
            logger.info(f"🖼️ Freepik: Generated output path: {output_path}")
            
            # Handle different response formats
            if isinstance(img_data, dict):
                if "url" in img_data:
                    await download_image(img_data["url"], output_path)
                elif "base64" in img_data:
                    await save_base64_image(img_data["base64"], output_path)
                elif "image" in img_data:
                    img_content = img_data["image"]
                    if img_content.startswith("http"):
                        await download_image(img_content, output_path)
                    else:
                        await save_base64_image(img_content, output_path)
            elif isinstance(img_data, str):
                if img_data.startswith("http"):
                    await download_image(img_data, output_path)
                else:
                    await save_base64_image(img_data, output_path)
            
            logger.info(f"🖼️ Freepik: Image saved to {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"🖼️ Freepik: Error generating image: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return None
    
    async def generate_scene_images(
        self,
        scene_data: Dict[str, Any],
        project_id: str,
        generate_frames: bool = False
    ) -> Dict[str, Any]:
        """
        Generate images for a single scene.
        
        Args:
            scene_data: Scene data containing prompts
            project_id: Project ID
            generate_frames: Whether to generate frame images (first, middle, last)
        
        Returns:
            Dict with scene_images and scene_frames paths
        """
        import logging
        logger = logging.getLogger("mexflow.freepik")
        
        # Always initialize result with scene IDs for database tracking
        scene_id = scene_data.get("scene_id_str", scene_data.get("id", "unknown"))
        scene_uuid = scene_data.get("id")  # Database UUID
        
        result = {
            "scene_id": scene_uuid,  # CRITICAL: UUID for database lookup
            "scene_id_str": scene_id,  # Display ID
            "scene_images": [],
            "scene_frames": {}
        }
        
        # Debug: Log what data we received
        logger.info(f"🖼️ Freepik: Scene data keys for {scene_id}: {list(scene_data.keys())}")
        logger.info(f"🖼️ Freepik: image_prompt={bool(scene_data.get('image_prompt'))}, scene_description={bool(scene_data.get('scene_description'))}, scene_details_text={bool(scene_data.get('scene_details_text'))}")
        
        # Get the appropriate prompt
        image_prompt = (
            scene_data.get("image_prompt") or 
            scene_data.get("scene_description") or 
            scene_data.get("scene_prompt") or 
            scene_data.get("scene_details_text", "")
        )
        
        if not image_prompt:
            logger.warning(f"🖼️ Freepik: No prompt available for scene {scene_id}")
            result["error"] = "No prompt available for scene"
            return result  # Return with empty arrays but with scene IDs
        
        logger.info(f"🖼️ Freepik: Processing scene {scene_id}")
        
        # Generate main scene image using internal method
        if plugin:
            plugin.status.update(f"Generating scene image for {scene_id}...")
        
        image_path = await self._generate_single_image(
            prompt=image_prompt,
            scene_id=scene_id,
            image_type="scene",
            aspect_ratio="16:9",
            style="cinematic"
        )
        
        if image_path:
            result["scene_images"] = [image_path]
            logger.info(f"🖼️ Freepik: Scene image generated: {image_path}")
        else:
            logger.error(f"🖼️ Freepik: Failed to generate scene image for {scene_id}")
        
        # Generate frame images if requested
        if generate_frames:
            characters = scene_data.get("characters_present", [])
            objects = scene_data.get("objects_present", [])
            
            context_suffix = ""
            if characters:
                context_suffix += f", featuring {', '.join(characters)}"
            if objects:
                context_suffix += f", with {', '.join(objects)}"
            
            frame_prompts = {
                "first": f"Opening shot of {image_prompt}{context_suffix}, establishing scene",
                "middle": f"Mid-scene shot of {image_prompt}{context_suffix}, action in progress",
                "last": f"Closing shot of {image_prompt}{context_suffix}, scene conclusion"
            }
            
            for frame_type, frame_prompt in frame_prompts.items():
                if plugin:
                    plugin.status.update(f"Generating {frame_type} frame for {scene_id}...")
                
                frame_path = await self._generate_single_image(
                    prompt=frame_prompt,
                    scene_id=scene_id,
                    image_type=f"frame_{frame_type}",
                    aspect_ratio="16:9",
                    style="cinematic"
                )
                
                if frame_path:
                    result["scene_frames"][frame_type] = frame_path
        
        return result
    
    async def generate_batch_images(
        self,
        scenes: List[Dict[str, Any]],
        project_id: str,
        generate_frames: bool = False,
        concurrent_processes: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Generate images for multiple scenes with concurrent processing.
        
        Args:
            scenes: List of scene data
            project_id: Project ID
            generate_frames: Whether to generate frames
            concurrent_processes: Number of concurrent generation tasks (1-10)
        
        Returns:
            List of results per scene
        """
        import logging
        logger = logging.getLogger("mexflow.freepik")
        
        total = len(scenes)
        
        if plugin:
            plugin.progress.set_stages([
                "Initialization",
                "Generating Images",
                "Complete"
            ])
            plugin.progress.update(5, f"Starting batch generation for {total} scenes with {concurrent_processes} concurrent processes...")
        
        logger.info(f"🖼️ Freepik: Batch generation starting - {total} scenes, concurrency={concurrent_processes}")
        
        # Use semaphore to limit concurrent tasks
        semaphore = asyncio.Semaphore(concurrent_processes)
        completed_count = 0
        
        async def process_scene(scene: Dict[str, Any], index: int) -> Dict[str, Any]:
            """Process a single scene with semaphore control"""
            nonlocal completed_count
            
            async with semaphore:
                logger.info(f"🖼️ Freepik: Starting scene {index+1}/{total} - {scene.get('scene_id_str')}")
                
                scene_result = await self.generate_scene_images(scene, project_id, generate_frames)
                
                # CRITICAL: Must include scene UUID (id) for database update
                scene_result["scene_id"] = scene.get("id")  # UUID - for database lookup
                scene_result["scene_id_str"] = scene.get("scene_id_str")  # String ID - for display
                
                completed_count += 1
                
                logger.info(f"🖼️ Freepik batch: Scene {scene.get('scene_id_str')} (UUID: {scene.get('id')}) - images: {len(scene_result.get('scene_images', []))}, frames: {len(scene_result.get('scene_frames', {}))}")
                
                if plugin:
                    plugin.progress.update(
                        ((completed_count) / total) * 90,
                        f"Completed {completed_count}/{total} scenes"
                    )
                
                return scene_result
        
        # Process all scenes concurrently with semaphore limit
        tasks = [process_scene(scene, i) for i, scene in enumerate(scenes)]
        results = await asyncio.gather(*tasks)
        
        logger.info(f"🖼️ Freepik: Batch generation complete - {len(results)} scenes processed")
        
        if plugin:
            plugin.progress.complete(f"Generated images for {total} scenes")
        
        logger.info(f"🖼️ Freepik batch complete: {total} scenes processed")
        return results


# =============================================================================
# Plugin Entry Point
# =============================================================================

# Main plugin instance
generator = FreepikImageGenerator()


async def execute(inputs: Dict[str, Any], context: Dict[str, Any] = None) -> PluginResult:
    """
    Plugin entry point for single image generation.
    
    This is called by the plugin executor.
    """
    return await generator.execute(inputs, context)


async def generate_scene_images(
    scene_data: Dict[str, Any],
    project_id: str,
    generate_frames: bool = False
) -> Dict[str, Any]:
    """
    Entry point for scene image generation.
    
    Called for Build Images functionality.
    """
    return await generator.generate_scene_images(scene_data, project_id, generate_frames)


async def generate_batch_images(
    scenes: List[Dict[str, Any]],
    project_id: str,
    generate_frames: bool = False,
    concurrent_processes: int = 3
) -> List[Dict[str, Any]]:
    """
    Entry point for batch image generation.
    
    Called for multi-scene Build Images.
    """
    return await generator.generate_batch_images(scenes, project_id, generate_frames, concurrent_processes)


# For testing
if __name__ == "__main__":
    import asyncio
    
    async def test():
        result = await execute({
            "prompt": "A beautiful sunset over mountains",
            "aspect_ratio": "16:9",
            "style": "cinematic",
            "freepik_api_key": "test_key"
        })
        print(f"Result: {result}")
    
    asyncio.run(test())
