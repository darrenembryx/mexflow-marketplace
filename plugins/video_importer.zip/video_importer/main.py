"""
Video Importer Plugin
====================

Imports existing video files directly into project scenes.
Instead of generating videos with AI, this plugin allows users to:
1. Drag and drop multiple video files
2. Arrange/sort them in desired order
3. Automatically assign them to project scenes

The plugin copies imported videos to the correct output directory
and updates scene statuses, making them appear as if they were generated.
"""

import asyncio
import os
import shutil
import logging
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger("mexflow.plugins.video_importer")


class VideoImporterPlugin:
    """
    Video Importer Plugin - Import videos instead of generating them.
    
    This plugin receives pre-uploaded video file paths from the frontend
    popup window and copies them into the video project output directory,
    updating scene statuses accordingly.
    """
    
    def __init__(self, context=None):
        self.context = context
        self.name = "Video Importer"
        self.version = "1.0.0"
    
    async def execute(self, inputs: Dict[str, Any], settings: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute the video import process.
        
        Args:
            inputs: Dictionary containing:
                - imported_videos: List of dicts with video info
                  Each dict has: {
                      "original_name": str,
                      "temp_path": str,  # Path to uploaded temp file
                      "size": int,
                      "type": str,
                      "order": int,  # 0-based order index
                      "scene_id": str  # Optional: specific scene to assign to
                  }
                - scenes: List of scene data (auto-provided by VideoBuilderContext)
                - video_id: str
                - project_id: str
                - output_dir: str
            settings: Plugin settings (not used for this plugin)
            
        Returns:
            Dictionary with success status and details
        """
        try:
            imported_videos = inputs.get("imported_videos", [])
            
            # Parse if it's a JSON string
            if isinstance(imported_videos, str):
                try:
                    imported_videos = json.loads(imported_videos)
                except json.JSONDecodeError:
                    return {"success": False, "error": "Invalid imported_videos format"}
            
            if not imported_videos:
                return {"success": False, "error": "No videos to import"}
            
            scenes = inputs.get("scenes", [])
            video_id = inputs.get("video_id", "")
            project_id = inputs.get("project_id", "")
            output_dir = inputs.get("output_dir", "")
            
            if not scenes:
                return {"success": False, "error": "No scenes found in project"}
            
            if not output_dir:
                if self.context:
                    output_dir = self.context.get_output_directory()
                else:
                    return {"success": False, "error": "No output directory specified"}
            
            # Ensure output directory exists
            os.makedirs(output_dir, exist_ok=True)
            
            total_videos = len(imported_videos)
            total_scenes = len(scenes)
            
            logger.info(f"📥 Video Importer: Importing {total_videos} videos for {total_scenes} scenes")
            
            # Report initial progress
            if self.context:
                await self.context.report_progress(
                    stage="Importing Videos",
                    progress=0,
                    message=f"Starting import of {total_videos} videos..."
                )
            
            # Sort videos by order
            imported_videos.sort(key=lambda v: v.get("order", 0))
            
            imported_count = 0
            errors = []
            
            for idx, video_info in enumerate(imported_videos):
                # Get the corresponding scene
                if idx >= total_scenes:
                    logger.warning(f"More videos ({total_videos}) than scenes ({total_scenes}), skipping extra video: {video_info.get('original_name', 'unknown')}")
                    break
                
                scene = scenes[idx]
                scene_id = scene.get("id") or scene.get("_scene_db_id", f"scene_{idx+1}")
                temp_path = video_info.get("temp_path", "")
                original_name = video_info.get("original_name", f"video_{idx+1}.mp4")
                
                try:
                    # Report scene progress
                    if self.context:
                        await self.context.report_scene_progress(
                            scene_id=str(scene_id),
                            stage="downloading",
                            progress=10,
                            message=f"Importing video {idx+1}/{min(total_videos, total_scenes)}: {original_name}"
                        )
                    
                    # Determine the output file path
                    # Use the same naming convention as other video generators
                    ext = os.path.splitext(original_name)[1] or ".mp4"
                    output_filename = f"scene_{scene_id}{ext}"
                    output_path = os.path.join(output_dir, output_filename)
                    
                    if temp_path and os.path.exists(temp_path):
                        # Copy the uploaded file to the output directory
                        shutil.copy2(temp_path, output_path)
                        logger.info(f"✅ Copied video for scene {scene_id}: {original_name} -> {output_path}")
                    else:
                        # The video might have been uploaded via a different mechanism
                        # Check if the original_name contains a full path
                        if original_name and os.path.exists(original_name):
                            shutil.copy2(original_name, output_path)
                            logger.info(f"✅ Copied video for scene {scene_id}: {original_name} -> {output_path}")
                        else:
                            error_msg = f"Video file not found: {temp_path or original_name}"
                            logger.error(f"❌ {error_msg}")
                            errors.append({"scene_id": str(scene_id), "error": error_msg})
                            
                            if self.context:
                                self.context.update_scene_status(
                                    scene_id=str(scene_id),
                                    status="error",
                                    error=error_msg
                                )
                                await self.context.report_scene_progress(
                                    scene_id=str(scene_id),
                                    stage="error",
                                    progress=0,
                                    message=error_msg,
                                    data={"error": error_msg}
                                )
                            continue
                    
                    # Update scene status in database
                    if self.context:
                        self.context.update_scene_status(
                            scene_id=str(scene_id),
                            status="completed",
                            progress=1.0,
                            file_path=output_path
                        )
                        
                        await self.context.report_scene_progress(
                            scene_id=str(scene_id),
                            stage="completed",
                            progress=100,
                            message=f"Imported: {original_name}",
                            data={"file_path": output_path}
                        )
                    
                    imported_count += 1
                    
                    # Report overall progress
                    overall_progress = ((idx + 1) / min(total_videos, total_scenes)) * 100
                    if self.context:
                        await self.context.report_progress(
                            stage="Importing Videos",
                            progress=overall_progress,
                            message=f"Imported {imported_count}/{min(total_videos, total_scenes)} videos"
                        )
                    
                except Exception as e:
                    error_msg = f"Failed to import video for scene {scene_id}: {str(e)}"
                    logger.error(f"❌ {error_msg}")
                    errors.append({"scene_id": str(scene_id), "error": error_msg})
                    
                    if self.context:
                        self.context.update_scene_status(
                            scene_id=str(scene_id),
                            status="error",
                            error=str(e)
                        )
                        await self.context.report_scene_progress(
                            scene_id=str(scene_id),
                            stage="error",
                            progress=0,
                            message=error_msg,
                            data={"error": str(e)}
                        )
            
            # Clean up temp files
            for video_info in imported_videos:
                temp_path = video_info.get("temp_path", "")
                if temp_path and os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except Exception:
                        pass  # Non-critical cleanup
            
            # Complete video
            success = imported_count > 0
            if self.context:
                self.context.complete_video(
                    success=success,
                    error_message=f"{len(errors)} errors" if errors else None
                )
            
            result = {
                "success": success,
                "video_count": imported_count,
                "total_scenes": total_scenes,
                "errors": errors,
                "message": f"Successfully imported {imported_count} of {min(total_videos, total_scenes)} videos"
                    + (f" ({len(errors)} errors)" if errors else "")
            }
            
            logger.info(f"📥 Video Import complete: {result['message']}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Video Import failed: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            
            if self.context:
                self.context.complete_video(success=False, error_message=str(e))
            
            return {
                "success": False,
                "error": str(e),
                "message": f"Video import failed: {str(e)}"
            }
    
    def get_info(self) -> Dict[str, Any]:
        """Return plugin information"""
        return {
            "name": self.name,
            "version": self.version,
            "description": "Import existing videos into project scenes"
        }
