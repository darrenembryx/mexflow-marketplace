"""
AI Director Framework v3.3 — BATCHED, BEAT-DRIVEN, IMAGE-FIRST
Hollywood-Level Story-to-Scene Conversion for MexFlow

═══════════════════════════════════════════════════════════════════════════
WHY v3.3 EXISTS — THE TRUNCATION FAILURE
═══════════════════════════════════════════════════════════════════════════
v3.2 added beat-sheet decomposition that correctly produced 55 beats for a
long story — but then the scene-generation LLM call hit its 64K-token
output ceiling and only serialized 4 scenes before truncating mid-stream.
The AI's own production_summary lied (claimed 55 scenes delivered, actually
delivered 4), and our defensive code accepted the truncated output.

55 scenes × ~10K chars each ≈ 550K chars needed. Even with a 64K-token cap
(~250K chars), this can never fit in one call. The fix is structural, not
prompt-tweakable: BATCHING.

═══════════════════════════════════════════════════════════════════════════
v3.3 MAJOR UPGRADES
═══════════════════════════════════════════════════════════════════════════
1. BATCHED SCENE GENERATION — fixes the truncation bug:
   Scenes are generated in chunks of BATCH_SIZE=6 beats per LLM call.
   Each batch produces ~6 scenes (~30-50 KB output), well within budget.
   No more truncation regardless of story length — a 55-beat story now
   becomes 10 batched calls instead of one impossible monolithic call.

2. PER-BATCH RETRY (up to 3 attempts) — if a batch returns fewer scenes
   than requested, it retries with an escalated retry-warning prompt. Max
   3 attempts per batch; partial coverage logged loudly.

3. CONTINUITY ANCHOR PASSING — the last scene of each completed batch is
   passed to the next batch as a "CONTINUITY ANCHOR" block, so scene 7
   (start of batch 2) flows naturally from scene 6 (end of batch 1).

4. REAL COVERAGE DETECTION — beat coverage is computed from the actual
   number of scenes in the array, not from the LLM's lying production_
   summary. The orchestrator builds the summary from actual data.

5. PLAIN-INTEGER SCENE IDS — "1", "2", "3", ..., "55" instead of the
   ridiculous "1.1", "1.2", ..., "1.55". Defensive _normalize_scene_id()
   converts any malformed LLM output ("1.5", "S1", "scene_7", "Scene 23")
   to plain integers.

═══════════════════════════════════════════════════════════════════════════
ALL v3.2 GUARANTEES ALSO REMAIN IN EFFECT
═══════════════════════════════════════════════════════════════════════════
  • Beat sheet decomposition (one beat → one scene)
  • Frame-to-frame continuity threading (incoming-state anchor blocks)
  • ASPECT RATIO LOCK + character portraits always 16:9
  • 14-block image prompt structure (320-480 words)
  • Visual DNA lock + tone lock + tone contracts
  • Defensive post-processing for every invariant

PIPELINE STAGES (still 9):
  1. Validate inputs
  2. Story Analysis
  3. Visual DNA
  4. Location Bible
  5. Beat Sheet
  6. Character Portraits
  7. Scene Direction (NOW BATCHED — chunks of 6 beats per LLM call)
     → invariants enforcement (with scene_id normalization)
     → continuity threading
  8. Save to Project DB
  9. Finalize

Services Used: ai, progress, stage, storage, scene_data, project_data,
               result, execution, utils
"""

from typing import Dict, Any, List, Optional
from mexflow_sdk import mexflow, TemplateBase, TemplateResult


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# VISUAL STYLE PRESETS (the "mood" layer — lighting/color/atmosphere)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VISUAL_STYLE_MAP = {
    "cinematic_epic": (
        "Cinematic epic blockbuster mood. Grand sweeping compositions, IMAX-quality clarity, "
        "rich dynamic range, deep blacks and luminous highlights. Inspired by Christopher Nolan's "
        "practical-first aesthetic and Denis Villeneuve's atmospheric immersion. Anamorphic lens "
        "characteristics with subtle horizontal flare. Dramatic chiaroscuro lighting, golden hour "
        "and blue hour palettes, deep staging with layered foreground/midground/background."
    ),
    "dark_noir": (
        "Dark noir cinematic mood. Desaturated cool tones with isolated warm practicals. "
        "Deep crushed blacks, lifted cool shadows, teal-and-orange grade. Hard directional "
        "lighting with deep shadows, volumetric haze, silhouette compositions."
    ),
    "fantasy_magical": (
        "Fantasy magical realism mood. Vibrant saturated colors with ethereal glow effects. "
        "Bioluminescent accents, particle effects (fireflies, embers, magical dust). "
        "Enchanted forest greens, deep ocean blues, golden magical light."
    ),
    "sci_fi_futuristic": (
        "Sci-fi futuristic cyberpunk mood. Neon-drenched palettes, cyan/magenta/electric blue "
        "with orange amber accents, LED strip lighting, volumetric fog, rain with neon reflections."
    ),
    "warm_dramatic": (
        "Warm dramatic emotional mood. Golden hour predominance, amber and honey tones, "
        "soft diffused natural light. Intimate compositions, shallow depth of field."
    ),
    "horror_suspense": (
        "Horror and suspense mood. Oppressive darkness with pools of motivated light. "
        "Sickly green, desaturated teal, and deep crimson accents. Under-lighting, harsh "
        "practicals, flickering lights creating unstable shadows."
    ),
    "anime_cinematic": (
        "Anime cinematic mood in the tradition of Makoto Shinkai and Studio Ghibli. "
        "Hyper-detailed painterly backgrounds, dramatic sky gradients, golden light rays."
    ),
    "documentary_realistic": (
        "Documentary realistic naturalistic mood. Available light, handheld camera feel, "
        "natural color rendering with minimal grading."
    ),
    "comedy_bright": (
        "Bright comedic mood. Even high-key lighting, warm saturated palette, sunny optimism. "
        "Wes Anderson symmetry energy, Amélie's warmth, sitcom crispness. Clear readable "
        "compositions, every face well-lit, no dramatic shadows that would undercut jokes. "
        "Pops of saturated color (red, yellow, teal) against soft neutral backgrounds."
    ),
    "storybook_whimsical": (
        "Storybook whimsical mood. Soft diffused light, pastel-meets-saturated palette, "
        "slightly oversaturated like a children's book illustration. Every element lightly "
        "stylized, gentle volumetric light, cozy and inviting atmosphere."
    )
}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# VISUAL DNA PRESETS — THE RENDERING MEDIUM LOCK
# This is THE fix for visual consistency. A single DNA block is chosen ONCE
# and pasted verbatim into every character portrait and every scene prompt.
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VISUAL_DNA_PRESETS = {
    "photoreal_cinema": (
        "RENDERING MEDIUM: Live-action photorealistic cinema. Captured on ARRI Alexa 65 with "
        "anamorphic 2.39:1 spherical lenses. Kodak Vision3 500T film stock emulation. Real human "
        "skin with authentic pore/subsurface scattering, real fabric with physically-accurate "
        "weave, real hair with individual strand fidelity. Every surface obeys real-world PBR: "
        "correct specular response, correct subsurface scattering, correct wear and dirt. NO "
        "cartoon stylization, NO anime shading, NO 3D animation look, NO illustration feel. "
        "Photoreal cinematography only. 16-bit color depth, subtle film grain, natural lens "
        "vignetting, realistic depth of field falloff."
    ),
    "pixar_3d_animation": (
        "RENDERING MEDIUM: 3D CGI animated film in the Pixar / DreamWorks tradition. Fully "
        "rendered 3D animation with stylized-yet-believable proportions — slightly enlarged "
        "heads and expressive eyes, smooth plastic-like skin with soft subsurface scattering, "
        "appealing-shape character silhouettes, hero-lit key light with soft wrap-around fill. "
        "Surfaces are physically-based but gently idealized (cleaner, warmer, more saturated "
        "than real life). Fabric drapes with stylized weight, hair rendered as grouped clumps "
        "not individual strands. NO photorealism, NO live-action human skin, NO anime cel-shading. "
        "Think Toy Story 4, Coco, Inside Out, Soul, The Incredibles. Crisp render, clean edges, "
        "volumetric God rays where motivated, shallow cinematic depth of field."
    ),
    "dreamworks_stylized_3d": (
        "RENDERING MEDIUM: 3D CGI stylized animation in the DreamWorks / Illumination tradition. "
        "More exaggerated proportions than Pixar — larger heads, bigger eyes, punchier poses. "
        "Saturated bold colors, strong silhouettes, soft-shadow animation lighting, slightly "
        "rubbery appealing skin. Think Kung Fu Panda, How to Train Your Dragon, Minions, "
        "Sing. Broad comedic appeal, readable from a distance. NO photorealism, NO anime, NO "
        "live-action. Clean CGI render with cinematic depth of field."
    ),
    "anime_shinkai": (
        "RENDERING MEDIUM: Anime in the Makoto Shinkai / Your Name / Weathering with You "
        "tradition. 2D cel-shaded characters with clean linework over hyper-detailed painterly "
        "backgrounds. Character eyes are large and expressive, hair rendered as flowing grouped "
        "shapes with rim highlights. Sky is the star — dramatic cloud gradients, godrays, lens "
        "flares. NO 3D CGI character rendering, NO photorealism, NO western cartoon. Strictly "
        "hand-painted anime aesthetic. Clean outlines, flat-plus-gradient shading, vibrant "
        "saturated palette, Kimi no Na wa color grade."
    ),
    "anime_ghibli": (
        "RENDERING MEDIUM: Anime in the Studio Ghibli / Miyazaki tradition. Soft hand-drawn 2D "
        "animation with painterly watercolor backgrounds, gentle line weight, warm earthy "
        "palette, believable natural detail married to fantastical elements. Characters have "
        "rounded friendly proportions. Think Spirited Away, My Neighbor Totoro, Howl's Moving "
        "Castle. NO 3D CGI, NO photorealism, NO sharp cel-shade. Hand-crafted, warm, breathing."
    ),
    "disney_classic_2d": (
        "RENDERING MEDIUM: Classic Disney 2D hand-drawn animation. Clean ink-and-paint linework, "
        "rounded appealing character shapes, smooth traditional animation timing. Warm "
        "saturated palette, soft watercolor or gouache backgrounds. Think The Lion King, "
        "Aladdin, Beauty and the Beast. NO 3D, NO photorealism, NO anime cel-shade."
    ),
    "western_cartoon_2d": (
        "RENDERING MEDIUM: Flat 2D western cartoon animation. Bold black outlines, flat color "
        "fills with minimal shading, stylized exaggerated proportions, punchy saturated palette. "
        "Think modern shows like Gravity Falls, Adventure Time, or classic Looney Tunes "
        "simplification. NO 3D, NO realism, NO painterly shading. Crisp graphic simplicity."
    ),
    "claymation_stopmotion": (
        "RENDERING MEDIUM: Stop-motion claymation in the Laika / Aardman tradition. Visible "
        "fingerprint texture on clay/putty surfaces, subtly imperfect movement feel, real "
        "handcrafted miniature sets with touch of warmth. Think Wallace & Gromit, Coraline, "
        "Isle of Dogs. Every material looks handmade — felt, wool, clay, wire. NO smooth CGI, "
        "NO photorealism, NO 2D animation."
    ),
    "comic_book_illustration": (
        "RENDERING MEDIUM: Comic book illustration style. Bold inked outlines, dynamic dramatic "
        "poses, halftone or ben-day dot shading, vibrant saturated colors with hard shadow "
        "shapes. Think Marvel/DC cinematic comic panels. NO 3D render, NO photorealism, NO "
        "anime. Inked-and-colored panel aesthetic."
    ),
    "watercolor_storybook": (
        "RENDERING MEDIUM: Watercolor storybook illustration. Soft wet-edge watercolor "
        "technique, visible paper texture, gentle line work, dreamy pastel-meets-saturated "
        "palette. Think Peter Rabbit, Winnie-the-Pooh illustrations. NO 3D, NO photorealism, "
        "NO digital sharpness."
    ),
    "ultra_realistic_3d": (
        "RENDERING MEDIUM: Ultra-realistic 3D CGI render, indistinguishable from live-action "
        "but computer-generated. Full photoreal PBR, subsurface skin, individual hair strands, "
        "realistic cloth simulation. Think MEG 2, modern VFX creature work. Shares the "
        "photoreal look of live-action but is fully CG."
    )
}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ORIENTATION / ASPECT RATIO PRESETS — v3.1
#
# The #1 silent killer of image-to-video consistency is aspect-ratio drift
# between frames. If scene 1 generates at 16:9 and scene 2 at 9:16, the
# downstream video pipeline produces letterboxed or stretched artifacts and
# the "shot continuity" feels broken.
#
# Solution: ONE orientation is chosen for the entire production. A verbatim
# ASPECT RATIO LOCK block is pasted at the TOP of every scene image_prompt
# AND the LLM is given orientation-specific framing guidance so the shots it
# chooses are COMPOSED FOR the chosen aspect (not just cropped to it).
#
# Character portraits are ALWAYS generated at 16:9 regardless of scene
# orientation — this is a hard contract. Why:
#   1. 4-panel reference sheets need horizontal room for front/side/side/back.
#   2. Character identity extraction works from any ref ratio; the scene
#      generator rebuilds the frame at the scene's aspect — it does NOT
#      blit-copy the reference.
#   3. Consistent reference ratio simplifies the downstream identity pipeline.
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ORIENTATION_PRESETS = {
    "16:9": {
        "label": "16:9 Landscape Widescreen",
        "canvas": "1920x1080",
        "aspect_lock": (
            "ASPECT RATIO LOCK — 16:9 LANDSCAPE WIDESCREEN. Canvas dimensions 1920x1080 "
            "pixels. Frame is HORIZONTAL — wider than tall (1.78:1). Every compositional "
            "decision in this image is built for a 16:9 horizontal frame. --ar 16:9"
        ),
        "framing_guidance": (
            "Natural choices for 16:9: wide establishing shots, symmetric two-shots with "
            "characters side by side, over-the-shoulder coverage, classic cinematic framing, "
            "horizontal leading lines, horizontal lead room for eye-lines. Rule of thirds "
            "reads along horizontal thirds. Avoid pure vertical stacking that would leave "
            "empty left/right space."
        ),
        "spatial_vocabulary": (
            "Use HORIZONTAL spatial language: 'left third / center third / right third', "
            "'foreground/midground/background layered from camera outward', 'frame edges "
            "left and right', 'horizontal ground line runs across lower third'."
        ),
        "reinforce": "FINAL OUTPUT: 16:9 landscape widescreen, 1920x1080, horizontal frame. --ar 16:9"
    },
    "9:16": {
        "label": "9:16 Vertical Portrait (Reels / Shorts / TikTok)",
        "canvas": "1080x1920",
        "aspect_lock": (
            "ASPECT RATIO LOCK — 9:16 VERTICAL PORTRAIT. Canvas dimensions 1080x1920 "
            "pixels. Frame is VERTICAL — taller than wide (0.5625:1). Every compositional "
            "decision in this image is built for a 9:16 vertical frame. --ar 9:16"
        ),
        "framing_guidance": (
            "Natural choices for 9:16 vertical: single-subject head-to-toe vertical framing, "
            "tight close-ups that fill the tall canvas, stacked compositions (elements arranged "
            "top-to-bottom not left-to-right), low-angle hero shots reading tall, vertical "
            "leading lines, tight CUs of one character at a time. For two-character scenes: "
            "stack characters (one higher, one lower), use tight stacked OTS, or isolate one "
            "character and imply the other off-frame. STRICTLY AVOID wide side-by-side two-shots "
            "— they produce tiny unreadable faces in vertical. AVOID horizontal epic sweeps."
        ),
        "spatial_vocabulary": (
            "Use VERTICAL spatial language: 'top third / middle third / bottom third', "
            "'foreground/midground/background layered from camera outward', 'frame edges "
            "top and bottom dominate', 'focal subject centered in upper-middle third where "
            "viewer eye naturally lands on phones'."
        ),
        "reinforce": "FINAL OUTPUT: 9:16 vertical portrait, 1080x1920, tall frame. --ar 9:16"
    },
    "1:1": {
        "label": "1:1 Square (Instagram Post)",
        "canvas": "1080x1080",
        "aspect_lock": (
            "ASPECT RATIO LOCK — 1:1 SQUARE. Canvas dimensions 1080x1080 pixels. Frame is "
            "SQUARE — equal width and height. Every compositional decision in this image is "
            "built for a 1:1 square frame. --ar 1:1"
        ),
        "framing_guidance": (
            "Natural choices for 1:1 square: tight centered compositions, medium shots that "
            "fill the square, symmetric framing around a central subject, tight two-shots "
            "with characters positioned close together, center-weighted rule-of-thirds. "
            "Avoid extreme wides that leave empty space, avoid tall vertical shots."
        ),
        "spatial_vocabulary": (
            "Use CENTERED spatial language: 'center of frame', 'upper half / lower half', "
            "'quadrants (top-left, top-right, bottom-left, bottom-right)', 'subject anchored "
            "to center with balanced surrounds'."
        ),
        "reinforce": "FINAL OUTPUT: 1:1 square, 1080x1080, square frame. --ar 1:1"
    },
    "4:3": {
        "label": "4:3 Classic TV / Standard",
        "canvas": "1440x1080",
        "aspect_lock": (
            "ASPECT RATIO LOCK — 4:3 CLASSIC STANDARD. Canvas dimensions 1440x1080 pixels. "
            "Frame is slightly wider than tall (1.33:1). Built for 4:3 classical frame. --ar 4:3"
        ),
        "framing_guidance": (
            "Natural choices for 4:3: classical TV-era composition, medium shots, tighter "
            "wides, close-ups with balanced negative space, Academy-ratio framing."
        ),
        "spatial_vocabulary": (
            "Use CLASSICAL spatial language: 'left third / center third / right third' with "
            "vertical room for head-and-shoulders, 'upper two-thirds for subjects, lower third "
            "for environment'."
        ),
        "reinforce": "FINAL OUTPUT: 4:3 classic, 1440x1080. --ar 4:3"
    },
    "21:9": {
        "label": "21:9 Ultrawide Cinematic",
        "canvas": "2560x1080",
        "aspect_lock": (
            "ASPECT RATIO LOCK — 21:9 ULTRAWIDE CINEMATIC. Canvas dimensions 2560x1080 "
            "pixels. Frame is ULTRA-HORIZONTAL (2.33:1). Built for 21:9 ultrawide frame. "
            "--ar 21:9"
        ),
        "framing_guidance": (
            "Natural choices for 21:9 ultrawide: epic sweeping horizontal establishers, "
            "extreme wide shots, parallel character blocking spread across wide frame, "
            "landscape-dominant compositions, long horizontal leading lines. Vertical subjects "
            "appear small; lean into horizontal grandeur."
        ),
        "spatial_vocabulary": (
            "Use ULTRAWIDE spatial language: 'far-left fifth / left-center / center / "
            "right-center / far-right fifth', 'horizontal sweep from frame-left to frame-right', "
            "'deep horizontal parallax layers'."
        ),
        "reinforce": "FINAL OUTPUT: 21:9 ultrawide, 2560x1080. --ar 21:9"
    },
    "2.39:1": {
        "label": "2.39:1 Anamorphic Cinema Scope",
        "canvas": "2580x1080",
        "aspect_lock": (
            "ASPECT RATIO LOCK — 2.39:1 ANAMORPHIC PANAVISION SCOPE. Canvas dimensions "
            "2580x1080 pixels. Frame is CINEMATIC ULTRAWIDE (2.39:1). Built for Scope. "
            "--ar 2.39:1"
        ),
        "framing_guidance": (
            "Natural choices for 2.39:1 Scope: anamorphic two-shots with wide space between "
            "characters, horizontal lead room for eye-lines, sweeping landscape establishers, "
            "cinematic hero low-angles. Horizontal lens flares read naturally at this ratio."
        ),
        "spatial_vocabulary": (
            "Use SCOPE spatial language: 'frame-left / left-of-center / center / "
            "right-of-center / frame-right', 'horizontal cinemascope spread', "
            "'horizontal anamorphic flares extending across frame'."
        ),
        "reinforce": "FINAL OUTPUT: 2.39:1 anamorphic Scope, 2580x1080. --ar 2.39:1"
    }
}


# Character portraits are LOCKED to 16:9 — strict, non-negotiable contract.
# (See ORIENTATION_PRESETS docstring for the rationale.)
CHARACTER_ASPECT_LOCK = (
    "ASPECT RATIO LOCK — 16:9 LANDSCAPE WIDESCREEN. Canvas dimensions 1920x1080 pixels. "
    "HORIZONTAL frame. Character centered in frame with balanced equal negative space on "
    "the left and right sides (for single portraits), or in a 4-panel layout arranged "
    "horizontally (for reference sheets). This character reference is ALWAYS 16:9 "
    "regardless of the final video output orientation — downstream scene generators "
    "extract character identity from this reference and re-compose each scene at the "
    "scene's own target aspect ratio. --ar 16:9"
)

CHARACTER_ASPECT_REINFORCE = (
    "CHARACTER REFERENCE OUTPUT: 16:9 landscape widescreen, 1920x1080, horizontal frame. "
    "--ar 16:9"
)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TONE CONTRACTS — the enforceable rulebook for each genre
# Every scene in a story MUST stay inside the detected tone's contract.
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TONE_CONTRACTS = {
    "comedy": {
        "pacing": "Snappy and bouncy. Short shots, quick cuts, reaction shots after every joke. "
                  "Setup-punchline rhythm. Never let a beat linger into dread.",
        "required_camera": ("Locked-off wide two-shots for setup, tight reaction CUs for punchlines, "
                            "symmetrical Wes-Anderson framing, whip-pans between characters for "
                            "rapid exchanges, static shots that let performance breathe."),
        "forbidden_camera": ("NO slow dread push-ins. NO dolly zooms (Vertigo effect is thriller-only). "
                             "NO worm's eye low-angle hero shots for ordinary characters. NO extreme "
                             "slow-motion for mundane actions (unless it's literally the joke). "
                             "NO oppressive close-ups on eyes."),
        "required_lighting": ("Bright high-key even lighting, every face clearly lit, warm practicals. "
                              "Clear readable compositions — the audience must see the joke."),
        "forbidden_lighting": ("NO chiaroscuro dread lighting. NO single-bulb horror pools. NO "
                               "extreme under-lighting. NO sickly green/teal horror grading. Faces "
                               "must be readable."),
        "required_audio": ("Bouncy pizzicato strings, ukulele, xylophone, light brushed drums, "
                           "comedic bass walks, 100-130 BPM. Signature SFX: boing on surprise, "
                           "record-scratch on unexpected reveal, rimshot after punchline, sad "
                           "trombone (wah-wah-wah-waaah) after failure, slide whistle on fall, "
                           "cartoon doink. SILENCE right before the punchline for comic timing."),
        "forbidden_audio": ("NO horror strings. NO braaam brass stabs. NO heartbeat percussion. "
                            "NO reverse cymbals. NO deep synth dread drones. NO 'ominous ticking "
                            "clock'. NO taiko war drums. NO epic choir swells. NO sub-bass THUMPs "
                            "that 'echo into nothing'."),
        "scene_beat_style": ("Setup → reaction → punchline → reaction-to-punchline. Each beat "
                             "serves comedy. Visual gags land on the beat. Mis-match between "
                             "expectation and delivery is the engine."),
        "emotional_color": ("Warm sunny saturated palette. Yellows, corals, pastel blues, soft "
                            "greens. NO desaturation, NO crushed blacks, NO horror teal-orange.")
    },
    "horror": {
        "pacing": "Slow-burn dread, held silences, sudden shocks. Let shots linger uncomfortably.",
        "required_camera": ("Slow push-ins on subjects, locked-off wides with deep negative space, "
                            "off-center unsettling framing, Kubrick-symmetrical corridor shots."),
        "forbidden_camera": "NO bouncy whip-pans. NO comedic cutting.",
        "required_lighting": "Pools of motivated light in surrounding darkness. Sickly green/teal tint.",
        "forbidden_lighting": "NO bright even key-light. NO cheerful warm practicals.",
        "required_audio": ("Detuned strings 50-70 BPM, sub-bass drones, bowed cymbals, reversed "
                           "violins. Signature SFX: Psycho-sting on reveals, heartbeat, sudden "
                           "silence before scare, infrasonic rumble."),
        "forbidden_audio": "NO comedic SFX. NO cheerful BGM.",
        "scene_beat_style": "Tension → hold → release OR tension → hold → shock.",
        "emotional_color": "Desaturated cool palette, sickly greens, crimson accents."
    },
    "thriller": {
        "pacing": "Pulsing driving tension, ticking-clock energy, 90-110 BPM.",
        "required_camera": "Steadicam follows, handheld urgency, parallel cross-cut coverage.",
        "forbidden_camera": "NO slow contemplative static shots.",
        "required_lighting": "Hard directional motivated light, teal-and-orange grade.",
        "forbidden_lighting": "NO soft flat key-light.",
        "required_audio": ("Ticking clock percussion, synth pulse bass, staccato strings, 90-110 BPM. "
                           "Signature SFX: rising braam on stakes reveal, metallic shings."),
        "forbidden_audio": "NO comedic SFX. NO whimsical BGM.",
        "scene_beat_style": "Stakes → pursuit → near-miss → escalation.",
        "emotional_color": "Teal-orange contrast, steel blue, gunmetal."
    },
    "epic": {
        "pacing": "Grand, swelling, 80-100 BPM orchestral build.",
        "required_camera": "Epic crane/drone establishing shots, sweeping dollies, hero low-angles.",
        "forbidden_camera": "NO claustrophobic handheld (saves for intimacy beats).",
        "required_lighting": "Volumetric godrays, dramatic chiaroscuro, golden hour hero light.",
        "forbidden_lighting": "NO flat sitcom light.",
        "required_audio": ("Full orchestra, taiko drums, male/female choir, brass prominence, "
                           "80-110 BPM. Signature SFX: gran cassa boom, choir swell, hero brass."),
        "forbidden_audio": "NO comedic SFX. NO sitcom BGM.",
        "scene_beat_style": "Reveal → awe → action swell.",
        "emotional_color": "Rich golds, deep blacks, luminous highlights."
    },
    "drama": {
        "pacing": "Measured, breathing, emotionally grounded, 60-80 BPM.",
        "required_camera": "Intimate tight CUs, over-the-shoulder coverage, handheld for emotion.",
        "forbidden_camera": "NO gratuitous action moves.",
        "required_lighting": "Soft motivated natural light, golden hour warmth, Rembrandt keys.",
        "forbidden_lighting": "NO harsh horror pools.",
        "required_audio": ("Solo piano, cello, soft pad synths, acoustic guitar, 60-80 BPM. "
                           "Signature SFX: breath, subtle environmental sounds anchoring realism."),
        "forbidden_audio": "NO comedic SFX. NO dread drones.",
        "scene_beat_style": "Vulnerability → connection → shift.",
        "emotional_color": "Warm earth tones, honey amber, soft neutrals."
    },
    "romance": {
        "pacing": "Warm dreamy, 70-90 BPM, soft lingering beats.",
        "required_camera": "Soft two-shots, over-the-shoulder, slow romantic orbits.",
        "forbidden_camera": "NO action/horror coverage.",
        "required_lighting": "Golden hour, soft window light, warm practicals.",
        "forbidden_lighting": "NO horror dread.",
        "required_audio": ("Piano, strings, acoustic guitar, soft pads, 70-90 BPM. Signature SFX: "
                           "soft wind, gentle rain, swelling strings on eye-contact beats."),
        "forbidden_audio": "NO horror/thriller SFX.",
        "scene_beat_style": "Glance → tension → touch → breath.",
        "emotional_color": "Warm amber, rose gold, soft dusty pink."
    },
    "action": {
        "pacing": "Adrenaline, 120-150 BPM, rapid cuts.",
        "required_camera": "Handheld chase coverage, whip pans, speed ramps, tracking follows.",
        "forbidden_camera": "NO contemplative slow static shots.",
        "required_lighting": "High-contrast hard light, saturated accents, impact flashes.",
        "forbidden_lighting": "NO flat cartoon light (unless medium is 2D).",
        "required_audio": ("Distorted guitar, heavy percussion, synth bass, brass stabs, 120-150 BPM. "
                           "Signature SFX: impact whooshes, metal clangs, sub drops."),
        "forbidden_audio": "NO comedic SFX.",
        "scene_beat_style": "Threat → engage → escalate → resolve.",
        "emotional_color": "High contrast, bold saturated accents."
    }
}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AUDIO PRESETS (kept for backward compat, now lighter — TONE_CONTRACTS is primary)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

AUDIO_TONE_PRESETS = {
    "comedy": (
        "COMEDY audio design. Light quirky bouncy BGM 100-130 BPM. Instrument palette: "
        "pizzicato strings, ukulele, xylophone/marimba, slide whistle, muted trumpet, "
        "light brushed drums, kazoo. Signature SFX: boing, squeak, pop, record-scratch, "
        "cartoon doink, rimshot, sad trombone. Silence before punchlines for timing."
    ),
    "horror": (
        "HORROR audio design. Tense dread BGM 50-70 BPM. Detuned cellos, bowed cymbals, "
        "dissonant piano clusters, sub-bass drones. Signature SFX: heartbeat, Psycho string "
        "sting, creaking wood, sudden silence before jump beats."
    ),
    "thriller": (
        "THRILLER audio design. Pulsing tension BGM 90-110 BPM. Ticking clock percussion, "
        "synth pulse bass, staccato strings, metallic hits, brass stabs. Signature SFX: "
        "rising braam, accelerating heartbeat, reverse cymbals."
    ),
    "epic": (
        "EPIC audio design. Orchestral BGM 80-110 BPM. Full symphony, taiko drums, choir, "
        "brass prominence. Signature SFX: gran cassa boom, choir swells, hero brass."
    ),
    "drama": (
        "DRAMA audio design. Intimate emotional BGM 60-80 BPM. Solo piano, cello, soft pads, "
        "acoustic guitar. Signature SFX: breath, heartbeat on emotional peaks."
    ),
    "romance": (
        "ROMANCE audio design. Warm dreamy BGM 70-90 BPM. Piano, strings, acoustic guitar, "
        "soft pads. Signature SFX: soft wind, gentle rain, swelling strings."
    ),
    "action": (
        "ACTION audio design. Adrenaline BGM 120-150 BPM. Distorted guitar, heavy percussion, "
        "synth bass, brass stabs. Signature SFX: impact whooshes, metal clangs."
    ),
    "default": (
        "Balanced cinematic BGM 80-100 BPM. Orchestral strings, piano, light percussion."
    )
}


# ═══════════════════════════════════════════════════════════════════════════
# SYSTEM PROMPTS — all rewritten for v3.0
# ═══════════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT_ANALYZE = """You are DIRECTOR-X — elite Hollywood director, dramaturg, and tonal reader. Your first job is to READ THE STORY AS IT IS WRITTEN and honor its actual tone.

CRITICAL RULE — TONE HONESTY:
If the story is COMEDY, every scene will be comedy. You will NEVER label a comedy scene as "epic" or "thriller" or "horror". A silly scene about a man unplugging a router because he forgot the bill is NOT a "climactic action sequence with taiko drums". Read the AUTHOR'S intent. A joke is a joke. A romance is a romance. A horror story is a horror story.

If you detect a comedy: mark it comedy. If you detect a drama: mark it drama. If you detect a horror: mark it horror. Do not "elevate" comedy into false gravitas. Do not "darken" drama into false horror.

Your output drives the entire production. If you get the tone wrong, every downstream scene is wrong.

NOTE: You are NOT deciding scene count or duration here. A separate downstream BEAT SHEET stage will decompose the story into atomic narrative beats; that stage decides scene count. Your job is character/location/audio/tone analysis ONLY.

Return ONLY valid JSON. No markdown, no prose, no explanation."""


SYSTEM_PROMPT_BEAT_SHEET = """You are DIRECTOR-X — script supervisor and head editor of a Hollywood production. Your task: DECOMPOSE THE STORY INTO ATOMIC NARRATIVE BEATS.

═══════════════════════════════════════════════════════════════════════════
WHAT IS A "BEAT" IN FILM?
═══════════════════════════════════════════════════════════════════════════
A beat is the smallest indivisible unit of story action — a single line of dialogue, a single visual gag, a single character reaction, a single physical action. In a finished film, each beat earns its OWN shot in the cut. A real script supervisor breaks a 90-second comedy short into 15-25 shots, not 4.

═══════════════════════════════════════════════════════════════════════════
COMEDY-SPECIFIC RULE — THIS IS THE MOST IMPORTANT RULE
═══════════════════════════════════════════════════════════════════════════
Comedy LIVES in setup-and-payoff timing. NEVER compress multiple jokes, character reactions, or visual gags into one beat. Each character action gets its own beat. Each line of dialogue gets its own beat. Each punchline gets its own beat. The reaction TO a punchline gets its OWN beat.

EXAMPLE — for the line:
  "Rafiq shouted 'Relax! I'll fix it.' He opened his laptop and immediately Googled 'how to fix WiFi without WiFi.'"

A novice would compress this into ONE beat: "Rafiq tries to fix WiFi."
A Hollywood editor sees THREE distinct beats:
  Beat A: Rafiq's confident shout to the group ("Relax! I'll fix it.")
  Beat B: Rafiq opens his laptop with determination
  Beat C: Insert/CU on the Google search query "how to fix WiFi without WiFi" — THIS IS THE JOKE

If you compress these into one beat, the joke DIES on screen. The visual punchline (the search query on the laptop) MUST be its own beat to land.

EXAMPLE — for an exchange:
  "Babul smiled and said, 'Because I forgot to pay the bill. No WiFi anyway.' They all froze."

A novice would compress this into ONE beat.
A Hollywood editor sees THREE beats:
  Beat A: Babul's deadpan smile, calm body language (setup for the punchline)
  Beat B: Babul delivers the line
  Beat C: Group reaction shot — everyone frozen, mid-gesture

═══════════════════════════════════════════════════════════════════════════
ABSOLUTE BEAT-EXTRACTION RULES
═══════════════════════════════════════════════════════════════════════════
1. Read EVERY sentence of the story. Every sentence has at least one beat. Most have 2-3.
2. Every named character's distinct action gets its own beat.
3. Every spoken line gets its own beat (or pairs with a tight reaction beat).
4. Every reaction to a major event gets its own beat.
5. Every visual gag/punchline gets its own beat — NEVER compressed with setup.
6. Every realization or twist gets its own beat (often two: realization + response).
7. Setup and payoff are ALWAYS separate beats.
8. Character introductions in opening sections each get their own beat (a 4-character cast = 4 intro beats minimum, usually with a setup wide before them).
9. NEVER fewer than 8 beats for a story longer than 100 words.
10. NEVER fewer than 12 beats for a story longer than 200 words.
11. NEVER fewer than 16 beats for a story longer than 400 words.
12. A two-character exchange ("X said... Y replied...") is ALWAYS at least 2 beats.
13. You are NOT writing a SUMMARY. You are TRANSCRIBING every story moment into atomic visual units that can each become a single shot.

═══════════════════════════════════════════════════════════════════════════
DURATION ASSIGNMENT
═══════════════════════════════════════════════════════════════════════════
Assign each beat an estimated duration from the allowed durations supplied to you. Comedy beats often want short durations (5s for setups, reactions; 6s for delivered punchlines; 8s for the most important payoffs that need to land and breathe).

If the sum of beat durations exceeds the user's max_total, prefer using SHORTER allowed durations rather than dropping beats. Beat coverage is non-negotiable; precise duration is flexible.

═══════════════════════════════════════════════════════════════════════════
BEAT TYPES (use these — the scene generator uses them to choose camera/audio)
═══════════════════════════════════════════════════════════════════════════
- "establishing"  — sets location, world, mood (usually scene 1)
- "introduction"  — introduces a character with a defining visual
- "inciting"      — the event that kicks off the story
- "setup"         — sets up a future joke/payoff
- "action"        — a character physically does something
- "reaction"      — a character reacts to something
- "dialogue"      — a spoken line (often paired with action or reaction)
- "punchline"     — the joke landing (comedy) or the dramatic reveal (drama)
- "realization"   — a character figures something out
- "twist"         — a story turn
- "tag"           — closing beat / final image

Return ONLY valid JSON."""


SYSTEM_PROMPT_VISUAL_DNA = """You are DIRECTOR-X — the head of visual development for a feature. You are authoring the VISUAL DNA BLOCK — a single canonical text block that will be pasted VERBATIM into EVERY character portrait prompt AND every scene image prompt in the entire production.

Why this matters: AI image generators render the same description in many different visual styles unless you lock the rendering medium. We lock it ONCE here so every output shares the exact same visual look. Character in scene 1 must look identical in scene 17. Environment in scene 3 must share the same rendering medium as environment in scene 12.

The VISUAL DNA BLOCK must specify — unambiguously — the rendering medium (photoreal / 3D animated / 2D anime / claymation / etc.) plus enough technical specification that every AI-generated image shares:
• the same rendering approach (photo capture vs CG render vs 2D cel)
• the same material fidelity level (full PBR vs stylized shaders vs flat fills)
• the same character proportions logic (realistic vs stylized)
• the same edge/line treatment (photographic softness vs cel outlines vs inked linework)
• the same level of detail (photoreal pores vs smooth CG skin vs flat-shaded shapes)

Match the medium to the story's genre and audience. Comedy stories about everyday villagers fit naturally with 3D stylized (Pixar) or western 2D cartoon — NOT with ARRI Alexa photoreal. Horror fits photoreal or ultra-realistic 3D. Shinkai-style anime fits melancholy romance and coming-of-age. Pick the medium that SERVES THE STORY.

Return ONLY valid JSON."""


SYSTEM_PROMPT_LOCATIONS = """You are DIRECTOR-X — the production designer. Build a LOCATION BIBLE: for every distinct location, author ONE canonical hyper-detailed description that will be pasted VERBATIM into every scene set there.

CRITICAL: The canonical description must be written FROM WITHIN the visual DNA you've been given. If the visual DNA is 3D Pixar animation, describe the location with Pixar-style appealing shapes and stylized lighting vocabulary. If the visual DNA is photoreal, describe it with photographic specificity. NEVER write a location in a style that contradicts the visual DNA.

Each location description (120-200 words) must cover:
1. Architecture — walls/floor/ceiling/openings with exact materials and wear.
2. Dominant color palette (2-4 specific color descriptors).
3. Fixed furniture & props with exact placement.
4. 5-8 specific dressing objects with positions.
5. Lighting signature — sources, color temp, quality.
6. Atmospheric texture — dust/humidity/clutter.
7. Time-of-day default.
8. Staging notes — where characters face, where entrances are.

QUALITY RULE: Reading the description must let anyone on Earth build the same set — AND in the same rendering medium.

Return ONLY valid JSON."""


SYSTEM_PROMPT_CHARACTERS = """You are DIRECTOR-X — Hollywood character designer. Create exhaustively detailed FULL-BODY character reference portraits.

ABSOLUTE RULES:

1. ASPECT RATIO LOCK — 16:9 ALWAYS, NO EXCEPTIONS:
   Every character image_prompt MUST open with the verbatim 16:9 ASPECT RATIO LOCK block
   supplied to you, and MUST end with the 16:9 REINFORCE tag. Character reference
   portraits are ALWAYS 16:9 landscape widescreen, 1920x1080 — regardless of the final
   video output orientation. Downstream scene generators extract character identity from
   this reference and re-compose each scene at its own target aspect ratio. This
   separation is critical: identity transfer is aspect-ratio-agnostic.

2. VISUAL DNA INJECTION — every image_prompt MUST contain the full visual DNA block
   pasted verbatim, up front, directly after the aspect ratio lock. This forces the
   portrait to be rendered in the same medium as every downstream scene.

3. FRAMING: Always FULL-BODY, head to toe visible. Centered with balanced negative
   space on both left and right (for single portraits) or laid out horizontally across
   four panels (for 4-panel reference sheets). NEVER head-and-shoulders only.

4. POSE: Standing upright, neutral heroic stance, front-facing, arms slightly away
   from body so the silhouette is clear and readable.

5. BACKGROUND: SOLID FLAT chroma-key background of the specified color. NO gradients,
   NO shadows on background, NO environment, NO props behind the character.

6. LIGHTING: Cinematic dramatic studio lighting. Strong key, rim light for clean edge
   separation. Every surface detail visible and readable.

7. CHARACTER DETAIL: Full physicality — height/build, face bone structure, eyes
   (color + shape), skin/fur texture, hair (color + length + style), clothing head to
   toe, distinctive features, accessories, any weapons or items. So exhaustive that
   regenerating produces the same character.

8. STORY-FAITHFUL ARCHETYPES: Character designs must match the story's tone. A comedy
   cast has comedic-appeal features (slightly exaggerated, expressive). A horror cast
   can have unsettling features. NEVER design a "gritty cinematic warrior" for a
   sitcom — give them comedic everyday designs that match the tone.

9. CHARACTER ORDER LOCK: Return characters in the exact order given — (1) protagonist,
   (2) antagonist if any, (3) supporting by weight, (4) minor last. This order locks
   the reference image index used by every downstream scene.

10. FOR 4-PANEL MODE format:
    "[16:9 ASPECT RATIO LOCK]
    [VISUAL DNA BLOCK]
    4-panel character reference sheet of [desc]. Top-left: full-body front view.
    Top-right: left side profile. Bottom-left: right side profile. Bottom-right: back
    view. [detail]. [quality tags]. Solid flat [color] chroma-key background. No
    gradients, no shadows.
    [16:9 REINFORCE TAG]"

11. FOR SINGLE PORTRAIT format:
    "[16:9 ASPECT RATIO LOCK]
    [VISUAL DNA BLOCK]
    Full-body front-facing portrait of [desc]. Centered in 16:9 horizontal frame with
    balanced negative space on left and right, standing upright, neutral confident
    stance. [detail]. [quality tags]. Solid flat [color] chroma-key background. No
    gradients, no shadows.
    [16:9 REINFORCE TAG]"

12. Always end with one_line_identifier (5-10 word disambiguation tag used later in
    scene prompts).

Return ONLY valid JSON."""


SYSTEM_PROMPT_SCENES = """You are DIRECTOR-X — elite Hollywood director, cinematographer, sound designer, editor. Your output feeds an AI pipeline: IMAGE GENERATION from image_prompt, then IMAGE-TO-VIDEO from scene_prompt.

═══════════════════════════════════════════════════════════════════════════
CRITICAL MENTAL MODEL — READ THIS FIRST
═══════════════════════════════════════════════════════════════════════════
The image_prompt generates the FIRST FRAME of the video clip. The video clip
unfolds FROM that still frame over the scene's duration. This means:
  • The image captures t=0 of the scene — the starting state, not a climax.
  • Motion described in scene_prompt beats BEGINS FROM this still frame.
  • If the image is weak or inconsistent, the entire video clip fails.
  • Therefore the image_prompt is the MOST IMPORTANT artifact you produce.
  • Every image_prompt must be RICH, SPATIAL, SPECIFIC, and CONSISTENT with
    every other image_prompt in the production.

═══════════════════════════════════════════════════════════════════════════
ABSOLUTE RULES — VIOLATING ANY BREAKS THE PIPELINE
═══════════════════════════════════════════════════════════════════════════

0. BEAT COVERAGE — THE MOST IMPORTANT RULE:
   You are given a BEAT SHEET listing every atomic narrative beat in the
   story (typically 8-25 beats). EVERY BEAT MUST BECOME A SCENE.
   • Default mapping: 1 beat → 1 scene. This is the norm.
   • You MAY merge 2 ADJACENT beats into 1 scene ONLY if BOTH:
     (a) same location AND same characters AND adjacent in beat sequence
     (b) combined estimated duration ≤ largest allowed duration
   • You MAY NEVER drop a beat. You MAY NEVER combine non-adjacent beats.
   • You MAY NEVER compress a "punchline" beat or a "twist" beat — those
     ALWAYS get their own scene to land properly.
   • Final scene count MUST be in [num_beats × 0.85, num_beats × 1.0].
     If beats=18 then scenes must be 16-18. NOT 4. NOT 6. NOT 10.
   • Each scene MUST reference exactly one beat_id (or two adjacent
     beat_ids if merged) in its `covers_beats` field.
   • The order of scenes MUST follow the order of beats in the beat sheet.
   This rule supersedes the AI's instinct to "summarize" or "trim". You
   are TRANSCRIBING the beat sheet into shootable scenes, not editorialising.

1. DURATION LOCK: Each scene duration MUST be EXACTLY one of the allowed
   durations.

2. TOTAL CAP: Sum of durations MUST NOT exceed the maximum. If beat
   coverage forces this — use the smallest allowed durations across all
   scenes. NEVER drop a beat to fit a duration cap.

3. ONE LOCKED TONE — NEVER CHANGES PER SCENE:
   The story has ONE tone (comedy / drama / horror / thriller / epic /
   romance / action) given in the production package. Every scene MUST stay
   inside that tone's contract. NEVER label individual scenes with tones
   that contradict the story tone. A comedy has zero horror scenes. A drama
   has zero epic-swell scenes. A comedy punchline gets a RIMSHOT, not a
   HANS-ZIMMER-BRAAM.
   The TONE CONTRACT given to you lists required camera moves, forbidden
   camera moves, required audio, forbidden audio, required lighting,
   forbidden lighting. You will obey every item.

4. ASPECT RATIO LOCK — VERBATIM AT TOP + REINFORCE AT BOTTOM:
   Every scene image_prompt MUST open with the verbatim ASPECT RATIO LOCK
   block supplied to you, BEFORE the REFERENCE MAP. Every scene image_prompt
   MUST end with the verbatim REINFORCE tag (e.g. `--ar 9:16`). In between,
   all FRAMING and SPATIAL LAYOUT decisions must be composed FOR that
   orientation using the orientation-specific framing guidance and spatial
   vocabulary given to you — not just cropped to it. Vertical 9:16 cannot
   use wide horizontal two-shots. Ultrawide 21:9 cannot use tall vertical
   close-ups.

5. VISUAL DNA INJECTION — VERBATIM:
   You are given a VISUAL DNA BLOCK. You MUST paste it — word for word, no
   paraphrasing — into EVERY scene's image_prompt, right after the ASPECT
   RATIO LOCK and REFERENCE MAP and before the FIRST-FRAME / SCENE CONTEXT
   section. This guarantees every rendered image shares the same medium.

6. LOCATION CANONICAL INJECTION — VERBATIM:
   Every scene is set in ONE location from the Location Bible. Paste the
   location's canonical_description VERBATIM into the image_prompt. Place
   it after the VISUAL DNA and before the FIRST-FRAME block.

7. CHARACTER REFERENCE INDEXING — CRITICAL:
   The character list is in LOCKED GLOBAL ORDER. Downstream, the image
   generator receives portraits in that same order, filtered to only
   characters in this scene.
   EVERY image_prompt with 1+ characters MUST include a REFERENCE MAP block
   (placed AFTER the ASPECT RATIO LOCK, BEFORE the VISUAL DNA):
     "REFERENCE MAP: The 1st reference character is [NAME_A]
     ([one_line_identifier]). The 2nd reference character is [NAME_B]
     ([one_line_identifier])..."
   In the scene body, always remind: "[NAME_A] (1st reference) ...
   [NAME_B] (2nd reference) ..."
   The scene's characters_present list MUST match the global order filtered.

═══════════════════════════════════════════════════════════════════════════
8. IMAGE_PROMPT STRUCTURE — 14 BLOCKS, STRICT ORDER (v3.1)
═══════════════════════════════════════════════════════════════════════════

[01] ASPECT RATIO LOCK — pasted verbatim from production package. Starts the
     prompt. E.g. "ASPECT RATIO LOCK — 9:16 VERTICAL PORTRAIT. Canvas 1080x1920..."

[02] REFERENCE MAP — if 1+ characters present. Opens with "REFERENCE MAP:"
     and uses ordinal ("1st", "2nd", ...) naming in global character order.

[03] VISUAL DNA — pasted verbatim from production package. E.g.
     "RENDERING MEDIUM: 3D CGI animated film in the Pixar tradition..."

[04] LOCATION — pasted verbatim from Location Bible canonical_description.

[05] FIRST-FRAME SEMANTICS — one sentence establishing this is t=0, the
     starting frame of a [duration]s clip, from which motion unfolds. E.g.
     "This image captures the opening frame (t=0) of a 6-second clip;
     character action and camera motion will unfold FROM this still."

[06] SCENE CONTEXT — what is physically captured in THIS EXACT moment.
     Ultra-specific, not generic. Describe micro-moments:
       • Exact body/hand/face position at t=0
       • Objects mid-motion or at rest
       • Expressions at this instant
       • Tension in posture
       • What is about-to-happen vs already-happened
     4-7 sentences. Example of good specificity:
       "Babul's right index finger and thumb have just made contact with
       the locking tab of the yellow ethernet plug; his thumb is pressing
       the tab down but the plug has not yet begun to slide; his left hand
       steadies the router box; his weight is shifted slightly forward onto
       his right foot; his gaze is directed at the plug, not the camera;
       his mouth is closed in a neutral calm expression with a faint
       suggestion of a knowing smile."

[07] FRAMING — shot size (EWS/WS/FS/MWS/MS/MCU/CU/ECU/OTS/two-shot/POV),
     angle (eye-level/low 15°/high 30°/Dutch 10°/worm's-eye/bird's-eye),
     lens (14mm/24mm/35mm/50mm/85mm/135mm), depth of field (f/1.4 ... f/11,
     rack focus, split diopter), and how the chosen orientation influences
     the framing decision. Obey the TONE CONTRACT required/forbidden camera
     rules AND the orientation framing guidance. State the aspect explicitly
     again here (e.g. "composed for 9:16 vertical").

[08] SPATIAL LAYOUT — where elements sit in the frame using the
     orientation-appropriate spatial vocabulary supplied to you. Name
     foreground/midground/background. Name which thirds/quadrants/regions
     elements occupy. Name frame edges. Name where the eye travels.
     Example for 16:9:
       "Babul (1st reference) occupies the left-third of frame, foreground
       layer. Router box sits center-third, midground. Adobe wall fills
       right two-thirds and extends top-to-bottom. Ground line enters
       lower-third of frame running horizontally. Negative space in
       upper-right lets the blue twilight sky breathe."
     Example for 9:16:
       "Babul (1st reference) occupies middle-third of the tall frame,
       head and shoulders in upper-middle third, hands mid-frame at plug
       level. Router box center-frame directly below his hands. Wall
       texture fills entire width; twilight sky visible in top-third;
       ground line in bottom-third."

[09] SUBJECTS — each character with (Nth reference) tag, restating KEY
     identifying details from their portrait (hair, eyes, wardrobe, build)
     plus their pose/action/expression at t=0. Even brief descriptions MUST
     re-anchor these portrait details or the identity will drift.

[10] LIGHTING — motivated, extending the location's lighting signature AND
     obeying the TONE CONTRACT lighting rules. Name key/fill/rim/backlight,
     color temperature (Kelvin), quality (hard/soft/diffused/specular),
     direction, and what is lit vs what falls to shadow.

[11] COLOR & GRADE — specific palette matching the TONE CONTRACT's
     emotional_color rule. Name the grade (teal-and-orange / bleach-bypass /
     warm-natural / desaturated-cool / pastel-saturated / etc.).

[12] ATMOSPHERE — haze/dust/fog/embers/fireflies/rain/mist/lens flares/
     particle density/film grain. Consistent with the location + tone.

[13] CONTINUITY VISUAL CUES — what carries over from the previous scene.
     Reference specific visual elements: matching time-of-day, recurring
     props, continuing posture, the same light direction, unchanged
     wardrobe, same dust particles still suspended. For scene 1.1 write
     "Opening scene — this image establishes the visual language (medium,
     palette, light direction, wardrobe, atmosphere) that all subsequent
     scenes will reference." Mention 2-4 visual anchors.

[14] QUALITY TAGS + ORIENTATION REINFORCE — "hyper-sharp 8K detail,
     cinematic composition, photographically-plausible lighting (within
     the locked rendering medium)" + the verbatim REINFORCE tag.

TARGET LENGTH: 320-480 words per image_prompt.

═══════════════════════════════════════════════════════════════════════════
9. SCENE_PROMPT STRUCTURE — STRICT BEAT FORMAT
═══════════════════════════════════════════════════════════════════════════
   [OVERALL PACING one-liner matching the tone contract's pacing rule]
   [BEAT 1 (0-2s)] Camera | Subject action | Environment | Light | Sound
   [BEAT 2 (2-4s)] Camera | Subject action | Environment | Light | Sound
   [BEAT 3 (4-6s)] Camera | Subject action | Environment | Light | Sound
   (5s scenes: 0-2 / 2-4 / 4-5. 8s scenes: 0-2 / 2-4 / 4-6 / 6-8.)

   CRITICAL: BEAT 1 must BEGIN from the still frame described in the
   image_prompt. The first 0.2 seconds should match the image exactly, then
   motion starts. Never contradict the image_prompt.

   [AUDIO DESIGN — obeys the tone contract]:
     • BGM: [style + BPM + instruments] — ALL from tone contract's
       required_audio palette
     • AMBIENT: [location sound bed from the Location Bible]
     • SFX: timed at @Xs — using the tone contract's signature SFX
     • DIALOGUE: tone and language (or "none")
     • VOICEOVER: tone (or "none")

   [GENRE BEAT — matching the STORY TONE: comedy pop / horror sting /
   thriller pulse / epic swell / drama breath / romance breath / action hit]

   [TRANSITION — exact type + timing]

   TARGET LENGTH: 280-420 words.

═══════════════════════════════════════════════════════════════════════════
10. SCENE CONTINUITY CHAIN — MANDATORY
═══════════════════════════════════════════════════════════════════════════
Each scene MUST have a `continuity_from_previous` field describing what
state the previous scene left (character position, emotion, camera, lighting,
any visual anchor elements). The first beat of every scene (except 1.1)
MUST flow from that state. Example:
  "Previous scene ended on Babul's deadpan MCU smile, warm 2800K tungsten
  key-light from above, dust motes suspended in air. This scene opens on a
  matched wider shot showing that same smile, same light direction, same
  dust still visible."

═══════════════════════════════════════════════════════════════════════════
11. CHARACTER CONSISTENCY
═══════════════════════════════════════════════════════════════════════════
Always re-state key identifying details (hair color + length, eye color,
wardrobe specifics, posture traits) from the character portrait in every
scene they appear. "Babul" is not enough — "Babul (1st reference, 30s
weary-eyed man in blue-grey checkered kurta, dusty trousers, short dark
hair)" IS enough.

═══════════════════════════════════════════════════════════════════════════
12. CINEMATOGRAPHIC VOCABULARY — PRECISE TERMS ONLY
═══════════════════════════════════════════════════════════════════════════
(And only those permitted by the tone contract.)
Shots: EWS / WS / FS / MWS / MS / MCU / CU / ECU / insert / OTS / two-shot / POV
Lenses: 14mm / 24mm / 35mm / 50mm / 85mm / 135mm / anamorphic 2.39:1 / macro
DoF: f/1.4 / f/2.0 / f/2.8 / f/4 / f/8 / f/11 / rack focus / split diopter
Angles: eye-level / low 15° / high 30° / Dutch 10° / worm's-eye / bird's-eye
Movement (scene_prompt only): locked-off / pan / tilt / dolly / tracking /
  steadicam / handheld / crane / whip pan / orbit / push-in / pull-back
Lighting: key / fill / rim / backlight / practicals / motivated / high-key /
  low-key / golden hour / blue hour / Rembrandt

Every word earns its place. No filler. No vagueness.

Return ONLY valid JSON."""


# ═══════════════════════════════════════════════════════════════════════════
# MAIN TEMPLATE CLASS
# ═══════════════════════════════════════════════════════════════════════════

class AIDirectorFramework(TemplateBase):
    """
    AI Director Framework v3.0 — Professional-grade story-to-scene conversion.

    Pipeline (8 stages):
      1. Validate inputs
      2. Story Analysis — with TONE DETECTION
      3. Visual DNA — canonical rendering medium (NEW in v3.0)
      4. Location Bible — verbatim canonical descriptions
      5. Character Portraits — with visual DNA embedded
      6. Scene Direction — with tone lock, continuity chain, visual DNA injection
      7. Save to Project DB
      8. Finalize
    """

    async def execute(self, inputs: Dict[str, Any]) -> TemplateResult:

        # ─────────────────────────────────────────────────────────────────────
        # STAGE 1: VALIDATE INPUTS
        # ─────────────────────────────────────────────────────────────────────
        story = inputs.get("story_text", "").strip()
        if not story:
            return mexflow.result.error(
                "Story text is required.",
                details={"field": "story_text"}
            )
        if len(story) < 50:
            return mexflow.result.error(
                "Story is too short. Provide at least 50 characters.",
                details={"min_length": 50, "current_length": len(story)}
            )

        raw_durations = inputs.get("allowed_durations", "5, 6, 8")
        allowed_durations = self._parse_durations(raw_durations)
        if not allowed_durations:
            return mexflow.result.error(
                "Invalid durations. Example: 5, 6, 8",
                details={"field": "allowed_durations", "received": raw_durations}
            )

        max_duration_mode = inputs.get("max_duration_mode", "auto")
        if max_duration_mode == "auto":
            max_duration = "AUTO"
        else:
            max_duration = int(inputs.get("max_duration_seconds", 120))
            if max_duration < max(allowed_durations):
                return mexflow.result.error(
                    f"Max duration ({max_duration}s) must be >= largest allowed ({max(allowed_durations)}s).",
                    details={"field": "max_duration_seconds"}
                )

        style_key = inputs.get("visual_style", "cinematic_epic")
        if style_key == "custom":
            visual_style = inputs.get("custom_visual_style", "").strip() or VISUAL_STYLE_MAP["cinematic_epic"]
        else:
            visual_style = VISUAL_STYLE_MAP.get(style_key, VISUAL_STYLE_MAP["cinematic_epic"])

        # NEW v3.0: Visual DNA selection
        dna_key = inputs.get("render_medium", "auto")
        if dna_key == "auto":
            render_medium_preset = None  # AI will pick based on tone
        elif dna_key == "custom":
            render_medium_preset = inputs.get("custom_render_medium", "").strip() or None
        else:
            render_medium_preset = VISUAL_DNA_PRESETS.get(dna_key)

        # NEW v3.0: Forced tone
        forced_tone = inputs.get("force_tone", "auto")  # auto / comedy / drama / horror / thriller / epic / romance / action

        # NEW v3.1: Output orientation (aspect ratio) — LOCKED for every scene.
        # Character portraits are always 16:9 regardless of this setting.
        orientation_key = inputs.get("output_orientation", "16:9")
        if orientation_key not in ORIENTATION_PRESETS:
            orientation_key = "16:9"
        orientation_preset = ORIENTATION_PRESETS[orientation_key]

        prompt_language = inputs.get("prompt_language", "english")
        bg_color = inputs.get("character_bg_color", "#1a5fb4")
        portrait_mode = inputs.get("portrait_mode", "4panel")

        mexflow.progress.setup(9)
        mexflow.progress.start_stage("Validating", "Preparing the Director's workspace...")
        mexflow.progress.complete_stage(
            f"Durations: {allowed_durations} | Max: {max_duration} | "
            f"Medium: {dna_key} | Tone: {forced_tone} | "
            f"Scene Orientation: {orientation_key} | Character Portraits: 16:9 (locked)"
        )

        # ─────────────────────────────────────────────────────────────────────
        # CHECK FOR RESUME
        # ─────────────────────────────────────────────────────────────────────
        resume_info = await mexflow.stage.check_resume()
        analysis_data = None
        visual_dna = None
        location_bible = None
        beat_sheet = None
        characters_data = None
        scenes_data = None

        if resume_info:
            await mexflow.stage.resume_from(resume_info['execution_id'])
            stage_name = resume_info.get('stage_name', '')
            if stage_name in ("story_analysis", "visual_dna", "location_bible", "beat_sheet", "character_generation", "scene_generation"):
                analysis_data = await mexflow.stage.get("story_analysis")
            if stage_name in ("visual_dna", "location_bible", "beat_sheet", "character_generation", "scene_generation"):
                visual_dna = await mexflow.stage.get("visual_dna")
            if stage_name in ("location_bible", "beat_sheet", "character_generation", "scene_generation"):
                location_bible = await mexflow.stage.get("location_bible")
            if stage_name in ("beat_sheet", "character_generation", "scene_generation"):
                beat_sheet = await mexflow.stage.get("beat_sheet")
            if stage_name in ("character_generation", "scene_generation"):
                characters_data = await mexflow.stage.get("character_generation")
            if stage_name == "scene_generation":
                scenes_data = await mexflow.stage.get("scene_generation")

        # ─────────────────────────────────────────────────────────────────────
        # STAGE 2: ANALYZE STORY (with rigorous tone detection)
        # ─────────────────────────────────────────────────────────────────────
        if not analysis_data:
            mexflow.progress.start_stage("Story Analysis", "Reading the story with a critical eye — detecting true tone...")
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()

            analysis_data = await self._analyze_story(
                story, allowed_durations, max_duration, visual_style, forced_tone
            )
            if not analysis_data:
                return mexflow.result.error(
                    "Failed to analyze story.",
                    details={"suggestion": "Simplify or clarify the story structure."}
                )

            # Force tone if user requested
            if forced_tone != "auto":
                analysis_data["locked_tone"] = forced_tone
                analysis_data["genre"] = forced_tone
            else:
                analysis_data["locked_tone"] = self._normalize_tone(analysis_data.get("genre", "drama"))

            await mexflow.stage.save("story_analysis", analysis_data)
            mexflow.progress.complete_stage(
                f"Tone: {analysis_data.get('locked_tone')} | "
                f"Characters: {len(analysis_data.get('characters', []))} | "
                f"Locations: {len(analysis_data.get('locations', []))} | "
                f"Moments: {len(analysis_data.get('key_moments', []))}"
            )
        else:
            mexflow.progress.start_stage("Story Analysis", "Resuming...")
            mexflow.progress.complete_stage("Loaded from checkpoint")

        locked_tone = analysis_data.get("locked_tone") or self._normalize_tone(analysis_data.get("genre", "drama"))

        # ─────────────────────────────────────────────────────────────────────
        # STAGE 3: VISUAL DNA (NEW in v3.0)
        # ─────────────────────────────────────────────────────────────────────
        if not visual_dna:
            mexflow.progress.start_stage("Visual DNA", "Locking the canonical rendering medium for the entire production...")
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()

            visual_dna = await self._generate_visual_dna(
                story, analysis_data, visual_style, render_medium_preset, locked_tone
            )
            if not visual_dna:
                visual_dna = self._fallback_visual_dna(locked_tone, render_medium_preset)

            await mexflow.stage.save("visual_dna", visual_dna)
            mexflow.progress.complete_stage(
                f"Visual DNA locked: {visual_dna.get('medium_name', 'unknown')}"
            )
        else:
            mexflow.progress.start_stage("Visual DNA", "Resuming...")
            mexflow.progress.complete_stage("Visual DNA loaded from checkpoint")

        # ─────────────────────────────────────────────────────────────────────
        # STAGE 4: LOCATION BIBLE
        # ─────────────────────────────────────────────────────────────────────
        if not location_bible:
            mexflow.progress.start_stage("Location Bible", "Production Designer is building canonical locations...")
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()

            location_bible = await self._generate_location_bible(
                story, analysis_data, visual_style, visual_dna, locked_tone
            )
            if not location_bible or not location_bible.get("locations"):
                location_bible = self._fallback_location_bible(analysis_data)

            await mexflow.stage.save("location_bible", location_bible)
            mexflow.progress.complete_stage(
                f"Sealed {len(location_bible.get('locations', []))} locations"
            )
        else:
            mexflow.progress.start_stage("Location Bible", "Resuming...")
            mexflow.progress.complete_stage("Location Bible loaded")

        # ─────────────────────────────────────────────────────────────────────
        # STAGE 5: BEAT SHEET DECOMPOSITION (NEW in v3.2 — the headline fix)
        # Forces atomic narrative-beat extraction so we never undercount scenes.
        # ─────────────────────────────────────────────────────────────────────
        if not beat_sheet:
            mexflow.progress.start_stage(
                "Beat Sheet",
                "Script Supervisor is decomposing the story into atomic narrative beats..."
            )
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()

            beat_sheet = await self._generate_beat_sheet(
                story, analysis_data, allowed_durations, max_duration, locked_tone
            )
            if not beat_sheet or not beat_sheet.get("beats"):
                # Fall back gracefully — derive from key_moments
                beat_sheet = self._fallback_beat_sheet(analysis_data, allowed_durations)

            await mexflow.stage.save("beat_sheet", beat_sheet)

            num_beats = len(beat_sheet.get("beats", []))
            beat_seconds = sum(
                b.get("estimated_seconds", 0) for b in beat_sheet.get("beats", [])
            )
            word_count = len(story.split())
            expected_floor = max(8, word_count // 25)

            warning = ""
            if num_beats < expected_floor:
                warning = (
                    f" ⚠ UNDERCOUNT: AI returned {num_beats} beats for "
                    f"{word_count}-word story (expected floor: {expected_floor}). "
                    f"Downstream scenes may be undercounted."
                )

            mexflow.progress.complete_stage(
                f"Decomposed into {num_beats} atomic beats "
                f"(~{beat_seconds}s total).{warning}"
            )
        else:
            mexflow.progress.start_stage("Beat Sheet", "Resuming...")
            mexflow.progress.complete_stage("Beat sheet loaded from checkpoint")

        # ─────────────────────────────────────────────────────────────────────
        # STAGE 6: CHARACTER PORTRAITS
        # ─────────────────────────────────────────────────────────────────────
        if not characters_data:
            mexflow.progress.start_stage("Character Design", "Casting Director crafting portraits with visual DNA embedded...")
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()

            characters_data = await self._generate_characters(
                story, analysis_data, bg_color, visual_style,
                portrait_mode, visual_dna, locked_tone
            )
            if not characters_data:
                return mexflow.result.error("Failed to generate character portraits.")

            characters_data["characters"] = self._sort_characters_by_significance(
                characters_data.get("characters", []),
                analysis_data.get("characters", [])
            )

            # Defensive: ensure visual DNA AND 16:9 aspect ratio are injected
            # into every portrait prompt (v3.1 — aspect ratio added).
            characters_data["characters"] = self._enforce_dna_in_portraits(
                characters_data.get("characters", []), visual_dna, bg_color
            )

            await mexflow.stage.save("character_generation", characters_data)
            mexflow.progress.complete_stage(
                f"Designed {len(characters_data.get('characters', []))} characters "
                f"(locked order: {', '.join(c.get('name', '?') for c in characters_data.get('characters', []))}) "
                f"at 16:9 portrait ratio"
            )
        else:
            mexflow.progress.start_stage("Character Design", "Resuming...")
            mexflow.progress.complete_stage("Character portraits loaded")

        # ─────────────────────────────────────────────────────────────────────
        # STAGE 6: SCENE GENERATION
        # ─────────────────────────────────────────────────────────────────────
        if not scenes_data:
            mexflow.progress.start_stage(
                "Scene Direction",
                f"Storyboarding every beat — tone={locked_tone}, "
                f"orientation={orientation_key}, continuity-chained..."
            )
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()

            scenes_data = await self._generate_scenes(
                story, analysis_data, location_bible, characters_data,
                allowed_durations, max_duration, visual_style, visual_dna,
                locked_tone, prompt_language, orientation_preset, beat_sheet
            )
            if not scenes_data or not scenes_data.get("scenes"):
                return mexflow.result.error(
                    "Failed to generate scenes.",
                    details={"suggestion": "Try different duration settings."}
                )

            # Defensive post-processing — guarantees invariants
            # (v3.1: now also enforces orientation lock + reinforce tag)
            scenes_data["scenes"] = self._enforce_scene_invariants(
                scenes_data.get("scenes", []),
                characters_data.get("characters", []),
                location_bible.get("locations", []),
                visual_dna,
                locked_tone,
                orientation_preset
            )

            # NEW v3.2: Frame-to-frame continuity threading
            # Walks scenes sequentially and injects "INCOMING STATE FROM
            # PREVIOUS SCENE" anchor blocks, guaranteeing each scene's
            # first frame visually matches the previous scene's last frame.
            scenes_data["scenes"] = self._thread_continuity_state(
                scenes_data.get("scenes", []),
                characters_data.get("characters", []),
                location_bible.get("locations", [])
            )

            # v3.3: Beat-coverage check (now meaningful — batching prevents
            # truncation, so any coverage gap means a batch retry exhausted)
            num_beats = len(beat_sheet.get("beats", []))
            num_scenes = len(scenes_data.get("scenes", []))
            coverage_warning = ""
            if num_beats > 0:
                coverage_pct = num_scenes / num_beats * 100
                if num_scenes < num_beats * 0.85:
                    coverage_warning = (
                        f" ⚠ BEAT-COVERAGE GAP: {num_scenes} scenes for "
                        f"{num_beats} beats ({coverage_pct:.0f}% coverage, "
                        f"target ≥85%). One or more batches exhausted their "
                        f"retry budget. Some beats may be missing from the "
                        f"final cut — review batch logs above."
                    )
                    print(f"[Scene Direction] {coverage_warning}")
                else:
                    print(
                        f"[Scene Direction] ✓ Beat coverage: {num_scenes}/{num_beats} "
                        f"scenes ({coverage_pct:.0f}%)"
                    )

            await mexflow.stage.save("scene_generation", scenes_data)
            total_dur = sum(s.get("duration", 0) for s in scenes_data.get("scenes", []))
            mexflow.progress.complete_stage(
                f"Directed {num_scenes} scenes from {num_beats} beats, "
                f"total {total_dur}s.{coverage_warning}"
            )
        else:
            mexflow.progress.start_stage("Scene Direction", "Resuming...")
            mexflow.progress.complete_stage("Scene data loaded")

        # ─────────────────────────────────────────────────────────────────────
        # STAGE 7: SAVE TO PROJECT DB
        # ─────────────────────────────────────────────────────────────────────
        mexflow.progress.start_stage("Saving to Project", "Writing all data to project database...")
        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        await self._save_to_project(characters_data, scenes_data, bg_color)
        mexflow.progress.complete_stage("All data saved")

        # ─────────────────────────────────────────────────────────────────────
        # STAGE 8: FINALIZE
        # ─────────────────────────────────────────────────────────────────────
        mexflow.progress.start_stage("Finalizing", "Compiling production report...")

        scenes_list = scenes_data.get("scenes", [])
        chars_list = characters_data.get("characters", [])
        total_duration = sum(s.get("duration", 0) for s in scenes_list)

        duration_dist = {}
        for s in scenes_list:
            d = s.get("duration", 0)
            duration_dist[d] = duration_dist.get(d, 0) + 1

        await mexflow.stage.complete()
        mexflow.progress.complete_stage(
            f"Production complete! {len(scenes_list)} scenes, {len(chars_list)} chars, {total_duration}s"
        )

        return_scenes = []
        for i, scene in enumerate(scenes_list):
            return_scenes.append({
                "scene_id_str": scene.get("scene_id", f"{i+1}"),
                "title": scene.get("title", f"Scene {i+1}"),
                "image_prompt": scene.get("image_prompt", ""),
                "voiceover": scene.get("description", ""),
                "duration": scene.get("duration", 5),
                "metadata": {
                    "scene_prompt": scene.get("scene_prompt", ""),
                    "characters_present": scene.get("characters_present", []),
                    "location_name": scene.get("location_name", ""),
                    "transition": scene.get("transition", ""),
                    "camera": scene.get("camera_info", ""),
                    "lighting": scene.get("lighting_info", ""),
                    "audio": scene.get("audio_info", ""),
                    "continuity_from_previous": scene.get("continuity_from_previous", ""),
                    "tone": locked_tone
                }
            })

        return mexflow.result.success(
            scenes=return_scenes,
            message=f"AI Director v3.3 delivered {len(scenes_list)} cinematic scenes "
                    f"with {len(chars_list)} characters across {total_duration}s "
                    f"in locked {locked_tone.upper()} tone at {orientation_key} output.",
            metadata={
                "total_scenes": len(scenes_list),
                "total_characters": len(chars_list),
                "total_locations": len(location_bible.get("locations", [])),
                "total_duration_seconds": total_duration,
                "allowed_durations": allowed_durations,
                "duration_distribution": duration_dist,
                "visual_style": style_key,
                "render_medium": visual_dna.get("medium_name", "unknown"),
                "locked_tone": locked_tone,
                "output_orientation": orientation_key,
                "output_canvas": orientation_preset.get("canvas", ""),
                "character_portrait_orientation": "16:9",
                "character_portrait_canvas": "1920x1080",
                "prompt_language": prompt_language,
                "audio_strategy": analysis_data.get("audio_strategy", {}),
                "character_reference_order": [c.get("name") for c in chars_list]
            }
        )


    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # HELPER METHODS
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def _parse_durations(self, raw: str) -> List[int]:
        try:
            durations = []
            for part in raw.replace(" ", "").split(","):
                if part.strip():
                    val = int(part.strip())
                    if val > 0:
                        durations.append(val)
            return sorted(list(set(durations)))
        except (ValueError, TypeError):
            return []


    def _normalize_scene_id(self, raw: str, fallback_index: int) -> str:
        """
        Convert any scene_id format the LLM might emit to a plain integer
        string ("1", "2", "3", ...).

        Handles:
          • "1.1", "1.5", "1.42"   → "1", "5", "42"  (strip dotted prefix)
          • "S1", "scene_5", "ep1-3" → "1", "5", "3"  (extract last integer)
          • "1"                     → "1"             (already correct)
          • ""                      → str(fallback_index + 1)
        """
        s = (raw or "").strip()
        if not s:
            return str(fallback_index + 1)

        # Already a clean integer string?
        if s.isdigit():
            return s

        # Dotted format ("1.5", "1.42") — take the part after the last dot
        if "." in s:
            tail = s.rsplit(".", 1)[-1].strip()
            if tail.isdigit():
                return tail

        # Extract the last contiguous run of digits from the string
        digits = ""
        last_run = ""
        for ch in s:
            if ch.isdigit():
                digits += ch
            else:
                if digits:
                    last_run = digits
                    digits = ""
        if digits:
            last_run = digits
        if last_run:
            return last_run

        return str(fallback_index + 1)


    def _normalize_tone(self, genre: str) -> str:
        """Normalize any genre string to one of the canonical tone keys."""
        g = (genre or "").lower().strip()
        tone_aliases = {
            "comedy": ["comedy", "comedic", "funny", "humor", "humour", "satire", "sitcom", "parody", "farce"],
            "horror": ["horror", "scary", "terror", "ghost", "supernatural horror"],
            "thriller": ["thriller", "suspense", "mystery", "crime", "noir"],
            "epic": ["epic", "blockbuster"],
            "drama": ["drama", "dramatic", "slice of life", "coming of age", "tragedy", "biography"],
            "romance": ["romance", "romantic", "love"],
            "action": ["action", "fight", "war", "combat"],
        }
        for canonical, aliases in tone_aliases.items():
            for alias in aliases:
                if alias in g:
                    return canonical
        return "drama"


    def _get_tone_contract(self, tone: str) -> Dict[str, str]:
        return TONE_CONTRACTS.get(tone.lower(), TONE_CONTRACTS["drama"])


    def _get_audio_preset(self, tone: str) -> str:
        return AUDIO_TONE_PRESETS.get(tone.lower(), AUDIO_TONE_PRESETS["default"])


    # ─────────────────────────────────────────────────────────────────────
    # STAGE 2 — STORY ANALYSIS with tone-first priority
    # ─────────────────────────────────────────────────────────────────────
    async def _analyze_story(
        self, story: str, allowed_durations: List[int],
        max_duration, visual_style: str, forced_tone: str
    ) -> Optional[Dict[str, Any]]:

        max_dur_str = f"{max_duration} seconds (hard limit)" if max_duration != "AUTO" else (
            "AUTO — determine optimal based on narrative complexity"
        )

        forced_tone_instruction = ""
        if forced_tone != "auto":
            forced_tone_instruction = (
                f"\n\nTONE IS PRE-LOCKED BY THE USER: The story tone is **{forced_tone.upper()}**. "
                f"You MUST return genre = '{forced_tone}' and treat every narrative beat as "
                f"{forced_tone}. Do not second-guess this."
            )

        prompt = f"""{SYSTEM_PROMPT_ANALYZE}

Analyze this story for cinematic scene breakdown.{forced_tone_instruction}

STORY:
\"\"\"
{story}
\"\"\"

ALLOWED SCENE DURATIONS: {allowed_durations} seconds (each scene must be EXACTLY one)
MAXIMUM TOTAL DURATION: {max_dur_str}
VISUAL STYLE MOOD: {visual_style}

Return this JSON:

{{
    "story_summary": "2-3 sentence summary",
    "genre": "ONE primary genre: comedy | horror | thriller | drama | action | epic | romance",
    "sub_genre": "specific descriptor (e.g. 'village sitcom comedy', 'cosmic horror')",
    "tone_detection_reasoning": "1-2 sentences explaining WHY you chose this tone based on textual cues",
    "mood": "overall emotional tone in 3-5 words",
    "mood_arc": "how emotion progresses scene 1 → final scene (MUST stay inside the chosen genre — a comedy mood arc goes from small joke → bigger joke → biggest joke, NOT from light → dark dread)",
    "setting": "primary setting description",
    "time_period": "time period of the story",
    "narrative_arc": {{
        "act_1_setup": "setup description",
        "act_2_confrontation": "rising action",
        "act_3_resolution": "resolution"
    }},
    "characters": [
        {{
            "name": "Character Name",
            "role": "protagonist|antagonist|supporting|minor",
            "description": "brief role description",
            "age_estimate": "estimated age",
            "significance_score": 10,
            "significance": "why this character matters"
        }}
    ],
    "locations": [
        {{
            "name": "Concise Location Name",
            "brief": "1-sentence what-happens-here",
            "time_of_day_default": "day / evening / night / magic hour"
        }}
    ],
    "audio_strategy": {{
        "overall_genre": "must match genre field above",
        "bgm_style": "sub-style 1 sentence (must match the genre — a comedy uses 'bouncy pizzicato strings and ukulele', NEVER 'deep synth bass drones')",
        "reference_tracks": ["score/composer 1", "2"],
        "tempo_bpm_range": "e.g. 100-125 for comedy, 60-80 for drama",
        "instrument_palette": ["instrument1", "instrument2"],
        "signature_sfx": ["SFX1", "SFX2", "SFX3"],
        "mood_arc_beats": "how BGM evolves — stay inside genre",
        "dialogue_style": "how characters speak"
    }},
    "key_moments": [
        {{
            "moment": "visual moment description",
            "emotional_beat": "emotion served (MUST match the genre — e.g. for a comedy: 'setup', 'escalation', 'punchline', 'reaction', NEVER 'dread' or 'epic reveal')",
            "location_ref": "which location",
            "suggested_duration": 5,
            "act": 1
        }}
    ],
    "total_scenes_recommended": 8,
    "total_duration_recommended": 50,
    "color_arc": "how color progresses (stay inside genre)",
    "visual_motifs": ["recurring visual elements"]
}}

CRITICAL:
- suggested_duration MUST be one of {allowed_durations}
- Sum MUST NOT exceed {max_dur_str}
- Characters in order: protagonist first, then by significance_score desc
- genre MUST be ONE of: comedy | horror | thriller | drama | action | epic | romance
- If the story contains jokes and absurd humor: genre = "comedy". Period.
- audio_strategy MUST match the genre — NEVER give a comedy story a horror audio palette"""

        try:
            response = await mexflow.ai.generate(prompt, max_tokens=6000)
            data = mexflow.ai.parse_json(response)

            if isinstance(data, dict) and "characters" in data and "key_moments" in data:
                if "locations" not in data or not data["locations"]:
                    data["locations"] = [{"name": "Primary Location", "brief": "main setting", "time_of_day_default": "day"}]
                if "audio_strategy" not in data:
                    data["audio_strategy"] = {
                        "overall_genre": data.get("genre", "drama"),
                        "bgm_style": "Cinematic score matching tone",
                        "tempo_bpm_range": "80-100",
                        "instrument_palette": ["strings", "piano"],
                        "signature_sfx": [],
                        "mood_arc_beats": "Flows with narrative"
                    }
                chars = data.get("characters", [])
                def _rank(c):
                    role = c.get("role", "minor").lower()
                    role_weight = {"protagonist": 0, "antagonist": 1, "supporting": 2, "minor": 3}.get(role, 4)
                    sig = c.get("significance_score", 0)
                    try:
                        sig = int(sig)
                    except (ValueError, TypeError):
                        sig = 0
                    return (role_weight, -sig)
                data["characters"] = sorted(chars, key=_rank)
                return data
            return None
        except Exception as e:
            mexflow.progress.error("Story Analysis", f"Failed: {str(e)}")
            return None


    # ─────────────────────────────────────────────────────────────────────
    # STAGE 3 — VISUAL DNA GENERATION (NEW in v3.0)
    # ─────────────────────────────────────────────────────────────────────
    async def _generate_visual_dna(
        self, story: str, analysis: Dict[str, Any], visual_style: str,
        render_medium_preset: Optional[str], locked_tone: str
    ) -> Optional[Dict[str, Any]]:

        preset_instruction = ""
        if render_medium_preset:
            preset_instruction = (
                f"\nUSER HAS PRE-SELECTED THIS RENDERING MEDIUM. You MUST use it verbatim as the "
                f"canonical medium_dna_block:\n\n\"\"\"\n{render_medium_preset}\n\"\"\"\n\n"
                f"Your job is only to set medium_name and supporting fields. Do NOT rewrite the block."
            )

        prompt = f"""{SYSTEM_PROMPT_VISUAL_DNA}

Author the VISUAL DNA for this production.
{preset_instruction}

STORY SUMMARY: {analysis.get('story_summary', '')}
GENRE / TONE: {locked_tone}
MOOD: {analysis.get('mood', '')}
SETTING: {analysis.get('setting', '')}
VISUAL STYLE MOOD (lighting/color atmosphere): {visual_style}

Return this JSON:

{{
    "medium_name": "short name of the chosen medium (e.g. 'Pixar 3D Animation', 'Photoreal Cinema', 'Shinkai Anime', 'Western 2D Cartoon', 'Claymation Stop-Motion')",
    "medium_dna_block": "THE CANONICAL VISUAL DNA TEXT BLOCK — 90-180 words. This exact text will be PASTED VERBATIM into every character portrait AND every scene image prompt in the production. Must specify: rendering approach (live-action photo capture / 3D CG render / 2D cel animation / stop-motion / etc.), material fidelity level, character proportion logic, edge/line treatment, level of detail, explicit negatives listing what this medium is NOT (NO cartoon / NO anime / NO photorealism — whichever does not apply). Start with the exact phrase 'RENDERING MEDIUM:'.",
    "medium_rationale": "1 sentence on why this medium suits the story",
    "shared_aesthetic_tokens": ["5-8 short phrases that will appear in every scene — e.g. 'warm saturated palette', 'soft wrap-around key light', 'stylized appealing shapes', 'clean CG render', 'shallow cinematic DoF'"],
    "consistency_negatives": ["explicit things to NEVER do — e.g. 'NO photorealistic human skin', 'NO anime cel outlines', 'NO flat 2D shading']
}}

ABSOLUTE REQUIREMENTS:
- medium_dna_block must begin with 'RENDERING MEDIUM:' and be 90-180 words.
- medium_dna_block must include explicit negatives (what the medium is NOT).
- Pick a medium that SERVES THE STORY — a village comedy does NOT need photoreal ARRI Alexa; it would feel bizarre. A warm 3D stylized animation (Pixar/DreamWorks) or a 2D cartoon serves comedy far better. A slow horror needs photoreal or ultra-realistic 3D for dread.
- Guideline picks:
  • comedy → '3D Pixar/DreamWorks stylized animation' OR 'Western 2D cartoon' OR 'claymation'
  • horror → 'photoreal cinema' OR 'ultra-realistic 3D'
  • thriller → 'photoreal cinema'
  • drama → 'photoreal cinema' OR 'grounded 3D CG'
  • romance → 'photoreal cinema' OR 'Shinkai anime'
  • epic → 'photoreal cinema' OR 'cinematic 3D'
  • action → 'photoreal cinema' OR 'comic book illustration'"""

        try:
            response = await mexflow.ai.generate(prompt, max_tokens=2500)
            data = mexflow.ai.parse_json(response)

            if isinstance(data, dict) and "medium_dna_block" in data:
                # If user pre-specified a preset, force it
                if render_medium_preset:
                    data["medium_dna_block"] = render_medium_preset
                return data
            return None
        except Exception as e:
            mexflow.progress.error("Visual DNA", f"Failed: {str(e)}")
            return None


    def _fallback_visual_dna(self, locked_tone: str, render_medium_preset: Optional[str]) -> Dict[str, Any]:
        if render_medium_preset:
            return {
                "medium_name": "Custom",
                "medium_dna_block": render_medium_preset,
                "medium_rationale": "User-specified rendering medium",
                "shared_aesthetic_tokens": ["cinematic composition", "consistent medium throughout"],
                "consistency_negatives": []
            }
        default_map = {
            "comedy": ("pixar_3d_animation", "Pixar 3D Animation"),
            "horror": ("photoreal_cinema", "Photoreal Cinema"),
            "thriller": ("photoreal_cinema", "Photoreal Cinema"),
            "drama": ("photoreal_cinema", "Photoreal Cinema"),
            "romance": ("photoreal_cinema", "Photoreal Cinema"),
            "epic": ("photoreal_cinema", "Photoreal Cinema"),
            "action": ("photoreal_cinema", "Photoreal Cinema"),
        }
        key, name = default_map.get(locked_tone, ("photoreal_cinema", "Photoreal Cinema"))
        return {
            "medium_name": name,
            "medium_dna_block": VISUAL_DNA_PRESETS[key],
            "medium_rationale": f"Fallback default for {locked_tone}",
            "shared_aesthetic_tokens": ["consistent medium", "cinematic composition"],
            "consistency_negatives": []
        }


    # ─────────────────────────────────────────────────────────────────────
    # NEW STAGE (v3.2) — BEAT SHEET DECOMPOSITION
    # The single most important upgrade for proper scene breakdown.
    # ─────────────────────────────────────────────────────────────────────
    async def _generate_beat_sheet(
        self, story: str, analysis: Dict[str, Any], allowed_durations: List[int],
        max_duration, locked_tone: str
    ) -> Optional[Dict[str, Any]]:
        """
        Decompose the story into atomic narrative beats. Each beat will become
        one scene downstream (with rare adjacent merges allowed).
        """
        max_dur_str = (
            f"{max_duration} seconds (hard limit)" if max_duration != "AUTO"
            else "AUTO — sum of beat durations is the total"
        )

        # Tone-specific beat-density guidance
        tone_density = {
            "comedy": (
                "COMEDY DENSITY GUIDANCE: Comedy needs MANY beats. Setup-payoff "
                "rhythm requires every joke to have its own setup beat AND its own "
                "punchline beat AND its own reaction beat. A 280-word comedy story "
                "should produce 15-22 beats minimum. NEVER fewer. The user's worst "
                "complaint about a comedy edit is 'jokes don't land' — and jokes "
                "don't land when you compress beats. ERR ON THE SIDE OF MORE BEATS."
            ),
            "drama": (
                "DRAMA DENSITY GUIDANCE: Drama beats can be slightly longer and "
                "more emotional, but every emotional shift, every line of dialogue, "
                "every reaction shot still earns its own beat. A 280-word drama "
                "should produce 12-18 beats."
            ),
            "horror": (
                "HORROR DENSITY GUIDANCE: Horror uses tension-build sequences "
                "(slow push-ins, held silences) that may span multiple beats. "
                "Still extract every reveal, every reaction, every scare moment "
                "as a separate beat. A 280-word horror should produce 12-18 beats."
            ),
            "thriller": (
                "THRILLER DENSITY GUIDANCE: Thriller uses rapid cross-cutting. "
                "More beats than drama. Every plot move, every clue, every "
                "decision earns a beat. 280-word thriller → 14-20 beats."
            ),
            "epic": (
                "EPIC DENSITY GUIDANCE: Epic alternates wide establishers with "
                "intimate hero moments. 280-word epic → 12-18 beats."
            ),
            "romance": (
                "ROMANCE DENSITY GUIDANCE: Romance lives in glances, micro-"
                "expressions, near-touches. Each of these is a beat. 280-word "
                "romance → 14-20 beats."
            ),
            "action": (
                "ACTION DENSITY GUIDANCE: Action uses rapid cutting between "
                "moves, reactions, impacts. Highest beat density of any genre. "
                "280-word action → 18-25 beats."
            ),
        }
        density_guidance = tone_density.get(locked_tone, tone_density["drama"])

        # Build location reference
        locs = analysis.get("locations", [])
        loc_names = [l.get("name", "Location") for l in locs]
        char_names = [c.get("name", "Unknown") for c in analysis.get("characters", [])]

        word_count = len(story.split())

        prompt = f"""{SYSTEM_PROMPT_BEAT_SHEET}

═══════════════════════════════════════════════════════════════════════════
THE STORY (read every sentence — every sentence has at least one beat):
═══════════════════════════════════════════════════════════════════════════
\"\"\"
{story}
\"\"\"

Story word count: {word_count}
Locked tone: {locked_tone}
Available characters: {char_names}
Available locations: {loc_names}

Genre/sub-genre context: {analysis.get('genre', '')} / {analysis.get('sub_genre', '')}
Mood: {analysis.get('mood', '')}
Mood arc: {analysis.get('mood_arc', '')}

═══════════════════════════════════════════════════════════════════════════
{density_guidance}
═══════════════════════════════════════════════════════════════════════════

ALLOWED BEAT DURATIONS (each beat is assigned EXACTLY one): {allowed_durations}
MAXIMUM TOTAL: {max_dur_str}

If the natural beat count × shortest_allowed_duration exceeds the maximum
total, prefer SHORTER durations across all beats. NEVER drop a beat to
fit a duration cap.

═══════════════════════════════════════════════════════════════════════════
RETURN THIS JSON
═══════════════════════════════════════════════════════════════════════════

{{
    "beats": [
        {{
            "beat_id": "B01",
            "sequence": 1,
            "description": "Concise description of what physically happens in this beat — focus on the visible action, dialogue line, or moment. 1-2 sentences max.",
            "type": "establishing | introduction | inciting | setup | action | reaction | dialogue | punchline | realization | twist | tag",
            "characters_involved": ["Name1", "Name2"],
            "location_ref": "Exact name from available locations list",
            "estimated_seconds": 5,
            "emotional_function": "what this beat does for the audience (e.g. 'introduces Rafiq's tech-incompetence', 'lands the bill-payment punchline', 'reveals Munni was lying')",
            "dialogue_line": "Exact line of dialogue if any, or null",
            "is_punchline": false,
            "is_payoff_for_setup": null,
            "story_text_anchor": "Quote 1-12 words from the original story that this beat covers — proves you didn't skip anything"
        }}
    ],
    "beat_sheet_summary": {{
        "total_beats": 18,
        "total_estimated_seconds": 102,
        "duration_distribution": {{"5": 10, "6": 5, "8": 3}},
        "beats_per_act": {{"act_1": 6, "act_2": 8, "act_3": 4}},
        "coverage_check": "1-sentence statement confirming you covered every sentence of the source story"
    }}
}}

═══════════════════════════════════════════════════════════════════════════
SELF-CHECK BEFORE RETURNING — RE-READ THE STORY
═══════════════════════════════════════════════════════════════════════════
☐ Did I extract a beat for EVERY character introduction? (cast = N → at least N intro beats)
☐ Did I extract a SEPARATE beat for every line of dialogue?
☐ Did I extract a SEPARATE beat for every visual gag/punchline?
☐ Did I extract a SEPARATE beat for every reaction to a major event?
☐ Are setup beats and their payoff beats SEPARATE (never merged)?
☐ Is my total_beats >= the minimum for this story length?
   ({word_count} words → minimum {max(8, word_count // 25)} beats)
☐ Does every beat's `story_text_anchor` quote a real fragment of the source story?
☐ Is the beat order strictly sequential and matches the story's narrative order?

If any check fails — go back and add the missing beats. DO NOT return an undercounted beat sheet."""

        try:
            response = await mexflow.ai.generate(prompt, max_tokens=10000)
            data = mexflow.ai.parse_json(response)

            if isinstance(data, dict) and "beats" in data and isinstance(data["beats"], list):
                # Sanity floor: if word count > 100 and beats < 8, accept anyway
                # but log loudly. We don't want to fail the run.
                num_beats = len(data["beats"])
                expected_floor = max(8, word_count // 25)
                if num_beats < expected_floor:
                    print(
                        f"[BEAT SHEET] WARNING: AI returned {num_beats} beats for "
                        f"{word_count}-word story (expected floor: {expected_floor}). "
                        f"Continuing but downstream scenes may be undercounted."
                    )
                # Renumber sequence to be safe
                for i, b in enumerate(data["beats"]):
                    b["sequence"] = i + 1
                    if "beat_id" not in b or not b["beat_id"]:
                        b["beat_id"] = f"B{i+1:02d}"
                return data
            if isinstance(data, list):
                return {"beats": data, "beat_sheet_summary": {"total_beats": len(data)}}
            return None
        except Exception as e:
            mexflow.progress.error("Beat Sheet", f"Failed: {str(e)}")
            return None


    def _fallback_beat_sheet(self, analysis: Dict[str, Any], allowed_durations: List[int]) -> Dict[str, Any]:
        """Minimal fallback if AI call fails — derives beats from key_moments."""
        moments = analysis.get("key_moments", [])
        if not moments:
            return {"beats": [], "beat_sheet_summary": {"total_beats": 0}}
        smallest_dur = min(allowed_durations) if allowed_durations else 5
        beats = []
        for i, m in enumerate(moments):
            dur = m.get("suggested_duration", smallest_dur)
            if dur not in allowed_durations and allowed_durations:
                dur = smallest_dur
            beats.append({
                "beat_id": f"B{i+1:02d}",
                "sequence": i + 1,
                "description": m.get("moment", ""),
                "type": "action",
                "characters_involved": [],
                "location_ref": m.get("location_ref", "Primary Location"),
                "estimated_seconds": dur,
                "emotional_function": m.get("emotional_beat", ""),
                "dialogue_line": None,
                "is_punchline": False,
                "is_payoff_for_setup": None,
                "story_text_anchor": ""
            })
        return {
            "beats": beats,
            "beat_sheet_summary": {
                "total_beats": len(beats),
                "coverage_check": "Fallback from key_moments — may be undercounted."
            }
        }


    # ─────────────────────────────────────────────────────────────────────
    # STAGE 4 — LOCATION BIBLE
    # ─────────────────────────────────────────────────────────────────────
    async def _generate_location_bible(
        self, story: str, analysis: Dict[str, Any], visual_style: str,
        visual_dna: Dict[str, Any], locked_tone: str
    ) -> Optional[Dict[str, Any]]:

        locations_list = analysis.get("locations", [])
        if not locations_list:
            return {"locations": []}

        locations_seed = "\n".join([
            f"- {loc.get('name', 'Location')}: {loc.get('brief', '')} "
            f"(default time of day: {loc.get('time_of_day_default', 'day')})"
            for loc in locations_list
        ])

        tone_contract = self._get_tone_contract(locked_tone)

        prompt = f"""{SYSTEM_PROMPT_LOCATIONS}

Build the Location Bible.

STORY:
\"\"\"
{story}
\"\"\"

CONTEXT:
- Genre / Locked Tone: {locked_tone}
- Mood: {analysis.get('mood', '')}
- Setting: {analysis.get('setting', '')}
- Time Period: {analysis.get('time_period', '')}
- Visual Style Mood: {visual_style}

VISUAL DNA (the rendering medium you MUST describe each location in):
\"\"\"
{visual_dna.get('medium_dna_block', '')}
\"\"\"

TONE CONTRACT LIGHTING RULES (apply to every location's lighting_signature):
REQUIRED: {tone_contract.get('required_lighting', '')}
FORBIDDEN: {tone_contract.get('forbidden_lighting', '')}

TONE CONTRACT COLOR RULES (apply to every location's palette):
{tone_contract.get('emotional_color', '')}

LOCATIONS TO BUILD:
{locations_seed}

Return JSON:

{{
    "locations": [
        {{
            "name": "Exact name from list",
            "canonical_description": "120-200 words, DENSE, describing the location THROUGH the visual DNA — architecture, palette (matching tone color rules), fixed furniture + placement, 5-8 dressing objects with positions, lighting signature (obeying tone lighting rules — a comedy never gets horror-pool lighting here), atmospheric texture, time-of-day default, staging notes. Every location must read in the same rendering medium as every other.",
            "lighting_signature": "1-2 sentence summary of key lights + color temp + quality, obeying tone contract",
            "color_palette": ["specific-color-1", "specific-color-2", "specific-color-3"],
            "signature_props": ["prop1 at position1", "prop2 at position2"],
            "ambient_sound_bed": "baseline sound at this location (used for scene audio AMBIENT)"
        }}
    ]
}}

ABSOLUTE:
- 120-200 words per canonical_description.
- Written from WITHIN the visual DNA (don't describe a 3D Pixar location with photoreal vocabulary and vice versa).
- Lighting must obey the tone contract — comedy gets bright warm readable light, horror gets pools of motivated dread, etc.
- Be ruthlessly specific."""

        try:
            response = await mexflow.ai.generate(prompt, max_tokens=6000)
            data = mexflow.ai.parse_json(response)
            if isinstance(data, dict) and "locations" in data:
                return data
            if isinstance(data, list):
                return {"locations": data}
            return None
        except Exception as e:
            mexflow.progress.error("Location Bible", f"Failed: {str(e)}")
            return None


    def _fallback_location_bible(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        locs = analysis.get("locations", [])
        if not locs:
            return {"locations": [{
                "name": "Primary Location",
                "canonical_description": analysis.get("setting", "A location appropriate to the story."),
                "lighting_signature": "Natural motivated light.",
                "color_palette": ["neutral"],
                "signature_props": [],
                "ambient_sound_bed": "Ambient environmental sound."
            }]}
        out = []
        for loc in locs:
            out.append({
                "name": loc.get("name", "Location"),
                "canonical_description": loc.get("brief", "") or analysis.get("setting", ""),
                "lighting_signature": "Natural motivated light.",
                "color_palette": ["neutral"],
                "signature_props": [],
                "ambient_sound_bed": "Ambient environmental sound."
            })
        return {"locations": out}


    # ─────────────────────────────────────────────────────────────────────
    # STAGE 5 — CHARACTER PORTRAITS with Visual DNA embedded
    # ─────────────────────────────────────────────────────────────────────
    async def _generate_characters(
        self, story: str, analysis: Dict[str, Any], bg_color: str,
        visual_style: str, portrait_mode: str, visual_dna: Dict[str, Any],
        locked_tone: str
    ) -> Optional[Dict[str, Any]]:

        characters_from_analysis = analysis.get("characters", [])
        char_list_str = "\n".join([
            f"- {c.get('name', 'Unknown')}: {c.get('role', '')} — {c.get('description', '')}, "
            f"Age: {c.get('age_estimate', 'unknown')}"
            for c in characters_from_analysis
        ])

        if portrait_mode == "4panel":
            portrait_format = f"""FORMAT: 4-PANEL CHARACTER REFERENCE SHEET at 16:9

Each image_prompt MUST follow this STRICT STRUCTURE (all blocks mandatory):
"{CHARACTER_ASPECT_LOCK}

[VISUAL DNA BLOCK VERBATIM]

4-panel character reference sheet of [FULL CHARACTER DESCRIPTION, tone-appropriate archetype], laid out horizontally across the 16:9 frame. Top-left panel: full-body front view. Top-right panel: left side profile. Bottom-left panel: right side profile. Bottom-right panel: back view. [ALL physical details head to toe — face bone structure, eyes (color + shape), skin/fur texture, hair (color + length + style), clothing head-to-toe, distinctive features, props held]. Hyper-sharp 8K detail, cinematic dramatic studio lighting, rim light edge separation, every detail visible. Solid flat {bg_color} chroma-key background. No gradients, no shadows on background.

{CHARACTER_ASPECT_REINFORCE}" """
        else:
            portrait_format = f"""FORMAT: SINGLE FULL-BODY FRONT-FACING PORTRAIT at 16:9

Each image_prompt MUST follow this STRICT STRUCTURE (all blocks mandatory):
"{CHARACTER_ASPECT_LOCK}

[VISUAL DNA BLOCK VERBATIM]

Full-body front-facing portrait of [FULL CHARACTER DESCRIPTION, tone-appropriate archetype]. Centered in the 16:9 horizontal frame with balanced equal negative space on the left and right, standing upright, neutral confident stance. [ALL physical details head to toe — face bone structure, eyes (color + shape), skin/fur texture, hair (color + length + style), clothing head-to-toe, distinctive features, props held]. Hyper-sharp 8K detail, cinematic dramatic studio lighting, rim light for clean edge separation. Solid flat {bg_color} chroma-key background. No gradients, no shadows.

{CHARACTER_ASPECT_REINFORCE}" """

        tone_archetype_guidance = {
            "comedy": "Comedy characters — slightly exaggerated appealing features, expressive faces, readable silhouettes, gently caricatured. Not glamorous — relatable everyday people with a touch of cartoon charm.",
            "horror": "Horror characters — can have unsettling features, hollow eyes, sickly pallor for ghosts/monsters. Protagonists should feel real and vulnerable.",
            "thriller": "Thriller characters — grounded realistic, stressed expressions, practical wardrobes, urban textures.",
            "epic": "Epic characters — heroic proportions, detailed costumes/armor, commanding presence.",
            "drama": "Drama characters — realistic natural features, lived-in wardrobes, authentic human detail.",
            "romance": "Romance characters — attractive but grounded, warm expressive eyes, flattering natural styling.",
            "action": "Action characters — fit athletic builds, practical gear, determined expressions."
        }

        prompt = f"""{SYSTEM_PROMPT_CHARACTERS}

Create FULL-BODY portrait prompts.

STORY CONTEXT:
{analysis.get('story_summary', '')}
Genre / Locked Tone: {locked_tone}
Sub-genre: {analysis.get('sub_genre', '')}
Setting: {analysis.get('setting', '')}
Time Period: {analysis.get('time_period', '')}
Visual Style Mood: {visual_style}

TONE-APPROPRIATE ARCHETYPE GUIDANCE: {tone_archetype_guidance.get(locked_tone, tone_archetype_guidance['drama'])}

═══════════════════════════════════════════════════════════════════════════
CHARACTER ASPECT RATIO LOCK (paste VERBATIM at the TOP of every image_prompt):
═══════════════════════════════════════════════════════════════════════════
\"\"\"
{CHARACTER_ASPECT_LOCK}
\"\"\"

CHARACTER ASPECT RATIO REINFORCE (paste VERBATIM at the BOTTOM of every image_prompt):
\"\"\"
{CHARACTER_ASPECT_REINFORCE}
\"\"\"

═══════════════════════════════════════════════════════════════════════════
VISUAL DNA BLOCK (paste VERBATIM directly after the aspect lock):
═══════════════════════════════════════════════════════════════════════════
\"\"\"
{visual_dna.get('medium_dna_block', '')}
\"\"\"

CHARACTERS TO DESIGN (KEEP THIS EXACT ORDER — locks reference index):
{char_list_str}

BACKGROUND COLOR: {bg_color} (solid flat chroma-key, NO gradients)

{portrait_format}

Return JSON (preserve character order EXACTLY):

{{
    "characters": [
        {{
            "name": "Character Name",
            "role": "protagonist/antagonist/supporting/minor",
            "age": "estimated age",
            "build": "body type",
            "one_line_identifier": "5-10 word disambiguation tag (e.g. 'balding 50s man, striped kurta, worried eyes')",
            "image_prompt": "FULL PROMPT in this exact structure:\\n\\n[1] CHARACTER ASPECT RATIO LOCK pasted verbatim.\\n\\n[2] VISUAL DNA BLOCK pasted verbatim.\\n\\n[3] Character portrait description following the FORMAT structure above — 120-200 words describing the character in exhaustive detail.\\n\\n[4] CHARACTER ASPECT RATIO REINFORCE tag pasted verbatim at the end.\\n\\nTotal length: 280-420 words including the verbatim blocks. Must include cinematic studio lighting and solid {bg_color} chroma-key background."
        }}
    ]
}}

ABSOLUTE:
- CHARACTER ASPECT RATIO LOCK pasted VERBATIM at the TOP of every image_prompt.
- CHARACTER ASPECT RATIO REINFORCE pasted VERBATIM at the BOTTOM.
- VISUAL DNA BLOCK pasted VERBATIM directly after the aspect lock.
- 16:9 is non-negotiable for character portraits — do NOT change it, do NOT use --ar 9:16 or --ar 1:1 here.
- Preserve character order — locks reference index.
- FULL-BODY always, head-to-toe visible.
- Tone-appropriate archetype — comedy characters look like comedic everyday people, not warriors.
- Solid {bg_color} chroma-key end tag on every portrait."""

        try:
            response = await mexflow.ai.generate(prompt, max_tokens=10000)
            data = mexflow.ai.parse_json(response)
            if isinstance(data, dict) and "characters" in data:
                return data
            if isinstance(data, list):
                return {"characters": data}
            return None
        except Exception as e:
            mexflow.progress.error("Character Design", f"Failed: {str(e)}")
            return None


    def _sort_characters_by_significance(
        self, portraits: List[Dict[str, Any]], analysis_chars: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        if not portraits:
            return []
        if not analysis_chars:
            return portraits
        order_map = {c.get("name", "").strip().lower(): i for i, c in enumerate(analysis_chars)}
        def _key(p):
            n = p.get("name", "").strip().lower()
            return order_map.get(n, 10_000)
        return sorted(portraits, key=_key)


    def _enforce_dna_in_portraits(
        self, portraits: List[Dict[str, Any]], visual_dna: Dict[str, Any], bg_color: str
    ) -> List[Dict[str, Any]]:
        """
        Guarantee every portrait prompt has — in order, at the top:
          1. The CHARACTER_ASPECT_LOCK (16:9) block.
          2. The VISUAL DNA block.
        And at the bottom:
          3. The CHARACTER_ASPECT_REINFORCE tag (e.g. --ar 16:9).

        This is defensive — if the LLM forgot any of these, we inject them
        so the downstream image generator always sees a consistent contract.
        """
        dna_block = (visual_dna.get("medium_dna_block", "") or "").strip()
        dna_probe = dna_block[:60].lower() if dna_block else ""

        aspect_lock = CHARACTER_ASPECT_LOCK.strip()
        aspect_probe = aspect_lock[:60].lower()

        reinforce = CHARACTER_ASPECT_REINFORCE.strip()
        reinforce_probe = reinforce[:40].lower()

        for p in portraits:
            prompt = (p.get("image_prompt", "") or "").strip()
            if not prompt:
                continue

            prompt_lower = prompt.lower()

            # ── 1. Inject CHARACTER_ASPECT_LOCK at the top if missing ──
            has_aspect = aspect_probe in prompt_lower
            has_dna = dna_probe and dna_probe in prompt_lower

            if not has_aspect:
                # Aspect lock MUST be at the very top
                if has_dna:
                    # DNA is present but aspect isn't — put aspect BEFORE DNA
                    dna_start = prompt_lower.find(dna_probe)
                    if dna_start >= 0:
                        prompt = (
                            aspect_lock + "\n\n"
                            + prompt[:dna_start].rstrip()
                            + ("\n\n" if prompt[:dna_start].strip() else "")
                            + prompt[dna_start:]
                        )
                    else:
                        prompt = aspect_lock + "\n\n" + prompt
                else:
                    prompt = aspect_lock + "\n\n" + prompt
                prompt_lower = prompt.lower()

            # ── 2. Inject DNA block directly after aspect lock if missing ──
            if dna_block and dna_probe not in prompt_lower:
                # Find where aspect lock ends, insert DNA after it
                aspect_start = prompt_lower.find(aspect_probe)
                if aspect_start >= 0:
                    aspect_end = aspect_start + len(aspect_lock)
                    # Find the next blank line after aspect_end
                    insertion_point = aspect_end
                    prompt = (
                        prompt[:insertion_point].rstrip()
                        + "\n\n" + dna_block + "\n\n"
                        + prompt[insertion_point:].lstrip()
                    )
                else:
                    prompt = prompt + "\n\n" + dna_block
                prompt_lower = prompt.lower()

            # ── 3. Append REINFORCE tag at bottom if missing ──
            if reinforce_probe not in prompt_lower:
                prompt = prompt.rstrip() + "\n\n" + reinforce

            p["image_prompt"] = prompt

        return portraits


    # ─────────────────────────────────────────────────────────────────────
    # STAGE 7 — SCENE GENERATION (v3.2: now driven by the beat sheet)
    # tone lock + continuity chain + DNA + orientation + beat coverage
    # ─────────────────────────────────────────────────────────────────────
    async def _generate_scenes(
        self, story: str, analysis: Dict[str, Any],
        location_bible: Dict[str, Any], characters_data: Dict[str, Any],
        allowed_durations: List[int], max_duration, visual_style: str,
        visual_dna: Dict[str, Any], locked_tone: str, prompt_language: str,
        orientation_preset: Dict[str, str], beat_sheet: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:

        global_chars = characters_data.get("characters", [])
        char_order_block = "\n".join([
            f"  [Global Index {i+1}] {c.get('name', 'Unknown')} — "
            f"{c.get('one_line_identifier', c.get('role', ''))}"
            for i, c in enumerate(global_chars)
        ])
        char_ref_block = "\n".join([
            f"CHARACTER [{i+1}] — {c.get('name', 'Unknown')} ({c.get('role', '')}):\n"
            f"  ONE-LINE: {c.get('one_line_identifier', '')}\n"
            f"  PORTRAIT: {c.get('image_prompt', c.get('description', ''))[:500]}..."
            for i, c in enumerate(global_chars)
        ])

        locations = location_bible.get("locations", [])
        location_bible_block = "\n\n".join([
            f"LOCATION: {loc.get('name', 'Location')}\n"
            f"CANONICAL_DESCRIPTION (paste VERBATIM in every scene set here):\n"
            f"\"\"\"\n{loc.get('canonical_description', '')}\n\"\"\"\n"
            f"LIGHTING: {loc.get('lighting_signature', '')}\n"
            f"PALETTE: {', '.join(loc.get('color_palette', []))}\n"
            f"AMBIENT SOUND: {loc.get('ambient_sound_bed', '')}"
            for loc in locations
        ])

        # Tone contract block
        contract = self._get_tone_contract(locked_tone)
        tone_contract_block = f"""TONE CONTRACT FOR **{locked_tone.upper()}** — ENFORCE EVERY ITEM:

PACING: {contract.get('pacing', '')}

REQUIRED CAMERA: {contract.get('required_camera', '')}
FORBIDDEN CAMERA: {contract.get('forbidden_camera', '')}

REQUIRED LIGHTING: {contract.get('required_lighting', '')}
FORBIDDEN LIGHTING: {contract.get('forbidden_lighting', '')}

REQUIRED AUDIO: {contract.get('required_audio', '')}
FORBIDDEN AUDIO: {contract.get('forbidden_audio', '')}

SCENE BEAT STYLE: {contract.get('scene_beat_style', '')}

EMOTIONAL COLOR: {contract.get('emotional_color', '')}"""

        audio_strat = analysis.get("audio_strategy", {})
        audio_preset = self._get_audio_preset(locked_tone)

        audio_block = f"""GLOBAL AUDIO STRATEGY (applies to every scene — stays inside tone contract):
BGM Style: {audio_strat.get('bgm_style', '')}
Tempo: {audio_strat.get('tempo_bpm_range', '80-100')} BPM
Instruments: {', '.join(audio_strat.get('instrument_palette', []))}
Signature SFX: {', '.join(audio_strat.get('signature_sfx', []))}
Mood Arc: {audio_strat.get('mood_arc_beats', '')}
Dialogue Style: {audio_strat.get('dialogue_style', 'natural')}

TONE PRESET (reinforce in every scene):
{audio_preset}"""

        moments_ref = "\n".join([
            f"  Moment {i+1} (Act {m.get('act', '?')}, ~{m.get('suggested_duration', 5)}s, "
            f"Location: {m.get('location_ref', 'Primary')}): {m.get('moment', '')} "
            f"[{m.get('emotional_beat', '')}]"
            for i, m in enumerate(analysis.get("key_moments", []))
        ])

        # ── Beat sheet block — v3.2 (THE headline upgrade) ──
        # The scene generator MUST produce one scene per beat (rare merges allowed).
        beats_list = beat_sheet.get("beats", []) if beat_sheet else []
        beat_sheet_block_lines = []
        for b in beats_list:
            line = (
                f"  [{b.get('beat_id', '?')}] (seq {b.get('sequence', '?')}, "
                f"~{b.get('estimated_seconds', 5)}s, type={b.get('type', '?')}, "
                f"location={b.get('location_ref', '?')}, "
                f"chars={b.get('characters_involved', [])}): "
                f"{b.get('description', '')}"
            )
            if b.get("dialogue_line"):
                line += f"  DIALOGUE: \"{b.get('dialogue_line')}\""
            if b.get("is_punchline"):
                line += "  ⚠ PUNCHLINE — never compress this beat"
            beat_sheet_block_lines.append(line)
        beat_sheet_block = "\n".join(beat_sheet_block_lines) if beat_sheet_block_lines else "(no beats — falling back to key_moments)"
        num_beats_total = len(beats_list)
        min_scenes = max(1, int(num_beats_total * 0.85))
        max_scenes = num_beats_total

        max_dur_str = f"{max_duration}" if max_duration != "AUTO" else "AUTO"

        lang_instruction = ""
        if prompt_language != "english":
            lang_instruction = (
                f"\n\nLANGUAGE: 'description' field and any character-spoken dialogue lines "
                f"inside scene_prompt AUDIO DESIGN should be in {prompt_language} (native script). "
                f"ALL direction/technical language (image_prompt, scene_prompt structure) stays in English."
            )

        location_names = [l.get("name", "") for l in locations]

        # ── Orientation block — v3.1 ──
        aspect_lock_text = orientation_preset.get("aspect_lock", "")
        aspect_reinforce_text = orientation_preset.get("reinforce", "")
        aspect_framing_guidance = orientation_preset.get("framing_guidance", "")
        aspect_spatial_vocab = orientation_preset.get("spatial_vocabulary", "")
        aspect_label = orientation_preset.get("label", "")
        aspect_canvas = orientation_preset.get("canvas", "")

        orientation_block = f"""ASPECT RATIO / ORIENTATION LOCK FOR EVERY SCENE IMAGE — {aspect_label} ({aspect_canvas}):

ASPECT RATIO LOCK BLOCK (paste VERBATIM at the TOP of every scene image_prompt, BEFORE the REFERENCE MAP):
\"\"\"
{aspect_lock_text}
\"\"\"

ASPECT RATIO REINFORCE TAG (paste VERBATIM at the BOTTOM of every scene image_prompt, after the QUALITY TAGS):
\"\"\"
{aspect_reinforce_text}
\"\"\"

ORIENTATION-AWARE FRAMING GUIDANCE (obey this when choosing shot sizes, angles, and compositions):
{aspect_framing_guidance}

ORIENTATION-AWARE SPATIAL VOCABULARY (use this language when describing SPATIAL LAYOUT):
{aspect_spatial_vocab}

CRITICAL: Every SHOT CHOICE in every scene image_prompt must be COMPOSED FOR this orientation — not cropped to it. A wide side-by-side two-shot does not work in 9:16 vertical; use stacked framing or tight single-character CUs instead. An extreme tall close-up does not work in 21:9 ultrawide; use horizontal spread instead. If the chosen orientation is 9:16 vertical, the SPATIAL LAYOUT block must use vertical vocabulary (top/middle/bottom third). If it is 16:9, horizontal (left/center/right third). If it is 1:1, quadrants and center."""

        # ═══════════════════════════════════════════════════════════════════
        # v3.3 BATCHED SCENE GENERATION — fixes truncation bug
        # ═══════════════════════════════════════════════════════════════════
        # Each scene's image_prompt + scene_prompt is ~5-8 KB. The LLM has a
        # ~64K token (~250 KB char) output ceiling. So we can fit AT MOST
        # ~30-40 full scenes per call, and even that risks truncation. For
        # any beat sheet of 8+ beats, we MUST batch.
        #
        # We split beats into chunks of BATCH_SIZE and call the LLM once per
        # chunk. Each batch only needs to output ~6 scenes (~30-50 KB), which
        # fits comfortably. The last scene of each completed batch is passed
        # to the next batch as a continuity anchor.

        BATCH_SIZE = 6  # beats per LLM call

        # Bundle all the shared context into one dict — never rebuilt per batch
        shared_ctx = {
            "story": story,
            "analysis": analysis,
            "locked_tone": locked_tone,
            "visual_style": visual_style,
            "char_order_block": char_order_block,
            "char_ref_block": char_ref_block,
            "location_bible_block": location_bible_block,
            "location_names": location_names,
            "tone_contract_block": tone_contract_block,
            "audio_block": audio_block,
            "moments_ref": moments_ref,
            "orientation_block": orientation_block,
            "visual_dna_text": visual_dna.get("medium_dna_block", ""),
            "visual_dna_name": visual_dna.get("medium_name", ""),
            "shared_aesthetic_tokens": ", ".join(visual_dna.get("shared_aesthetic_tokens", [])),
            "consistency_negatives": ", ".join(visual_dna.get("consistency_negatives", [])),
            "allowed_durations": allowed_durations,
            "max_dur_str": max_dur_str,
            "lang_instruction": lang_instruction,
            "aspect_label": aspect_label,
            "aspect_canvas": aspect_canvas,
            "num_beats_total": num_beats_total,
            "min_scenes": min_scenes,
            "max_scenes": max_scenes,
        }

        # Split beats into chunks
        if not beats_list:
            mexflow.progress.error(
                "Scene Direction",
                "Cannot generate scenes — beat sheet is empty."
            )
            return None

        batches = []
        for batch_start in range(0, len(beats_list), BATCH_SIZE):
            batches.append(beats_list[batch_start:batch_start + BATCH_SIZE])

        all_scenes: List[Dict[str, Any]] = []
        last_scene_for_continuity: Optional[Dict[str, Any]] = None

        try:
            for batch_index, batch_beats in enumerate(batches):
                if mexflow.execution.is_cancelled():
                    return None

                batch_num = batch_index + 1
                expected_scene_count = len(batch_beats)

                mexflow.progress.update(
                    stage="Scene Direction",
                    stage_index=7,
                    total_stages=9,
                    current_progress=int((batch_index / max(len(batches), 1)) * 100),
                    message=(
                        f"Generating batch {batch_num}/{len(batches)} "
                        f"({expected_scene_count} scenes for beats "
                        f"{batch_beats[0].get('beat_id', '?')}–"
                        f"{batch_beats[-1].get('beat_id', '?')})..."
                    )
                )

                # Per-batch retry loop — up to 2 retries if batch undercounts
                batch_scenes: List[Dict[str, Any]] = []
                MAX_BATCH_ATTEMPTS = 3  # 1 initial + 2 retries
                for attempt in range(1, MAX_BATCH_ATTEMPTS + 1):
                    batch_result = await self._generate_scene_batch(
                        shared_ctx=shared_ctx,
                        batch_beats=batch_beats,
                        batch_index=batch_index,
                        total_batches=len(batches),
                        previous_scene_anchor=last_scene_for_continuity,
                        attempt=attempt,
                        scene_id_offset=len(all_scenes),
                    )

                    if batch_result and isinstance(batch_result, list):
                        batch_scenes = batch_result
                        if len(batch_scenes) >= expected_scene_count:
                            # Got everything we asked for — accept and move on
                            break
                        elif attempt < MAX_BATCH_ATTEMPTS:
                            # Got fewer scenes than beats — retry with a stricter reminder
                            print(
                                f"[Scene Direction] Batch {batch_num} attempt {attempt} "
                                f"returned {len(batch_scenes)}/{expected_scene_count} "
                                f"scenes. Retrying..."
                            )
                            continue
                        else:
                            # Last attempt — accept whatever we got, log warning
                            print(
                                f"[Scene Direction] ⚠ Batch {batch_num} settled at "
                                f"{len(batch_scenes)}/{expected_scene_count} scenes "
                                f"after {MAX_BATCH_ATTEMPTS} attempts."
                            )
                            break
                    elif attempt < MAX_BATCH_ATTEMPTS:
                        print(
                            f"[Scene Direction] Batch {batch_num} attempt {attempt} "
                            f"returned no parseable scenes. Retrying..."
                        )
                        continue

                if not batch_scenes:
                    print(
                        f"[Scene Direction] ⚠ Batch {batch_num} produced zero scenes "
                        f"after {MAX_BATCH_ATTEMPTS} attempts — skipping."
                    )
                    continue

                all_scenes.extend(batch_scenes)
                # The last successfully-generated scene anchors the next batch
                last_scene_for_continuity = batch_scenes[-1]

        except Exception as e:
            mexflow.progress.error("Scene Direction", f"Batched generation failed: {str(e)}")
            if not all_scenes:
                return None
            # If we got SOME scenes, return what we have rather than nothing
            print(f"[Scene Direction] Returning partial result: {len(all_scenes)} scenes")

        if not all_scenes:
            return None

        # Build aggregate production_summary based on ACTUAL data, not LLM claims
        total_dur_actual = sum(s.get("duration", 0) for s in all_scenes)
        dur_dist: Dict[int, int] = {}
        for s in all_scenes:
            d = s.get("duration", 0)
            dur_dist[d] = dur_dist.get(d, 0) + 1

        coverage_pct = (len(all_scenes) / max(num_beats_total, 1)) * 100

        return {
            "scenes": all_scenes,
            "production_summary": {
                "total_scenes": len(all_scenes),
                "total_duration": total_dur_actual,
                "duration_distribution": dur_dist,
                "total_beats": num_beats_total,
                "beat_coverage_percent": round(coverage_pct, 1),
                "batched_generation": {
                    "batch_size": BATCH_SIZE,
                    "total_batches": len(batches),
                    "scenes_per_batch_target": BATCH_SIZE,
                },
                "orientation_notes": (
                    f"All scene images locked to {aspect_label} ({aspect_canvas}). "
                    f"Character references remain 16:9."
                ),
                "continuity_chain_notes": (
                    f"Scenes batched in chunks of {BATCH_SIZE}; each batch's "
                    f"final scene was passed to the next batch as a continuity anchor."
                ),
            },
        }


    # ─────────────────────────────────────────────────────────────────────
    # v3.3 — Per-batch scene generator (called by _generate_scenes loop)
    # ─────────────────────────────────────────────────────────────────────
    async def _generate_scene_batch(
        self,
        shared_ctx: Dict[str, Any],
        batch_beats: List[Dict[str, Any]],
        batch_index: int,
        total_batches: int,
        previous_scene_anchor: Optional[Dict[str, Any]],
        attempt: int,
        scene_id_offset: int,
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Generate scenes for ONE batch of beats. Returns a list of scene dicts
        on success, or None on failure.

        scene_id_offset: how many scenes have already been generated in
        previous batches — used to assign correct sequential scene_ids.
        """
        # Build the per-batch beat list
        batch_beat_lines = []
        for b in batch_beats:
            line = (
                f"  [{b.get('beat_id', '?')}] (seq {b.get('sequence', '?')}, "
                f"~{b.get('estimated_seconds', 5)}s, type={b.get('type', '?')}, "
                f"location={b.get('location_ref', '?')}, "
                f"chars={b.get('characters_involved', [])}): "
                f"{b.get('description', '')}"
            )
            if b.get("dialogue_line"):
                line += f"  DIALOGUE: \"{b.get('dialogue_line')}\""
            if b.get("is_punchline"):
                line += "  ⚠ PUNCHLINE — never compress this beat"
            batch_beat_lines.append(line)
        batch_beats_block = "\n".join(batch_beat_lines)

        first_scene_id = scene_id_offset + 1
        last_scene_id = scene_id_offset + len(batch_beats)
        expected_count = len(batch_beats)

        # Continuity anchor block — if this is not the first batch, name the
        # exact state the previous batch's last scene ended in
        continuity_anchor_block = ""
        if previous_scene_anchor:
            prev_title = previous_scene_anchor.get("title", "")
            prev_loc = previous_scene_anchor.get("location_name", "")
            prev_chars = previous_scene_anchor.get("characters_present", [])
            prev_camera = previous_scene_anchor.get("camera_info", "")
            prev_lighting = previous_scene_anchor.get("lighting_info", "")
            prev_continuity_to_next = previous_scene_anchor.get("continuity_to_next", "")
            prev_id = previous_scene_anchor.get("scene_id", "")

            continuity_anchor_block = f"""
═══════════════════════════════════════════════════════════════════════════
CONTINUITY ANCHOR — PREVIOUS BATCH'S LAST SCENE
═══════════════════════════════════════════════════════════════════════════
The previous batch ended on scene {prev_id} ('{prev_title}'). The first
scene of THIS batch (scene {first_scene_id}) MUST flow visually from that
scene's ending state.

Previous scene's location: {prev_loc}
Previous scene's characters: {prev_chars}
Previous scene's camera: {prev_camera}
Previous scene's lighting: {prev_lighting}
Previous scene's continuity_to_next note: "{prev_continuity_to_next}"

The first scene of this batch MUST set its `continuity_from_previous` field
to a sentence that explicitly references one or more of the above details.
"""

        # Retry-attempt warning — escalate strictness on retry
        retry_warning = ""
        if attempt > 1:
            retry_warning = f"""
═══════════════════════════════════════════════════════════════════════════
⚠ RETRY ATTEMPT {attempt} — YOU PREVIOUSLY UNDERCOUNTED
═══════════════════════════════════════════════════════════════════════════
On the previous attempt, you returned fewer than {expected_count} scenes
for this batch. This is a HARD FAILURE. You MUST return EXACTLY
{expected_count} scenes — one for each beat below. No exceptions, no
"summarization", no merging beats.
"""

        # Build the per-batch prompt (much smaller than the v3.2 monolith)
        prompt = f"""{SYSTEM_PROMPT_SCENES}

═══════════════════════════════════════════════════════════════════════════
PRODUCTION PACKAGE — BATCH {batch_index + 1} of {total_batches}
═══════════════════════════════════════════════════════════════════════════

This is BATCH {batch_index + 1} of {total_batches} total batches in the
production. Earlier batches have been generated and saved. You are
responsible ONLY for generating scenes for the {expected_count} beats
listed in this batch (scenes {first_scene_id} through {last_scene_id}).

STORY (full reference, for context):
\"\"\"
{shared_ctx['story']}
\"\"\"

STORY ANALYSIS:
- LOCKED TONE: **{shared_ctx['locked_tone']}** (every scene MUST be {shared_ctx['locked_tone']})
- Sub-genre: {shared_ctx['analysis'].get('sub_genre', '')}
- Mood: {shared_ctx['analysis'].get('mood', '')}
- Mood Arc: {shared_ctx['analysis'].get('mood_arc', '')}
- Setting: {shared_ctx['analysis'].get('setting', '')}

═══════════════════════════════════════════════════════════════════════════
VISUAL DNA — PASTE VERBATIM INTO EVERY IMAGE_PROMPT
═══════════════════════════════════════════════════════════════════════════
\"\"\"
{shared_ctx['visual_dna_text']}
\"\"\"

Medium name: {shared_ctx['visual_dna_name']}
Shared aesthetic tokens: {shared_ctx['shared_aesthetic_tokens']}
NEVER do: {shared_ctx['consistency_negatives']}

═══════════════════════════════════════════════════════════════════════════
{shared_ctx['orientation_block']}
═══════════════════════════════════════════════════════════════════════════

═══════════════════════════════════════════════════════════════════════════
{shared_ctx['tone_contract_block']}
═══════════════════════════════════════════════════════════════════════════

═══════════════════════════════════════════════════════════════════════════
THIS BATCH'S BEATS — GENERATE EXACTLY ONE SCENE PER BEAT (in order)
═══════════════════════════════════════════════════════════════════════════
You MUST output EXACTLY {expected_count} scenes. Scene IDs MUST run
sequentially as PLAIN INTEGER STRINGS from "{first_scene_id}" to
"{last_scene_id}". Do NOT use dotted format like "1.{first_scene_id}".

Beats in this batch:
{batch_beats_block}
{continuity_anchor_block}{retry_warning}
═══════════════════════════════════════════════════════════════════════════
GLOBAL CHARACTER REFERENCE ORDER — LOCKED
═══════════════════════════════════════════════════════════════════════════
{shared_ctx['char_order_block']}

═══════════════════════════════════════════════════════════════════════════
CHARACTER DETAILS
═══════════════════════════════════════════════════════════════════════════
{shared_ctx['char_ref_block']}

═══════════════════════════════════════════════════════════════════════════
LOCATION BIBLE — LOCKED CANONICAL DESCRIPTIONS
═══════════════════════════════════════════════════════════════════════════
{shared_ctx['location_bible_block']}

Allowed location_name values: {shared_ctx['location_names']}

═══════════════════════════════════════════════════════════════════════════
{shared_ctx['audio_block']}
═══════════════════════════════════════════════════════════════════════════

VISUAL STYLE MOOD: {shared_ctx['visual_style']}

CONSTRAINTS:
- ALLOWED DURATIONS: {shared_ctx['allowed_durations']}
- This batch must produce EXACTLY {expected_count} scenes.
{shared_ctx['lang_instruction']}

═══════════════════════════════════════════════════════════════════════════
RETURN THIS JSON
═══════════════════════════════════════════════════════════════════════════

{{
    "scenes": [
        {{
            "scene_id": "{first_scene_id}",
            "title": "Scene Title",
            "duration": 5,
            "location_name": "Exact name from Location Bible",
            "characters_present": ["Name1 in global order"],
            "covers_beats": ["{batch_beats[0].get('beat_id', 'B?')}"],
            "description": "Brief narrative description of what happens.",
            "continuity_from_previous": "What state the previous scene left and how this scene picks up.",
            "continuity_to_next": "What state this scene leaves for the next scene.",
            "image_prompt": "320-480 words. STRICT 14-block order: aspect lock → reference map → visual DNA → location canonical → first-frame semantics → scene context → framing → spatial layout → subjects → lighting → color → atmosphere → continuity cues → quality + aspect reinforce.",
            "scene_prompt": "280-420 words. STRICT: pacing one-liner + 3 beats + audio design + genre beat + transition.",
            "camera_info": "Primary shot + lens + movement in 1 line",
            "lighting_info": "Lighting summary in 1 line",
            "audio_info": "BGM + primary SFX in 1 line",
            "transition": "cut | dissolve | fade | match_cut | whip_pan | smash_cut"
        }}
        // ... {expected_count} scenes total ...
    ]
}}

Do NOT include a `production_summary` in this batch's response — only the
scenes array. The orchestrator will build the summary from all batches.

═══════════════════════════════════════════════════════════════════════════
HARD CHECKLIST FOR THIS BATCH
═══════════════════════════════════════════════════════════════════════════
☐ Output contains EXACTLY {expected_count} scenes (not fewer, not more).
☐ Scene IDs are plain integer strings: "{first_scene_id}", "{first_scene_id + 1}", ..., "{last_scene_id}".
☐ Each scene's covers_beats references a beat_id from THIS BATCH'S beat list.
☐ Each scene's image_prompt opens with the ASPECT RATIO LOCK BLOCK verbatim.
☐ Each scene's image_prompt ends with the ASPECT RATIO REINFORCE TAG verbatim.
☐ Each scene's image_prompt contains the VISUAL DNA block verbatim.
☐ Each scene's image_prompt contains the LOCATION canonical_description verbatim.
☐ The first scene's continuity_from_previous references the previous batch's anchor (if provided).
☐ All audio uses ONLY the locked tone's required instruments/SFX — no forbidden elements.
☐ Every word earns its place."""

        try:
            # Per-batch token budget: ~10K chars/scene × 6 scenes = ~60K chars output ≈ ~16K tokens
            # We give a generous 32K-token cap to allow long image_prompts.
            response = await mexflow.ai.generate(prompt, max_tokens=32000)
            data = mexflow.ai.parse_json(response)

            scenes_out: Optional[List[Dict[str, Any]]] = None
            if isinstance(data, dict):
                if "scenes" in data and isinstance(data["scenes"], list):
                    scenes_out = data["scenes"]
            elif isinstance(data, list):
                scenes_out = data

            if scenes_out is None:
                return None

            # Reassign scene_ids to guarantee correct sequential numbering
            # (defensive — the LLM might still emit dotted format despite instructions)
            for i, scene in enumerate(scenes_out):
                scene["scene_id"] = str(scene_id_offset + i + 1)

            return scenes_out
        except Exception as e:
            print(f"[Scene Batch {batch_index + 1}/{total_batches}] Generation error: {str(e)}")
            return None


    # ─────────────────────────────────────────────────────────────────────
    # DEFENSIVE POST-PROCESSING (v3.1 — orientation-aware)
    # ─────────────────────────────────────────────────────────────────────
    def _enforce_scene_invariants(
        self,
        scenes: List[Dict[str, Any]],
        global_chars: List[Dict[str, Any]],
        locations: List[Dict[str, Any]],
        visual_dna: Dict[str, Any],
        locked_tone: str,
        orientation_preset: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """
        Guarantees — regardless of LLM output — every scene image_prompt has:
          1. ASPECT RATIO LOCK BLOCK at the very top (v3.1).
          2. REFERENCE MAP block matching characters_present in global order.
          3. VISUAL DNA block pasted verbatim.
          4. LOCATION canonical_description pasted verbatim.
          5. ASPECT RATIO REINFORCE TAG at the very bottom (v3.1).
        Also:
          6. characters_present in global order (inferred if missing).
          7. continuity_from_previous set to a sensible default if missing.
          8. locked_tone / tone fields forced onto every scene.

        Order of blocks in the final prompt (v3.1):
          [ASPECT LOCK] → [REFERENCE MAP] → [VISUAL DNA] → [LOCATION canonical]
          → [rest of LLM-authored scene content] → [... + ASPECT REINFORCE]
        """
        import re

        if not scenes:
            return scenes

        global_order = [c.get("name", "").strip() for c in global_chars if c.get("name")]
        global_by_lower = {c.get("name", "").strip().lower(): c for c in global_chars if c.get("name")}
        loc_by_name_lower = {l.get("name", "").strip().lower(): l for l in locations if l.get("name")}

        ordinals = ["1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th"]

        dna_block = (visual_dna.get("medium_dna_block", "") or "").strip()
        dna_probe = dna_block[:60].lower() if dna_block else ""

        aspect_lock = (orientation_preset.get("aspect_lock", "") or "").strip()
        aspect_probe = aspect_lock[:60].lower() if aspect_lock else ""
        reinforce = (orientation_preset.get("reinforce", "") or "").strip()
        reinforce_probe = reinforce[:40].lower() if reinforce else ""

        # Strip any LLM-written ASPECT RATIO LOCK to re-author a clean one
        # (they sometimes malform or paraphrase it).
        aspect_strip_pattern = (
            r"^\s*ASPECT\s*RATIO\s*LOCK.*?"
            r"(?=(?:\n\s*\n|\bREFERENCE\s*MAP\b|\bRENDERING MEDIUM\b|\bLOCATION\b|$))"
        )
        aspect_strip_flags = re.IGNORECASE | re.DOTALL

        ref_map_strip_pattern = (
            r"^\s*REFERENCE\s*MAP\s*:.*?"
            r"(?=(?:\n\s*\n|\bRENDERING MEDIUM\b|\bFRAMING\b|\bSHOT\b|\bLOCATION\b|"
            r"\[\s*FRAMING|\[\s*LOCATION|\[\s*SHOT|$))"
        )
        ref_map_strip_flags = re.IGNORECASE | re.DOTALL

        previous_scene = None

        for scene_idx, scene in enumerate(scenes):
            # ── 0. Normalize scene_id to plain integer string (v3.3) ──
            # Convert any "1.5", "S1.5", "scene_5", "1-5", etc. to "5".
            # The downstream pipeline expects plain sequential integers.
            raw_id = str(scene.get("scene_id", "") or "").strip()
            normalized_id = self._normalize_scene_id(raw_id, scene_idx)
            scene["scene_id"] = normalized_id

            img_prompt = (scene.get("image_prompt", "") or "").strip()
            scene_prompt = scene.get("scene_prompt", "") or ""
            desc = scene.get("description", "") or ""
            title = scene.get("title", "") or ""

            # ── 1. Characters present — infer + reorder to global order ──
            cp = scene.get("characters_present", []) or []
            cp_lower_set = {c.strip().lower() for c in cp if isinstance(c, str)}

            if not cp_lower_set and global_order:
                haystack = " ".join([desc, img_prompt, scene_prompt, title]).lower()
                for name in global_order:
                    if name and name.lower() in haystack:
                        cp_lower_set.add(name.lower())

            reordered = [name for name in global_order if name.lower() in cp_lower_set]
            scene["characters_present"] = reordered

            # ── 2. Strip LLM-authored ASPECT RATIO LOCK (we'll re-inject clean) ──
            img_prompt = re.sub(
                aspect_strip_pattern, "", img_prompt, flags=aspect_strip_flags
            ).lstrip()

            # ── 3. Strip LLM-authored REFERENCE MAP (we'll re-author it clean) ──
            img_prompt = re.sub(
                ref_map_strip_pattern, "", img_prompt, flags=ref_map_strip_flags
            ).lstrip()

            # ── 4. Build the authoritative prefix: ASPECT LOCK + REFERENCE MAP ──
            prefix_parts = []

            if aspect_lock:
                prefix_parts.append(aspect_lock)

            if reordered:
                ref_lines = []
                for idx, name in enumerate(reordered):
                    char_obj = global_by_lower.get(name.lower(), {})
                    one_line = char_obj.get("one_line_identifier") or char_obj.get("role", "") or ""
                    ord_str = ordinals[idx] if idx < len(ordinals) else f"{idx+1}th"
                    if one_line:
                        ref_lines.append(f"The {ord_str} reference character is {name} ({one_line}).")
                    else:
                        ref_lines.append(f"The {ord_str} reference character is {name}.")
                ref_map_block = "REFERENCE MAP: " + " ".join(ref_lines)
                prefix_parts.append(ref_map_block)

            prefix = "\n\n".join(prefix_parts)
            img_prompt = (prefix + "\n\n" + img_prompt) if prefix else img_prompt

            # ── 5. Inject VISUAL DNA block if missing — AFTER prefix, BEFORE rest ──
            if dna_block and dna_probe not in img_prompt.lower():
                # Find end of prefix (after the last prefix block + its blank line)
                if prefix:
                    # Insert right after the prefix
                    prefix_len = len(prefix)
                    img_prompt = (
                        img_prompt[:prefix_len].rstrip()
                        + "\n\n" + dna_block + "\n\n"
                        + img_prompt[prefix_len:].lstrip()
                    )
                else:
                    img_prompt = dna_block + "\n\n" + img_prompt

            # ── 6. Inject LOCATION canonical_description if missing ──
            loc_name = (scene.get("location_name", "") or "").strip().lower()
            loc_obj = loc_by_name_lower.get(loc_name)
            if not loc_obj and locations:
                loc_obj = locations[0]
                scene["location_name"] = loc_obj.get("name", "")

            if loc_obj:
                canon = (loc_obj.get("canonical_description", "") or "").strip()
                if canon and len(canon) >= 40:
                    loc_probe = canon[:80].lower()
                    if loc_probe not in img_prompt.lower():
                        # Insert after DNA block if possible, else after prefix
                        if dna_probe and dna_probe in img_prompt.lower():
                            dna_start = img_prompt.lower().find(dna_probe)
                            dna_end = dna_start + len(dna_block)
                            if 0 < dna_end <= len(img_prompt):
                                img_prompt = (
                                    img_prompt[:dna_end].rstrip()
                                    + "\n\n" + f"LOCATION (locked canonical): {canon}"
                                    + "\n\n" + img_prompt[dna_end:].lstrip()
                                )
                            else:
                                img_prompt = img_prompt + "\n\n" + f"LOCATION (locked canonical): {canon}"
                        else:
                            img_prompt = img_prompt + "\n\n" + f"LOCATION (locked canonical): {canon}"

            # ── 7. Append ASPECT RATIO REINFORCE TAG at the very bottom ──
            if reinforce and reinforce_probe not in img_prompt.lower():
                img_prompt = img_prompt.rstrip() + "\n\n" + reinforce

            scene["image_prompt"] = img_prompt

            # ── 8. Continuity from previous — default if missing ──
            if not scene.get("continuity_from_previous"):
                if previous_scene is None:
                    scene["continuity_from_previous"] = (
                        "Opening scene — establishes the story's tone, world, "
                        "visual medium, and aspect ratio. Subsequent scenes will "
                        "reference the wardrobe, lighting direction, palette, and "
                        "atmospheric state introduced here."
                    )
                else:
                    prev_title = previous_scene.get("title", "previous scene")
                    prev_chars = previous_scene.get("characters_present", [])
                    prev_loc = previous_scene.get("location_name", "")
                    scene["continuity_from_previous"] = (
                        f"Follows '{prev_title}' in {prev_loc} with "
                        f"{', '.join(prev_chars) or 'no characters'}. "
                        f"This scene picks up the narrative thread, same wardrobe, "
                        f"same lighting key direction, same atmospheric state."
                    )

            # ── 9. Force tone attribute on every scene ──
            scene["tone"] = locked_tone
            scene["locked_tone"] = locked_tone

            # ── 10. Store orientation on scene (for downstream consumers) ──
            scene["orientation"] = {
                "label": orientation_preset.get("label", ""),
                "canvas": orientation_preset.get("canvas", ""),
                "aspect_lock": aspect_lock,
                "reinforce": reinforce
            }

            previous_scene = scene

        return scenes


    # ─────────────────────────────────────────────────────────────────────
    # NEW (v3.2) — FRAME-TO-FRAME CONTINUITY STATE THREADING
    # Walks the scene list sequentially after invariants enforcement, builds
    # an evolving environmental + per-character state, and injects an
    # explicit "INCOMING STATE FROM PREVIOUS SCENE" anchor block into every
    # scene N>1's image_prompt — guaranteeing that the first frame of each
    # video clip visually matches the last frame of the previous clip.
    # ─────────────────────────────────────────────────────────────────────
    def _thread_continuity_state(
        self,
        scenes: List[Dict[str, Any]],
        global_chars: List[Dict[str, Any]],
        locations: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Defensive frame-to-frame state continuity.

        For every scene N > 1, injects an INCOMING STATE block into the
        image_prompt that explicitly names:
          • Which characters carried over from scene N-1 and what state
            they ended in (position in frame, posture, expression).
          • Same location vs new location (and what the visual transition is).
          • Lighting state (time-of-day continuation, key direction).
          • Wardrobe persistence (same clothes — no costume changes within
            the same narrative day).
          • Atmospheric state (dust still suspended, weather continuing).

        This block is placed AFTER the LOCATION canonical and BEFORE the
        FIRST-FRAME SEMANTICS block, so the image generator sees the
        continuity contract before reading the scene-specific instructions.
        """
        if not scenes or len(scenes) < 2:
            return scenes

        # Build per-character "last known state" tracker
        # (default state = portrait baseline)
        char_by_lower = {
            c.get("name", "").strip().lower(): c
            for c in global_chars if c.get("name")
        }

        # Track per-scene outgoing state
        prev_scene = None
        prev_outgoing = None  # dict: location_name, characters_present, time_feel

        for idx, scene in enumerate(scenes):
            if idx == 0:
                # Scene 1 sets the baseline — no incoming state to inject
                prev_scene = scene
                prev_outgoing = self._extract_outgoing_state(scene, char_by_lower)
                continue

            # Build the INCOMING STATE anchor block for this scene
            incoming_block = self._build_incoming_state_block(
                prev_scene, prev_outgoing, scene, char_by_lower
            )

            if incoming_block:
                # Inject into image_prompt: place AFTER LOCATION canonical
                # block (or after DNA if no location), BEFORE the rest.
                img = scene.get("image_prompt", "") or ""
                img = self._inject_incoming_state(img, incoming_block)
                scene["image_prompt"] = img

                # Also store on scene metadata for downstream consumers
                scene["incoming_state_from_previous"] = incoming_block

            # Compute this scene's outgoing state for the next iteration
            prev_scene = scene
            prev_outgoing = self._extract_outgoing_state(scene, char_by_lower)

        return scenes


    def _extract_outgoing_state(
        self,
        scene: Dict[str, Any],
        char_by_lower: Dict[str, Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Extract a structured 'last frame state' from a scene. We pull from
        whatever the scene has — characters_present, location, continuity_to_next
        if the LLM populated it, else fall back to character one-line identifiers.
        """
        cp = scene.get("characters_present", []) or []
        char_states = []
        for name in cp:
            c = char_by_lower.get(name.strip().lower(), {})
            char_states.append({
                "name": name,
                "identifier": c.get("one_line_identifier", "") or c.get("role", ""),
                "wardrobe_anchor": c.get("one_line_identifier", "")
            })

        # Try to pull camera/lighting one-liners
        return {
            "location_name": scene.get("location_name", ""),
            "characters_present": cp,
            "character_states": char_states,
            "camera_summary": scene.get("camera_info", ""),
            "lighting_summary": scene.get("lighting_info", ""),
            "scene_title": scene.get("title", ""),
            "continuity_to_next": scene.get("continuity_to_next", ""),
            "tone": scene.get("locked_tone", ""),
        }


    def _build_incoming_state_block(
        self,
        prev_scene: Dict[str, Any],
        prev_outgoing: Dict[str, Any],
        cur_scene: Dict[str, Any],
        char_by_lower: Dict[str, Dict[str, Any]]
    ) -> str:
        """
        Build the human-readable INCOMING STATE anchor block that gets
        injected into the current scene's image_prompt.
        """
        if not prev_outgoing:
            return ""

        prev_loc = (prev_outgoing.get("location_name") or "").strip()
        cur_loc = (cur_scene.get("location_name") or "").strip()
        same_location = bool(prev_loc) and bool(cur_loc) and (
            prev_loc.lower() == cur_loc.lower()
        )

        prev_cp = set([n.strip().lower() for n in prev_outgoing.get("characters_present", [])])
        cur_cp = set([n.strip().lower() for n in cur_scene.get("characters_present", [])])
        carried_over = prev_cp & cur_cp
        new_in_scene = cur_cp - prev_cp
        left_after_prev = prev_cp - cur_cp

        # Build wardrobe persistence statement for carried-over characters
        wardrobe_anchors = []
        for name_lower in carried_over:
            c = char_by_lower.get(name_lower, {})
            ident = c.get("one_line_identifier", "") or c.get("role", "")
            real_name = c.get("name") or name_lower.title()
            if ident:
                wardrobe_anchors.append(f"{real_name} ({ident})")
            else:
                wardrobe_anchors.append(real_name)

        # Compose the block
        lines = []
        lines.append(
            "INCOMING STATE FROM PREVIOUS SCENE (frame-to-frame continuity contract — "
            "the first frame of THIS scene must match the last frame of the previous scene "
            "in every visual element below):"
        )

        # Location continuity
        if same_location:
            lines.append(
                f"• LOCATION CONTINUITY: Same location as previous scene "
                f"('{cur_loc}'). DO NOT reset the room — same dust state, same "
                f"object positions, same door state, same prop placement as prev frame."
            )
        else:
            lines.append(
                f"• LOCATION TRANSITION: Previous scene ended in '{prev_loc or 'unknown'}'; "
                f"this scene opens in '{cur_loc or 'unknown'}'. Treat as a hard cut "
                f"to a new location — but maintain time-of-day, weather, and tone continuity."
            )

        # Character carry-over with wardrobe persistence
        if wardrobe_anchors:
            lines.append(
                f"• CHARACTER WARDROBE PERSISTENCE: These characters appear in both "
                f"the previous scene and this scene — their wardrobe, hair, and any "
                f"props they were holding must be IDENTICAL to the previous frame: "
                f"{'; '.join(wardrobe_anchors)}."
            )

        # New character entries
        if new_in_scene:
            new_names = []
            for nl in new_in_scene:
                c = char_by_lower.get(nl, {})
                new_names.append(c.get("name") or nl.title())
            lines.append(
                f"• NEW CHARACTERS THIS SCENE (not in previous frame): "
                f"{', '.join(new_names)}. Render at portrait baseline wardrobe."
            )

        # Characters who left
        if left_after_prev:
            left_names = []
            for nl in left_after_prev:
                c = char_by_lower.get(nl, {})
                left_names.append(c.get("name") or nl.title())
            lines.append(
                f"• CHARACTERS NO LONGER PRESENT: {', '.join(left_names)} "
                f"(were in previous scene but not in this frame)."
            )

        # Lighting / time-of-day continuity
        prev_light = (prev_outgoing.get("lighting_summary") or "").strip()
        if prev_light:
            lines.append(
                f"• LIGHTING CONTINUITY: Previous scene's lighting summary — "
                f"'{prev_light}'. This scene's lighting must continue from that "
                f"state (same key direction, same color temperature, same time-of-day) "
                f"unless a deliberate scene-cut to a new time/location is happening."
            )

        # Camera/blocking continuity hint
        prev_cam = (prev_outgoing.get("camera_summary") or "").strip()
        prev_title = (prev_outgoing.get("scene_title") or "").strip()
        prev_continuity_to_next = (prev_outgoing.get("continuity_to_next") or "").strip()
        if prev_continuity_to_next:
            lines.append(
                f"• PREVIOUS SCENE LEFT-OFF NOTE (from director): "
                f"\"{prev_continuity_to_next}\""
            )
        elif prev_title and prev_cam:
            lines.append(
                f"• PREVIOUS SCENE WAS '{prev_title}' shot as: {prev_cam}. "
                f"This scene's first frame should feel like the natural next "
                f"shot in the same edit."
            )

        return "\n".join(lines)


    def _inject_incoming_state(self, image_prompt: str, incoming_block: str) -> str:
        """
        Insert the INCOMING STATE block into the right place in image_prompt.
        Order target: after LOCATION canonical, before FIRST-FRAME SEMANTICS.
        Falls back: end of prompt (before REINFORCE tag if present).
        """
        if not incoming_block or not image_prompt:
            return image_prompt

        # If already injected (idempotent), skip
        if "INCOMING STATE FROM PREVIOUS SCENE" in image_prompt:
            return image_prompt

        # Try insertion after "LOCATION (locked canonical):" block
        loc_marker = "LOCATION (locked canonical):"
        if loc_marker in image_prompt:
            # Find the end of the location block (next blank line)
            loc_idx = image_prompt.find(loc_marker)
            after_marker = image_prompt[loc_idx:]
            # Find the first double-newline AFTER the marker
            blank_pos = after_marker.find("\n\n")
            if blank_pos > 0:
                insertion_offset = loc_idx + blank_pos
                return (
                    image_prompt[:insertion_offset].rstrip()
                    + "\n\n" + incoming_block
                    + "\n\n" + image_prompt[insertion_offset:].lstrip()
                )

        # Fallback A: try inserting before "FINAL OUTPUT:" reinforce tag
        final_markers = ["FINAL OUTPUT:", "--ar "]
        for marker in final_markers:
            if marker in image_prompt:
                idx = image_prompt.find(marker)
                # Walk back to start of that line
                line_start = image_prompt.rfind("\n", 0, idx)
                if line_start < 0:
                    line_start = 0
                return (
                    image_prompt[:line_start].rstrip()
                    + "\n\n" + incoming_block
                    + "\n\n" + image_prompt[line_start:].lstrip()
                )

        # Fallback B: append at end
        return image_prompt.rstrip() + "\n\n" + incoming_block


    # ─────────────────────────────────────────────────────────────────────
    # STAGE 7 — SAVE TO PROJECT DB
    # ─────────────────────────────────────────────────────────────────────
    async def _save_to_project(
        self, characters_data: Dict[str, Any],
        scenes_data: Dict[str, Any], bg_color: str
    ):
        chars = characters_data.get("characters", [])
        scenes = scenes_data.get("scenes", [])

        character_list_for_project = []
        for char in chars:
            char_name = char.get("name", "Unknown")
            char_prompt = char.get("image_prompt", char.get("description", ""))
            character_list_for_project.append({"name": char_name, "prompt": char_prompt})
            try:
                await mexflow.project_data.add_character(char_name, char_prompt)
            except Exception:
                pass

        try:
            await mexflow.project_data.save_characters(character_list_for_project)
        except Exception:
            pass

        all_character_names = [c.get("name", "") for c in chars if c.get("name")]
        print(f"[AI Director v3] Locked reference order: {all_character_names}")

        bulk_scenes = []
        for i, scene in enumerate(scenes):
            scene_id = scene.get("scene_id", f"{i+1}")
            scene_characters_present = scene.get("characters_present", []) or []

            if not scene_characters_present and all_character_names:
                scene_text = " ".join([
                    scene.get("description", ""),
                    scene.get("image_prompt", ""),
                    scene.get("scene_prompt", ""),
                    scene.get("title", "")
                ]).lower()
                for char_name in all_character_names:
                    if char_name.lower() in scene_text:
                        scene_characters_present.append(char_name)
                if scene_characters_present:
                    scene["characters_present"] = scene_characters_present
            else:
                present_set = {c.strip().lower() for c in scene_characters_present if isinstance(c, str)}
                reordered = [n for n in all_character_names if n.lower() in present_set]
                if reordered:
                    scene_characters_present = reordered
                    scene["characters_present"] = reordered

            bulk_scenes.append({
                "scene_id_str": scene_id,
                "title": scene.get("title", f"Scene {i+1}"),
                "image_prompt": scene.get("image_prompt", ""),
                "voiceover": scene.get("description", ""),
                "duration": scene.get("duration", 5),
                "scene_prompt": scene.get("scene_prompt", ""),
                "scene_description": scene.get("description", ""),
                "characters_present": scene_characters_present,
                "characters": [{"name": cn} for cn in scene_characters_present],
                "metadata": {
                    "scene_prompt": scene.get("scene_prompt", ""),
                    "camera_info": scene.get("camera_info", ""),
                    "lighting_info": scene.get("lighting_info", ""),
                    "audio_info": scene.get("audio_info", ""),
                    "location_name": scene.get("location_name", ""),
                    "transition": scene.get("transition", ""),
                    "characters_present": scene_characters_present,
                    "continuity_from_previous": scene.get("continuity_from_previous", ""),
                    "continuity_to_next": scene.get("continuity_to_next", ""),
                    "locked_tone": scene.get("locked_tone", "")
                }
            })

        try:
            await mexflow.scene_data.save_scenes_bulk(
                scenes=bulk_scenes, clear_existing=True
            )
        except Exception:
            pass

        for i, scene in enumerate(scenes):
            scene_id = scene.get("scene_id", f"{i+1}")
            try:
                await mexflow.scene_data.save_scene_duration(scene_id, scene.get("duration", 5))
            except Exception:
                pass
            try:
                await mexflow.scene_data.save_scene_prompt(scene_id, scene.get("scene_prompt", ""))
            except Exception:
                pass
            try:
                await mexflow.scene_data.save_scene_description(scene_id, scene.get("description", ""))
            except Exception:
                pass
            try:
                await mexflow.scene_data.save_characters_present(
                    scene_id, scene.get("characters_present", [])
                )
            except Exception:
                pass
            try:
                await mexflow.scene_data.update_status(scene_id, "generated")
            except Exception:
                pass

            progress_pct = ((i + 1) / max(len(scenes), 1)) * 100
            mexflow.progress.update(
                stage="Saving to Project",
                stage_index=7,
                total_stages=8,
                current_progress=progress_pct,
                message=f"Saved scene {i + 1} of {len(scenes)}: {scene.get('title', '')}"
            )
