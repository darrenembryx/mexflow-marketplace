"""
Jungle Cinematic Agent - Library Module
Contains prompt templates and helper utilities
"""

from .prompts import (
    PHASE_0_GLOBAL_BLUEPRINTS,
    PHASE_1_SCENE_BREAKDOWN,
    PHASE_2_GENERATE_SHOTS,
    CHARACTER_BLUEPRINT_PROMPT
)

__all__ = [
    "PHASE_0_GLOBAL_BLUEPRINTS",
    "PHASE_1_SCENE_BREAKDOWN", 
    "PHASE_2_GENERATE_SHOTS",
    "CHARACTER_BLUEPRINT_PROMPT"
]
