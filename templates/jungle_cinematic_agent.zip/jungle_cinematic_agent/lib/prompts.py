"""
Prompt Templates for Jungle Cinematic Agent
Extracted from film_pipeline.py for use in MexFlow template
"""

# ============================================================================
# PHASE 0: GLOBAL BLUEPRINTS PROMPT
# ============================================================================

PHASE_0_GLOBAL_BLUEPRINTS = """You are a professional Hollywood production designer and character artist.
Analyze the following story and create COMPLETE, DETAILED blueprints for ALL elements needed for film production.

STORY:
{{story}}

Create a comprehensive JSON object with these sections:

{
  "characters": [
    {
      "blueprint_id": "unique_character_id_v1",
      "name": "Character Name",
      "role": "Protagonist/Antagonist/Supporting",
      "gender": "Male/Female/Non-binary",
      "age": "Age or age range",
      "species": "Human/Animal/Creature",
      "origin": "Where they come from",
      "ethnicity": "Ethnicity if applicable",
      "body": {
        "height": "Height description",
        "weight": "Weight description",
        "build": "Body type",
        "skin_texture": "Skin/fur/scales description",
        "posture": "How they carry themselves",
        "movement_style": "How they move",
        "distinctive_features": "Unique physical traits"
      },
      "face": {
        "structure": "Face shape",
        "skin_tone": "Exact color with hex code",
        "eyes": "Eye description with color hex",
        "distinctive_features": "Unique facial features"
      },
      "hair": {
        "style": "Hair style",
        "color": "Hair color with hex",
        "length": "Hair length"
      },
      "outfit": {
        "attire": "Complete outfit description",
        "fabric_textures": "Material descriptions",
        "accessories": "Any accessories"
      },
      "personality": {
        "traits": ["trait1", "trait2", "trait3"],
        "motivation": "What drives them",
        "fears": "What they fear"
      },
      "voice_profile": {
        "tone": "Voice characteristics",
        "accent": "Accent if any",
        "speaking_style": "How they speak"
      },
      "backstory": "Brief background"
    }
  ],
  "environments": [
    {
      "blueprint_id": "unique_environment_id_v1",
      "name": "Environment Name",
      "location": "General location",
      "time_of_day": "Time of day",
      "weather": "Weather conditions",
      "sky": "Sky description with colors",
      "land": "Ground/terrain description",
      "surroundings": "What's around",
      "lighting": "Lighting conditions",
      "atmosphere": "Mood and feel",
      "color_palette": {
        "dominant_colors": ["#hex1", "#hex2", "#hex3"]
      },
      "environment_sounds": {
        "ambience": "Ambient sounds",
        "creatures": "Creature sounds",
        "additional_effects": "Other sounds"
      },
      "flora_and_fauna": "Plants and animals",
      "scale_and_perspective": "Size and viewpoint notes",
      "dynamic_elements": "Moving elements"
    }
  ],
  "objects": [
    {
      "blueprint_id": "unique_object_id_v1",
      "name": "Object Name",
      "type": "Object category",
      "material": "Materials used",
      "color": "#hex color",
      "size": "Size description",
      "condition": "Object condition",
      "notable_features": "Special characteristics"
    }
  ],
  "visual_style": {
    "core_concept": {
      "artistic_influence": "Art style reference",
      "color_grading": "Color treatment",
      "film_grain": "Grain/texture level"
    },
    "lighting": {
      "primary_style": "Main lighting approach",
      "color_temperature": "Warm/cool",
      "contrast": "high/medium/low"
    }
  },
  "camera_defaults": {
    "default_lens": "Default lens mm",
    "default_aperture": "Default aperture",
    "focus_style": "Focus approach"
  },
  "audio_defaults": {
    "music": {
      "genre": "Music genre",
      "mood_and_emotion": "Musical mood",
      "tempo": "BPM range"
    },
    "sound_effects": {
      "style": "SFX approach"
    }
  },
  "narrator_profiles": [
    {
      "profile_id": "narrator_main_v1",
      "name": "Narrator Name",
      "voice_type": "Voice description",
      "tone": "Speaking tone",
      "language": "Language"
    }
  ]
}

IMPORTANT:
- Use unique, descriptive blueprint_id for each element
- Include hex color codes where applicable
- Be extremely detailed - this will be used for AI image/video generation
- Create ALL characters, environments, and objects that appear in the story

Output valid JSON only."""


# ============================================================================
# PHASE 1: SCENE BREAKDOWN PROMPT
# ============================================================================

PHASE_1_SCENE_BREAKDOWN = """You are a professional Hollywood story analyst and cinematographer.
Break down the following story into cinematic scenes with precise detail for film production.

STORY:
{story}

SCENE CONSTRAINTS:
{scene_constraints}

AVAILABLE GLOBAL ASSETS (USE ONLY THESE):
{global_assets}

Create a JSON array of scenes. Each scene must include:

[
  {
    "scene_id": "S01",
    "scene_number": 1,
    "title": "Scene Title",
    "description": "Detailed scene description (NO dialogue - visual actions only)",
    "duration_seconds": 30,
    "time_of_day": "dawn/morning/midday/afternoon/dusk/night",
    "location_ref": "environment_blueprint_id from global assets",
    "characters_present": ["character_blueprint_id1", "character_blueprint_id2"],
    "objects_present": ["object_blueprint_id1"],
    "narrative_purpose": "What this scene achieves in the story",
    "emotional_beat": "The emotional tone",
    "pacing_notes": "Slow/Medium/Fast pacing",
    "audio_profile": {
      "primary_sfx": ["sound1", "sound2"],
      "music_mood": "musical mood for scene"
    },
    "state_changes": {
      "character_deltas": {
        "character_id": {
          "delta_id": "delta_scene_character_change",
          "changed_keys": {
            "outfit.attire": "+ Added bandage on left arm",
            "condition": "wounded"
          },
          "persists_until": "end"
        }
      },
      "environment_deltas": {},
      "object_deltas": {}
    },
    "transition_in": "cut/fade/dissolve",
    "transition_out": "cut/fade/dissolve"
  }
]

CRITICAL RULES:
1. Use ONLY blueprint_ids from the provided global assets
2. Track state changes (injuries, wetness, outfit changes) with deltas
3. Deltas persist forward unless explicitly changed
4. NO dialogue in descriptions - visual actions only
5. Each scene should have clear narrative purpose

Output valid JSON array only."""


# ============================================================================
# PHASE 2: GENERATE SHOTS PROMPT
# ============================================================================

PHASE_2_GENERATE_SHOTS = """You are a master cinematographer and film director.
Generate detailed shot lists for the following scenes with PERFECT visual continuity.

SCENES:
{scenes_json}

LAST SHOT CONTEXT (for continuity):
{last_shot_context}

MAX SHOT DURATION: {max_duration_cap} seconds

GLOBAL ASSETS (for reference):
{global_assets_json}

Generate 2-5 shots per scene. Each shot must include:

{
  "shots": [
    {
      "shot_id": "S01_001",
      "scene_ref": "S01",
      "shot_number_in_scene": 1,
      "duration": 6.0,
      "start_time": 0.0,
      "end_time": 6.0,
      "continuity_analysis": {
        "continues_from_previous": "Description of continuity from last shot",
        "spatial_relationship": "How this shot relates spatially",
        "temporal_gap": "Time gap from previous shot",
        "motion_carryover": "Any ongoing motion"
      },
      "camera": {
        "shot_type": "Wide/Medium/Close-up/Extreme Close-up/Over-the-shoulder",
        "angle": "eye-level/low-angle/high-angle/dutch/bird's eye",
        "movement": "static/pan/tilt/dolly/tracking/crane/handheld",
        "lens": "24mm/35mm/50mm/85mm/135mm",
        "focus_technique": "deep-focus/shallow-focus/rack-focus",
        "overrides": {
          "aperture": "f/2.8",
          "iso": "400"
        }
      },
      "composition": {
        "primary_subject": "What's the main focus",
        "subject_position": "Rule of thirds position",
        "depth_layers": ["foreground", "midground", "background"],
        "framing": "Type of framing"
      },
      "shot_blocking": {
        "character_staging": {
          "character_id": {
            "position_in_frame": "left/center/right",
            "body_facing": "direction",
            "outfit_state": "Current outfit with any deltas applied",
            "holding_items": "Items in hands"
          }
        }
      },
      "characters": {
        "character_id": {
          "position": "frame position",
          "action": "what they're doing",
          "emotional_state": "emotion",
          "visible_parts": "full_body/upper_body/face",
          "active_deltas": ["delta_id1"]
        }
      },
      "environment": {
        "ref": "environment_blueprint_id",
        "focus_elements": "What environment elements to emphasize",
        "depth_visibility": "how much of environment is visible"
      },
      "objects_in_shot": {
        "object_id": {
          "position": "where in frame",
          "prominence": "foreground/midground/background",
          "in_use": true
        }
      },
      "lighting_notes": "Specific lighting for this shot",
      "audio": {
        "dialogue": [
          {
            "character_blueprint_id": "speaker_id",
            "line": "Dialogue line",
            "emotion": "speaking emotion"
          }
        ],
        "sfx": ["sound effect list"],
        "music": "music notes"
      },
      "clip_beats": [
        {
          "start_time": 0.0,
          "end_time": 3.0,
          "visual_description": "ULTRA-detailed visual description for AI generation",
          "camera_notes": "Camera behavior",
          "character_actions": {
            "character_id": "Specific action"
          }
        }
      ],
      "director_notes": "Any additional direction"
    }
  ]
}

CRITICAL RULES:
1. PERFECT CONTINUITY - each shot must connect smoothly to the last
2. Character outfits/injuries MUST persist with applied deltas
3. Shot durations must not exceed {max_duration_cap} seconds
4. clip_beats visual_description should be EXTREMELY detailed for AI video generation
5. Track ALL character positions and states between shots

Output valid JSON with "shots" array."""


# ============================================================================
# CHARACTER BLUEPRINT PROMPT (for Phase 1.5)
# ============================================================================

CHARACTER_BLUEPRINT_PROMPT = """You are a professional AI film character designer.
Create detailed character blueprints for characters discovered in scene analysis.

These characters appeared in scenes but need proper character blueprints:
{characters_list}

For each character, create a detailed blueprint:

{
  "characters": [
    {
      "blueprint_id": "character_name_descriptor_v1",
      "name": "Character Name",
      "role": "Role in story",
      "gender": "Male/Female/Non-binary/N/A",
      "age": "Age or life stage",
      "species": "Human/Animal/Creature type",
      "origin": "Where they come from",
      "body": {
        "height": "Height description",
        "weight": "Weight description",
        "build": "Body build",
        "skin_texture": "Skin/fur/scales",
        "posture": "How they stand",
        "movement_style": "How they move",
        "distinctive_features": "Unique traits"
      },
      "face": {
        "structure": "Face/head structure",
        "eyes": "Eye description with color",
        "distinctive_features": "Facial features"
      },
      "outfit": {
        "style": "Clothing or covering style",
        "colors": "Dominant colors",
        "description": "Detailed outfit description"
      },
      "personality": {
        "traits": ["trait1", "trait2", "trait3"],
        "motivation": "What drives them",
        "fears": "What they fear"
      },
      "backstory": "Brief background",
      "voice_profile": {
        "tone": "Voice characteristics",
        "distinctive_sounds": "Unique sounds"
      },
      "abilities": ["ability1", "ability2"]
    }
  ]
}

Return a JSON object with "characters" array."""
