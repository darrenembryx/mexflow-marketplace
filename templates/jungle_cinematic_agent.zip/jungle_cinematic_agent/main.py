"""
Jungle Cinematic Agent Template
Simple, working implementation that matches film_pipeline.py agent output.
"""

import json
from typing import Dict, Any, List, Optional

from mexflow_sdk import mexflow, TemplateBase, TemplateResult


class JungleCinematicTemplate(TemplateBase):
    """Simple template that generates shots and saves them as scenes."""
    
    TOTAL_STAGES = 4
    
    async def execute(self, inputs: Dict[str, Any]) -> TemplateResult:
        """Main execution"""
        try:
            # Extract inputs
            story_text = inputs.get("story_text", "")
            scene_constraints = inputs.get("scene_constraints", "Create 8-12 scenes")
            max_shot_duration = float(inputs.get("max_shot_duration", 8.0))
            visual_style = inputs.get("visual_style", "cinematic")
            
            if not story_text.strip():
                return mexflow.result.error("Story text is required")
            
            mexflow.progress.setup(self.TOTAL_STAGES)
            
            # ========================================
            # STAGE 1: Generate Global Blueprints
            # ========================================
            mexflow.progress.start_stage("Global Blueprints", "Creating blueprints...")
            
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()
            
            global_assets = await self._generate_global_assets(story_text, visual_style)
            await mexflow.storage.set("global_assets", global_assets)
            
            # ========================================
            # SAVE CHARACTERS AND OBJECTS TO PROJECT
            # ========================================
            # Convert character data to project format and save
            characters_for_project = []
            for char in global_assets.get("characters", []):
                char_prompt = f"{char.get('appearance', '')}. {char.get('outfit', '')}. {char.get('personality', '')}"
                characters_for_project.append({
                    "name": char.get("name", char.get("id", "Unknown")),
                    "prompt": char_prompt.strip()
                })
            
            if characters_for_project:
                await mexflow.project_data.save_characters(characters_for_project)
                print(f"[Template] Saved {len(characters_for_project)} characters to project")
            
            # Convert object data to project format and save
            objects_for_project = []
            for obj in global_assets.get("objects", []):
                objects_for_project.append({
                    "name": obj.get("name", obj.get("id", "Unknown")),
                    "prompt": obj.get("description", "")
                })
            
            if objects_for_project:
                await mexflow.project_data.save_objects(objects_for_project)
                print(f"[Template] Saved {len(objects_for_project)} objects to project")
            
            mexflow.progress.complete_stage(
                f"Created {len(global_assets.get('characters', []))} characters, "
                f"{len(global_assets.get('environments', []))} environments"
            )
            
            # ========================================
            # STAGE 2: Generate Scene Breakdown
            # ========================================
            mexflow.progress.start_stage("Scene Breakdown", "Breaking story into scenes...")
            
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()
            
            scenes = await self._generate_scenes(story_text, scene_constraints, global_assets)
            await mexflow.storage.set("scenes", scenes)
            
            mexflow.progress.complete_stage(f"Created {len(scenes)} scenes")
            
            # ========================================
            # STAGE 3: Generate Shots and Merge
            # ========================================
            mexflow.progress.start_stage("Shot Generation", "Generating and merging shots...")
            
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()
            
            final_shots = await self._generate_and_merge_shots(
                scenes, global_assets, max_shot_duration, visual_style
            )
            await mexflow.storage.set("final_shots", final_shots)
            
            mexflow.progress.complete_stage(f"Generated {len(final_shots)} shots")
            
            # ========================================
            # STAGE 4: Save to Database
            # ========================================
            mexflow.progress.start_stage("Save to Database", "Saving shots as scenes...")
            
            if mexflow.execution.is_cancelled():
                return mexflow.result.cancelled()
            
            # Each shot becomes a scene with sequential number
            scenes_for_db = []
            for i, shot in enumerate(final_shots):
                scene_number = i + 1
                
                # Build image prompt
                image_prompt = self._build_image_prompt(shot, visual_style)
                
                # Extract character names for characters_present
                characters = shot.get("characters", [])
                characters_present = [c.get("name", c.get("id", "")) for c in characters if isinstance(c, dict)]
                if not characters_present:
                    characters_present = [c for c in characters if isinstance(c, str)]
                
                # Extract object names for objects_present
                objects = shot.get("objects", [])
                objects_present = [o.get("name", o.get("id", "")) for o in objects if isinstance(o, dict)]
                if not objects_present:
                    objects_present = [o for o in objects if isinstance(o, str)]
                
                db_scene = {
                    "scene_id_str": str(scene_number),
                    "title": shot.get("title", f"Scene {scene_number}"),
                    "image_prompt": image_prompt,
                    "duration": shot.get("duration", 6.0),
                    "description": shot.get("description", ""),
                    "characters": characters,
                    "characters_present": characters_present,  # List of character names
                    "objects_present": objects_present,  # List of object names
                    "metadata": {
                        "shot_id": shot.get("shot_id"),
                        "scene_ref": shot.get("scene_ref"),
                        "camera": shot.get("camera", {}),
                        "environment": shot.get("environment", {}),
                        "clip": shot.get("clip", []),
                        "lighting_notes": shot.get("lighting_notes", ""),
                        "audio": shot.get("audio", {})
                    }
                }
                scenes_for_db.append(db_scene)
            
            # Save to database
            scene_uuids = await mexflow.scene_data.save_scenes_bulk(
                scenes=scenes_for_db,
                clear_existing=True
            )
            
            # Save all data for each scene separately
            for i, scene in enumerate(scenes_for_db):
                scene_id = scene["scene_id_str"]
                shot = final_shots[i]  # Get corresponding shot for full data
                
                # Save image prompt
                if scene.get("image_prompt"):
                    await mexflow.scene_data.save_image_prompt(scene_id, scene["image_prompt"])
                
                # Save description
                if scene.get("description"):
                    await mexflow.scene_data.save_scene_description(scene_id, scene["description"])
                
                # Save duration
                await mexflow.scene_data.save_scene_duration(scene_id, int(scene.get("duration", 6)))
                
                # Save characters (full character data)
                characters = shot.get("characters", [])
                if characters:
                    await mexflow.scene_data.save_characters(scene_id, characters)
                    # Also save character names as characters_present
                    char_names = [c.get("name", c.get("id", "")) for c in characters]
                    await mexflow.scene_data.save_characters_present(scene_id, char_names)
                
                # Save objects
                objects = shot.get("objects", [])
                if objects:
                    obj_names = [o.get("name", o.get("id", "")) for o in objects]
                    await mexflow.scene_data.save_objects_present(scene_id, obj_names)
                
                # Save full metadata including environment, camera, etc.
                await mexflow.scene_data.save_metadata(scene_id, {
                    "shot_id": shot.get("shot_id"),
                    "scene_ref": shot.get("scene_ref"),
                    "camera": shot.get("camera", {}),
                    "environment": shot.get("environment", {}),
                    "objects": objects,
                    "clip": shot.get("clip", []),
                    "lighting_notes": shot.get("lighting_notes", ""),
                    "audio": shot.get("audio", {}),
                    "scene_context": shot.get("scene_context", {})
                })
                
                # Update status
                await mexflow.scene_data.update_status(scene_id, "generated")
            
            mexflow.progress.complete_stage(f"Saved {len(scene_uuids)} scenes!")
            
            return mexflow.result.success(
                scenes=final_shots,
                message=f"Created {len(final_shots)} shots"
            )
            
        except Exception as e:
            mexflow.progress.error("Error", str(e))
            return mexflow.result.error(str(e))
    
    # ========================================================================
    # STAGE 1: Global Blueprints
    # ========================================================================
    
    async def _generate_global_assets(self, story: str, style: str) -> Dict[str, Any]:
        """Generate character, environment, object blueprints"""
        
        prompt = mexflow.ai.create_prompt(
            '''Analyze this story and create detailed blueprints.

STORY:
{story}

Return JSON:
{{
    "title": "Film title",
    "characters": [
        {{
            "id": "character_id",
            "name": "Name",
            "role": "Protagonist/Antagonist/Supporting",
            "appearance": "Detailed physical description - age, height, build, face, hair, skin",
            "outfit": "Complete clothing description with colors and materials",
            "personality": "Key traits"
        }}
    ],
    "environments": [
        {{
            "id": "environment_id",
            "name": "Location Name",
            "description": "Detailed visual description",
            "time_of_day": "morning/afternoon/night",
            "weather": "Weather conditions",
            "lighting": "Lighting description",
            "atmosphere": "Mood and feel"
        }}
    ],
    "objects": [
        {{
            "id": "object_id",
            "name": "Object Name",
            "description": "Visual description"
        }}
    ]
}}

Create comprehensive blueprints:''',
            story=story
        )
        
        response = await mexflow.ai.generate(prompt, max_tokens=8000)
        result = mexflow.ai.parse_json(response)
        
        if isinstance(result, dict) and not result.get("error"):
            return result
        
        # Fallback
        return {
            "title": "Untitled",
            "characters": [],
            "environments": [],
            "objects": []
        }
    
    # ========================================================================
    # STAGE 2: Scene Breakdown
    # ========================================================================
    
    async def _generate_scenes(
        self, story: str, constraints: str, global_assets: Dict
    ) -> List[Dict]:
        """Break story into scenes"""
        
        char_names = [c.get("name", c.get("id", "")) for c in global_assets.get("characters", [])]
        env_names = [e.get("name", e.get("id", "")) for e in global_assets.get("environments", [])]
        
        prompt = mexflow.ai.create_prompt(
            '''Break this story into cinematic scenes.

STORY:
{story}

CONSTRAINTS: {constraints}

CHARACTERS: {characters}
ENVIRONMENTS: {environments}

Return JSON:
{{
    "scenes": [
        {{
            "scene_id": "S01",
            "scene_number": 1,
            "title": "Scene Title",
            "description": "Detailed visual description (NO dialogue)",
            "duration_seconds": 60,
            "environment_id": "environment_id",
            "character_ids": ["character_id"],
            "object_ids": [],
            "emotional_beat": "Emotion",
            "time_of_day": "afternoon"
        }}
    ]
}}

Create scenes:''',
            story=story,
            constraints=constraints,
            characters=", ".join(char_names),
            environments=", ".join(env_names)
        )
        
        response = await mexflow.ai.generate(prompt, max_tokens=8000)
        result = mexflow.ai.parse_json(response)
        
        if isinstance(result, dict) and "scenes" in result:
            return result["scenes"]
        elif isinstance(result, list):
            return result
        return []
    
    # ========================================================================
    # STAGE 3: Generate Shots and Merge with Global Assets
    # ========================================================================
    
    async def _generate_and_merge_shots(
        self, 
        scenes: List[Dict], 
        global_assets: Dict, 
        max_duration: float,
        visual_style: str
    ) -> List[Dict]:
        """Generate shots for each scene and merge with global asset data"""
        
        all_final_shots = []
        
        for scene_idx, scene in enumerate(scenes):
            scene_id = scene.get("scene_id", f"S{scene_idx+1:02d}")
            
            # Update progress
            progress = ((scene_idx + 1) / len(scenes)) * 100
            mexflow.progress.update(
                stage="Shot Generation",
                stage_index=3,
                total_stages=4,
                current_progress=progress,
                message=f"Processing {scene_id}"
            )
            
            # Get full character data for this scene
            scene_characters = []
            for char_id in scene.get("character_ids", []):
                char = self._find_by_id(global_assets.get("characters", []), char_id)
                if char:
                    scene_characters.append(char)
            
            # Get full environment data
            env_id = scene.get("environment_id", "")
            scene_environment = self._find_by_id(global_assets.get("environments", []), env_id)
            if not scene_environment:
                scene_environment = {
                    "name": "Scene Environment",
                    "description": scene.get("description", "")[:200]
                }
            
            # Get objects
            scene_objects = []
            for obj_id in scene.get("object_ids", []):
                obj = self._find_by_id(global_assets.get("objects", []), obj_id)
                if obj:
                    scene_objects.append(obj)
            
            # Generate shots for this scene
            shots = await self._generate_shots_for_scene(
                scene, scene_characters, scene_environment, scene_objects, max_duration
            )
            
            # If no shots generated, create fallback
            if not shots:
                shots = [self._create_fallback_shot(scene, scene_characters, scene_environment)]
            
            # Merge each shot with full character/environment data
            for shot in shots:
                merged_shot = self._merge_shot(
                    shot, scene, scene_characters, scene_environment, scene_objects
                )
                all_final_shots.append(merged_shot)
        
        return all_final_shots
    
    async def _generate_shots_for_scene(
        self,
        scene: Dict,
        characters: List[Dict],
        environment: Dict,
        objects: List[Dict],
        max_duration: float
    ) -> List[Dict]:
        """Generate detailed shots for a scene"""
        
        scene_id = scene.get("scene_id", "S01")
        
        prompt = mexflow.ai.create_prompt(
            '''Generate 2-4 cinematic shots for this scene.

SCENE: {scene_title}
DESCRIPTION: {description}
DURATION: {duration} seconds
EMOTIONAL BEAT: {emotion}

CHARACTERS IN SCENE:
{characters}

ENVIRONMENT:
{environment}

OBJECTS:
{objects}

MAX SHOT DURATION: {max_duration} seconds

Return JSON:
{{
    "shots": [
        {{
            "shot_id": "{scene_id}_001",
            "shot_number": 1,
            "duration": 6.0,
            "shot_type": "Wide/Medium/Close-up/Extreme Close-up",
            "camera_angle": "eye-level/low-angle/high-angle",
            "camera_movement": "static/pan/dolly/tracking/crane",
            "lens": "24mm/35mm/50mm/85mm",
            "composition": "How subjects are arranged in frame",
            "visual_description": "ULTRA-DETAILED visual description of EVERYTHING visible - character positions, actions, expressions, environment details, lighting, colors, atmosphere. This is the most important field.",
            "lighting_notes": "Specific lighting for this shot",
            "audio_notes": "Sound effects and ambient sounds"
        }}
    ]
}}

Generate professional shots:''',
            scene_title=scene.get("title", "Scene"),
            description=scene.get("description", ""),
            duration=scene.get("duration_seconds", 30),
            emotion=scene.get("emotional_beat", "neutral"),
            characters=json.dumps(characters, indent=2) if characters else "No characters",
            environment=json.dumps(environment, indent=2) if environment else "No environment",
            objects=json.dumps(objects, indent=2) if objects else "No objects",
            max_duration=max_duration,
            scene_id=scene_id
        )
        
        response = await mexflow.ai.generate(prompt, max_tokens=6000)
        result = mexflow.ai.parse_json(response)
        
        if isinstance(result, dict) and "shots" in result:
            return result["shots"]
        elif isinstance(result, list):
            return result
        return []
    
    def _create_fallback_shot(
        self, scene: Dict, characters: List[Dict], environment: Dict
    ) -> Dict:
        """Create fallback shot when AI fails"""
        return {
            "shot_id": f"{scene.get('scene_id', 'S01')}_001",
            "shot_number": 1,
            "duration": min(8.0, scene.get("duration_seconds", 30) / 3),
            "shot_type": "Medium",
            "camera_angle": "eye-level",
            "camera_movement": "static",
            "lens": "35mm",
            "visual_description": scene.get("description", "Scene content"),
            "lighting_notes": "Natural lighting",
            "audio_notes": "Ambient sound"
        }
    
    def _merge_shot(
        self,
        shot: Dict,
        scene: Dict,
        characters: List[Dict],
        environment: Dict,
        objects: List[Dict]
    ) -> Dict:
        """Merge shot with full character/environment data"""
        
        # Create final shot structure
        final_shot = {
            "shot_id": shot.get("shot_id", "unknown"),
            "scene_ref": scene.get("scene_id", ""),
            "title": scene.get("title", ""),
            "duration": shot.get("duration", 6.0),
            
            # Camera settings
            "camera": {
                "shot_type": shot.get("shot_type", "Medium"),
                "angle": shot.get("camera_angle", "eye-level"),
                "movement": shot.get("camera_movement", "static"),
                "lens": shot.get("lens", "35mm")
            },
            
            # Composition
            "composition": shot.get("composition", ""),
            
            # Visual description (for clip data)
            "description": shot.get("visual_description", scene.get("description", "")),
            
            # Clip beats
            "clip": [
                {
                    "start_time": 0,
                    "end_time": shot.get("duration", 6.0),
                    "visual_description": shot.get("visual_description", "")
                }
            ],
            
            # Full character data - EMBEDDED
            "characters": characters,
            
            # Full environment data - EMBEDDED
            "environment": environment,
            
            # Objects
            "objects": objects,
            
            # Lighting
            "lighting_notes": shot.get("lighting_notes", ""),
            
            # Audio
            "audio": {
                "notes": shot.get("audio_notes", ""),
                "sfx": []
            },
            
            # Scene context
            "scene_context": {
                "emotional_beat": scene.get("emotional_beat", ""),
                "time_of_day": scene.get("time_of_day", "")
            }
        }
        
        return final_shot
    
    def _build_image_prompt(self, shot: Dict, visual_style: str) -> str:
        """Build complete image prompt from shot data"""
        parts = []
        
        # Camera
        camera = shot.get("camera", {})
        parts.append(f"{camera.get('shot_type', 'Medium')} shot")
        parts.append(f"{camera.get('angle', 'eye-level')} angle")
        
        if camera.get("movement") and camera["movement"] != "static":
            parts.append(f"{camera['movement']} camera movement")
        
        # Main visual description from clip
        clip = shot.get("clip", [])
        if clip and isinstance(clip, list) and clip[0].get("visual_description"):
            parts.append(clip[0]["visual_description"])
        elif shot.get("description"):
            parts.append(shot["description"])
        
        # Characters with full details
        characters = shot.get("characters", [])
        for char in characters:
            char_parts = []
            char_parts.append(char.get("name", "Character"))
            
            if char.get("appearance"):
                char_parts.append(char["appearance"])
            
            if char.get("outfit"):
                char_parts.append(f"wearing {char['outfit']}")
            
            parts.append(", ".join(char_parts))
        
        # Environment
        env = shot.get("environment", {})
        if env:
            env_parts = []
            if env.get("name"):
                env_parts.append(env["name"])
            if env.get("description"):
                env_parts.append(env["description"])
            if env.get("lighting"):
                env_parts.append(env["lighting"])
            if env.get("atmosphere"):
                env_parts.append(env["atmosphere"])
            
            if env_parts:
                parts.append(". ".join(env_parts))
        
        # Lighting notes
        if shot.get("lighting_notes"):
            parts.append(shot["lighting_notes"])
        
        # Style
        style_map = {
            "cinematic": "Hollywood blockbuster quality, IMAX cinematography, dramatic lighting, Dolby Vision, professional color grading",
            "documentary": "documentary style, natural lighting, authentic composition",
            "anime": "anime visual style, vibrant colors, dynamic action",
            "noir": "film noir style, high contrast, dramatic shadows",
            "fantasy": "epic fantasy, magical atmosphere, ethereal lighting",
            "horror": "horror film aesthetic, dark shadows, unsettling angles",
            "scifi": "futuristic sci-fi, neon accents, blade runner aesthetic"
        }
        parts.append(style_map.get(visual_style, style_map["cinematic"]))
        
        # Quality tags
        parts.append("8K resolution, professional cinematography, film grain, movie quality")
        
        return ". ".join(parts)
    
    # ========================================================================
    # HELPER METHODS
    # ========================================================================
    
    def _find_by_id(self, items: List[Dict], item_id: str) -> Optional[Dict]:
        """Find item by id"""
        if not items or not item_id:
            return None
        
        for item in items:
            # Check id field
            if item.get("id") == item_id:
                return item
            # Check name (normalized)
            if item.get("name", "").lower().replace(" ", "_") == item_id.lower().replace(" ", "_"):
                return item
            # Partial match
            if item_id.lower() in item.get("id", "").lower():
                return item
            if item_id.lower() in item.get("name", "").lower():
                return item
        
        return None
