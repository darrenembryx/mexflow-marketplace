"""
Audio Workflow Template — Director's Cut v4 (Image-to-Video Edition)
====================================================================

A world-class audiovisual scene generation engine with full character
extraction, character reference portrait generation, and image-to-video
pipeline support. Every scene produces a scene_prompt (for image-to-video conversion).

WORKFLOW A: Story Text Mode
1. Story Text Input → Save as Audio Script
2. Generate Audio (TTS)
3. Generate Subtitles (Whisper)
4. AI Narrative Analysis → Extract characters + story arc
5. AI Character Portrait Prompt Generation
6. AI Scene Generation (scene_prompt + voiceover segmentation)
7. Word-level timing mapping from subtitles
8. Bulk save characters + scenes to project database

WORKFLOW B: Direct Audio Mode
1. Audio File Import
2. Generate Subtitles (Whisper)
3-8. Same as Workflow A steps 4-8

Key Capabilities:
- Character extraction with unique names and persistent order numbers
- Full-body character portrait image prompts with chroma-key backgrounds
- scene_prompt: 100-180 word image-to-video motion direction per scene
- Characters referenced by order number in all prompts for consistency
- Flexible duration control (comma-separated allowed durations)
- 100% subtitle-to-scene audio synchronization
- Narrative continuity threading across scenes
- Stage save/resume for long-running operations

Requirements:
- Default Audio Generator plugin (for Story mode)
- Default Subtitle Generator plugin (both modes)
- AI Provider for analysis and prompt generation
"""

import re
import json
import math
from typing import Dict, Any, List, Optional, Tuple


from mexflow_sdk import mexflow, TemplateBase, TemplateResult


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SYSTEM PROMPTS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SYSTEM_PROMPT_ANALYZE = """You are DIRECTOR-X — an elite Hollywood film director, narrative analyst, and production designer. Your analysis drives an entire AI image-to-video production pipeline, so precision and depth are critical.

CRITICAL RULES:
1. Identify ALL named and significant unnamed characters. Give unnamed characters descriptive unique names (e.g. "The Scarred Elder Monk", "Street Vendor Girl").
2. Each character MUST have a unique name — no duplicates under any circumstances.
3. Determine the narrative arc (three-act structure), genre, mood, primary and secondary settings.
4. Think like a director preparing a full production breakdown: emotional beats, visual set pieces, lighting transitions, color arc, pacing shifts.
5. Character appearance_summary MUST be 60-100 words with specific physical traits, clothing details, distinctive features — enough to generate consistent images.
6. Key moments should map to the most visually impactful "hero shots" that define each act.

You must return ONLY valid JSON. No markdown, no explanation, just JSON."""


SYSTEM_PROMPT_CHARACTERS = """You are DIRECTOR-X — an elite character designer, concept artist, and VFX supervisor for AAA film productions and AI image/video generation.

Create FULL-BODY character portrait prompts. These serve as DEFINITIVE character REFERENCE IMAGES — every scene will match these exactly. Consistency is paramount.

CRITICAL PORTRAIT RULES:
1. FRAMING: Always FULL-BODY, head to toe visible, character centered. NEVER head-and-shoulders only.
2. POSE: Standing upright, neutral heroic stance, front-facing, arms slightly away from body. Hands visible and well-defined.
3. BACKGROUND: SOLID FLAT chroma-key background of the specified color. NO gradients, NO shadows on background, NO environment.
4. LIGHTING: Cinematic three-point studio lighting. Strong key light at 45°. Soft fill at 2:1 ratio. Strong rim light for clean separation. Hair light for strand detail.
5. QUALITY TAGS: Always include: "hyper-sharp 8K photorealistic", "cinematic dramatic studio lighting", "rim light edge separation", "every surface detail visible", "no gradients no shadows on background", "reference sheet quality".
6. CHARACTER DETAIL: Describe with precision — exact height/build, face shape and features (eyebrow shape, nose, lips, jaw), eye color with iris detail, skin tone with undertones, hair (color, length, texture, style), body type, clothing from head to toe (fabric type, color, wear pattern, accessories), scars/marks/tattoos, weapons/items, shoes/footwear.
7. MINIMUM 100 words per portrait prompt. Be specific enough that regenerating produces a visually IDENTICAL character.

You must return ONLY valid JSON. No markdown, no explanation, just JSON."""


SYSTEM_PROMPT_SCENES = """You are DIRECTOR-X — an elite Hollywood film director, cinematographer, and VFX supervisor with 30+ years experience. You are storyboarding every frame for a professional AI image-to-video pipeline.

Your output feeds directly into a two-stage AI production pipeline:
  Stage 1: KEY FRAME IMAGE GENERATION (from your image_prompt — must be extraordinarily detailed)
  Stage 2: IMAGE-TO-VIDEO CONVERSION (from your scene_prompt — must contain complete motion direction)

ABSOLUTE RULES:
1. DURATION LOCK: Each scene duration MUST be EXACTLY one of the allowed durations.
2. CHARACTER ORDER REFERENCING: When characters appear in image_prompt or scene_prompt, ALWAYS reference them as "Character #N (Name, brief appearance)" where N is their persistent order number.
3. IMAGE_PROMPT: 200-350 words of ULTRA-DENSE cinematographic description for KEY FRAME image generation. Must include: exact composition (shot size, angle, lens, DoF), subject micro-details (poses, expressions, wardrobe textures), environment layers (FG/MG/BG), lighting rig (key/fill/rim with Kelvin temps, volumetrics), color science (palette, tonality, grade reference), atmosphere (particles, haze, lens effects), and film aesthetic reference.
4. SCENE_PROMPT: 150-250 words of comprehensive motion/action direction for image-to-video. Must include: camera movement (type, direction, speed, start-to-end trajectory), character actions (gestures, expression shifts, movement choreography), environmental dynamics (wind, rain, light changes, particle motion), lighting transitions, pacing rhythm, and transition to next scene. Reference characters by order number.
5. CHARACTER REFERENCE IMAGES: In image_prompt, specify which reference images to use: "Use reference image 1 for Character #N (Name), reference image 2 for Character #M (Name)" — in order of characters_present array.
6. VOICEOVER: Must contain the EXACT narration words for this scene segment — no paraphrasing, no adding, no removing.
7. CHARACTERS_PRESENT: List ONLY characters that ACTUALLY APPEAR in that specific scene — NOT all characters.

You must return ONLY valid JSON. No markdown, no explanation, just JSON."""


class AudioWorkflowTemplate(TemplateBase):
    """
    Audio Workflow Template — Director's Cut v4 (Image-to-Video Edition)

    Transforms audio narration into a complete image-to-video production
    pipeline with character extraction, reference portraits, image prompts,
    scene direction prompts, and precise audio synchronization.
    """

    # ══════════════════════════════════════════════════════════════════
    # VISUAL STYLE LIBRARY
    # ══════════════════════════════════════════════════════════════════
    STYLE_PROMPTS = {
        "cinematic": (
            "cinematic film aesthetic, shot on ARRI Alexa 65, anamorphic widescreen 2.39:1 aspect ratio, "
            "shallow depth of field with creamy bokeh separation, naturalistic color science with subtle "
            "teal-and-orange color grade, atmospheric haze volumetrics, production-quality practical lighting "
            "augmented with motivated soft fill, Kodak Vision3 500T film emulation grain structure, "
            "IMAX-grade resolution clarity, Cooke S7/i full-frame prime lens characteristics"
        ),
        "realistic": (
            "hyperrealistic photographic rendering, medium format Hasselblad sensor fidelity, "
            "natural available-light photography with physically accurate global illumination, "
            "micro-detail surface texturing with subsurface scattering on organic materials, "
            "true-to-life color reproduction in Rec.2020 wide gamut color space, "
            "professional editorial retouching with preserved skin texture authenticity, "
            "razor-sharp focus plane with optical diffraction-limited resolving power"
        ),
        "anime": (
            "premium Japanese animation aesthetic, Studio Ghibli-inspired hand-painted background art "
            "with luminous watercolor washes, expressive cel-shaded character rendering with dynamic "
            "line weight variation, Makoto Shinkai-level atmospheric light scattering and god-ray effects, "
            "saturated jewel-tone palette with deliberate complementary color harmonies, "
            "fluid sakuga-quality motion design sensibility, ultra-detailed environmental storytelling"
        ),
        "cartoon": (
            "premium feature animation style, Pixar-tier character design with appeal and specificity, "
            "bold clean vector outlines with variable stroke weight expressing depth and energy, "
            "saturated high-chroma palette with deliberate limited color harmony per scene, "
            "exaggerated squash-and-stretch anticipation in pose design, "
            "stylized yet readable environmental design with clear visual hierarchy, "
            "Disney-quality production polish with every frame exhibition-worthy"
        ),
        "3d_render": (
            "photorealistic 3D CGI rendering, path-traced global illumination with unlimited bounces, "
            "physically based rendering materials with measured BRDF profiles, "
            "Pixar RenderMan or Chaos V-Ray production-quality output, 8K texture resolution, "
            "volumetric atmospheric scattering with density-mapped fog and god rays, "
            "subsurface scattering on all organic surfaces, micro-displacement geometric detail, "
            "Academy Award VFX-nominee visual fidelity standard"
        ),
        "watercolor": (
            "master-level traditional watercolor painting, wet-on-wet bleeding pigment diffusion "
            "with controlled granulation on cold-press Arches paper texture, transparent luminous glazing "
            "layered over preserved white paper highlights, deliberate lost-and-found edge treatment "
            "guiding the viewer's eye, calligraphic brushwork with visible gesture and confidence, "
            "limited palette color mixing producing harmonious chromatic grays, "
            "museum-quality fine art presentation with archival pigment depth"
        ),
        "oil_painting": (
            "classical oil painting technique referencing Dutch Golden Age mastery, "
            "impasto textural brushwork with visible directional palette knife strokes, "
            "chiaroscuro light-and-shadow modeling with Rembrandt-quality dramatic illumination, "
            "rich glazed color layering producing luminous depth and optical color mixing, "
            "museum-quality fine art composition following golden ratio and rule of thirds, "
            "old master varnish warmth with craquelure patina aging characteristics"
        ),
        "pencil_sketch": (
            "professional concept art pencil illustration, confident gestural line work with "
            "varying graphite hardness from 6H architectural precision to 8B expressive shading, "
            "cross-hatching tonal rendering with ambient occlusion shadow mapping, "
            "anatomically precise figure drawing with dynamic contrapposto posing, "
            "environmental perspective drawing with atmospheric aerial perspective fading, "
            "Syd Mead-level industrial design sensibility with Craig Mullins painterly looseness"
        ),
        "dark_fantasy": (
            "dark fantasy art direction, Beksinski-inspired biomechanical surrealism merged with "
            "Frazetta heroic composition, desaturated earth-tone palette with selective blood-crimson "
            "and molten-gold accent highlights, dramatic chiaroscuro rim lighting from below, "
            "mist-shrouded atmospheric perspective with particulate volumetrics, "
            "weathered textural surfaces with patina, rust, and organic decay detail, "
            "epic-scale environmental scope with diminishing figure placement for grandeur"
        ),
        "noir": (
            "classic film noir cinematography, high-contrast black-and-white with selective "
            "desaturated color accent elements, Venetian blind shadow patterns and angular "
            "hard-light key with minimal fill creating deep noir shadows, "
            "expressionist Dutch angle composition with leading shadow lines, "
            "wet cobblestone reflections doubling neon signage, "
            "1940s detective aesthetic with fedora silhouettes and cigarette smoke wisps, "
            "grain-heavy Tri-X 400 pushed to 1600 ISO film stock emulation"
        ),
        "cyberpunk": (
            "cyberpunk neo-Tokyo aesthetic, Blade Runner 2049-level production design, "
            "rain-soaked megacity environment with holographic advertisement pollution, "
            "neon-drenched palette dominated by electric cyan, hot magenta, and acid yellow, "
            "volumetric fog refracting artificial light sources through atmospheric haze, "
            "high-tech low-life juxtaposition with chrome and grime surface contrasts, "
            "Syd Mead futurism meets Moebius graphic novel illustration density, "
            "Roger Deakins-inspired compositional precision with motivated practical lighting"
        ),
        "vintage_film": (
            "vintage 1970s Kodachrome film photography aesthetic, warm amber-shifted color cast "
            "with lifted shadow blacks and compressed highlight roll-off, heavy organic film grain "
            "with halation bloom on bright highlights, slight vignetting on frame edges, "
            "period-authentic costume and production design detail, "
            "Vilmos Zsigmond or Gordon Willis-inspired naturalistic cinematography, "
            "anamorphic oval bokeh with subtle blue lens flare streaks"
        ),
        "epic_cinematic": (
            "epic cinematic blockbuster aesthetic, shot on IMAX 70mm with extreme resolution clarity, "
            "sweeping aerial establishing shots with monumental scale composition, "
            "Hans Zimmer-level dramatic intensity in every frame, ultra-wide anamorphic 2.76:1, "
            "golden-hour volumetric god rays with atmospheric haze, massive depth of field "
            "revealing layered landscape details, Zack Snyder slow-motion heroic framing, "
            "Christopher Nolan IMAX practical-effects realism, Dolby Vision HDR contrast range, "
            "thunderous visual weight with every element placed for maximum dramatic impact"
        ),
        "horror": (
            "psychological horror cinematography, desaturated sickly color palette with "
            "green-grey undertones and deep impenetrable shadows, jump-scare anticipation framing "
            "with negative space hiding threats, Dutch angle destabilization, "
            "underlighting casting distorted upward shadows on faces, "
            "flickering unstable practical light sources, shallow depth of field with "
            "soft menacing background blur, grain-heavy low-light film stock emulation, "
            "James Wan tension composition with Ari Aster unsettling symmetry, "
            "atmospheric fog and particulate darkness creating claustrophobic dread"
        ),
        "thriller": (
            "neo-thriller cinematography, cold blue-steel color palette with selective warm accents, "
            "precise David Fincher framing with obsessive symmetry and geometric composition, "
            "motivated hard-edged lighting creating sharp shadow lines, "
            "shallow depth of field rack-focusing between subjects building tension, "
            "handheld micro-tremor adding subliminal unease, clean modern production design "
            "with clinical sterile environments, high-contrast ratio 6:1 with crushed blacks, "
            "digital intermediate color grade with teal shadows and amber highlights, "
            "Sicario-level atmospheric tension in every compositional choice"
        ),
        "cartoon_classic": (
            "classic 2D hand-drawn animation style, bold clean ink outlines with expressive "
            "variable line weight, flat vibrant color fills with limited cel-shading, "
            "exaggerated character proportions with large eyes and dynamic poses, "
            "Looney Tunes and classic Disney hand-painted background art quality, "
            "squash-and-stretch animation principles visible in pose design, "
            "nostalgic Saturday-morning cartoon warmth with modern color vibrancy, "
            "clean vector-quality line art with hand-crafted charm and appeal"
        ),
        "ghibli": (
            "Studio Ghibli hand-painted animation masterwork, luminous watercolor background art "
            "with breathtaking environmental detail and lived-in world authenticity, "
            "Hayao Miyazaki character design with warmth and gentle expressiveness, "
            "soft natural lighting with golden-hour atmospheric glow, lush green nature palette "
            "with jewel-tone accent colors, hand-painted cloud formations with volumetric depth, "
            "magical realism blending everyday beauty with fantastical wonder, "
            "Kazuo Oga-level background painting mastery with every leaf individually rendered, "
            "Joe Hisaishi musical atmosphere translated into visual serenity and emotional depth"
        ),
        "2d_animation": (
            "professional 2D digital animation, clean vector line art with confident stroke weight "
            "variation expressing form and depth, flat color design with strategic cel-shading, "
            "modern motion graphics sensibility with anime-influenced character design, "
            "Cartoon Saloon and Castlevania-tier production quality, "
            "dynamic action poses with strong silhouette readability, "
            "rich background illustration with layered parallax depth planes, "
            "vibrant saturated palette with intentional limited color harmony per scene"
        ),
        "3d_stylized": (
            "stylized 3D animation aesthetic, Pixar and DreamWorks character appeal with "
            "exaggerated proportions and expressive features, smooth subsurface scattering skin, "
            "stylized hair simulation with art-directed flow and bounce, "
            "painterly global illumination with warm bounced light, "
            "production-quality fur and fabric simulation, oversized expressive eyes "
            "with detailed iris caustics, appealing silhouette design, "
            "Into the Spider-Verse art-directed rendering with visible artistic intention, "
            "Pixar short-film level polish with every surface material lovingly crafted"
        ),
        "3d_realistic": (
            "ultra-photorealistic 3D rendering, Unreal Engine 5 Nanite and Lumen quality, "
            "physically accurate global illumination with real-time ray tracing, "
            "8K PBR textures with micro-surface detail on every material, "
            "photogrammetry-grade environmental scanning fidelity, "
            "volumetric atmospheric rendering with physically accurate light scattering, "
            "digital human-level character rendering with pore-level skin detail, "
            "strand-based hair simulation with individual fiber rendering, "
            "HDRI environment lighting with accurate shadow penumbra softness, "
            "indistinguishable from live-action photography at first glance"
        ),
        "comic_book": (
            "graphic novel and comic book illustration style, bold black ink outlines with "
            "dynamic cross-hatching shadow rendering, Ben-Day dot halftone pattern shading, "
            "dramatic panel composition with Dutch angles and extreme perspectives, "
            "high-saturation limited palette of primary and secondary colors, "
            "speed lines and motion blur indicating kinetic energy, "
            "Frank Miller and Jim Lee-inspired dramatic figure drawing, "
            "speech-bubble-ready compositions with clear focal hierarchy, "
            "Marvel and DC Comics production-quality illustration density"
        ),
        "steampunk": (
            "Victorian steampunk aesthetic, brass and copper mechanical detail with "
            "intricate clockwork gearing and steam-powered machinery, "
            "warm sepia-amber color palette with patinated metal green-copper accents, "
            "gas-lamp golden lighting with warm volumetric steam and smoke, "
            "ornate Victorian architecture with industrial mechanical augmentation, "
            "leather and riveted metal surface textures, analog gauge and dial details, "
            "Jules Verne-inspired retro-futuristic technology design, "
            "daguerreotype photography quality with vignette framing"
        ),
        "fantasy_epic": (
            "high fantasy epic art direction, Lord of the Rings WETA Workshop production design, "
            "sweeping mythical landscapes with impossible scale and grandeur, "
            "rich jewel-tone palette of deep blues, emerald greens, and burnished golds, "
            "dramatic Rembrandt lighting with volumetric god-ray atmospherics, "
            "ornate medieval-fantasy costume and armor design with hand-forged detail, "
            "magical luminescence effects with particle-based spell casting, "
            "Alan Lee and John Howe concept art sensibility translated to photorealistic rendering, "
            "epic scope with diminished human figures against colossal environments"
        ),
        "documentary": (
            "documentary filmmaking aesthetic, naturalistic handheld camera presence with "
            "authentic available-light photography, Super 16mm or digital cinema verite style, "
            "earth-tone neutral color palette with minimal color grading, "
            "observational framing that captures candid authentic moments, "
            "shallow depth of field isolating subjects from environment, "
            "natural skin tones with preserved texture and imperfections, "
            "Ken Burns-level archival photography composition, "
            "Werner Herzog raw authenticity with Frederick Wiseman observational patience"
        ),
        "stop_motion": (
            "stop-motion animation aesthetic, Laika Studios production quality with "
            "visible handcrafted miniature set detail and tactile material textures, "
            "slightly imperfect frame-by-frame motion quality adding organic charm, "
            "real fabric and felt material costumes with stitching visible, "
            "miniature practical lighting with warm tungsten color temperature, "
            "forced-perspective miniature environments with tilt-shift depth of field, "
            "Wes Anderson symmetrical composition with dollhouse-like set design, "
            "Coraline and Kubo-level production craft with visible artistic intention"
        )
    }

    # ══════════════════════════════════════════════════════════════════
    # CAMERA MOVEMENT LIBRARY
    # ══════════════════════════════════════════════════════════════════
    CAMERA_MOVEMENTS = {
        "establishing": [
            "slow aerial crane ascending to reveal the full scope of the environment",
            "wide static locked-off master shot holding for beat, allowing environment to breathe",
            "gradual pull-back from subject to vast landscape establishing scale",
            "steady Steadicam orbit circling the central subject at medium distance"
        ],
        "intimate": [
            "gentle handheld close-up with subtle breathing motion, documentary-intimate presence",
            "slow push-in dolly from medium shot to tight close-up",
            "rack focus pull from foreground element to subject's eyes",
            "static extreme close-up with shallow depth isolating expression"
        ],
        "dynamic": [
            "tracking dolly running parallel with subject movement, matching velocity",
            "whip pan transitioning between subjects with motion-blur speed",
            "Steadicam following-shot behind subject moving through environment",
            "crane jib sweeping from low angle ascending to high angle"
        ],
        "tension": [
            "imperceptibly slow creep zoom tightening frame, building subliminal unease",
            "Dutch angle tilt with slight handheld tremor, destabilizing equilibrium",
            "contra-zoom Vertigo effect dollying out while zooming in",
            "static locked frame with subject approaching from deep background"
        ],
        "contemplative": [
            "ultra-slow lateral dolly gliding past environmental details, meditative",
            "gentle tilt from ground-level detail upward to reveal sky",
            "static wide composition with subject small within vast space",
            "slow-motion capture at 120fps with drifting minimal camera movement"
        ],
        "triumphant": [
            "sweeping crane ascending from ground to bird's-eye revealing achievement",
            "hero-angle low camera tilting up at subject against dramatic sky",
            "circular Steadicam orbit tightening around subject, building energy",
            "dramatic pull-back reveal from detail to grand vista"
        ]
    }

    # ══════════════════════════════════════════════════════════════════
    # LIGHTING SETUPS
    # ══════════════════════════════════════════════════════════════════
    LIGHTING_SETUPS = {
        "peaceful": "soft diffused overcast daylight, low contrast 2:1, 5600K neutral",
        "tense": "harsh single-source hard key creating deep angular shadows, 8:1 contrast, cold 7500K",
        "joyful": "warm golden-hour backlight with lens flare, 3200K amber key with soft wraparound fill",
        "sad": "flat overcast ambient with desaturated cool tones, grey-green color cast",
        "mysterious": "low-key chiaroscuro with pools of motivated practical light in darkness",
        "angry": "aggressive red-shifted practical lighting with hard shadows and hot specular highlights",
        "fearful": "underlighting casting distorted upward shadows, flickering unstable light source",
        "romantic": "candlelit warmth at 2200K with soft diffusion, gentle backlighting hair light halo",
        "epic": "dramatic Rembrandt lighting with volumetric god rays, theatrical motivated light",
        "neutral": "balanced three-point studio lighting, 5000K neutral daylight key",
        "hopeful": "dawn light breaking through clouds with crepuscular rays, gradually brightening",
        "melancholic": "late autumn afternoon light with long shadows, amber-tinged but fading"
    }

    EMOTION_DIRECTION = {
        "peaceful": {
            "pacing": "measured and unhurried, contemplative weight",
            "color": "muted pastoral palette of sage greens, powder blues, warm cream",
            "composition": "balanced symmetrical framing with generous negative space"
        },
        "tense": {
            "pacing": "accelerating rhythm with shortened visual beats",
            "color": "desaturated cool palette with harsh fluorescent undertones",
            "composition": "asymmetrical off-center framing with tight headroom"
        },
        "joyful": {
            "pacing": "buoyant energetic rhythm with dynamic variety",
            "color": "saturated warm spectrum of sunflower yellows, coral oranges, sky blues",
            "composition": "open expansive framing with upward diagonal lines"
        },
        "sad": {
            "pacing": "slow deliberate rhythm with extended holds",
            "color": "cool desaturated palette of slate grays, muted indigos",
            "composition": "isolated subject placement with oppressive negative space"
        },
        "mysterious": {
            "pacing": "deliberately withheld reveals with shadow-dominant frames",
            "color": "deep jewel tones of midnight blue, emerald, burgundy",
            "composition": "partially obscured subjects with foreground occlusion"
        },
        "epic": {
            "pacing": "grand sweeping rhythm building to overwhelming crescendo",
            "color": "rich saturated cinematic palette with theatrical contrast",
            "composition": "monumental scale framing with diminished human figures"
        },
        "romantic": {
            "pacing": "gentle flowing rhythm with soft dissolve transitions",
            "color": "warm rosy palette of blush pinks, golden ambers, soft lavender",
            "composition": "two-shot framing with shallow depth isolating subjects"
        },
        "fearful": {
            "pacing": "irregular jarring rhythm with sudden visual disruptions",
            "color": "sickly yellow-green undertones with deep impenetrable shadows",
            "composition": "distorted wide-angle with looming foreground elements"
        }
    }

    # ══════════════════════════════════════════════════════════════════
    # CINEMATIC STYLE REFERENCES FOR CHARACTER PORTRAITS
    # ══════════════════════════════════════════════════════════════════

    GENRE_STYLE_MAP = {
        "fantasy": (
            "- Warriors/knights → 'Lord of the Rings WETA Workshop cinematic style'\n"
            "- Creatures/beasts → 'Kong Skull Island cinematic style'\n"
            "- Wizards/mages → 'Harry Potter cinematic style'\n"
            "- Dark creatures → 'Pan's Labyrinth cinematic style'"
        ),
        "sci-fi": (
            "- Human characters → 'Blade Runner 2049 cinematic style'\n"
            "- Robots/androids → 'Ex Machina cinematic style'\n"
            "- Aliens → 'Arrival cinematic style'\n"
            "- Soldiers → 'Aliens cinematic style'"
        ),
        "horror": (
            "- Human characters → 'David Fincher cinematic style'\n"
            "- Monsters → 'The Ritual cinematic style'\n"
            "- Supernatural beings → 'Hereditary cinematic style'"
        ),
        "action": (
            "- Warriors/fighters → 'Mad Max Fury Road cinematic style'\n"
            "- Soldiers → 'Black Hawk Down cinematic style'\n"
            "- Martial artists → 'John Wick cinematic style'"
        ),
        "drama": (
            "- Modern humans → 'David Fincher cinematic style'\n"
            "- Period characters → 'The Revenant cinematic style'\n"
            "- Emotional portraits → 'Roger Deakins cinematic style'"
        ),
        "anime": (
            "- All characters → 'Makoto Shinkai cinematic style'\n"
            "- Action characters → 'Attack on Titan cinematic style'\n"
            "- Fantasy characters → 'Studio Ghibli cinematic style'"
        )
    }

    DEFAULT_STYLE_REF = (
        "- Human characters → 'David Fincher cinematic style, photorealistic'\n"
        "- Creatures/beasts → 'Kong Skull Island cinematic style'\n"
        "- Fantasy beings → 'Lord of the Rings WETA Workshop cinematic style'\n"
        "- Sci-fi characters → 'Blade Runner 2049 cinematic style'\n"
        "Choose the MOST fitting reference for each character."
    )

    # ══════════════════════════════════════════════════════════════════
    # UTILITY METHODS
    # ══════════════════════════════════════════════════════════════════

    @staticmethod
    def _clean_and_parse_json(raw_response: str, sdk_parser=None) -> Any:
        """Robustly extract and parse JSON from AI responses.

        Handles all common AI response formats:
        - Clean JSON
        - JSON wrapped in ```json ... ``` markdown fences
        - JSON wrapped in ``` ... ``` fences
        - JSON with leading/trailing prose text
        - JSON arrays and objects

        Args:
            raw_response: Raw string from AI
            sdk_parser: Optional mexflow.ai.parse_json function

        Returns:
            Parsed dict/list or None on failure
        """
        if not raw_response:
            return None

        text = raw_response.strip()

        # ── Step 1: Strip markdown code fences ──
        # Handle ```json ... ``` and ``` ... ```
        if text.startswith("```"):
            # Remove opening fence (```json or ```)
            first_newline = text.find("\n")
            if first_newline > 0:
                text = text[first_newline + 1:]
            else:
                text = text[3:]
            # Remove closing fence
            if text.rstrip().endswith("```"):
                text = text.rstrip()
                text = text[:-3].rstrip()

        text = text.strip()

        # ── Step 2: Try SDK parser first (it may handle edge cases) ──
        if sdk_parser:
            try:
                result = sdk_parser(text)
                if result is not None:
                    return result
            except Exception:
                pass

        # ── Step 3: Try direct json.loads ──
        try:
            return json.loads(text)
        except (json.JSONDecodeError, ValueError):
            pass

        # ── Step 4: Extract JSON object/array from surrounding text ──
        # Find the first { or [ and match to the last } or ]
        obj_start = text.find("{")
        arr_start = text.find("[")

        if obj_start == -1 and arr_start == -1:
            return None

        # Pick whichever comes first
        if arr_start != -1 and (obj_start == -1 or arr_start < obj_start):
            # Array
            start = arr_start
            end = text.rfind("]")
            if end > start:
                try:
                    return json.loads(text[start:end + 1])
                except (json.JSONDecodeError, ValueError):
                    pass
        else:
            # Object
            start = obj_start
            end = text.rfind("}")
            if end > start:
                try:
                    return json.loads(text[start:end + 1])
                except (json.JSONDecodeError, ValueError):
                    pass

        # ── Step 5: Try SDK parser on original response as last resort ──
        if sdk_parser:
            try:
                result = sdk_parser(raw_response)
                if result is not None:
                    return result
            except Exception:
                pass

        return None

    @staticmethod
    def _parse_durations(raw: str) -> List[int]:
        """Parse comma-separated duration string into sorted list of ints."""
        try:
            durations = []
            for part in raw.replace(" ", "").split(","):
                if part.strip():
                    val = int(part.strip())
                    if val > 0:
                        durations.append(val)
            return sorted(list(set(durations)))
        except (ValueError, TypeError):
            return []

    @staticmethod
    def _snap_to_allowed_duration(duration: float, allowed: List[int]) -> int:
        """Snap a raw duration to the nearest allowed value."""
        if not allowed:
            allowed = [5, 10, 15]
        best = allowed[0]
        best_diff = abs(duration - best)
        for d in allowed:
            diff = abs(duration - d)
            if diff < best_diff:
                best = d
                best_diff = diff
        return int(best)

    @staticmethod
    def _snap_duration_ceil(duration: float, allowed: List[int]) -> int:
        """Snap duration to the smallest allowed value that COVERS the audio segment.
        Falls back to nearest if all allowed values are smaller than duration."""
        if not allowed:
            allowed = [5, 10, 15]
        # Find smallest allowed duration >= raw duration
        candidates = [d for d in allowed if d >= duration]
        if candidates:
            return min(candidates)
        # All allowed are smaller — use the largest
        return max(allowed)

    @staticmethod
    def _fuzzy_match_character_name(query: str, known_names: List[str]) -> Optional[str]:
        """Fuzzy-match a character name against known names.
        Handles case differences, partial matches, and minor AI variations."""
        if not query or not known_names:
            return None
        query_clean = query.strip().lower()
        # Exact match (case-insensitive)
        for name in known_names:
            if name.strip().lower() == query_clean:
                return name
        # Substring match — query contains known name or vice versa
        for name in known_names:
            name_lower = name.strip().lower()
            if name_lower in query_clean or query_clean in name_lower:
                return name
        # Word overlap — at least 2 significant words match
        query_words = set(re.sub(r'[^a-z0-9\s]', '', query_clean).split())
        query_words -= {'the', 'a', 'an', 'of', 'and', 'in', 'on', 'at', 'to', 'for'}
        for name in known_names:
            name_words = set(re.sub(r'[^a-z0-9\s]', '', name.strip().lower()).split())
            name_words -= {'the', 'a', 'an', 'of', 'and', 'in', 'on', 'at', 'to', 'for'}
            overlap = query_words & name_words
            if len(overlap) >= 2 or (len(overlap) >= 1 and len(name_words) == 1):
                return name
        return None

    def _allocate_synced_durations(
        self,
        scene_audio_starts: List[float],
        scene_audio_ends: List[float],
        allowed_durations: List[int],
        total_audio_duration: float
    ) -> List[int]:
        """Allocate scene durations that keep cumulative video time synchronized
        with actual audio timestamps. This is the KEY to audio-video sync.

        Algorithm:
        1. For each scene, compute the ideal video start time (= audio start time)
        2. The duration of each scene = next_scene_audio_start - this_scene_audio_start
        3. Snap each duration to an allowed value using a drift-aware strategy:
           - Track cumulative video time vs cumulative audio time
           - If video is running AHEAD, prefer ceiling snap (longer duration)
           - If video is running BEHIND, prefer floor snap (shorter duration)
        4. Final scene extends to cover remaining audio
        """
        n = len(scene_audio_starts)
        if n == 0:
            return []
        if n == 1:
            raw = max(scene_audio_ends[0] - scene_audio_starts[0], min(allowed_durations))
            return [self._snap_duration_ceil(raw, allowed_durations)]

        durations = []
        cumulative_video_time = 0.0

        for i in range(n):
            # Calculate raw segment duration from audio timestamps
            if i < n - 1:
                raw_dur = scene_audio_starts[i + 1] - scene_audio_starts[i]
            else:
                # Last scene: cover from start to end of its audio
                raw_dur = scene_audio_ends[i] - scene_audio_starts[i]
                # Ensure it covers any remaining audio
                remaining_audio = total_audio_duration - cumulative_video_time
                raw_dur = max(raw_dur, remaining_audio)

            # Ensure minimum meaningful duration
            raw_dur = max(raw_dur, min(allowed_durations) * 0.5)

            # Drift-aware snapping
            audio_target = scene_audio_starts[i]  # Where audio expects this scene to start
            drift = cumulative_video_time - audio_target  # Positive = video ahead, negative = behind

            if abs(drift) < 0.5:
                # Within tolerance — snap normally
                snapped = self._snap_to_allowed_duration(raw_dur, allowed_durations)
            elif drift > 0:
                # Video is running AHEAD — prefer shorter duration to let audio catch up
                floor_candidates = [d for d in allowed_durations if d <= raw_dur]
                if floor_candidates:
                    snapped = max(floor_candidates)
                else:
                    snapped = min(allowed_durations)
            else:
                # Video is running BEHIND — prefer longer duration to let video catch up
                snapped = self._snap_duration_ceil(raw_dur, allowed_durations)

            durations.append(snapped)
            cumulative_video_time += snapped

        # Final check: ensure total video duration >= total audio duration
        total_video = sum(durations)
        while total_video < total_audio_duration:
            # Extend the last scene
            current_last = durations[-1]
            bigger = [d for d in allowed_durations if d > current_last]
            if bigger:
                durations[-1] = min(bigger)
            else:
                # Add a padding scene duration
                durations.append(min(allowed_durations))
            total_video = sum(durations)

        return durations

    def _split_subtitle_into_scenes(
        self,
        subtitle_data: List[Dict],
        allowed_durations: List[int],
        audio_duration: float,
        required_scene_count: int
    ) -> List[Dict]:
        """Split subtitle words into scene segments based on ACTUAL TIMESTAMPS.

        This is the critical synchronization method. Instead of asking the AI
        to split text (which causes drift), we split using word-level timestamps
        from the transcription engine.

        Algorithm:
        1. Calculate scene time boundaries from allowed durations
           (Scene 1 = 0–6s, Scene 2 = 6–12s, etc.)
        2. For each scene's time window, find all words whose midpoint
           falls within that window
        3. Snap split points to the nearest sentence/clause boundary
           within ±3 words to avoid mid-sentence cuts
        4. Return segments with exact voiceover text and timestamps

        Returns list of dicts:
        {
            "voiceover": str,        # exact words for this scene
            "start_time": float,     # audio start (first word)
            "end_time": float,       # audio end (last word)
            "duration": int,         # scene duration from allowed_durations
            "word_start_idx": int,   # index in subtitle_data
            "word_end_idx": int,     # index in subtitle_data (inclusive)
        }
        """
        if not subtitle_data or required_scene_count == 0:
            return []

        total_words = len(subtitle_data)
        min_dur = min(allowed_durations) if allowed_durations else 5

        # ── Step 1: Determine scene durations and time boundaries ──
        # Greedily assign scene durations to cover the full audio
        scene_durations = []
        remaining = audio_duration

        for i in range(required_scene_count):
            if i == required_scene_count - 1:
                # Last scene: must cover all remaining audio
                dur = self._snap_duration_ceil(remaining, allowed_durations)
            else:
                # Split remaining time evenly for remaining scenes
                avg_remaining = remaining / (required_scene_count - i)
                dur = self._snap_to_allowed_duration(avg_remaining, allowed_durations)
            scene_durations.append(dur)
            remaining -= dur
            if remaining < 0:
                remaining = 0

        # Ensure total covers audio
        total_video = sum(scene_durations)
        while total_video < audio_duration:
            # Extend last scene or add one
            current_last = scene_durations[-1]
            bigger = [d for d in allowed_durations if d > current_last]
            if bigger:
                scene_durations[-1] = min(bigger)
            else:
                scene_durations.append(min_dur)
            total_video = sum(scene_durations)

        # Build time boundaries
        # Scene 1: [0, dur1), Scene 2: [dur1, dur1+dur2), ...
        scene_boundaries = []
        cumulative = 0.0
        for dur in scene_durations:
            scene_boundaries.append((cumulative, cumulative + dur))
            cumulative += dur

        print(f"[SPLIT] Scene durations: {scene_durations}")
        print(f"[SPLIT] Scene boundaries: {[(round(s,1), round(e,1)) for s,e in scene_boundaries]}")
        print(f"[SPLIT] Total video: {sum(scene_durations)}s | Audio: {round(audio_duration,1)}s")

        # ── Step 2: Assign words to scenes by their timestamp midpoint ──
        # Each word goes to whichever scene's time window contains its midpoint
        word_scene_assignment = [0] * total_words  # scene index for each word

        for w_idx in range(total_words):
            word = subtitle_data[w_idx]
            w_start = word.get("start", 0)
            w_end = word.get("end", w_start + 0.1)
            w_mid = (w_start + w_end) / 2.0

            # Find which scene this word's midpoint falls into
            assigned = len(scene_boundaries) - 1  # default to last scene
            for s_idx, (s_start, s_end) in enumerate(scene_boundaries):
                if w_mid < s_end:
                    assigned = s_idx
                    break
            word_scene_assignment[w_idx] = assigned

        # ── Step 3: Find raw split points and snap to sentence boundaries ──
        # Raw split points: where scene assignment changes
        raw_splits = [0]  # first segment always starts at word 0
        for w_idx in range(1, total_words):
            if word_scene_assignment[w_idx] != word_scene_assignment[w_idx - 1]:
                raw_splits.append(w_idx)

        # Ensure we have exactly len(scene_durations) segments
        # Add final endpoint
        raw_splits.append(total_words)

        # If we have fewer splits than needed, subdivide the largest segment
        while len(raw_splits) - 1 < len(scene_durations):
            # Find largest segment and split it in half
            max_size = 0
            max_idx = 0
            for i in range(len(raw_splits) - 1):
                size = raw_splits[i + 1] - raw_splits[i]
                if size > max_size:
                    max_size = size
                    max_idx = i
            mid = raw_splits[max_idx] + max_size // 2
            raw_splits.insert(max_idx + 1, mid)

        # If we have more splits than needed, merge smallest adjacent segments
        while len(raw_splits) - 1 > len(scene_durations):
            min_size = float('inf')
            min_idx = 0
            for i in range(len(raw_splits) - 2):
                size = raw_splits[i + 1] - raw_splits[i]
                if size < min_size:
                    min_size = size
                    min_idx = i
            raw_splits.pop(min_idx + 1)

        # Snap each split point to the nearest sentence or clause boundary (±5 words)
        SNAP_RANGE = 5
        snapped_splits = [raw_splits[0]]  # always start at 0

        for sp_idx in range(1, len(raw_splits) - 1):
            raw_sp = raw_splits[sp_idx]
            best_sp = raw_sp
            best_score = -1  # higher is better

            search_lo = max(raw_splits[sp_idx - 1] + 1, raw_sp - SNAP_RANGE)
            search_hi = min(raw_splits[sp_idx + 1] if sp_idx + 1 < len(raw_splits) else total_words,
                           raw_sp + SNAP_RANGE + 1)

            for candidate in range(search_lo, search_hi):
                if candidate <= 0 or candidate >= total_words:
                    continue
                prev_word = (subtitle_data[candidate - 1].get("word", "")
                             or subtitle_data[candidate - 1].get("text", ""))

                # Score: sentence boundary = 10, clause boundary = 5,
                # natural pause (>300ms gap) = 3, proximity to raw = 1
                score = 0
                if self._detect_sentence_boundary(prev_word):
                    score += 10
                elif self._detect_clause_boundary(prev_word):
                    score += 5

                # Check for natural pause between words
                if candidate < total_words:
                    prev_end = subtitle_data[candidate - 1].get("end", 0)
                    next_start = subtitle_data[candidate].get("start", 0)
                    pause = next_start - prev_end
                    if pause > 0.3:
                        score += 3
                    elif pause > 0.15:
                        score += 1

                # Prefer staying close to the raw split
                distance = abs(candidate - raw_sp)
                score -= distance * 0.5  # small penalty for distance

                if score > best_score:
                    best_score = score
                    best_sp = candidate

            snapped_splits.append(best_sp)

        snapped_splits.append(raw_splits[-1])  # always end at total_words

        # ── Step 4: Build segments ──
        segments = []
        for i in range(len(snapped_splits) - 1):
            w_start_idx = snapped_splits[i]
            w_end_idx = snapped_splits[i + 1]  # exclusive

            if w_start_idx >= w_end_idx:
                # Empty segment — skip or give it empty voiceover
                dur = scene_durations[i] if i < len(scene_durations) else min_dur
                prev_end = segments[-1]["end_time"] if segments else 0
                segments.append({
                    "voiceover": "",
                    "start_time": prev_end,
                    "end_time": prev_end,
                    "duration": dur,
                    "word_start_idx": w_start_idx,
                    "word_end_idx": w_start_idx,
                })
                continue

            seg_words = subtitle_data[w_start_idx:w_end_idx]

            voiceover = " ".join(
                (w.get("word", "") or w.get("text", "")) for w in seg_words
            ).strip()

            seg_start = seg_words[0].get("start", 0)
            seg_end = seg_words[-1].get("end", seg_words[-1].get("start", 0) + 0.2)

            dur = scene_durations[i] if i < len(scene_durations) else min_dur

            segments.append({
                "voiceover": voiceover,
                "start_time": round(seg_start, 3),
                "end_time": round(seg_end, 3),
                "duration": dur,
                "word_start_idx": w_start_idx,
                "word_end_idx": w_end_idx - 1,  # inclusive
            })

        print(f"[SPLIT] Generated {len(segments)} segments:")
        for i, seg in enumerate(segments):
            word_count = len(seg['voiceover'].split()) if seg['voiceover'] else 0
            print(f"  Scene {i+1}: {seg['start_time']:.1f}s–{seg['end_time']:.1f}s "
                  f"| dur={seg['duration']}s | words={word_count} "
                  f"| text=\"{seg['voiceover'][:60]}...\"")

        return segments

    @staticmethod
    def _detect_sentence_boundary(word: str) -> bool:
        """Check if a word ends at a sentence boundary."""
        cleaned = word.strip()
        return bool(re.search(r'[.!?;:—]$', cleaned)) or bool(re.search(r'[.!?]["\')\]]$', cleaned))

    @staticmethod
    def _detect_clause_boundary(word: str) -> bool:
        """Check if a word ends at a clause boundary."""
        cleaned = word.strip()
        return bool(re.search(r'[,;:\-–—]$', cleaned))

    @staticmethod
    def _calculate_pause_between_words(current_end: float, next_start: float) -> float:
        """Calculate the silence gap between two words."""
        return max(0, next_start - current_end)

    def _categorize_emotion_for_camera(self, emotion: str) -> str:
        """Map an emotion string to a camera movement category."""
        emotion_lower = emotion.lower().strip()
        mapping = {
            "peaceful": "contemplative", "calm": "contemplative", "serene": "contemplative",
            "reflective": "contemplative", "meditative": "contemplative",
            "tense": "tension", "anxious": "tension", "suspenseful": "tension",
            "nervous": "tension", "uneasy": "tension", "dread": "tension",
            "joyful": "dynamic", "excited": "dynamic", "energetic": "dynamic",
            "happy": "dynamic", "celebratory": "triumphant", "triumphant": "triumphant",
            "victorious": "triumphant", "proud": "triumphant",
            "sad": "intimate", "melancholic": "intimate", "grief": "intimate",
            "lonely": "intimate", "vulnerable": "intimate",
            "mysterious": "establishing", "curious": "establishing", "wonder": "establishing",
            "awe": "establishing", "discovery": "establishing",
            "angry": "dynamic", "furious": "dynamic", "rage": "dynamic",
            "fearful": "tension", "terrified": "tension", "horror": "tension",
            "romantic": "intimate", "tender": "intimate", "loving": "intimate",
            "epic": "triumphant", "grand": "triumphant", "majestic": "triumphant",
            "hopeful": "contemplative", "inspiring": "triumphant",
            "neutral": "establishing"
        }
        return mapping.get(emotion_lower, "establishing")

    def _get_genre_style_ref(self, genre: str) -> str:
        """Return cinematic style references for character portraits based on genre."""
        genre_lower = genre.lower() if genre else ""
        for key, val in self.GENRE_STYLE_MAP.items():
            if key in genre_lower:
                return val
        return self.DEFAULT_STYLE_REF

    def _map_voiceover_timing(
        self,
        voiceover_text: str,
        subtitle_data: List[Dict],
        search_start_idx: int = 0
    ) -> Tuple[float, float, int]:
        """
        Given voiceover text, find matching words in subtitle_data
        and return (start_time, end_time, next_search_idx).
        """
        if not voiceover_text or not subtitle_data:
            return (0.0, 0.0, search_start_idx)

        vo_words_raw = voiceover_text.split()
        if not vo_words_raw:
            return (0.0, 0.0, search_start_idx)

        def clean_word(w):
            return re.sub(r'[^a-zA-Z0-9\u0080-\uffff]', '', w.lower()).strip()

        vo_words_clean = [clean_word(w) for w in vo_words_raw]
        vo_words_clean = [w for w in vo_words_clean if w]

        if not vo_words_clean:
            return (0.0, 0.0, search_start_idx)

        first_vo_word = vo_words_clean[0]
        start_time = 0.0
        end_time = 0.0
        match_start_idx = search_start_idx
        found_start = False

        for idx in range(search_start_idx, len(subtitle_data)):
            sub_word = subtitle_data[idx].get("word", "") or subtitle_data[idx].get("text", "")
            sub_word_clean = clean_word(sub_word)
            if sub_word_clean == first_vo_word:
                start_time = subtitle_data[idx].get("start", 0)
                match_start_idx = idx
                found_start = True
                break

        if not found_start:
            if search_start_idx < len(subtitle_data):
                start_time = subtitle_data[search_start_idx].get("start", 0)
                match_start_idx = search_start_idx

        last_vo_word = vo_words_clean[-1]
        end_idx = match_start_idx
        max_scan = min(match_start_idx + len(vo_words_clean) * 2 + 5, len(subtitle_data))

        for idx in range(max_scan - 1, match_start_idx - 1, -1):
            if idx >= len(subtitle_data):
                continue
            sub_word = subtitle_data[idx].get("word", "") or subtitle_data[idx].get("text", "")
            sub_word_clean = clean_word(sub_word)
            if sub_word_clean == last_vo_word:
                end_time = subtitle_data[idx].get("end", subtitle_data[idx].get("start", 0) + 0.3)
                end_idx = idx
                break

        if end_time <= start_time:
            estimated_end_idx = min(match_start_idx + len(vo_words_clean) - 1, len(subtitle_data) - 1)
            end_time = subtitle_data[estimated_end_idx].get("end",
                subtitle_data[estimated_end_idx].get("start", 0) + 0.3
            )
            end_idx = estimated_end_idx

        next_search_idx = end_idx + 1
        return (start_time, end_time, next_search_idx)

    # ══════════════════════════════════════════════════════════════════
    # MAIN EXECUTION — 8-STAGE PIPELINE
    # ══════════════════════════════════════════════════════════════════

    async def execute(self, inputs: Dict[str, Any]) -> TemplateResult:
        """Main execution entry point."""

        # ── Extract all inputs ──
        input_mode = inputs.get("input_mode", "story")
        story_text = inputs.get("story_text", "").strip()
        audio_file = inputs.get("audio_file")
        language = inputs.get("language", "en-US")
        visual_style = inputs.get("visual_style", "cinematic")
        voice_style = inputs.get("voice_style", "neutral")
        add_camera = inputs.get("add_camera_movements", True)
        include_emotions = inputs.get("include_emotions", True)
        aspect_ratio = inputs.get("aspect_ratio", "16:9")
        color_grading = inputs.get("color_grading", "auto")
        narrative_continuity = inputs.get("narrative_continuity", True)
        bg_color = inputs.get("character_bg_color", "#1a5fb4")
        portrait_mode = inputs.get("portrait_mode", "single")

        # ── Parse durations ──
        raw_durations = inputs.get("allowed_durations", "5, 6, 8")
        allowed_durations = self._parse_durations(raw_durations)
        if not allowed_durations:
            return mexflow.result.error(
                "Invalid durations. Provide comma-separated numbers. Example: 5, 6, 8",
                details={"field": "allowed_durations", "received": raw_durations}
            )

        max_duration_mode = inputs.get("max_duration_mode", "auto")
        if max_duration_mode == "auto":
            max_duration = "AUTO"
        else:
            max_duration = int(inputs.get("max_duration_seconds", 120))

        # ── Validate inputs ──
        if input_mode == "story":
            if not story_text:
                return mexflow.result.error(
                    "Please provide story text when using Story Text mode.",
                    details={"field": "story_text"}
                )
        else:
            if not audio_file:
                return mexflow.result.error(
                    "Please provide an audio file when using Direct Audio mode.",
                    details={"field": "audio_file"}
                )

        # ── Setup progress (8 stages) ──
        mexflow.progress.setup(8)

        # ════════════════════════════════════════════════════════════
        # STAGE 1: Configuration Check
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Configuration Check", "Verifying plugin availability...")

        config_issues = []

        if input_mode == "story":
            audio_config = await mexflow.audio_generator.get_config()
            if not audio_config:
                config_issues.append("Audio Generator plugin not configured (required for Story mode)")

        subtitle_config = await mexflow.subtitle_generator.get_config()
        if not subtitle_config:
            config_issues.append("Subtitle Generator plugin not configured")

        if config_issues:
            issue_text = "\n• ".join(config_issues)
            return mexflow.result.error(
                f"Plugin configuration required:\n• {issue_text}\n\nPlease configure in Settings > Default Plugins.",
                details={"missing_plugins": config_issues}
            )

        mexflow.progress.complete_stage("All plugins verified and ready")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 2: Audio Preparation
        # ════════════════════════════════════════════════════════════
        audio_id = None
        audio_duration = 0

        if input_mode == "story":
            mexflow.progress.start_stage("Generating Audio", "Converting narrative text to speech...")

            script_id = await mexflow.audio_script.save(
                script_text=story_text,
                language_code=language,
                status="generated"
            )
            if not script_id:
                return mexflow.result.error("Failed to save audio script")

            audio_result = await mexflow.audio_generator.generate(
                audio_script_id=script_id,
                speaking_rate=1.0
            )
            if not audio_result.get("success"):
                error_msg = audio_result.get("error", "Unknown error")
                warning_msg = audio_result.get("warning", "")
                return mexflow.result.error(
                    f"Audio generation failed: {warning_msg or error_msg}",
                    details={"stage": "audio_generation", "error": error_msg}
                )

            audio_id = audio_result.get("audio_id")
            audio_duration = audio_result.get("duration_seconds", 0)
            mexflow.progress.complete_stage(f"Audio generated — {audio_duration:.1f}s total duration")
        else:
            mexflow.progress.start_stage("Importing Audio", "Processing uploaded audio file...")

            if audio_file:
                if isinstance(audio_file, dict):
                    audio_id = audio_file.get("id") or audio_file.get("audio_id")
                    audio_duration = audio_file.get("duration_seconds", 0)
                elif isinstance(audio_file, str):
                    file_info = mexflow.file.get_file_info(audio_file)
                    if not file_info.get("exists"):
                        return mexflow.result.error(
                            f"Audio file not found: {file_info.get('name', audio_file)}",
                            details={"stage": "audio_import", "file": audio_file}
                        )
                    if file_info.get("type") not in ("audio", "video"):
                        return mexflow.result.error(
                            "Invalid file type. Please select an audio file.",
                            details={"stage": "audio_import", "type": file_info.get("type")}
                        )
                    import_result = await mexflow.file.import_audio(
                        file_input=audio_file, language=language
                    )
                    if not import_result.get("success"):
                        return mexflow.result.error(
                            f"Failed to import audio: {import_result.get('error', 'Unknown')}",
                            details={"stage": "audio_import"}
                        )
                    audio_id = import_result.get("audio_id")
                    audio_duration = import_result.get("duration_seconds", 0)

            if not audio_id:
                return mexflow.result.error("Could not process the uploaded audio file.")
            mexflow.progress.complete_stage(f"Audio imported — {audio_duration:.1f}s")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 3: Subtitle Generation
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Generating Subtitles", "Transcribing audio with word-level timing...")

        lang_code = language.split("-")[0] if "-" in language else language
        subtitle_result = await mexflow.subtitle_generator.generate(
            audio_id=audio_id, language=lang_code
        )
        if not subtitle_result.get("success"):
            error_msg = subtitle_result.get("error", "Unknown error")
            warning_msg = subtitle_result.get("warning", "")
            return mexflow.result.error(
                f"Subtitle generation failed: {warning_msg or error_msg}",
                details={"stage": "subtitle_generation"}
            )

        subtitle_data = subtitle_result.get("subtitle_data", [])
        word_count = subtitle_result.get("word_count", 0)
        if not subtitle_data or word_count == 0:
            return mexflow.result.error(
                "No words detected in audio. Please verify the audio file contains speech."
            )

        # Normalize subtitle data
        normalized_subtitle_data = []
        for item in subtitle_data:
            if isinstance(item, dict):
                normalized = dict(item)
                if 'word' not in normalized and 'text' in normalized:
                    normalized['word'] = normalized['text']
                elif 'word' not in normalized and 'text' not in normalized:
                    continue
                normalized_subtitle_data.append(normalized)

        full_narrative = " ".join(
            (w.get("word", "") or w.get("text", "")) for w in normalized_subtitle_data
        ).strip()

        if not full_narrative:
            return mexflow.result.error("Could not build transcript from subtitle data.")

        # Derive audio duration from subtitles if needed
        if audio_duration <= 0 and normalized_subtitle_data:
            last_word = normalized_subtitle_data[-1]
            audio_duration_from_subs = last_word.get("end", last_word.get("start", 0))
            if audio_duration_from_subs > 0:
                audio_duration = audio_duration_from_subs + 1.5

        mexflow.progress.complete_stage(f"Transcribed {word_count} words with precise timestamps")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 4: AI Narrative Analysis
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage(
            "Analyzing Narrative",
            "Director is analyzing story structure, characters, and emotional arc..."
        )

        # Check for resume
        resume_info = await mexflow.stage.check_resume()
        analysis_data = None
        characters_data = None

        if resume_info:
            await mexflow.stage.resume_from(resume_info['execution_id'])
            stage_name = resume_info.get('stage_name', '')
            if stage_name in ("narrative_analysis", "character_generation", "scene_generation"):
                analysis_data = await mexflow.stage.get("narrative_analysis")
            if stage_name in ("character_generation", "scene_generation"):
                characters_data = await mexflow.stage.get("character_generation")

        if not analysis_data:
            analysis_data = await self._analyze_narrative(
                full_narrative, allowed_durations, max_duration, visual_style
            )
            if not analysis_data:
                return mexflow.result.error(
                    "Failed to analyze narrative. The AI could not parse the story structure."
                )
            await mexflow.stage.save("narrative_analysis", analysis_data)
            char_count = len(analysis_data.get("characters", []))
            print(f"[AUDIO_TEMPLATE][STAGE4] Analysis complete: {char_count} characters extracted")
            print(f"[AUDIO_TEMPLATE][STAGE4] Characters: {[c.get('name','?') for c in analysis_data.get('characters',[])]}")
            mexflow.progress.complete_stage(
                f"Found {char_count} characters, {len(analysis_data.get('key_moments', []))} key moments"
            )
        else:
            char_count = len(analysis_data.get("characters", []))
            print(f"[AUDIO_TEMPLATE][STAGE4] Loaded from checkpoint: {char_count} characters")
            mexflow.progress.complete_stage("Narrative analysis loaded from checkpoint")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 5: Character Portrait Generation
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage(
            "Character Design",
            "Casting Director is crafting character reference portraits..."
        )

        if not characters_data:
            characters_data = await self._generate_character_prompts(
                analysis_data, bg_color, visual_style, portrait_mode
            )
            if not characters_data:
                return mexflow.result.error("Failed to generate character portraits.")
            await mexflow.stage.save("character_generation", characters_data)
            char_portraits = characters_data.get('characters', [])
            print(f"[AUDIO_TEMPLATE][STAGE5] Generated {len(char_portraits)} character portraits")
            for c in char_portraits:
                has_prompt = bool(c.get('image_prompt',''))
                print(f"  -> #{c.get('order',0)} {c.get('name','?')} | has image_prompt={has_prompt} | appearance={c.get('appearance_summary','')[:60]}")
            mexflow.progress.complete_stage(
                f"Designed {len(char_portraits)} character portraits with order numbers"
            )
        else:
            char_portraits = characters_data.get('characters', [])
            print(f"[AUDIO_TEMPLATE][STAGE5] Loaded from checkpoint: {len(char_portraits)} characters")
            mexflow.progress.complete_stage("Character portraits loaded from checkpoint")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ── Calculate required scene count ──
        # Use the average of allowed durations for scene count estimation
        # This gives a balanced split — synced duration algorithm handles fine-tuning
        min_allowed = min(allowed_durations)
        avg_allowed = sum(allowed_durations) / len(allowed_durations)
        if audio_duration > 0:
            # Estimate scene count using average duration for natural pacing
            raw_count = audio_duration / avg_allowed
            required_scene_count = max(1, round(raw_count))
            # Verify: total must cover audio with at least min_allowed per scene
            if required_scene_count * min_allowed < audio_duration:
                required_scene_count = math.ceil(audio_duration / min_allowed)
            required_scene_count = max(required_scene_count, 1)
        else:
            estimated_duration = len(normalized_subtitle_data) / 4.0
            required_scene_count = max(1, math.ceil(estimated_duration / avg_allowed))

        # ════════════════════════════════════════════════════════════
        # STAGE 6: Scene Generation (scene_prompt)
        # ════════════════════════════════════════════════════════════
        style_desc = self.STYLE_PROMPTS.get(visual_style, self.STYLE_PROMPTS["cinematic"])

        mexflow.progress.start_stage(
            "Generating Scenes",
            f"Director is creating {required_scene_count} scenes with image & video prompts..."
        )

        scenes = await self._generate_scene_prompts(
            subtitle_data=normalized_subtitle_data,
            full_narrative=full_narrative,
            audio_duration=audio_duration,
            required_scene_count=required_scene_count,
            allowed_durations=allowed_durations,
            characters_data=characters_data,
            analysis_data=analysis_data,
            style=style_desc,
            visual_style=visual_style,
            add_camera=add_camera,
            include_emotions=include_emotions,
            aspect_ratio=aspect_ratio,
            color_grading=color_grading,
            narrative_continuity=narrative_continuity
        )

        if not scenes:
            return mexflow.result.error("Failed to generate scene prompts.")

        mexflow.progress.complete_stage(f"Generated {len(scenes)} scenes with image & video prompts")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 7: Save Characters + Scenes to Database
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Saving to Project", "Writing characters and scenes to database...")

        await self._save_to_project(characters_data, scenes, bg_color, visual_style, aspect_ratio)

        mexflow.progress.complete_stage(f"Saved {len(characters_data.get('characters', []))} characters + {len(scenes)} scenes")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 8: Finalize
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Finalizing", "Compiling production report...")

        total_duration = sum(s.get("duration", 0) for s in scenes)
        duration_dist = {}
        for s in scenes:
            d = s.get("duration", 0)
            duration_dist[d] = duration_dist.get(d, 0) + 1

        await mexflow.stage.complete()

        mexflow.progress.complete_stage(
            f"Production complete! {len(scenes)} scenes, "
            f"{len(characters_data.get('characters', []))} characters, {total_duration}s total"
        )

        return mexflow.result.success(
            scenes,
            message=f"Successfully created {len(scenes)} scenes with {len(characters_data.get('characters', []))} characters!",
            metadata={
                "scene_count": len(scenes),
                "character_count": len(characters_data.get("characters", [])),
                "audio_duration": audio_duration,
                "total_duration": total_duration,
                "word_count": word_count,
                "input_mode": input_mode,
                "visual_style": visual_style,
                "allowed_durations": allowed_durations,
                "duration_distribution": duration_dist,
                "aspect_ratio": aspect_ratio,
                "audio_id": audio_id
            }
        )

    # ══════════════════════════════════════════════════════════════════
    # NARRATIVE ANALYSIS — Extract characters, arc, key moments
    # ══════════════════════════════════════════════════════════════════

    async def _analyze_narrative(
        self, full_narrative: str, allowed_durations: List[int],
        max_duration, visual_style: str
    ) -> Optional[Dict[str, Any]]:
        """Analyze narration transcript to extract characters, narrative arc, and key moments."""

        max_dur_str = f"{max_duration} seconds (hard limit)" if max_duration != "AUTO" else (
            "AUTO — determine optimal total duration based on narrative complexity"
        )

        prompt = f"""Analyze this narration transcript for a professional cinematic scene breakdown. Your analysis drives an AI image-to-video production pipeline.

NARRATION:
\"\"\"
{full_narrative[:5000]}
\"\"\"

ALLOWED SCENE DURATIONS: {allowed_durations} seconds (each scene must be exactly one of these)
MAXIMUM TOTAL DURATION: {max_dur_str}
VISUAL STYLE: {visual_style}

Perform deep cinematic analysis and return this JSON structure:

{{
    "story_summary": "3-4 sentence comprehensive summary capturing core conflict, emotional journey, and resolution",
    "genre": "specific primary genre (e.g. 'dark fantasy adventure' not just 'fantasy')",
    "mood": "overall emotional tone with progression (e.g. 'begins hopeful, descends into tension, resolves with bittersweet triumph')",
    "setting": "detailed primary setting — geography, architecture, atmosphere, sensory details (60-100 words)",
    "time_period": "time period with visual context (e.g. 'late medieval Europe, circa 1400s — stone castles, muddy roads, candlelit interiors')",
    "narrative_arc": {{
        "act_1_setup": "detailed setup — who, where, what's at stake (40-60 words)",
        "act_2_confrontation": "detailed rising action — conflicts, obstacles, turning points (40-60 words)",
        "act_3_resolution": "detailed resolution — climax, aftermath, final image (40-60 words)"
    }},
    "characters": [
        {{
            "name": "Character Unique Name (MUST be unique — for unnamed characters use descriptive names like 'The Scarred Elder Monk', 'Lantern-Bearing Street Girl')",
            "role": "protagonist/antagonist/supporting/minor",
            "description": "detailed role description — motivations, arc, relationships (30-50 words)",
            "age_estimate": "specific estimated age (e.g. 'mid-30s' not 'adult')",
            "appearance_summary": "CRITICAL for AI image generation: exact hair (color, length, texture, style), face shape and features, skin tone, build/height/posture, clothing head-to-toe with fabric/color/condition, distinctive marks/scars/tattoos, accessories, weapons. Must be 60-100 words and specific enough to regenerate this character identically across dozens of images.",
            "significance": "why this character matters to the story"
        }}
    ],
    "key_moments": [
        {{
            "moment": "vivid description of the key visual moment (30-40 words)",
            "emotional_beat": "specific emotion (e.g. 'dawning realization of betrayal' not just 'surprise')",
            "characters_involved": ["Character Name 1"],
            "suggested_duration": 5,
            "act": 1
        }}
    ],
    "total_scenes_recommended": 8,
    "total_duration_recommended": 50,
    "color_arc": "detailed color progression per act (e.g. 'Act 1: warm ambers → Act 2: desaturated teals → Act 3: deep crimsons returning to gold')",
    "visual_motifs": ["specific recurring visual elements with symbolic meaning"],
    "lighting_arc": "how lighting evolves across the narrative"
}}

Rules:
- suggested_duration for each moment MUST be one of {allowed_durations}
- Sum of all suggested_durations must NOT exceed {max_dur_str}
- Give ALL characters UNIQUE names — never duplicate names
- For unnamed/generic characters, create vivid descriptive unique names
- appearance_summary for every character MUST be 60-100 words with SPECIFIC visual details
- key_moments should cover the full narrative arc
- Extract EVERY character mentioned or implied in the narration"""

        try:
            print(f"[AUDIO_TEMPLATE][ANALYZE] Sending narrative analysis prompt ({len(prompt)} chars)")
            response = await mexflow.ai.generate(prompt, max_tokens=10000)
            print(f"[AUDIO_TEMPLATE][ANALYZE] Raw AI response ({len(response) if response else 0} chars): {repr(response[:300]) if response else 'EMPTY'}")
            data = self._clean_and_parse_json(response, mexflow.ai.parse_json)
            if isinstance(data, dict):
                print(f"[AUDIO_TEMPLATE][ANALYZE] Parsed keys: {list(data.keys())}")
                raw_chars = data.get("characters", [])
                print(f"[AUDIO_TEMPLATE][ANALYZE] Raw characters from AI: {len(raw_chars)} — {[c.get('name','?') for c in raw_chars]}")
            if isinstance(data, dict) and "characters" in data:
                # Ensure every character has a unique name and order number
                seen_names = set()
                for i, char in enumerate(data.get("characters", [])):
                    name = char.get("name", f"Character {i+1}")
                    if name in seen_names:
                        name = f"{name} ({i+1})"
                    seen_names.add(name)
                    char["name"] = name
                    char["order"] = i + 1  # Persistent order number
                print(f"[AUDIO_TEMPLATE][ANALYZE] Final characters: {[(c['name'], c['order']) for c in data['characters']]}")
                return data
            print(f"[AUDIO_TEMPLATE][ANALYZE] FAILED: no 'characters' key in parsed data")
            return None
        except Exception as e:
            print(f"[AUDIO_TEMPLATE][ANALYZE] EXCEPTION: {e}")
            mexflow.progress.error("Narrative Analysis", f"Analysis failed: {str(e)}")
            return None

    # ══════════════════════════════════════════════════════════════════
    # CHARACTER PORTRAIT PROMPT GENERATION
    # ══════════════════════════════════════════════════════════════════

    async def _generate_character_prompts(
        self, analysis: Dict[str, Any], bg_color: str,
        visual_style: str, portrait_mode: str = "single"
    ) -> Optional[Dict[str, Any]]:
        """Generate detailed full-body character portrait image prompts."""

        characters_from_analysis = analysis.get("characters", [])
        char_list_str = "\n".join([
            f"- Character #{c.get('order', i+1)}: {c.get('name', 'Unknown')} "
            f"({c.get('role', '')}) — {c.get('description', '')}, "
            f"Age: {c.get('age_estimate', 'unknown')}, "
            f"Appearance: {c.get('appearance_summary', 'not specified')}"
            for i, c in enumerate(characters_from_analysis)
        ])

        genre = analysis.get("genre", "drama").lower()
        style_refs = self._get_genre_style_ref(genre)

        if portrait_mode == "4panel":
            format_instruction = (
                f"PORTRAIT FORMAT: 4-PANEL CHARACTER REFERENCE SHEET\n\n"
                f"Each image_prompt MUST follow: \"4-panel character reference sheet of "
                f"[FULL CHARACTER DESCRIPTION with cinematic style reference]. "
                f"Top-left: full-body front view. Top-right: left side profile. "
                f"Bottom-left: right side profile. Bottom-right: back view. "
                f"[ALL physical details]. Hyper-sharp 8K photorealistic, cinematic dramatic "
                f"studio lighting, rim light edge separation, every detail visible. "
                f"Solid flat {bg_color} chroma-key background. No gradients.\""
            )
        else:
            format_instruction = (
                f"PORTRAIT FORMAT: SINGLE FULL-BODY FRONT-FACING PORTRAIT\n\n"
                f"Each image_prompt MUST follow: \"Full-body front-facing portrait of "
                f"[FULL CHARACTER DESCRIPTION with cinematic style reference]. "
                f"Centered composition, standing upright, [pose]. "
                f"[ALL physical details]. Hyper-sharp 8K photorealistic, cinematic dramatic "
                f"studio lighting, rim light for clean edge separation. "
                f"Solid flat {bg_color} chroma-key background. No gradients, no shadows.\""
            )

        prompt = f"""Create cinematic full-body character portrait image prompts for these characters.

STORY CONTEXT:
{analysis.get('story_summary', '')}
Genre: {analysis.get('genre', '')}
Setting: {analysis.get('setting', '')}
Time Period: {analysis.get('time_period', '')}
Visual Style: {visual_style}

CHARACTERS TO DESIGN (with their persistent ORDER NUMBERS):
{char_list_str}

BACKGROUND COLOR: {bg_color} (solid flat chroma-key, NO gradients)

{format_instruction}

CINEMATIC STYLE REFERENCES:
{style_refs}

Return this JSON:

{{
    "characters": [
        {{
            "name": "Character Name (MUST match exactly the name above)",
            "order": 1,
            "role": "protagonist/antagonist/supporting/minor",
            "age": "estimated age",
            "build": "body type and stature",
            "appearance_summary": "60-100 word distinctive visual summary for cross-scene reference — include: hair (color/length/texture/style), face shape, eye color, skin tone, build, signature clothing, distinctive marks. Must be unique enough to identify this character in any scene.",
            "image_prompt": "[FULL PORTRAIT PROMPT following the format above. MUST be 100-180 words. Structure: cinematic style reference + full-body head-to-toe description (face features, eye details, skin texture, hair, build, clothing layer by layer, footwear, accessories, weapons, scars/marks) + pose description + quality tags + solid {bg_color} background.]"
        }}
    ]
}}

CRITICAL REQUIREMENTS:
- FULL-BODY always — head to toe visible, NEVER head-and-shoulders only
- ALWAYS include a cinematic style reference matching the genre
- ALWAYS end with quality tags and background specification
- Describe EVERYTHING with precision: face shape, eye color/shape, nose, lips, jaw, skin tone/texture, hair, body proportions, each clothing layer (fabric, color, condition), accessories, weapons, scars/marks/tattoos, stance
- image_prompt MUST be 100-180 words — be exhaustively specific for consistency
- The ORDER number MUST match the character's order from the analysis
- The NAME must be EXACTLY the same unique name from analysis
- appearance_summary is used in ALL scene prompts — make it distinctively specific"""

        try:
            print(f"[AUDIO_TEMPLATE][CHARS] Sending character prompt ({len(prompt)} chars)")
            response = await mexflow.ai.generate(prompt, max_tokens=12000)
            print(f"[AUDIO_TEMPLATE][CHARS] Raw AI response ({len(response) if response else 0} chars): {repr(response[:300]) if response else 'EMPTY'}")
            data = self._clean_and_parse_json(response, mexflow.ai.parse_json)
            if isinstance(data, dict):
                print(f"[AUDIO_TEMPLATE][CHARS] Parsed keys: {list(data.keys())}")
                raw_chars = data.get("characters", [])
                print(f"[AUDIO_TEMPLATE][CHARS] Characters from AI: {len(raw_chars)}")
                for c in raw_chars:
                    print(f"  -> {c.get('name','?')} | image_prompt length: {len(c.get('image_prompt',''))} | appearance: {c.get('appearance_summary','')[:80]}")
            if isinstance(data, dict) and "characters" in data:
                # Ensure order numbers are preserved
                for i, char in enumerate(data.get("characters", [])):
                    if "order" not in char:
                        char["order"] = i + 1
                print(f"[AUDIO_TEMPLATE][CHARS] Final characters with orders: {[(c['name'], c.get('order',0)) for c in data['characters']]}")
                return data
            if isinstance(data, list):
                print(f"[AUDIO_TEMPLATE][CHARS] AI returned list of {len(data)} characters")
                for i, char in enumerate(data):
                    if "order" not in char:
                        char["order"] = i + 1
                    print(f"  -> {char.get('name','?')} | order={char['order']} | image_prompt length: {len(char.get('image_prompt',''))}")
                return {"characters": data}
            print(f"[AUDIO_TEMPLATE][CHARS] FAILED: unexpected data format")
            return None
        except Exception as e:
            print(f"[AUDIO_TEMPLATE][CHARS] EXCEPTION: {e}")
            mexflow.progress.error("Character Design", f"Character generation failed: {str(e)}")
            return None

    # ══════════════════════════════════════════════════════════════════
    # SCENE GENERATION — scene_prompt + voiceover
    # ══════════════════════════════════════════════════════════════════

    async def _generate_scene_prompts(
        self,
        subtitle_data: List[Dict],
        full_narrative: str,
        audio_duration: float,
        required_scene_count: int,
        allowed_durations: List[int],
        characters_data: Dict[str, Any],
        analysis_data: Dict[str, Any],
        style: str,
        visual_style: str,
        add_camera: bool,
        include_emotions: bool,
        aspect_ratio: str,
        color_grading: str,
        narrative_continuity: bool
    ) -> List[Dict]:
        """
        Generate scenes with PERFECT audio-video synchronization.

        CRITICAL ARCHITECTURE:
        ─────────────────────
        The voiceover text for each scene is split HERE using word-level
        timestamps from the subtitle engine — NOT by the AI. This guarantees
        that each scene's voiceover contains EXACTLY the words spoken during
        that scene's video duration.

        The AI's ONLY job is to generate:
        - image_prompt (key frame description)
        - scene_prompt (motion/video direction)
        - characters_present, emotion, camera, lighting, etc.

        The AI CANNOT override the voiceover or duration — those are locked
        by the timestamp data.
        """
        import random

        # ══════════════════════════════════════════════════════════════
        # STEP 1: Split subtitle data into scene segments by TIMESTAMPS
        # ══════════════════════════════════════════════════════════════
        # This is the foundation of audio-video sync.
        # Each segment contains the EXACT words spoken during that scene's
        # video time window, determined by word-level timestamps.

        segments = self._split_subtitle_into_scenes(
            subtitle_data=subtitle_data,
            allowed_durations=allowed_durations,
            audio_duration=audio_duration,
            required_scene_count=required_scene_count
        )

        if not segments:
            return self._generate_fallback_scenes(
                subtitle_data, full_narrative, audio_duration,
                required_scene_count, allowed_durations,
                characters_data.get("characters", []),
                style, visual_style, aspect_ratio
            )

        # Update required_scene_count to match actual segments
        actual_scene_count = len(segments)

        # ══════════════════════════════════════════════════════════════
        # STEP 2: Build context blocks for AI prompt
        # ══════════════════════════════════════════════════════════════

        chars = characters_data.get("characters", [])
        char_ref_lines = []
        for c in chars:
            order = c.get("order", 0)
            name = c.get("name", "Unknown")
            portrait = c.get("image_prompt", c.get("appearance_summary", c.get("build", "")))
            char_ref_lines.append(
                f"  Character #{order} — {name} ({c.get('role', '')}):\n    {portrait}"
            )
        char_ref_block = "\n".join(char_ref_lines)

        analysis_block = ""
        if analysis_data:
            arc = analysis_data.get("narrative_arc", {})
            analysis_block = (
                f"Genre: {analysis_data.get('genre', '')}\n"
                f"Mood: {analysis_data.get('mood', '')}\n"
                f"Setting: {analysis_data.get('setting', '')}\n"
                f"Act 1: {arc.get('act_1_setup', '')}\n"
                f"Act 2: {arc.get('act_2_confrontation', '')}\n"
                f"Act 3: {arc.get('act_3_resolution', '')}\n"
                f"Color Arc: {analysis_data.get('color_arc', '')}"
            )

        color_grading_val = color_grading if color_grading != "auto" else "match visual style and emotional arc"

        # Build the pre-split voiceover block for the AI prompt
        # The AI sees exactly which words go in each scene — it does NOT split them
        voiceover_block_lines = []
        for i, seg in enumerate(segments):
            voiceover_block_lines.append(
                f"  SCENE {i+1} (duration: {seg['duration']}s, audio: {seg['start_time']:.1f}s–{seg['end_time']:.1f}s):\n"
                f"    \"{seg['voiceover']}\""
            )
        voiceover_block = "\n".join(voiceover_block_lines)

        # ══════════════════════════════════════════════════════════════
        # STEP 3: Build AI prompt — AI generates VISUAL prompts only
        # ══════════════════════════════════════════════════════════════
        # The voiceover is PRE-ASSIGNED. The AI must NOT change, reorder,
        # or redistribute the voiceover text.

        min_dur = min(allowed_durations)

        ai_prompt = mexflow.ai.create_prompt(
            '''You are DIRECTOR-X — an elite Hollywood filmmaker, cinematographer, and VFX supervisor directing a professional AI image-to-video pipeline.

═══════════════════════════════════════════════════════
CRITICAL: VOICEOVER IS ALREADY SPLIT — DO NOT CHANGE IT
═══════════════════════════════════════════════════════

The voiceover text for each scene has been precisely split using word-level audio timestamps. Each scene's voiceover contains EXACTLY the words spoken during that scene's video duration. You MUST NOT modify, add, remove, reorder, or redistribute ANY voiceover text. Copy each scene's voiceover VERBATIM into your output.

═══════════════════════════════════════════════════════
YOUR TWO TASKS — VISUAL PROMPT GENERATION:
═══════════════════════════════════════════════════════

TASK 1 — IMAGE PROMPT (Ultra-Dense Key Frame — 200-350 words per scene):

Write an extraordinarily detailed cinematographic description of the perfect frozen KEY FRAME moment that matches the voiceover content. This generates the actual image.

MANDATORY ELEMENTS IN EVERY image_prompt:
   A) COMPOSITION & LENS: Shot size, camera angle, specific lens, depth of field, {aspect_ratio} framing
   B) SUBJECT DETAIL: Character positions, poses, expressions, wardrobe. Reference as "Character #N (Name, traits)"
   C) ENVIRONMENT LAYERS: FOREGROUND, MIDGROUND, BACKGROUND detail. Time of day, weather
   D) LIGHTING RIG: Key/fill/rim with color temperatures and ratios
   E) COLOR SCIENCE: Dominant palette, tonality, grade reference
   F) ATMOSPHERE & MOOD: Particles, lens effects, film stock reference
   G) CHARACTER REFERENCES: "Use reference image 1 for Character #N (Name)" — in order of characters_present

TASK 2 — SCENE PROMPT (Comprehensive Motion Direction — 150-250 words per scene):

Write detailed image-to-video motion direction matching the voiceover pacing.

MANDATORY ELEMENTS IN EVERY scene_prompt:
   A) CAMERA MOVEMENT: Type, direction, speed, trajectory matching scene duration
   B) CHARACTER ACTIONS: Movement, gestures, expression shifts synced to voiceover beats
   C) ENVIRONMENT DYNAMICS: Wind, water, light changes, particle drift
   D) LIGHTING TRANSITIONS: How light evolves during the scene
   E) PACING & RHYTHM: Sync visual intensity to voiceover emphasis points
   F) TRANSITION: How this scene connects to the next
   G) COMPOSITION SHIFT: How framing evolves during the scene

═══════════════════════════════════════════════════════
PRE-SPLIT VOICEOVER SEGMENTS (LOCKED — DO NOT MODIFY):
═══════════════════════════════════════════════════════
{voiceover_block}

═══════════════════════════════════════════════════════
STORY ANALYSIS & NARRATIVE ARC:
═══════════════════════════════════════════════════════
{analysis_block}

═══════════════════════════════════════════════════════
CHARACTER REFERENCE LIBRARY (use order numbers #N in ALL prompts):
═══════════════════════════════════════════════════════
{char_ref_block}

═══════════════════════════════════════════════════════
PRODUCTION PARAMETERS:
═══════════════════════════════════════════════════════
Visual Style: {style}
Aspect Ratio: {aspect_ratio}
Color Grading Direction: {color_grading_val}

═══════════════════════════════════════════════════════
OUTPUT — STRICT JSON ARRAY:
═══════════════════════════════════════════════════════

Return ONLY a JSON array with EXACTLY {actual_scene_count} elements:

[
  {{
    "scene_number": 1,
    "title": "Evocative 3-6 word cinematic title",
    "voiceover": "COPY THE EXACT PRE-SPLIT VOICEOVER TEXT FOR THIS SCENE — VERBATIM, NO CHANGES",
    "characters_present": ["Character Name 1", "Character Name 2"],
    "image_prompt": "200-350 word ULTRA-DENSE key frame description with ALL mandatory elements A-G",
    "scene_prompt": "150-250 word COMPREHENSIVE motion direction with ALL mandatory elements A-G",
    "emotion": "specific emotional tone",
    "camera": "camera movement and lens summary",
    "lighting": "lighting rig summary with color temps",
    "transition": "cut/dissolve/fade_to_black/match_cut",
    "camera_movement_type": "static/dolly/crane/steadicam/handheld/tracking",
    "camera_speed": "ultra_slow/slow/medium/fast",
    "shot_size": "EWS/WS/MWS/FS/MFS/MS/MCU/CU/ECU",
    "color_palette": ["color1", "color2", "color3"],
    "atmosphere": "atmospheric elements summary"
  }}
]

ABSOLUTE RULES — VIOLATION INVALIDATES OUTPUT:
1. EXACTLY {actual_scene_count} scenes
2. voiceover MUST be copied VERBATIM from the pre-split segments above — NO modifications, NO redistribution
3. image_prompt: 200-350 words with ALL 7 mandatory elements, matching the voiceover content
4. scene_prompt: 150-250 words with ALL 7 mandatory elements, pacing synced to voiceover
5. characters_present: MUST list EVERY character relevant to that scene. Use EXACT names from Character Reference Library. NEVER leave empty if scene has character activity
6. scene_number: sequential integers from 1
7. Every scene must have visual continuity with adjacent scenes

Return ONLY the JSON array:''',
            voiceover_block=voiceover_block,
            actual_scene_count=actual_scene_count,
            style=style,
            visual_style=visual_style,
            aspect_ratio=aspect_ratio,
            color_grading_val=color_grading_val,
            analysis_block=analysis_block,
            char_ref_block=char_ref_block
        )

        # ══════════════════════════════════════════════════════════════
        # STEP 4: Generate with AI
        # ══════════════════════════════════════════════════════════════
        print(f"[AUDIO_TEMPLATE][SCENES] char_ref_block has {len(chars)} characters:")
        for c in chars:
            print(f"  -> #{c.get('order',0)} {c.get('name','?')} | image_prompt len={len(c.get('image_prompt',''))} | appearance len={len(c.get('appearance_summary',''))}")
        print(f"[AUDIO_TEMPLATE][SCENES] Requesting {actual_scene_count} scenes from AI (prompt {len(ai_prompt)} chars)")
        response = await mexflow.ai.generate(prompt=ai_prompt, max_tokens=80000)
        print(f"[AUDIO_TEMPLATE][SCENES] AI response length: {len(response) if response else 0}")

        if not response:
            print("[AUDIO_TEMPLATE][SCENES] EMPTY response — falling back")
            return self._generate_fallback_scenes(
                subtitle_data, full_narrative, audio_duration,
                required_scene_count, allowed_durations, chars,
                style, visual_style, aspect_ratio
            )

        # ── Parse AI response ──
        ai_scenes = self._clean_and_parse_json(response, mexflow.ai.parse_json)
        print(f"[AUDIO_TEMPLATE][SCENES] Parsed: len={len(ai_scenes) if isinstance(ai_scenes, (list, dict)) else 'N/A'}")

        if not ai_scenes or not isinstance(ai_scenes, list):
            if isinstance(ai_scenes, dict):
                ai_scenes = ai_scenes.get("scenes", [])
                print(f"[AUDIO_TEMPLATE][SCENES] Extracted scenes from dict: {len(ai_scenes) if ai_scenes else 0}")
            if not ai_scenes:
                print("[AUDIO_TEMPLATE][SCENES] No scenes parsed — falling back")
                return self._generate_fallback_scenes(
                    subtitle_data, full_narrative, audio_duration,
                    required_scene_count, allowed_durations, chars,
                    style, visual_style, aspect_ratio
                )

        print(f"[AUDIO_TEMPLATE][SCENES] Got {len(ai_scenes)} scenes from AI")
        for s in ai_scenes[:3]:
            cp = s.get("characters_present", [])
            print(f"  -> Scene {s.get('scene_number','?')}: characters_present={cp}")

        # Sort by scene_number
        ai_scenes.sort(key=lambda s: int(s.get("scene_number", 0)) if s.get("scene_number") is not None else 0)

        # ══════════════════════════════════════════════════════════════
        # STEP 5: Build final scenes using PRE-SPLIT timestamps
        # ══════════════════════════════════════════════════════════════
        # CRITICAL: We use the pre-split segment data for voiceover,
        # timestamps, and duration. The AI's output only provides
        # image_prompt, scene_prompt, characters, emotion, etc.

        all_char_names = [c.get("name", "") for c in chars if c.get("name")]
        scenes = []
        cumulative_video_time = 0.0

        for i, seg in enumerate(segments):
            scene_idx = i + 1

            # Get AI data for this scene (if available)
            ai_scene = ai_scenes[i] if i < len(ai_scenes) else {}

            # VOICEOVER: Always from pre-split segment — NEVER from AI
            voiceover = seg["voiceover"]

            # DURATION: Always from pre-split segment — NEVER from AI
            duration = seg["duration"]

            # TIMING: From pre-split segment timestamps
            audio_start = seg["start_time"]
            audio_end = seg["end_time"]

            # VIDEO TIMELINE: Contiguous, no gaps
            video_start = cumulative_video_time
            video_end = video_start + duration
            cumulative_video_time = video_end

            # Emotion and camera (from AI)
            emotion = ai_scene.get("emotion", "neutral")
            camera_category = self._categorize_emotion_for_camera(emotion)
            camera_text = ai_scene.get("camera", "")
            if not camera_text and add_camera:
                category_moves = self.CAMERA_MOVEMENTS.get(camera_category, self.CAMERA_MOVEMENTS["establishing"])
                camera_text = random.choice(category_moves)

            lighting_text = ai_scene.get("lighting", "")
            if not lighting_text:
                lighting_text = self.LIGHTING_SETUPS.get(emotion.lower().strip(), self.LIGHTING_SETUPS["neutral"])

            # Characters present — with FUZZY MATCHING for robustness
            raw_chars_present = ai_scene.get("characters_present", [])
            chars_present = []
            matched_names = set()

            for cp in raw_chars_present:
                cp_name = ""
                if isinstance(cp, str):
                    cp_name = cp.strip()
                elif isinstance(cp, dict):
                    cp_name = (cp.get("name") or "").strip()

                if not cp_name:
                    continue

                matched = self._fuzzy_match_character_name(cp_name, all_char_names)
                if matched and matched not in matched_names:
                    order_num = next((c.get("order", 0) for c in chars if c.get("name") == matched), 0)
                    chars_present.append({"name": matched, "order": order_num})
                    matched_names.add(matched)

            # Infer from scene text if AI returned nothing
            if not chars_present and all_char_names:
                scene_text = " ".join([
                    ai_scene.get("image_prompt", ""),
                    ai_scene.get("scene_prompt", ""),
                    voiceover
                ]).lower()
                for cn in all_char_names:
                    cn_words = [w for w in cn.lower().split()
                                if w not in ('the', 'a', 'an', 'of', 'and')]
                    matches = sum(1 for w in cn_words if w in scene_text)
                    if matches >= max(1, len(cn_words) // 2):
                        if cn not in matched_names:
                            order_num = next((c.get("order", 0) for c in chars if c.get("name") == cn), 0)
                            chars_present.append({"name": cn, "order": order_num})
                            matched_names.add(cn)

            # Guarantee protagonist appears when no characters found
            if not chars_present and chars:
                protagonist = next((c for c in chars if c.get("role", "").lower() == "protagonist"), None)
                if protagonist:
                    chars_present.append({
                        "name": protagonist.get("name", ""),
                        "order": protagonist.get("order", 1)
                    })

            # ── Build comprehensive JSON scene_prompt ──
            scene_prompt_text = ai_scene.get("scene_prompt", "").strip()
            emotion_dir = self.EMOTION_DIRECTION.get(emotion.lower().strip(), {})

            scene_prompt_json = {
                "motion_description": scene_prompt_text,
                "camera": {
                    "movement_type": ai_scene.get("camera_movement_type", camera_category),
                    "direction": camera_text,
                    "speed": ai_scene.get("camera_speed", "medium"),
                    "lens_mm": 35,
                    "stabilization": "steadicam"
                },
                "characters": [
                    {
                        "character_ref": f"Character #{cp.get('order', 0)} ({cp.get('name', '')})",
                        "action": "present in scene",
                        "expression_arc": emotion
                    }
                    for cp in chars_present
                ],
                "environment": {
                    "motion": "ambient atmospheric movement",
                    "particles": ai_scene.get("atmosphere", "ambient atmospheric particles")
                },
                "lighting_dynamics": {
                    "setup": lighting_text,
                    "progression": "as described in scene_prompt"
                },
                "composition": {
                    "shot_size": ai_scene.get("shot_size", "MS"),
                    "aspect_ratio": aspect_ratio,
                    "depth_of_field": "cinematic"
                },
                "color_grading": {
                    "palette": ai_scene.get("color_palette", []),
                    "tonality": "match visual style",
                    "grade_reference": color_grading if color_grading != "auto" else "match visual style and emotion"
                },
                "pacing": {
                    "rhythm": emotion_dir.get("pacing", "moderate") if emotion_dir else "moderate",
                    "intensity_arc": "as driven by narration"
                },
                "transition": {
                    "type": ai_scene.get("transition", "cut"),
                    "to_next_scene": "continuous narrative flow"
                },
                "audio_sync": {
                    "video_start_time": round(video_start, 3),
                    "video_end_time": round(video_end, 3),
                    "audio_start_time": round(audio_start, 3),
                    "audio_end_time": round(audio_end, 3),
                    "duration_seconds": duration,
                    "sync_drift_ms": round((video_start - audio_start) * 1000, 1)
                },
                "technical": {
                    "visual_style": visual_style,
                    "aspect_ratio": aspect_ratio,
                    "render_quality": "8K photorealistic cinematic"
                }
            }

            scene_prompt_str = json.dumps(scene_prompt_json, ensure_ascii=False)

            scene = {
                "scene_id_str": f"1.{scene_idx}",
                "title": ai_scene.get("title", f"Scene {scene_idx}"),
                "image_prompt": ai_scene.get("image_prompt", ""),
                "scene_prompt": scene_prompt_str,
                "scene_description": voiceover,
                "description": voiceover,
                "voiceover": voiceover,
                "duration": duration,
                "start_time": round(audio_start, 3),
                "end_time": round(audio_end, 3),
                "camera": camera_text,
                "emotion": emotion,
                "lighting": lighting_text,
                "characters_present": chars_present,
                "characters": [{"name": cp.get("name", ""), "role": "subject"} for cp in chars_present],
                "order": scene_idx,
                "transition": ai_scene.get("transition", "cut"),
                "metadata": {
                    "image_prompt": ai_scene.get("image_prompt", ""),
                    "scene_prompt": scene_prompt_str,
                    "scene_prompt_json": scene_prompt_json,
                    "camera_info": camera_text,
                    "lighting_info": lighting_text,
                    "emotion": emotion,
                    "transition": ai_scene.get("transition", "cut"),
                    "characters_present": [cp.get("name", "") for cp in chars_present],
                    "aspect_ratio": aspect_ratio,
                    "visual_style": visual_style,
                    "color_grading": color_grading,
                    "start_time": round(audio_start, 3),
                    "end_time": round(audio_end, 3),
                    "video_start_time": round(video_start, 3),
                    "video_end_time": round(video_end, 3),
                    "duration": duration,
                    "sync_drift_ms": round((video_start - audio_start) * 1000, 1)
                }
            }
            scenes.append(scene)

        # Re-number
        for i, s in enumerate(scenes):
            s["order"] = i + 1
            s["scene_id_str"] = f"1.{i + 1}"

        # Log final sync report
        total_dur = sum(s["duration"] for s in scenes)
        print(f"[AUDIO_TEMPLATE][SCENES] ═══ SYNC REPORT ═══")
        print(f"[AUDIO_TEMPLATE][SCENES] Total scenes: {len(scenes)}")
        print(f"[AUDIO_TEMPLATE][SCENES] Total video duration: {total_dur}s")
        print(f"[AUDIO_TEMPLATE][SCENES] Total audio duration: {round(audio_duration, 2)}s")
        for i, s in enumerate(scenes):
            meta = s.get("metadata", {})
            drift = meta.get("sync_drift_ms", 0)
            cp_names = [cp.get("name", "") if isinstance(cp, dict) else cp for cp in s.get("characters_present", [])]
            word_ct = len(s.get("voiceover", "").split()) if s.get("voiceover") else 0
            print(f"  Scene {i+1}: dur={s['duration']}s | audio={s['start_time']}-{s['end_time']}s | "
                  f"video={meta.get('video_start_time',0)}-{meta.get('video_end_time',0)}s | "
                  f"drift={drift}ms | words={word_ct} | chars={cp_names}")

        return scenes

    # ══════════════════════════════════════════════════════════════════
    # DATABASE SAVE — Characters + Scenes
    # ══════════════════════════════════════════════════════════════════

    async def _save_to_project(
        self,
        characters_data: Dict[str, Any],
        scenes: List[Dict],
        bg_color: str,
        visual_style: str,
        aspect_ratio: str
    ) -> None:
        """Save characters and scenes to the project database."""

        chars = characters_data.get("characters", []) if characters_data else []
        all_character_names = [c.get("name", "") for c in chars if c.get("name")]
        print(f"[AUDIO_TEMPLATE] _save_to_project: {len(chars)} characters, {len(scenes)} scenes")

        # ── Save characters to project_data ──
        character_list_for_project = []
        for char in chars:
            char_name = char.get("name", "Unknown")
            char_prompt = char.get("image_prompt", char.get("appearance_summary", ""))

            character_list_for_project.append({
                "name": char_name,
                "prompt": char_prompt
            })

            try:
                await mexflow.project_data.add_character(char_name, char_prompt)
            except Exception as e:
                print(f"[AUDIO_TEMPLATE] add_character failed for {char_name!r}: {e}")

        try:
            result_save = await mexflow.project_data.save_characters(character_list_for_project)
            print(f"[AUDIO_TEMPLATE] save_characters({len(character_list_for_project)}) -> {result_save}")
        except Exception as e:
            print(f"[AUDIO_TEMPLATE] save_characters EXCEPTION: {e}")

        # ── Save scenes via bulk save ──
        bulk_scenes = []
        for i, scene in enumerate(scenes):
            scene_id = scene.get("scene_id_str", f"1.{i + 1}")

            scene_characters_present = scene.get("characters_present", [])

            # Infer characters_present if AI didn't populate it — using fuzzy matching
            if not scene_characters_present and all_character_names:
                scene_text = " ".join([
                    scene.get("image_prompt", ""),
                    scene.get("scene_prompt", ""),
                    scene.get("voiceover", ""),
                    scene.get("title", "")
                ]).lower()
                for char_name in all_character_names:
                    # Fuzzy: check if significant words from character name appear
                    cn_words = [w for w in char_name.lower().split()
                                if w not in ('the', 'a', 'an', 'of', 'and')]
                    matches = sum(1 for w in cn_words if w in scene_text)
                    if matches >= max(1, len(cn_words) // 2):
                        scene_characters_present.append(char_name)
                # Guarantee protagonist if still empty
                if not scene_characters_present and chars:
                    protagonist = next((c.get("name", "") for c in chars
                                       if c.get("role", "").lower() == "protagonist"), None)
                    if protagonist:
                        scene_characters_present.append(protagonist)
                if scene_characters_present:
                    scene["characters_present"] = scene_characters_present

            # Normalise to list of strings for bulk save
            chars_present_names = []
            for cp in scene_characters_present:
                if isinstance(cp, dict):
                    chars_present_names.append(cp.get("name", ""))
                elif isinstance(cp, str):
                    chars_present_names.append(cp)

            bulk_scenes.append({
                "scene_id_str": scene_id,
                "title": scene.get("title", f"Scene {i + 1}"),
                "image_prompt": scene.get("image_prompt", ""),
                "voiceover": scene.get("voiceover", ""),
                "duration": scene.get("duration", 5),
                "scene_prompt": scene.get("scene_prompt", ""),
                "scene_description": scene.get("voiceover", ""),
                "characters_present": chars_present_names,
                "characters": [{"name": cn} for cn in chars_present_names],
                "metadata": scene.get("metadata", {
                    "image_prompt": scene.get("image_prompt", ""),
                    "scene_prompt": scene.get("scene_prompt", ""),
                    "camera_info": scene.get("camera", ""),
                    "lighting_info": scene.get("lighting", ""),
                    "emotion": scene.get("emotion", "neutral"),
                    "transition": scene.get("transition", "cut"),
                    "characters_present": chars_present_names,
                    "aspect_ratio": aspect_ratio,
                    "visual_style": visual_style,
                    "start_time": scene.get("start_time", 0),
                    "end_time": scene.get("end_time", 0),
                    "duration": scene.get("duration", 5)
                })
            })

        try:
            await mexflow.scene_data.save_scenes_bulk(
                scenes=bulk_scenes,
                clear_existing=True
            )
        except Exception as e:
            print(f"[AUDIO_TEMPLATE] save_scenes_bulk exception: {e}")

        # Per-scene follow-up saves
        for i, scene in enumerate(scenes):
            scene_id = scene.get("scene_id_str", f"1.{i + 1}")

            try:
                await mexflow.scene_data.save_scene_duration(
                    scene_id, scene.get("duration", 5)
                )
            except Exception:
                pass

            # Save scene_prompt (already a JSON string from scene building)
            try:
                await mexflow.scene_data.save_scene_prompt(
                    scene_id, scene.get("scene_prompt", "")
                )
            except Exception:
                pass

            # Save scene description
            try:
                await mexflow.scene_data.save_scene_description(
                    scene_id, scene.get("voiceover", "")
                )
            except Exception:
                pass

            # Save comprehensive metadata
            try:
                scene_meta = scene.get("metadata", {})
                await mexflow.scene_data.save_metadata(scene_id, scene_meta)
            except Exception:
                pass

            chars_present_names = []
            for cp in scene.get("characters_present", []):
                if isinstance(cp, dict):
                    chars_present_names.append(cp.get("name", ""))
                elif isinstance(cp, str):
                    chars_present_names.append(cp)

            try:
                await mexflow.scene_data.save_characters_present(
                    scene_id, chars_present_names
                )
            except Exception:
                pass

            try:
                await mexflow.scene_data.update_status(scene_id, "generated")
            except Exception:
                pass

            mexflow.progress.update(
                stage="Saving to Project",
                stage_index=7,
                total_stages=8,
                current_progress=((i + 1) / len(scenes)) * 100,
                message=f"Saved scene {i + 1} of {len(scenes)}: {scene.get('title', '')}"
            )

    # ══════════════════════════════════════════════════════════════════
    # FALLBACK SCENE GENERATOR
    # ══════════════════════════════════════════════════════════════════

    def _generate_fallback_scenes(
        self,
        subtitle_data: List[Dict],
        full_narrative: str,
        audio_duration: float,
        required_scene_count: int,
        allowed_durations: List[int],
        characters: List[Dict],
        style: str,
        visual_style: str,
        aspect_ratio: str = "16:9"
    ) -> List[Dict]:
        """Generate fallback scenes when AI is unavailable.
        Uses the same timestamp-driven splitting as the main pipeline
        to guarantee perfect audio-video sync."""
        import random

        if not subtitle_data or required_scene_count == 0:
            return []

        min_dur = min(allowed_durations) if allowed_durations else 5

        # ── Use the same timestamp splitter as the main pipeline ──
        segments = self._split_subtitle_into_scenes(
            subtitle_data=subtitle_data,
            allowed_durations=allowed_durations,
            audio_duration=audio_duration,
            required_scene_count=required_scene_count
        )

        if not segments:
            return []

        # Build character reference string for prompts
        char_refs = []
        for c in characters:
            order = c.get("order", 0)
            name = c.get("name", "")
            appearance = c.get("appearance_summary", "")
            if name:
                char_refs.append(f"Character #{order} ({name}, {appearance[:60]})")

        # ── Build scenes using pre-split segments ──
        scenes = []
        cumulative_video_time = 0.0

        for scene_num, seg in enumerate(segments, 1):
            voiceover = seg["voiceover"]
            duration = seg["duration"]
            audio_start = seg["start_time"]
            audio_end = seg["end_time"]

            video_start = cumulative_video_time
            video_end = video_start + duration
            cumulative_video_time = video_end

            char_mention = ". ".join(char_refs[:3]) + ". " if char_refs else ""

            style_desc = self.STYLE_PROMPTS.get(visual_style, self.STYLE_PROMPTS.get("cinematic", ""))
            char_ref_text = ""
            if char_refs:
                ref_parts = []
                for idx, ref in enumerate(char_refs[:3]):
                    ref_parts.append(f"Use reference image {idx + 1} for {ref}")
                char_ref_text = ". ".join(ref_parts) + ". "

            shot_type = "Wide establishing shot" if scene_num == 1 else "Medium shot"
            image_prompt = (
                f"{shot_type} framed in {aspect_ratio}, {visual_style} aesthetic, {style_desc[:200]}. "
                f"{char_ref_text}"
                f"ENVIRONMENT: Layered composition with foreground depth elements, textured midground, "
                f"atmospheric background with aerial perspective. "
                f"LIGHTING: Cinematic three-point rig — motivated key at 45° camera-left 5000K, "
                f"soft fill at 3:1 ratio, rim light for separation. Volumetric haze. "
                f"COLOR: Rich natural palette, medium contrast, preserved shadow detail. "
                f"QUALITY: Hyper-sharp 8K, Cooke S7/i prime lens, subtle film grain."
            )

            camera_category = "establishing" if scene_num == 1 else random.choice(
                list(self.CAMERA_MOVEMENTS.keys())
            )
            camera = random.choice(
                self.CAMERA_MOVEMENTS.get(camera_category, self.CAMERA_MOVEMENTS["establishing"])
            )

            chars_present = [
                {"name": c.get("name", ""), "order": c.get("order", 0)}
                for c in characters[:3]
            ] if characters else []

            scene_prompt_text = (
                f"Camera slowly moves through the scene. {char_mention}"
                f"Subtle environmental motion — wind, light shifts, "
                f"atmospheric particles. Characters maintain natural poses with gentle "
                f"breathing motion. Smooth cinematic pacing matching {visual_style} aesthetic. "
                f"Camera: {camera}."
            )

            scene_prompt_json = {
                "motion_description": scene_prompt_text,
                "camera": {
                    "movement_type": camera_category,
                    "direction": camera,
                    "speed": "slow",
                    "lens_mm": 35 if scene_num == 1 else 50,
                    "stabilization": "steadicam"
                },
                "characters": [
                    {
                        "character_ref": f"Character #{cp.get('order', 0)} ({cp.get('name', '')})",
                        "action": "present with natural stance",
                        "expression_arc": "neutral"
                    }
                    for cp in chars_present
                ],
                "environment": {
                    "motion": "subtle wind, ambient particle drift",
                    "particles": "atmospheric dust motes"
                },
                "lighting_dynamics": {
                    "setup": self.LIGHTING_SETUPS["neutral"],
                    "progression": "consistent natural light"
                },
                "composition": {
                    "shot_size": "WS" if scene_num == 1 else "MS",
                    "aspect_ratio": aspect_ratio,
                    "depth_of_field": "deep" if scene_num == 1 else "medium"
                },
                "color_grading": {
                    "palette": ["neutral tones", "earth tones"],
                    "tonality": "neutral",
                    "grade_reference": visual_style
                },
                "pacing": {
                    "rhythm": "measured",
                    "intensity_arc": "steady"
                },
                "transition": {
                    "type": "cut",
                    "to_next_scene": "continuous"
                },
                "audio_sync": {
                    "video_start_time": round(video_start, 3),
                    "video_end_time": round(video_end, 3),
                    "audio_start_time": round(audio_start, 3),
                    "audio_end_time": round(audio_end, 3),
                    "duration_seconds": duration,
                    "sync_drift_ms": round((video_start - audio_start) * 1000, 1)
                },
                "technical": {
                    "visual_style": visual_style,
                    "aspect_ratio": aspect_ratio,
                    "render_quality": "8K photorealistic cinematic"
                }
            }
            scene_prompt_str = json.dumps(scene_prompt_json, ensure_ascii=False)

            scene = {
                "scene_id_str": f"1.{scene_num}",
                "title": f"Scene {scene_num}",
                "image_prompt": image_prompt,
                "scene_prompt": scene_prompt_str,
                "voiceover": voiceover,
                "scene_description": voiceover,
                "description": voiceover,
                "duration": duration,
                "start_time": round(audio_start, 3),
                "end_time": round(audio_end, 3),
                "camera": camera,
                "emotion": "neutral",
                "lighting": self.LIGHTING_SETUPS["neutral"],
                "characters_present": chars_present,
                "characters": [{"name": cp.get("name", ""), "role": "subject"} for cp in chars_present],
                "order": scene_num,
                "transition": "cut",
                "metadata": {
                    "image_prompt": image_prompt,
                    "scene_prompt": scene_prompt_str,
                    "scene_prompt_json": scene_prompt_json,
                    "camera_info": camera,
                    "lighting_info": self.LIGHTING_SETUPS["neutral"],
                    "emotion": "neutral",
                    "transition": "cut",
                    "characters_present": [cp.get("name", "") for cp in chars_present],
                    "aspect_ratio": aspect_ratio,
                    "visual_style": visual_style,
                    "start_time": round(audio_start, 3),
                    "end_time": round(audio_end, 3),
                    "video_start_time": round(video_start, 3),
                    "video_end_time": round(video_end, 3),
                    "duration": duration,
                    "sync_drift_ms": round((video_start - audio_start) * 1000, 1),
                    "fallback": True
                }
            }
            scenes.append(scene)

        return scenes


# Required export
Template = AudioWorkflowTemplate