"""
Audio Workflow Template — Director's Cut (Professional Edition)
================================================================

A production-grade audiovisual scene generation engine designed for
professional storytellers, cinematographers, and PSD-level directors.

WORKFLOW A: Story Text Mode
1. Story Text Input → Narrative Analysis
2. Save as Audio Script with linguistic metadata
3. Generate Audio (TTS via configured plugin)
4. Generate Subtitles (Whisper via configured plugin)
5. Intelligent subtitle segmentation with context preservation
6. Professional scene prompt generation (2500-3000 chars per scene)
7. Bulk save with full metadata

WORKFLOW B: Direct Audio Mode
1. Audio File Input → Import & Validate
2. Generate Subtitles (Whisper via configured plugin)
3. Context-aware subtitle segmentation
4. Professional scene prompt generation (2500-3000 chars per scene)
5. Bulk save with full metadata

Key Capabilities:
- PSD-level professional scene direction vocabulary
- 2500-3000 character scene prompts with exhaustive visual direction
- Exact user-defined scene durations (5, 10, or 15 seconds selectable)
- Multi-duration mode: mix different durations across scenes
- 100% subtitle-to-scene audio synchronization
- Narrative context threading across scenes for visual continuity
- Emotional arc analysis with per-scene mood mapping
- Professional cinematography terminology (lens, lighting, blocking, etc.)
- Integer-only scene numbering (no floating point IDs)
- Production-ready error handling with graceful fallbacks

Requirements:
- Default Audio Generator plugin (for Story mode)
- Default Subtitle Generator plugin (both modes)
- AI Provider for scene prompt generation
"""

import re
import json
import math
from typing import Dict, Any, List, Optional, Tuple


# Import MexFlow SDK (the only allowed import for templates)
from mexflow_sdk import mexflow, TemplateBase, TemplateResult


class AudioWorkflowTemplate(TemplateBase):
    """
    Audio Workflow Template — Director's Cut

    Transforms audio narration into PSD-level professional scene direction
    with exhaustive visual prompts, precise timing, and full audio sync.
    """

    # ══════════════════════════════════════════════════════════════════
    # PROFESSIONAL VISUAL STYLE LIBRARY
    # Each style contains layered descriptors used by professional
    # production designers and art directors in the film industry.
    # ══════════════════════════════════════════════════════════════════
    STYLE_PROMPTS = {
        "cinematic": (
            "cinematic film aesthetic, shot on ARRI Alexa 65, anamorphic widescreen 2.39:1 aspect ratio, "
            "shallow depth of field with creamy bokeh separation, naturalistic color science with subtle "
            "teal-and-orange color grade, atmospheric haze volumetrics, production-quality practical lighting "
            "augmented with motivated soft fill, Kodak Vision3 500T film emulation grain structure, "
            "IMAX-grade resolution clarity, Cooke S7/i full-frame prime lens characteristics"
        ),
        "realistic": (
            "hyperrealistic photographic rendering, medium format Hasselblad sensor fidelity, "
            "natural available-light photography with physically accurate global illumination, "
            "micro-detail surface texturing with subsurface scattering on organic materials, "
            "true-to-life color reproduction in Rec.2020 wide gamut color space, "
            "professional editorial retouching with preserved skin texture authenticity, "
            "razor-sharp focus plane with optical diffraction-limited resolving power"
        ),
        "anime": (
            "premium Japanese animation aesthetic, Studio Ghibli-inspired hand-painted background art "
            "with luminous watercolor washes, expressive cel-shaded character rendering with dynamic "
            "line weight variation, Makoto Shinkai-level atmospheric light scattering and god-ray effects, "
            "saturated jewel-tone palette with deliberate complementary color harmonies, "
            "fluid sakuga-quality motion design sensibility, ultra-detailed environmental storytelling"
        ),
        "cartoon": (
            "premium feature animation style, Pixar-tier character design with appeal and specificity, "
            "bold clean vector outlines with variable stroke weight expressing depth and energy, "
            "saturated high-chroma palette with deliberate limited color harmony per scene, "
            "exaggerated squash-and-stretch anticipation in pose design, "
            "stylized yet readable environmental design with clear visual hierarchy, "
            "Disney-quality production polish with every frame exhibition-worthy"
        ),
        "3d_render": (
            "photorealistic 3D CGI rendering, path-traced global illumination with unlimited bounces, "
            "physically based rendering materials with measured BRDF profiles, "
            "Pixar RenderMan or Chaos V-Ray production-quality output, 8K texture resolution, "
            "volumetric atmospheric scattering with density-mapped fog and god rays, "
            "subsurface scattering on all organic surfaces, micro-displacement geometric detail, "
            "Academy Award VFX-nominee visual fidelity standard"
        ),
        "watercolor": (
            "master-level traditional watercolor painting, wet-on-wet bleeding pigment diffusion "
            "with controlled granulation on cold-press Arches paper texture, transparent luminous glazing "
            "layered over preserved white paper highlights, deliberate lost-and-found edge treatment "
            "guiding the viewer's eye, calligraphic brushwork with visible gesture and confidence, "
            "limited palette color mixing producing harmonious chromatic grays, "
            "museum-quality fine art presentation with archival pigment depth"
        ),
        "oil_painting": (
            "classical oil painting technique referencing Dutch Golden Age mastery, "
            "impasto textural brushwork with visible directional palette knife strokes, "
            "chiaroscuro light-and-shadow modeling with Rembrandt-quality dramatic illumination, "
            "rich glazed color layering producing luminous depth and optical color mixing, "
            "museum-quality fine art composition following golden ratio and rule of thirds, "
            "old master varnish warmth with craquelure patina aging characteristics"
        ),
        "pencil_sketch": (
            "professional concept art pencil illustration, confident gestural line work with "
            "varying graphite hardness from 6H architectural precision to 8B expressive shading, "
            "cross-hatching tonal rendering with ambient occlusion shadow mapping, "
            "anatomically precise figure drawing with dynamic contrapposto posing, "
            "environmental perspective drawing with atmospheric aerial perspective fading, "
            "Syd Mead-level industrial design sensibility with Craig Mullins painterly looseness"
        ),
        "dark_fantasy": (
            "dark fantasy art direction, Beksinski-inspired biomechanical surrealism merged with "
            "Frazetta heroic composition, desaturated earth-tone palette with selective blood-crimson "
            "and molten-gold accent highlights, dramatic chiaroscuro rim lighting from below, "
            "mist-shrouded atmospheric perspective with particulate volumetrics, "
            "weathered textural surfaces with patina, rust, and organic decay detail, "
            "epic-scale environmental scope with diminishing figure placement for grandeur"
        ),
        "noir": (
            "classic film noir cinematography, high-contrast black-and-white with selective "
            "desaturated color accent elements, Venetian blind shadow patterns and angular "
            "hard-light key with minimal fill creating deep noir shadows, "
            "expressionist Dutch angle composition with leading shadow lines, "
            "wet cobblestone reflections doubling neon signage, "
            "1940s detective aesthetic with fedora silhouettes and cigarette smoke wisps, "
            "grain-heavy Tri-X 400 pushed to 1600 ISO film stock emulation"
        ),
        "cyberpunk": (
            "cyberpunk neo-Tokyo aesthetic, Blade Runner 2049-level production design, "
            "rain-soaked megacity environment with holographic advertisement pollution, "
            "neon-drenched palette dominated by electric cyan, hot magenta, and acid yellow, "
            "volumetric fog refracting artificial light sources through atmospheric haze, "
            "high-tech low-life juxtaposition with chrome and grime surface contrasts, "
            "Syd Mead futurism meets Moebius graphic novel illustration density, "
            "Roger Deakins-inspired compositional precision with motivated practical lighting"
        ),
        "vintage_film": (
            "vintage 1970s Kodachrome film photography aesthetic, warm amber-shifted color cast "
            "with lifted shadow blacks and compressed highlight roll-off, heavy organic film grain "
            "with halation bloom on bright highlights, slight vignetting on frame edges, "
            "period-authentic costume and production design detail, "
            "Vilmos Zsigmond or Gordon Willis-inspired naturalistic cinematography, "
            "anamorphic oval bokeh with subtle blue lens flare streaks"
        )
    }

    # ══════════════════════════════════════════════════════════════════
    # PROFESSIONAL CAMERA MOVEMENT LIBRARY
    # Categorized by emotional function for intelligent scene matching
    # ══════════════════════════════════════════════════════════════════
    CAMERA_MOVEMENTS = {
        "establishing": [
            "slow aerial crane ascending to reveal the full scope of the environment, establishing spatial geography",
            "wide static locked-off master shot holding for beat, allowing environment to breathe and settle",
            "gradual helicopter-perspective pull-back from subject to vast landscape establishing scale and isolation",
            "steady Steadicam orbit circling the central subject at medium distance, revealing environment progressively"
        ],
        "intimate": [
            "gentle handheld close-up with subtle breathing motion, creating documentary-intimate presence",
            "slow push-in dolly from medium shot to tight close-up, narrowing emotional distance to subject",
            "rack focus pull from foreground element to subject's eyes, directing attention to internal emotion",
            "static extreme close-up with shallow depth isolating subject's expression from background"
        ],
        "dynamic": [
            "tracking dolly running parallel with subject movement, matching velocity for kinetic energy",
            "whip pan transitioning between subjects with motion-blur speed, conveying urgency and chaos",
            "Steadicam following-shot maintaining medium distance behind subject moving through environment",
            "crane jib sweeping from low angle ascending to high angle in single fluid motivated movement"
        ],
        "tension": [
            "imperceptibly slow creep zoom tightening frame by millimeters, building subliminal unease",
            "Dutch angle tilt with slight handheld tremor, visually destabilizing the viewer's equilibrium",
            "contra-zoom Vertigo effect simultaneously dollying out while zooming in, warping spatial perception",
            "static locked frame with subject approaching camera from deep background, compressing distance"
        ],
        "contemplative": [
            "ultra-slow lateral dolly gliding past environmental details, meditative pacing inviting reflection",
            "gentle tilt from ground-level detail upward to reveal sky or ceiling, suggesting transcendence",
            "static wide composition with subject small within vast space, evoking solitude and contemplation",
            "slow-motion Phantom camera capture at 120fps with drifting minimal camera movement"
        ],
        "triumphant": [
            "sweeping crane ascending from ground level to soaring bird's-eye perspective revealing achievement",
            "hero-angle low camera tilting up at subject against dramatic sky, imbuing power and stature",
            "circular Steadicam orbit tightening radius around subject, building centripetal dramatic energy",
            "dramatic pull-back reveal from detail to grand vista, disclosing the full magnitude of the moment"
        ]
    }

    # ══════════════════════════════════════════════════════════════════
    # PROFESSIONAL LIGHTING SETUPS
    # Referenced by name in industry-standard terminology
    # ══════════════════════════════════════════════════════════════════
    LIGHTING_SETUPS = {
        "peaceful": "soft diffused overcast daylight with even fill, low contrast ratio 2:1, pastel color temperature 5600K neutral",
        "tense": "harsh single-source hard key light creating deep angular shadows, high contrast ratio 8:1, cold blue-shifted 7500K color temperature",
        "joyful": "warm golden-hour backlight with lens flare, 3200K amber key with soft wraparound fill, luminous and inviting atmosphere",
        "sad": "flat overcast ambient with desaturated cool tones, minimal shadow definition, grey-green color cast suggesting emotional weight",
        "mysterious": "low-key chiaroscuro with pools of motivated practical light in darkness, selective rim light revealing silhouette edges only",
        "angry": "aggressive red-shifted practical lighting with hard shadows and hot specular highlights, high contrast with crushed blacks",
        "fearful": "underlighting from below casting distorted upward shadows, flickering unstable light source suggesting danger and unpredictability",
        "romantic": "candlelit warmth at 2200K with soft diffusion filter, gentle backlighting creating hair light halo effect, intimate and tender",
        "epic": "dramatic Rembrandt lighting with volumetric god rays piercing through atmosphere, theatrical scale with motivated natural light sources",
        "neutral": "balanced three-point studio lighting setup, 5000K neutral daylight key with 2-stop fill ratio, clean professional exposure",
        "hopeful": "dawn light breaking through clouds with crepuscular rays, warm-cool color contrast at horizon, gradually brightening ambient",
        "melancholic": "late autumn afternoon light with long shadows, amber-tinged but fading, dust motes floating in shafts of diminishing warmth"
    }

    # ══════════════════════════════════════════════════════════════════
    # EMOTIONAL VOCABULARY MAPPING
    # Maps detected emotions to professional direction language
    # ══════════════════════════════════════════════════════════════════
    EMOTION_DIRECTION = {
        "peaceful": {
            "pacing": "measured and unhurried, allowing each visual beat to land with contemplative weight",
            "color": "muted pastoral palette of sage greens, powder blues, and warm cream tones",
            "composition": "balanced symmetrical framing with generous negative space suggesting harmony"
        },
        "tense": {
            "pacing": "accelerating rhythm with shortened visual beats creating mounting pressure",
            "color": "desaturated cool palette with harsh fluorescent green-blue undertones",
            "composition": "asymmetrical off-center framing with tight headroom creating visual claustrophobia"
        },
        "joyful": {
            "pacing": "buoyant energetic rhythm with dynamic visual variety and movement",
            "color": "saturated warm spectrum of sunflower yellows, coral oranges, and sky blues",
            "composition": "open expansive framing with upward diagonal lines suggesting uplift and freedom"
        },
        "sad": {
            "pacing": "slow deliberate rhythm with extended holds allowing emotional weight to accumulate",
            "color": "cool desaturated palette of slate grays, muted indigos, and washed-out blues",
            "composition": "isolated subject placement with oppressive negative space suggesting loneliness"
        },
        "mysterious": {
            "pacing": "deliberately withheld reveals with shadow-dominant frames obscuring information",
            "color": "deep jewel tones of midnight blue, emerald, and burgundy emerging from darkness",
            "composition": "partially obscured subjects with foreground occlusion elements adding visual intrigue"
        },
        "epic": {
            "pacing": "grand sweeping rhythm building from quiet introduction to overwhelming crescendo",
            "color": "rich saturated cinematic palette with theatrical contrast and color depth",
            "composition": "monumental scale framing with diminished human figures against vast environments"
        },
        "romantic": {
            "pacing": "gentle flowing rhythm with soft transitions dissolving between intimate moments",
            "color": "warm rosy palette of blush pinks, golden ambers, and soft lavender accents",
            "composition": "two-shot framing with shallow depth of field isolating subjects from world"
        },
        "fearful": {
            "pacing": "irregular jarring rhythm with sudden visual disruptions breaking established patterns",
            "color": "sickly yellow-green undertones with deep impenetrable shadow areas",
            "composition": "distorted wide-angle perspective with looming foreground elements creating threat"
        }
    }

    # Allowed scene durations for AI video generation models
    ALLOWED_DURATIONS = [5, 10, 15]

    # ══════════════════════════════════════════════════════════════════
    # UTILITY METHODS
    # ══════════════════════════════════════════════════════════════════

    @staticmethod
    def _snap_to_allowed_duration(duration: float, preferred_durations: List[int] = None) -> int:
        """
        Snap a raw duration to the nearest allowed value from the preferred list.
        AI video models only support 5, 10, or 15 second clips.

        Args:
            duration: Raw duration in seconds
            preferred_durations: User-selected allowed durations (subset of [5, 10, 15])

        Returns:
            Integer duration snapped to nearest allowed value
        """
        allowed = preferred_durations if preferred_durations else [5, 10, 15]
        # Find the closest allowed duration
        best = allowed[0]
        best_diff = abs(duration - best)
        for d in allowed:
            diff = abs(duration - d)
            if diff < best_diff:
                best = d
                best_diff = diff
        return int(best)

    @staticmethod
    def _parse_duration_selections(duration_setting: str) -> Tuple[Optional[List[int]], str]:
        """
        Parse the user's duration selection into a list of allowed durations
        and a distribution mode.

        Returns:
            Tuple of (allowed_durations_list_or_None, mode_string)
            - None means auto mode (use natural speech breaks)
            - List means only these durations are permitted
        """
        if duration_setting == "auto":
            return None, "auto"
        elif duration_setting == "5":
            return [5], "fixed"
        elif duration_setting == "10":
            return [10], "fixed"
        elif duration_setting == "15":
            return [15], "fixed"
        elif duration_setting == "5_10":
            return [5, 10], "mixed"
        elif duration_setting == "5_15":
            return [5, 15], "mixed"
        elif duration_setting == "10_15":
            return [10, 15], "mixed"
        elif duration_setting == "5_10_15":
            return [5, 10, 15], "mixed"
        else:
            return None, "auto"

    @staticmethod
    def _detect_sentence_boundary(word: str) -> bool:
        """Check if a word ends at a sentence boundary."""
        cleaned = word.strip()
        return bool(re.search(r'[.!?;:—]$', cleaned)) or bool(re.search(r'[.!?]["\')\]]$', cleaned))

    @staticmethod
    def _detect_clause_boundary(word: str) -> bool:
        """Check if a word ends at a clause boundary (comma, semicolon, dash)."""
        cleaned = word.strip()
        return bool(re.search(r'[,;:\-–—]$', cleaned))

    @staticmethod
    def _calculate_pause_between_words(current_end: float, next_start: float) -> float:
        """Calculate the silence gap between two words."""
        return max(0, next_start - current_end)

    def _categorize_emotion_for_camera(self, emotion: str) -> str:
        """Map an emotion string to a camera movement category."""
        emotion_lower = emotion.lower().strip()
        mapping = {
            "peaceful": "contemplative", "calm": "contemplative", "serene": "contemplative",
            "reflective": "contemplative", "meditative": "contemplative",
            "tense": "tension", "anxious": "tension", "suspenseful": "tension",
            "nervous": "tension", "uneasy": "tension", "dread": "tension",
            "joyful": "dynamic", "excited": "dynamic", "energetic": "dynamic",
            "happy": "dynamic", "celebratory": "triumphant", "triumphant": "triumphant",
            "victorious": "triumphant", "proud": "triumphant",
            "sad": "intimate", "melancholic": "intimate", "grief": "intimate",
            "lonely": "intimate", "vulnerable": "intimate",
            "mysterious": "establishing", "curious": "establishing", "wonder": "establishing",
            "awe": "establishing", "discovery": "establishing",
            "angry": "dynamic", "furious": "dynamic", "rage": "dynamic",
            "fearful": "tension", "terrified": "tension", "horror": "tension",
            "romantic": "intimate", "tender": "intimate", "loving": "intimate",
            "epic": "triumphant", "grand": "triumphant", "majestic": "triumphant",
            "hopeful": "contemplative", "inspiring": "triumphant",
            "neutral": "establishing"
        }
        return mapping.get(emotion_lower, "establishing")

    # ══════════════════════════════════════════════════════════════════
    # MAIN EXECUTION
    # ══════════════════════════════════════════════════════════════════

    async def execute(self, inputs: Dict[str, Any]) -> TemplateResult:
        """Main execution entry point."""

        # ── Extract all inputs ──
        input_mode = inputs.get("input_mode", "story")
        story_text = inputs.get("story_text", "").strip()
        audio_file = inputs.get("audio_file")
        language = inputs.get("language", "en-US")
        visual_style = inputs.get("visual_style", "cinematic")
        scene_duration_setting = inputs.get("scene_duration", "auto")
        voice_style = inputs.get("voice_style", "neutral")
        add_camera = inputs.get("add_camera_movements", True)
        include_emotions = inputs.get("include_emotions", True)
        prompt_detail_level = inputs.get("prompt_detail_level", "director")
        aspect_ratio = inputs.get("aspect_ratio", "16:9")
        color_grading = inputs.get("color_grading", "auto")
        narrative_continuity = inputs.get("narrative_continuity", True)

        # ── Validate inputs ──
        if input_mode == "story":
            if not story_text:
                return mexflow.result.error(
                    "Please provide story text when using Story Text mode.",
                    details={"field": "story_text"}
                )
        else:
            if not audio_file:
                return mexflow.result.error(
                    "Please provide an audio file when using Direct Audio mode.",
                    details={"field": "audio_file"}
                )

        # ── Parse duration preferences ──
        preferred_durations, duration_mode = self._parse_duration_selections(scene_duration_setting)

        # ── Setup progress ──
        if input_mode == "story":
            total_stages = 6  # Config + Audio + Subtitle + Analysis + Scenes + Save
        else:
            total_stages = 6  # Config + Import + Subtitle + Analysis + Scenes + Save

        mexflow.progress.setup(total_stages)

        # ════════════════════════════════════════════════════════════
        # STAGE 1: Configuration Verification
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Configuration Check", "Verifying plugin availability...")

        config_issues = []

        if input_mode == "story":
            audio_config = await mexflow.audio_generator.get_config()
            if not audio_config:
                config_issues.append("Audio Generator plugin not configured (required for Story mode)")

        subtitle_config = await mexflow.subtitle_generator.get_config()
        if not subtitle_config:
            config_issues.append("Subtitle Generator plugin not configured")

        if config_issues:
            issue_text = "\n• ".join(config_issues)
            return mexflow.result.error(
                f"Plugin configuration required:\n• {issue_text}\n\nPlease configure in Settings > Default Plugins.",
                details={"missing_plugins": config_issues}
            )

        mexflow.progress.complete_stage("All plugins verified and ready")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 2: Audio Preparation
        # ════════════════════════════════════════════════════════════
        audio_id = None
        audio_duration = 0

        if input_mode == "story":
            mexflow.progress.start_stage("Generating Audio", "Converting narrative text to speech...")

            # Save audio script
            script_id = await mexflow.audio_script.save(
                script_text=story_text,
                language_code=language,
                status="generated"
            )

            if not script_id:
                return mexflow.result.error("Failed to save audio script")

            # Generate audio via TTS
            audio_result = await mexflow.audio_generator.generate(
                audio_script_id=script_id,
                speaking_rate=1.0
            )

            if not audio_result.get("success"):
                error_msg = audio_result.get("error", "Unknown error")
                warning_msg = audio_result.get("warning", "")
                return mexflow.result.error(
                    f"Audio generation failed: {warning_msg or error_msg}",
                    details={"stage": "audio_generation", "error": error_msg}
                )

            audio_id = audio_result.get("audio_id")
            audio_duration = audio_result.get("duration_seconds", 0)

            mexflow.progress.complete_stage(f"Audio generated — {audio_duration:.1f}s total duration")

        else:
            # Direct audio mode
            mexflow.progress.start_stage("Importing Audio", "Processing uploaded audio file...")

            if audio_file:
                if isinstance(audio_file, dict):
                    audio_id = audio_file.get("id") or audio_file.get("audio_id")
                    audio_duration = audio_file.get("duration_seconds", 0)
                elif isinstance(audio_file, str):
                    file_info = mexflow.file.get_file_info(audio_file)

                    if not file_info.get("exists"):
                        return mexflow.result.error(
                            f"Audio file not found: {file_info.get('name', audio_file)}",
                            details={"stage": "audio_import", "file": audio_file}
                        )

                    if file_info.get("type") not in ("audio", "video"):
                        return mexflow.result.error(
                            f"Invalid file type. Please select an audio file.",
                            details={"stage": "audio_import", "type": file_info.get("type")}
                        )

                    import_result = await mexflow.file.import_audio(
                        file_input=audio_file,
                        language=language
                    )

                    if not import_result.get("success"):
                        return mexflow.result.error(
                            f"Failed to import audio: {import_result.get('error', 'Unknown error')}",
                            details={"stage": "audio_import"}
                        )

                    audio_id = import_result.get("audio_id")
                    audio_duration = import_result.get("duration_seconds", 0)

            if not audio_id:
                return mexflow.result.error(
                    "Could not process the uploaded audio file.",
                    details={"stage": "audio_import"}
                )

            mexflow.progress.complete_stage(f"Audio imported — {audio_duration:.1f}s")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 3: Subtitle Generation
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Generating Subtitles", "Transcribing audio with word-level timing precision...")

        lang_code = language.split("-")[0] if "-" in language else language

        subtitle_result = await mexflow.subtitle_generator.generate(
            audio_id=audio_id,
            language=lang_code
        )

        if not subtitle_result.get("success"):
            error_msg = subtitle_result.get("error", "Unknown error")
            warning_msg = subtitle_result.get("warning", "")
            return mexflow.result.error(
                f"Subtitle generation failed: {warning_msg or error_msg}",
                details={"stage": "subtitle_generation", "error": error_msg}
            )

        subtitle_data = subtitle_result.get("subtitle_data", [])
        word_count = subtitle_result.get("word_count", 0)

        if not subtitle_data or word_count == 0:
            return mexflow.result.error(
                "No words detected in audio. Please verify the audio file contains speech.",
                details={"stage": "subtitle_generation", "word_count": 0}
            )

        mexflow.progress.complete_stage(f"Transcribed {word_count} words with precise timestamps")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 4: Calculate Required Scene Count & Prepare Data
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage(
            "Analyzing Narration",
            "Calculating scene requirements and preparing narration data..."
        )

        # ── Normalize subtitle data for timing lookup ──
        normalized_subtitle_data = []
        for item in subtitle_data:
            if isinstance(item, dict):
                normalized = dict(item)
                if 'word' not in normalized and 'text' in normalized:
                    normalized['word'] = normalized['text']
                elif 'word' not in normalized and 'text' not in normalized:
                    continue
                normalized_subtitle_data.append(normalized)
            else:
                normalized_subtitle_data.append(item)

        # ── Build full transcript from subtitle words ──
        full_narrative = " ".join(
            (w.get("word", "") or w.get("text", "")) for w in normalized_subtitle_data
        ).strip()

        if not full_narrative:
            return mexflow.result.error(
                "Could not build transcript from subtitle data.",
                details={"stage": "scene_segmentation"}
            )

        # ── Determine base scene duration ──
        allowed_durations = preferred_durations if preferred_durations else [5, 10, 15]
        allowed_sorted = sorted(allowed_durations)

        if duration_mode == "fixed" and preferred_durations:
            base_scene_dur = preferred_durations[0]
        elif duration_mode == "mixed" and preferred_durations:
            base_scene_dur = min(preferred_durations)
        else:
            base_scene_dur = 5

        # ── If audio_duration is unknown, derive from subtitle timestamps ──
        # This is CRITICAL: without accurate audio_duration, scene count goes wrong.
        # Subtitle word timestamps are always available and give the true speech span.
        if audio_duration <= 0 and normalized_subtitle_data:
            # Use the last word's end_time as audio duration estimate
            last_word = normalized_subtitle_data[-1]
            audio_duration_from_subs = last_word.get("end", last_word.get("start", 0))
            if audio_duration_from_subs > 0:
                # Add a small buffer (1-2s) for trailing silence
                audio_duration = audio_duration_from_subs + 1.5

        # ── Calculate required scene count (CRITICAL FORMULA) ──
        # required = ceil(audio_duration / scene_duration)
        # Total scene coverage MUST be >= audio_duration
        if audio_duration > 0:
            raw_count = audio_duration / base_scene_dur
            required_scene_count = math.ceil(raw_count)
            # Safety: verify total covers audio
            if required_scene_count * base_scene_dur < audio_duration:
                required_scene_count += 1
            required_scene_count = max(required_scene_count, 1)
        else:
            # Last resort fallback: estimate from word count (~4 words/sec avg speech)
            estimated_duration = len(normalized_subtitle_data) / 4.0
            required_scene_count = max(1, math.ceil(estimated_duration / base_scene_dur))

        total_scene_duration = required_scene_count * base_scene_dur

        mexflow.progress.complete_stage(
            f"Audio: {audio_duration:.1f}s | Scene duration: {base_scene_dur}s | "
            f"Required scenes: {required_scene_count} | Total coverage: {total_scene_duration}s"
        )

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 5: AI Scene Generation + Voiceover Segmentation
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage(
            "Generating Director's Scene Prompts",
            f"AI is creating {required_scene_count} scenes with voiceover segmentation and full visual specification..."
        )

        style_desc = self.STYLE_PROMPTS.get(visual_style, self.STYLE_PROMPTS["cinematic"])

        scenes = await self._generate_scene_prompts(
            subtitle_data=normalized_subtitle_data,
            full_narrative=full_narrative,
            audio_duration=audio_duration,
            required_scene_count=required_scene_count,
            base_scene_dur=base_scene_dur,
            preferred_durations=preferred_durations,
            duration_mode=duration_mode,
            style=style_desc,
            visual_style=visual_style,
            add_camera=add_camera,
            include_emotions=include_emotions,
            language=language,
            aspect_ratio=aspect_ratio,
            color_grading=color_grading,
            narrative_continuity=narrative_continuity,
            prompt_detail_level=prompt_detail_level
        )

        if not scenes:
            return mexflow.result.error(
                "Failed to generate scene prompts.",
                details={"stage": "prompt_generation"}
            )

        mexflow.progress.complete_stage(
            f"Generated {len(scenes)} professional scene prompts"
        )

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 6: Bulk Save to Database
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Saving Scenes", "Writing scene data to project database...")

        # Prepare scenes for bulk save
        bulk_scenes = []
        for scene in scenes:
            bulk_scenes.append({
                "scene_id_str": scene.get("scene_id_str", f"1.{scene.get('order', 1)}"),
                "title": scene.get("title", f"Scene {scene.get('order', 1)}"),
                "image_prompt": scene.get("image_prompt", ""),
                "voiceover": scene.get("voiceover", ""),
                "duration": scene.get("duration", 5),
                "characters": scene.get("characters", []),
                "metadata": {
                    "start_time": scene.get("start_time", 0),
                    "end_time": scene.get("end_time", 0),
                    "camera": scene.get("camera", ""),
                    "emotion": scene.get("emotion", ""),
                    "lighting": scene.get("lighting", ""),
                    "aspect_ratio": aspect_ratio,
                    "visual_style": visual_style,
                    "color_grading": scene.get("color_grading", ""),
                    "composition": scene.get("composition", ""),
                    "scene_context": scene.get("scene_context", ""),
                    "json_prompt": scene.get("json_prompt", {})
                }
            })

        scene_uuids = await mexflow.scene_data.save_scenes_bulk(
            scenes=bulk_scenes,
            clear_existing=True
        )

        saved_count = len(scene_uuids) if scene_uuids else 0

        mexflow.progress.complete_stage(f"Saved {saved_count} scenes to project")

        # ════════════════════════════════════════════════════════════
        # Return Success
        # ════════════════════════════════════════════════════════════
        return mexflow.result.success(
            scenes,
            message=f"Successfully created {saved_count} professional scenes from audio workflow!",
            metadata={
                "scene_count": saved_count,
                "audio_duration": audio_duration,
                "word_count": word_count,
                "input_mode": input_mode,
                "visual_style": visual_style,
                "duration_mode": duration_mode,
                "preferred_durations": preferred_durations or [5, 10, 15],
                "aspect_ratio": aspect_ratio,
                "audio_id": audio_id
            }
        )

    # ══════════════════════════════════════════════════════════════════
    # SCENE SEGMENTATION ENGINE
    # ══════════════════════════════════════════════════════════════════

    def _segment_into_scenes(
        self,
        subtitle_data: List[Dict],
        preferred_durations: Optional[List[int]] = None,
        duration_mode: str = "auto",
        audio_duration: float = 0
    ) -> List[Dict]:
        """
        Intelligently segment subtitle word data into scene chunks while
        preserving semantic context and narrative coherence.

        CRITICAL RULE — FULL AUDIO COVERAGE:
        The total scene duration MUST be >= audio_duration. The required number
        of scenes is calculated FIRST from audio_duration / scene_duration, and
        then subtitle words are distributed across exactly that many scenes.

        Steps:
        1. Normalize subtitle data
        2. Calculate the REQUIRED number of scenes from audio duration
        3. Build sentence-level groupings from word data
        4. Distribute sentences across the required scene count
        5. Verify total scene duration >= audio duration, add scenes if not
        """
        if not subtitle_data:
            return []

        # ── Normalize subtitle data: handle both 'word' and 'text' keys ──
        normalized_subtitle_data = []
        for item in subtitle_data:
            if isinstance(item, dict):
                normalized = dict(item)
                if 'word' not in normalized and 'text' in normalized:
                    normalized['word'] = normalized['text']
                elif 'word' not in normalized and 'text' not in normalized:
                    continue
                normalized_subtitle_data.append(normalized)
            else:
                normalized_subtitle_data.append(item)

        subtitle_data = normalized_subtitle_data

        if not subtitle_data:
            return []

        # ══════════════════════════════════════════════════════════════
        # STEP 1: CALCULATE REQUIRED NUMBER OF SCENES
        # This is the authoritative scene count — everything else adapts
        # to produce exactly this many (or more) scenes.
        #
        # Formula: required = int(audio_duration / scene_dur)
        #          if remainder exists → +1
        #          then verify total >= audio_duration, if not → +1
        # ══════════════════════════════════════════════════════════════

        # Determine the base scene duration for calculation
        allowed = preferred_durations if preferred_durations else [5, 10, 15]
        allowed_sorted = sorted(allowed)

        if duration_mode == "fixed" and preferred_durations:
            base_scene_dur = preferred_durations[0]
        elif duration_mode == "mixed" and preferred_durations:
            # For mixed mode, use the smallest preferred duration to maximize coverage
            base_scene_dur = min(preferred_durations)
        else:
            # Auto mode — default to 5s base
            base_scene_dur = 5

        # If audio_duration is unknown, derive from subtitle timestamps
        if audio_duration <= 0 and subtitle_data:
            last_word = subtitle_data[-1]
            audio_duration_from_subs = last_word.get("end", last_word.get("start", 0))
            if audio_duration_from_subs > 0:
                audio_duration = audio_duration_from_subs + 1.5

        # Calculate required scene count from audio duration
        if audio_duration > 0:
            raw_count = audio_duration / base_scene_dur
            required_scene_count = math.ceil(raw_count)
            # Safety: verify total duration covers audio, if not add +1
            if required_scene_count * base_scene_dur < audio_duration:
                required_scene_count += 1
            # Minimum 1 scene
            required_scene_count = max(required_scene_count, 1)
        else:
            # No audio duration info — fall back to subtitle-driven segmentation
            required_scene_count = None  # Will be determined by content

        # ══════════════════════════════════════════════════════════════
        # STEP 2: BUILD SENTENCE-LEVEL GROUPINGS
        # ══════════════════════════════════════════════════════════════
        sentences = []
        current_sentence_words = []
        current_sentence_start = 0

        for i, word_info in enumerate(subtitle_data):
            word = word_info.get("word", "") or word_info.get("text", "")
            start = word_info.get("start", 0)
            end = word_info.get("end", start + 0.3)

            if not current_sentence_words:
                current_sentence_start = start

            current_sentence_words.append(word_info)

            is_sentence_end = self._detect_sentence_boundary(word)

            # Also check for significant pauses as implicit sentence breaks
            has_long_pause = False
            if i + 1 < len(subtitle_data):
                next_start = subtitle_data[i + 1].get("start", end)
                pause = self._calculate_pause_between_words(end, next_start)
                if pause >= 0.5:
                    has_long_pause = True

            if is_sentence_end or has_long_pause or i == len(subtitle_data) - 1:
                sentence_text = " ".join(
                    (w.get("word", "") or w.get("text", "")) for w in current_sentence_words
                ).strip()
                sentence_end = end

                sentences.append({
                    "words": current_sentence_words[:],
                    "text": sentence_text,
                    "start_time": current_sentence_start,
                    "end_time": sentence_end,
                    "duration": sentence_end - current_sentence_start,
                    "word_count": len(current_sentence_words)
                })
                current_sentence_words = []

        if not sentences:
            return []

        # ══════════════════════════════════════════════════════════════
        # STEP 3: DISTRIBUTE SENTENCES INTO THE REQUIRED NUMBER OF SCENES
        # Instead of merging by duration thresholds (which produces too few
        # scenes), we now target the required_scene_count directly.
        # ══════════════════════════════════════════════════════════════

        if required_scene_count is not None and required_scene_count > 0 and audio_duration > 0:
            # ── Duration-driven segmentation: target exactly required_scene_count scenes ──
            # Each scene covers approximately (audio_duration / required_scene_count) seconds
            target_scene_time = audio_duration / required_scene_count

            segments = []
            current_segment = {
                "words": [],
                "text": "",
                "start_time": 0,
                "end_time": 0,
                "sentence_texts": []
            }
            scenes_remaining = required_scene_count

            for si, sent in enumerate(sentences):
                sentences_remaining = len(sentences) - si

                # If current segment is empty, start fresh
                if not current_segment["words"]:
                    current_segment["start_time"] = sent["start_time"]
                    current_segment["words"] = sent["words"][:]
                    current_segment["sentence_texts"] = [sent["text"]]
                    current_segment["end_time"] = sent["end_time"]
                else:
                    # Merge this sentence into the current segment
                    current_segment["words"].extend(sent["words"])
                    current_segment["sentence_texts"].append(sent["text"])
                    current_segment["end_time"] = sent["end_time"]

                current_duration = current_segment["end_time"] - current_segment["start_time"]

                # Decide whether to finalize this segment:
                # 1. We've reached the target duration for this scene
                # 2. We need to leave enough sentences for remaining scenes
                # 3. This is the last sentence
                should_finalize = False

                if si == len(sentences) - 1:
                    # Last sentence — must finalize
                    should_finalize = True
                elif scenes_remaining <= 1:
                    # Only one scene left — collect all remaining sentences
                    # (will finalize at the end)
                    pass
                elif current_duration >= target_scene_time * 0.7:
                    # Current segment has reached a reasonable duration
                    # Check if we have enough sentences left for remaining scenes
                    if sentences_remaining - 1 >= scenes_remaining - 1:
                        # Still enough sentences for the other scenes
                        should_finalize = True
                    elif current_duration >= target_scene_time:
                        # Exceeded target, finalize regardless
                        should_finalize = True

                if should_finalize and scenes_remaining > 0:
                    current_segment["text"] = " ".join(current_segment["sentence_texts"]).strip()
                    segments.append(current_segment)
                    scenes_remaining -= 1

                    current_segment = {
                        "words": [],
                        "text": "",
                        "start_time": 0,
                        "end_time": 0,
                        "sentence_texts": []
                    }

            # Flush any remaining words
            if current_segment["words"]:
                current_segment["text"] = " ".join(current_segment["sentence_texts"]).strip()
                if segments:
                    # If we already have enough scenes, merge into the last one
                    # to avoid creating an extra tiny segment
                    last_dur = segments[-1]["end_time"] - segments[-1]["start_time"]
                    remaining_dur = current_segment["end_time"] - current_segment["start_time"]
                    if len(segments) >= required_scene_count and remaining_dur < base_scene_dur * 0.5:
                        segments[-1]["words"].extend(current_segment["words"])
                        segments[-1]["sentence_texts"].extend(current_segment["sentence_texts"])
                        segments[-1]["text"] = " ".join(segments[-1]["sentence_texts"]).strip()
                        segments[-1]["end_time"] = current_segment["end_time"]
                    else:
                        segments.append(current_segment)
                else:
                    segments.append(current_segment)

        else:
            # ── Fallback: Content-driven segmentation (no audio_duration) ──
            if duration_mode == "fixed" and preferred_durations:
                target = preferred_durations[0]
                min_dur = target * 0.5
                max_dur = target * 1.4
            elif duration_mode == "mixed" and preferred_durations:
                min_target = min(preferred_durations)
                max_target = max(preferred_durations)
                min_dur = min_target * 0.5
                max_dur = max_target * 1.3
            else:
                min_dur = 2.5
                max_dur = 8.0

            segments = []
            current_segment = {
                "words": [],
                "text": "",
                "start_time": 0,
                "end_time": 0,
                "sentence_texts": []
            }

            for sent in sentences:
                if not current_segment["words"]:
                    current_segment["start_time"] = sent["start_time"]
                    current_segment["words"] = sent["words"][:]
                    current_segment["sentence_texts"] = [sent["text"]]
                    current_segment["end_time"] = sent["end_time"]
                    continue

                potential_duration = sent["end_time"] - current_segment["start_time"]
                current_duration = current_segment["end_time"] - current_segment["start_time"]

                if current_duration >= min_dur and potential_duration > max_dur:
                    current_segment["text"] = " ".join(current_segment["sentence_texts"]).strip()
                    segments.append(current_segment)
                    current_segment = {
                        "words": sent["words"][:],
                        "text": "",
                        "start_time": sent["start_time"],
                        "end_time": sent["end_time"],
                        "sentence_texts": [sent["text"]]
                    }
                else:
                    current_segment["words"].extend(sent["words"])
                    current_segment["sentence_texts"].append(sent["text"])
                    current_segment["end_time"] = sent["end_time"]

            if current_segment["words"]:
                current_segment["text"] = " ".join(current_segment["sentence_texts"]).strip()
                segments.append(current_segment)

        # ── Handle very short trailing segments by merging back ──
        if len(segments) > 1:
            last = segments[-1]
            last_dur = last["end_time"] - last["start_time"]
            if last_dur < 1.5:
                prev = segments[-2]
                prev["words"].extend(last["words"])
                prev["sentence_texts"].extend(last.get("sentence_texts", []))
                prev["text"] = " ".join(prev.get("sentence_texts", [])).strip()
                if not prev["text"]:
                    prev["text"] = " ".join(
                        (w.get("word", "") or w.get("text", "")) for w in prev["words"]
                    ).strip()
                prev["end_time"] = last["end_time"]
                segments.pop()

        # ══════════════════════════════════════════════════════════════
        # STEP 4: SNAP DURATIONS TO ALLOWED VALUES
        # ══════════════════════════════════════════════════════════════
        finalized = []
        for seg in segments:
            raw_duration = seg["end_time"] - seg["start_time"]
            snapped_duration = self._snap_to_allowed_duration(raw_duration, preferred_durations)

            text = seg.get("text", "")
            if not text:
                text = " ".join(
                    (w.get("word", "") or w.get("text", "")) for w in seg.get("words", [])
                ).strip()

            finalized.append({
                "words": seg.get("words", []),
                "text": text,
                "start_time": round(seg["start_time"], 3),
                "end_time": round(seg["end_time"], 3),
                "raw_duration": round(raw_duration, 3),
                "duration": snapped_duration,
                "word_count": len(seg.get("words", []))
            })

        # ══════════════════════════════════════════════════════════════
        # STEP 5: ENFORCE FULL AUDIO COVERAGE (CRITICAL)
        # Total scene duration MUST be >= audio_duration.
        #
        # Strategy A: If we have fewer scenes than required, split the
        #             longest scenes or add new scenes.
        # Strategy B: Extend existing scene durations upward.
        # Strategy C: Add padding scenes until coverage is met.
        #
        # After all adjustments, re-verify and add +1 scene if still short.
        # ══════════════════════════════════════════════════════════════
        if audio_duration > 0 and finalized:
            min_allowed = allowed_sorted[0]
            max_allowed = allowed_sorted[-1]

            # ── Strategy A: Ensure we have at least required_scene_count scenes ──
            if required_scene_count is not None:
                while len(finalized) < required_scene_count:
                    # Find the longest scene and split it
                    longest_idx = 0
                    longest_dur = 0
                    for idx, seg in enumerate(finalized):
                        rd = seg.get("raw_duration", seg["duration"])
                        if rd > longest_dur:
                            longest_dur = rd
                            longest_idx = idx

                    seg_to_split = finalized[longest_idx]
                    words = seg_to_split.get("words", [])

                    if len(words) >= 2:
                        # Split words roughly in half
                        mid = len(words) // 2
                        first_words = words[:mid]
                        second_words = words[mid:]

                        first_text = " ".join(
                            (w.get("word", "") or w.get("text", "")) for w in first_words
                        ).strip()
                        second_text = " ".join(
                            (w.get("word", "") or w.get("text", "")) for w in second_words
                        ).strip()

                        first_start = seg_to_split["start_time"]
                        first_end = first_words[-1].get("end", first_words[-1].get("start", 0) + 0.3)
                        second_start = second_words[0].get("start", first_end)
                        second_end = seg_to_split["end_time"]

                        first_raw = first_end - first_start
                        second_raw = second_end - second_start

                        first_seg = {
                            "words": first_words,
                            "text": first_text,
                            "start_time": round(first_start, 3),
                            "end_time": round(first_end, 3),
                            "raw_duration": round(first_raw, 3),
                            "duration": self._snap_to_allowed_duration(first_raw, preferred_durations),
                            "word_count": len(first_words)
                        }
                        second_seg = {
                            "words": second_words,
                            "text": second_text,
                            "start_time": round(second_start, 3),
                            "end_time": round(second_end, 3),
                            "raw_duration": round(second_raw, 3),
                            "duration": self._snap_to_allowed_duration(second_raw, preferred_durations),
                            "word_count": len(second_words)
                        }

                        finalized[longest_idx] = first_seg
                        finalized.insert(longest_idx + 1, second_seg)
                    else:
                        # Can't split further — add a padding scene instead
                        last = finalized[-1]
                        padding_start = last["end_time"]
                        finalized.append({
                            "words": [],
                            "text": last.get("text", ""),
                            "start_time": round(padding_start, 3),
                            "end_time": round(padding_start + float(min_allowed), 3),
                            "raw_duration": float(min_allowed),
                            "duration": min_allowed,
                            "word_count": 0
                        })

            # ── Strategy B: Extend scene durations upward to cover gap ──
            total_scene_duration = sum(seg["duration"] for seg in finalized)

            if total_scene_duration < audio_duration:
                for i in range(len(finalized) - 1, -1, -1):
                    if total_scene_duration >= audio_duration:
                        break
                    current_dur = finalized[i]["duration"]
                    if current_dur < max_allowed:
                        higher = [d for d in allowed_sorted if d > current_dur]
                        if higher:
                            new_dur = higher[0]
                            total_scene_duration += (new_dur - current_dur)
                            finalized[i]["duration"] = new_dur

            # ── Strategy C: Add padding scenes until total >= audio_duration ──
            total_scene_duration = sum(seg["duration"] for seg in finalized)

            while total_scene_duration < audio_duration:
                last = finalized[-1]
                padding_start = last["end_time"]
                # Use base_scene_dur for padding scenes to be consistent
                pad_dur = base_scene_dur
                finalized.append({
                    "words": [],
                    "text": last.get("text", ""),
                    "start_time": round(padding_start, 3),
                    "end_time": round(padding_start + float(pad_dur), 3),
                    "raw_duration": float(pad_dur),
                    "duration": pad_dur,
                    "word_count": 0
                })
                total_scene_duration += pad_dur

            # ── Final verification: if STILL short after everything, add +1 ──
            total_scene_duration = sum(seg["duration"] for seg in finalized)
            if total_scene_duration < audio_duration:
                last = finalized[-1]
                padding_start = last["end_time"]
                finalized.append({
                    "words": [],
                    "text": last.get("text", ""),
                    "start_time": round(padding_start, 3),
                    "end_time": round(padding_start + float(min_allowed), 3),
                    "raw_duration": float(min_allowed),
                    "duration": min_allowed,
                    "word_count": 0
                })

        return finalized

    # ══════════════════════════════════════════════════════════════════
    # WORD TIMING MAPPER
    # Maps AI-generated voiceover text back to subtitle word timestamps
    # ══════════════════════════════════════════════════════════════════

    def _map_voiceover_timing(
        self,
        voiceover_text: str,
        subtitle_data: List[Dict],
        search_start_idx: int = 0
    ) -> Tuple[float, float, int]:
        """
        Given a voiceover text string from AI, find the matching words in
        subtitle_data and return (start_time, end_time, next_search_idx).

        Uses a forward-scanning fuzzy word match to handle minor AI
        reformulations (punctuation differences, minor word changes).
        """
        if not voiceover_text or not subtitle_data:
            return (0.0, 0.0, search_start_idx)

        # Extract words from the voiceover text (lowercase, strip punctuation for matching)
        vo_words_raw = voiceover_text.split()
        if not vo_words_raw:
            return (0.0, 0.0, search_start_idx)

        def clean_word(w):
            """Strip punctuation for fuzzy matching."""
            return re.sub(r'[^a-zA-Z0-9\u0080-\uffff]', '', w.lower()).strip()

        vo_words_clean = [clean_word(w) for w in vo_words_raw]
        # Remove empty strings
        vo_words_clean = [w for w in vo_words_clean if w]

        if not vo_words_clean:
            return (0.0, 0.0, search_start_idx)

        # Find the first matching word in subtitle_data starting from search_start_idx
        first_vo_word = vo_words_clean[0]
        start_time = 0.0
        end_time = 0.0
        match_start_idx = search_start_idx
        found_start = False

        for idx in range(search_start_idx, len(subtitle_data)):
            sub_word = subtitle_data[idx].get("word", "") or subtitle_data[idx].get("text", "")
            sub_word_clean = clean_word(sub_word)

            if sub_word_clean == first_vo_word:
                start_time = subtitle_data[idx].get("start", 0)
                match_start_idx = idx
                found_start = True
                break

        if not found_start:
            # Couldn't find exact match — use position-based fallback
            if search_start_idx < len(subtitle_data):
                start_time = subtitle_data[search_start_idx].get("start", 0)
                match_start_idx = search_start_idx

        # Find the last matching word
        last_vo_word = vo_words_clean[-1]
        end_idx = match_start_idx

        # Scan forward from match_start_idx to find the last word
        # Use a window that's proportional to the voiceover word count
        max_scan = min(match_start_idx + len(vo_words_clean) * 2 + 5, len(subtitle_data))

        for idx in range(max_scan - 1, match_start_idx - 1, -1):
            if idx >= len(subtitle_data):
                continue
            sub_word = subtitle_data[idx].get("word", "") or subtitle_data[idx].get("text", "")
            sub_word_clean = clean_word(sub_word)

            if sub_word_clean == last_vo_word:
                end_time = subtitle_data[idx].get("end", subtitle_data[idx].get("start", 0) + 0.3)
                end_idx = idx
                break

        if end_time <= start_time:
            # Fallback: estimate end from word count
            estimated_end_idx = min(match_start_idx + len(vo_words_clean) - 1, len(subtitle_data) - 1)
            end_time = subtitle_data[estimated_end_idx].get("end",
                subtitle_data[estimated_end_idx].get("start", 0) + 0.3
            )
            end_idx = estimated_end_idx

        next_search_idx = end_idx + 1
        return (start_time, end_time, next_search_idx)

    # ══════════════════════════════════════════════════════════════════
    # PROFESSIONAL SCENE PROMPT GENERATION (AI-DRIVEN SEGMENTATION)
    # ══════════════════════════════════════════════════════════════════

    async def _generate_scene_prompts(
        self,
        subtitle_data: List[Dict],
        full_narrative: str,
        audio_duration: float,
        required_scene_count: int,
        base_scene_dur: int,
        preferred_durations: Optional[List[int]],
        duration_mode: str,
        style: str,
        visual_style: str,
        add_camera: bool,
        include_emotions: bool,
        language: str,
        aspect_ratio: str,
        color_grading: str,
        narrative_continuity: bool,
        prompt_detail_level: str
    ) -> List[Dict]:
        """
        Generate PSD-level professional scene prompts using AI.

        CRITICAL: The AI is responsible for BOTH:
        1. Splitting the voiceover text into exactly required_scene_count segments
        2. Generating exhaustive scene direction prompts for each segment

        The AI receives: full_narrative, audio_duration, required_scene_count,
        and scene_duration — and must return exactly that many scenes with
        properly segmented voiceover text.

        After AI response, word-level timing is mapped from subtitle_data.
        """
        # ── Build comprehensive AI prompt ──
        camera_block = ""
        if add_camera:
            camera_block = """
CAMERA & LENS DIRECTION (MANDATORY for each scene):
- Specify exact camera movement pattern (dolly, crane, Steadicam, static, handheld, etc.)
- Include lens choice (wide-angle, telephoto, macro, anamorphic, etc.)
- Define camera angle (low angle, high angle, eye level, bird's eye, worm's eye, Dutch angle)
- Describe camera distance (extreme wide shot, wide, full, medium, close-up, extreme close-up)
- Note any focus techniques (rack focus, deep focus, shallow DOF, split diopter)
"""

        emotion_block = ""
        if include_emotions:
            emotion_block = """
EMOTIONAL & TONAL DIRECTION (MANDATORY for each scene):
- Primary emotional tone driving the visual choices
- Character emotional state reflected in posture, expression, and blocking
- Pacing rhythm (frenetic, measured, languid, staccato, flowing)
- Color psychology reinforcing the emotional arc
- Sound design atmosphere notes (ambient, silence, tension, warmth)
"""

        continuity_block = ""
        if narrative_continuity:
            continuity_block = """
NARRATIVE CONTINUITY RULES (CRITICAL):
- Each scene's visuals must logically follow from the previous scene
- Maintain consistent character appearance, wardrobe, and props across scenes
- Environmental transitions must be motivated by the narration
- Color palette should evolve gradually to reflect the narrative arc
- Time of day and weather must remain consistent within continuous sequences
- Reference previous scene elements when relevant for visual threading
"""

        # ── Duration info for AI ──
        if duration_mode == "mixed" and preferred_durations:
            duration_instruction = (
                f"Each scene duration is {base_scene_dur} seconds. "
                f"Allowed durations are: {preferred_durations} seconds. "
                f"You may assign any of these durations to each scene."
            )
        else:
            duration_instruction = f"Each scene duration is exactly {base_scene_dur} seconds."

        ai_prompt = mexflow.ai.create_prompt(
            '''You are an elite Production Scene Director (PSD) and Cinematographer with 30 years of experience directing visual storytelling for prestige cinema.

════════════════════════════════════════════════════
YOUR MISSION — TWO CRITICAL TASKS:
════════════════════════════════════════════════════

TASK 1 — VOICEOVER SEGMENTATION (CRITICAL):
You MUST split the full narration text below into EXACTLY {required_scene_count} voiceover segments.
- Total audio duration: {audio_duration} seconds
- {duration_instruction}
- Total scenes required: {required_scene_count}
- You MUST produce EXACTLY {required_scene_count} scenes — no more, no less.
- Split the narration at natural sentence or clause boundaries.
- Every single word from the narration MUST appear in exactly one scene's voiceover.
- Do NOT skip, drop, or add any words. The combined voiceover of all scenes must equal the full narration.
- Distribute the text roughly evenly — do NOT put all text in the first few scenes and leave others empty.

TASK 2 — SCENE DIRECTION (for each of the {required_scene_count} scenes):
Generate exhaustively detailed professional scene direction prompts.
Each scene's "image_prompt" MUST be between 2500 and 3000 characters long — this is a HARD REQUIREMENT.

════════════════════════════════════════════════════
FULL NARRATION TEXT (split this into {required_scene_count} voiceover segments):
════════════════════════════════════════════════════
{full_narrative}

════════════════════════════════════════════════════
AUDIO TIMING INFORMATION:
════════════════════════════════════════════════════
- Total audio duration: {audio_duration} seconds
- Required number of scenes: {required_scene_count}
- {duration_instruction}
- Total scene coverage must be >= {audio_duration} seconds

════════════════════════════════════════════════════
VISUAL STYLE SPECIFICATION:
════════════════════════════════════════════════════
{style}

Aspect Ratio: {aspect_ratio}
Color Grading Preference: {color_grading}

════════════════════════════════════════════════════
MANDATORY PROMPT STRUCTURE FOR EACH SCENE:
════════════════════════════════════════════════════

Each scene's "image_prompt" MUST contain ALL of the following woven into a cohesive professional direction paragraph (2500-3000 characters):

1. ENVIRONMENT & SETTING: Comprehensive description of the physical space
2. SUBJECT & BLOCKING: Detailed description of all subjects, positioning, body language
3. LIGHTING DESIGN: Technical lighting setup with color temperature and ratios
4. COMPOSITION & FRAMING: Precise compositional direction with rule of thirds
5. COLOR PALETTE & GRADING: Dominant and accent color specification (3-4 colors)
6. ATMOSPHERIC EFFECTS: Fog, mist, haze, particles, lens effects
7. TEXTURE & MATERIAL: Surface quality descriptions of materials in frame
8. MOOD & TONE KEYWORDS: Final line of concentrated style keywords

{camera_instruction}
{emotion_instruction}
{continuity_instruction}

════════════════════════════════════════════════════
OUTPUT FORMAT — STRICT JSON ARRAY:
════════════════════════════════════════════════════

Return ONLY a valid JSON array with EXACTLY {required_scene_count} elements. Each element MUST contain:
- "scene_number": integer (1, 2, 3... — MUST be integer, NOT float)
- "voiceover": string (the voiceover text segment for this scene — CRITICAL: must contain the actual narration words)
- "duration": integer ({base_scene_dur} seconds)
- "title": string (evocative 3-6 word professional scene title)
- "image_prompt": string (2500-3000 characters of exhaustive visual direction)
- "camera": string (detailed camera movement and lens direction, 100-200 characters)
- "emotion": string (primary emotional tone, single word or short phrase)
- "lighting": string (lighting setup name and description, 80-150 characters)
- "composition": string (compositional approach description, 80-150 characters)
- "color_palette": array of 4 strings (dominant colors in the scene)
- "subjects": array of strings (all subjects/characters visible in the scene)
- "scene_context": string (1-2 sentence description of what's happening)
- "transition": string ("cut", "dissolve", "fade", "wipe", or "match_cut")

════════════════════════════════════════════════════
CRITICAL REQUIREMENTS:
════════════════════════════════════════════════════
- You MUST return EXACTLY {required_scene_count} scene objects — this is NON-NEGOTIABLE
- "voiceover" field MUST contain the actual narration text for that scene (NOT a description)
- The combined voiceover text of ALL scenes must equal the FULL narration above
- image_prompt MUST be 2500-3000 characters per scene
- scene_number MUST be plain integers (1, 2, 3) — NEVER floats
- duration MUST be {base_scene_dur} for each scene
- Include visual style "{visual_style}" naturally in each prompt
- Professional cinematography terminology throughout

Return ONLY the JSON array, no commentary:''',
            full_narrative=full_narrative[:4000],
            audio_duration=round(audio_duration, 1),
            required_scene_count=required_scene_count,
            duration_instruction=duration_instruction,
            base_scene_dur=base_scene_dur,
            style=style,
            visual_style=visual_style,
            aspect_ratio=aspect_ratio,
            color_grading=color_grading if color_grading != "auto" else "match visual style and emotional arc",
            camera_instruction=camera_block if add_camera else "",
            emotion_instruction=emotion_block if include_emotions else "",
            continuity_instruction=continuity_block if narrative_continuity else ""
        )

        # ── Generate with AI ──
        response = await mexflow.ai.generate(
            prompt=ai_prompt,
            max_tokens=80000
        )

        if not response:
            return self._generate_fallback_scenes(
                subtitle_data=subtitle_data,
                full_narrative=full_narrative,
                audio_duration=audio_duration,
                required_scene_count=required_scene_count,
                base_scene_dur=base_scene_dur,
                style=style,
                visual_style=visual_style,
                add_camera=add_camera,
                preferred_durations=preferred_durations,
                aspect_ratio=aspect_ratio
            )

        # ── Parse AI response ──
        ai_scenes = mexflow.ai.parse_json(response)

        if not ai_scenes or not isinstance(ai_scenes, list):
            if isinstance(ai_scenes, dict):
                ai_scenes = ai_scenes.get("scenes", [])
            if not ai_scenes:
                return self._generate_fallback_scenes(
                    subtitle_data=subtitle_data,
                    full_narrative=full_narrative,
                    audio_duration=audio_duration,
                    required_scene_count=required_scene_count,
                    base_scene_dur=base_scene_dur,
                    style=style,
                    visual_style=visual_style,
                    add_camera=add_camera,
                    preferred_durations=preferred_durations,
                    aspect_ratio=aspect_ratio
                )

        # ── Sort AI scenes by scene_number to ensure order ──
        ai_scenes.sort(key=lambda s: int(s.get("scene_number", 0)) if s.get("scene_number") is not None else 0)

        # ── Map word-level timing from subtitle_data to each scene's voiceover ──
        scenes = []
        search_idx = 0  # Forward pointer into subtitle_data for timing lookup

        for i, ai_scene in enumerate(ai_scenes):
            scene_idx = i + 1

            # Fix scene_number if AI returned float
            sn = ai_scene.get("scene_number", scene_idx)
            if isinstance(sn, float):
                sn = int(sn)

            # Get voiceover text from AI
            voiceover = ai_scene.get("voiceover", "").strip()

            # Get duration from AI (should be base_scene_dur)
            duration = ai_scene.get("duration", base_scene_dur)
            if isinstance(duration, float):
                duration = int(duration)
            # Snap to allowed
            duration = self._snap_to_allowed_duration(duration, preferred_durations)

            # Map timing from subtitle word data
            start_time, end_time, search_idx = self._map_voiceover_timing(
                voiceover_text=voiceover,
                subtitle_data=subtitle_data,
                search_start_idx=search_idx
            )

            # If timing mapping failed, calculate from scene index
            if start_time == 0 and end_time == 0 and i > 0:
                # Use previous scene's end_time as this scene's start
                prev = scenes[-1]
                start_time = prev["end_time"]
                end_time = start_time + duration

            # Get emotion and map to camera category
            emotion = ai_scene.get("emotion", "neutral")
            camera_category = self._categorize_emotion_for_camera(emotion)

            # Get or generate camera movement
            import random
            camera_text = ai_scene.get("camera", "")
            if not camera_text and add_camera:
                category_moves = self.CAMERA_MOVEMENTS.get(camera_category, self.CAMERA_MOVEMENTS["establishing"])
                camera_text = random.choice(category_moves)

            # Get lighting
            lighting_text = ai_scene.get("lighting", "")
            if not lighting_text:
                emotion_key = emotion.lower().strip()
                lighting_text = self.LIGHTING_SETUPS.get(emotion_key, self.LIGHTING_SETUPS["neutral"])

            # Build the final scene object
            scene = {
                "scene_id_str": f"1.{scene_idx}",
                "title": ai_scene.get("title", f"Scene {scene_idx}"),
                "image_prompt": ai_scene.get("image_prompt", f"{style}, visual depiction of: {voiceover[:200]}"),
                "voiceover": voiceover,
                "duration": duration,
                "start_time": round(start_time, 3),
                "end_time": round(end_time, 3),
                "camera": camera_text,
                "emotion": emotion,
                "lighting": lighting_text,
                "composition": ai_scene.get("composition", "balanced professional framing"),
                "color_grading": ", ".join(ai_scene.get("color_palette", [])) if ai_scene.get("color_palette") else "",
                "scene_context": ai_scene.get("scene_context", voiceover[:150]),
                "characters": [{"name": s, "role": "subject"} for s in ai_scene.get("subjects", [])],
                "order": scene_idx,
                "json_prompt": {
                    "style": visual_style,
                    "lighting": lighting_text,
                    "subjects": ai_scene.get("subjects", []),
                    "camera_movement": camera_text,
                    "mood": emotion,
                    "composition": ai_scene.get("composition", ""),
                    "color_palette": ai_scene.get("color_palette", []),
                    "transition": ai_scene.get("transition", "cut"),
                    "aspect_ratio": aspect_ratio,
                    "duration": duration,
                    "scene_number": scene_idx
                }
            }

            scenes.append(scene)

        # ══════════════════════════════════════════════════════════════
        # POST-AI ENFORCEMENT: STRICTLY enforce required_scene_count
        # 
        # Rule: total scenes MUST be exactly required_scene_count
        # Rule: total duration MUST be >= audio_duration
        #
        # If AI returned TOO MANY → merge excess scenes into last scene
        # If AI returned TOO FEW → pad with continuation scenes
        # Then verify total_duration = scene_count × base_scene_dur
        # ══════════════════════════════════════════════════════════════

        # ── CASE 1: AI returned MORE scenes than required → trim to exact count ──
        if len(scenes) > required_scene_count:
            # Keep exactly required_scene_count scenes
            # Merge the voiceover text of excess scenes into the last kept scene
            kept_scenes = scenes[:required_scene_count]
            excess_scenes = scenes[required_scene_count:]

            # Collect excess voiceover text
            excess_voiceover = " ".join(
                s.get("voiceover", "") for s in excess_scenes
            ).strip()

            # Merge into last kept scene
            if excess_voiceover and kept_scenes:
                last_vo = kept_scenes[-1].get("voiceover", "")
                if last_vo:
                    kept_scenes[-1]["voiceover"] = last_vo + " " + excess_voiceover
                else:
                    kept_scenes[-1]["voiceover"] = excess_voiceover

            scenes = kept_scenes

        # ── CASE 2: AI returned FEWER scenes than required → pad ──
        while len(scenes) < required_scene_count:
            last = scenes[-1] if scenes else None
            pad_idx = len(scenes) + 1
            pad_start = last["end_time"] if last else 0

            scenes.append({
                "scene_id_str": f"1.{pad_idx}",
                "title": last.get("title", f"Scene {pad_idx}") if last else f"Scene {pad_idx}",
                "image_prompt": last.get("image_prompt", f"{style}, continuation") if last else f"{style}, establishing shot",
                "voiceover": "",
                "duration": base_scene_dur,
                "start_time": round(pad_start, 3),
                "end_time": round(pad_start + base_scene_dur, 3),
                "camera": last.get("camera", "") if last else "",
                "emotion": last.get("emotion", "neutral") if last else "neutral",
                "lighting": last.get("lighting", self.LIGHTING_SETUPS["neutral"]) if last else self.LIGHTING_SETUPS["neutral"],
                "composition": last.get("composition", "balanced professional framing") if last else "balanced professional framing",
                "color_grading": last.get("color_grading", "") if last else "",
                "scene_context": "Continuation of narrative",
                "characters": last.get("characters", []) if last else [],
                "order": pad_idx,
                "json_prompt": {
                    "style": visual_style,
                    "duration": base_scene_dur,
                    "scene_number": pad_idx,
                    "aspect_ratio": aspect_ratio
                }
            })

        # ── FORCE all scene durations to base_scene_dur ──
        for s in scenes:
            s["duration"] = base_scene_dur

        # ── Re-number scenes and fix order ──
        for i, s in enumerate(scenes):
            s["order"] = i + 1
            s["scene_id_str"] = f"1.{i + 1}"
            if s.get("json_prompt"):
                s["json_prompt"]["scene_number"] = i + 1
                s["json_prompt"]["duration"] = base_scene_dur

        # ── FINAL VERIFICATION ──
        total_scene_duration = len(scenes) * base_scene_dur

        # If somehow still short (shouldn't happen), add one more scene
        while total_scene_duration < audio_duration:
            pad_idx = len(scenes) + 1
            last = scenes[-1]
            pad_start = last["end_time"]
            scenes.append({
                "scene_id_str": f"1.{pad_idx}",
                "title": f"Scene {pad_idx}",
                "image_prompt": last.get("image_prompt", f"{style}, continuation"),
                "voiceover": "",
                "duration": base_scene_dur,
                "start_time": round(pad_start, 3),
                "end_time": round(pad_start + base_scene_dur, 3),
                "camera": last.get("camera", ""),
                "emotion": last.get("emotion", "neutral"),
                "lighting": last.get("lighting", self.LIGHTING_SETUPS["neutral"]),
                "composition": "balanced professional framing",
                "color_grading": "",
                "scene_context": "Extended coverage",
                "characters": [],
                "order": pad_idx,
                "json_prompt": {
                    "style": visual_style,
                    "duration": base_scene_dur,
                    "scene_number": pad_idx,
                    "aspect_ratio": aspect_ratio
                }
            })
            total_scene_duration += base_scene_dur

        return scenes

    # ══════════════════════════════════════════════════════════════════
    # FALLBACK SCENE GENERATOR
    # Used when AI is unavailable — creates scenes by evenly
    # distributing subtitle words across the required scene count.
    # ══════════════════════════════════════════════════════════════════

    def _generate_fallback_scenes(
        self,
        subtitle_data: List[Dict],
        full_narrative: str,
        audio_duration: float,
        required_scene_count: int,
        base_scene_dur: int,
        style: str,
        visual_style: str,
        add_camera: bool,
        preferred_durations: Optional[List[int]] = None,
        aspect_ratio: str = "16:9"
    ) -> List[Dict]:
        """
        Generate structured fallback scenes when AI is unavailable.
        Evenly distributes subtitle words across required_scene_count scenes.
        """
        import random

        scenes = []
        total_words = len(subtitle_data)

        if total_words == 0 or required_scene_count == 0:
            return []

        # ── Distribute words evenly across scenes ──
        words_per_scene = max(1, total_words // required_scene_count)
        word_idx = 0

        for scene_num in range(1, required_scene_count + 1):
            # Calculate word range for this scene
            if scene_num == required_scene_count:
                # Last scene gets all remaining words
                scene_words = subtitle_data[word_idx:]
            else:
                end_idx = min(word_idx + words_per_scene, total_words)
                scene_words = subtitle_data[word_idx:end_idx]

            # Build voiceover text
            voiceover = " ".join(
                (w.get("word", "") or w.get("text", "")) for w in scene_words
            ).strip()

            # Calculate timing
            if scene_words:
                start_time = scene_words[0].get("start", 0)
                end_time = scene_words[-1].get("end", scene_words[-1].get("start", 0) + 0.3)
            else:
                prev_end = scenes[-1]["end_time"] if scenes else 0
                start_time = prev_end
                end_time = start_time + base_scene_dur

            word_idx += len(scene_words)

            # Camera
            camera_category = "establishing" if scene_num == 1 else random.choice(
                list(self.CAMERA_MOVEMENTS.keys())
            )
            category_moves = self.CAMERA_MOVEMENTS.get(camera_category, self.CAMERA_MOVEMENTS["establishing"])
            camera = random.choice(category_moves) if add_camera else "static locked-off master shot"

            narration_excerpt = voiceover[:300] if len(voiceover) > 300 else voiceover
            image_prompt = (
                f"{style}. "
                f"A professionally composed {aspect_ratio} frame depicting: {narration_excerpt}. "
                f"The scene is rendered with meticulous attention to environmental detail, "
                f"subject placement within the frame follows classical compositional principles, "
                f"atmospheric depth is established through layered foreground, midground, and background elements, "
                f"natural motivated lighting creates dimensional modeling on all surfaces, "
                f"the color palette is harmoniously unified to reinforce the narrative mood, "
                f"every visual element serves the storytelling purpose of this moment in the narration."
            )

            scene = {
                "scene_id_str": f"1.{scene_num}",
                "title": f"Scene {scene_num}",
                "image_prompt": image_prompt,
                "voiceover": voiceover,
                "duration": base_scene_dur,
                "start_time": round(start_time, 3),
                "end_time": round(end_time, 3),
                "camera": camera,
                "emotion": "neutral",
                "lighting": self.LIGHTING_SETUPS["neutral"],
                "composition": "balanced professional framing with clear visual hierarchy",
                "color_grading": "",
                "scene_context": voiceover[:150],
                "characters": [],
                "order": scene_num,
                "json_prompt": {
                    "style": visual_style,
                    "camera_movement": camera,
                    "duration": base_scene_dur,
                    "scene_number": scene_num,
                    "aspect_ratio": aspect_ratio
                }
            }

            scenes.append(scene)

        return scenes


# Required export
Template = AudioWorkflowTemplate