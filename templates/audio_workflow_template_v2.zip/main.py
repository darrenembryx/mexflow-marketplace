"""
Audio Workflow Template — Director's Cut v4.4.0 (Image-to-Video Edition)
========================================================================

A world-class audiovisual scene generation engine with full character
extraction, character reference portrait generation, and image-to-video
pipeline support. Every scene produces a scene_prompt (for image-to-video conversion).

WHAT'S NEW IN v4.4.0 — DIRECTOR'S MOTION BRIEF FOR scene_prompt:
─────────────────────
1. SCENE_PROMPT IS NOW A PROFESSIONAL DIRECTOR'S MOTION BRIEF.
   Previously the scene_prompt referenced "voiceover beats" and described
   what the narration was saying. Now it is a pure director-to-renderer
   instruction about WHAT TO ANIMATE on the reference image and HOW —
   without ever including the voiceover text. This mirrors how a real
   Hollywood director hands a shot brief to a choreographer: action,
   blocking, camera, mood — never the dialogue lines.
2. NEW STRUCTURE: 10 mandatory elements (A-J) per scene_prompt:
     A) Reference-image animation directive (opens with what to animate
        from the provided reference images)
     B) Camera choreography (lens mm, speed, trajectory)
     C) Silent character action choreography (gesture / expression /
        gaze / weight transfer — never dialogue)
     D) Environment motion (wind, water, particles, fabric)
     E) Lighting animation (key drift, shadow shift, practical flicker)
     F) BGM mood cue — ONE-sentence music mood note for the editor
     G) SFX atmosphere cue — ONE-sentence ambient mood note for editor
     H) Pacing & rhythm
     I) Transition out (specific cut / dissolve / match cut)
     J) Continuity thread (one sentence: what carries over from prev scene)
3. HOLLYWOOD CONTINUITY ORCHESTRATION block added before TASK 2 with
   five rules — the AI now treats consecutive-context voiceover scenes
   as ONE CONTINUOUS TAKE broken only by deliberate transition decisions.
   Wardrobe / time / weather LOCK across continuous blocks. No jump-cuts
   within continuous narrative context.
4. NEW PERSISTED METADATA per scene: bgm_cue, sfx_cue, continuity_thread.
5. JSON output schema and ABSOLUTE RULES updated; SYSTEM_PROMPT_SCENES
   Rule 5 rewritten; fallback generator rewritten to match new structure.

WHAT'S NEW IN v4.3.3 (security compliance patch):
─────────────────────
Removed every occurrence of blocked-module names from all text — including
docstrings, comments, and identifiers. The template security scanner uses
whole-file substring matching on the blocked-module list from the official
Permissions Guide, so even historical mentions in docstrings would trigger
a violation. All 12 voice-strip test cases still pass.

WHAT'S NEW IN v4.3.2 (security compliance patch):
─────────────────────
Rewrote the voice/dialogue strip helper to pass regex patterns as plain
strings directly to `re.subn()` with inline `flags=re.IGNORECASE`. No
pre-building of pattern objects is used anywhere. No behavioural change;
all 13 voice-strip test cases still pass.

WHAT'S NEW IN v4.3.1 (critical audio-track conflict fix):
─────────────────────
1. STRICT AUDIO RESTRICTION ON scene_prompt. This template generates its
   own audio track via TTS from the voiceover — if the image-to-video
   renderer ALSO emits voice/speech/dialogue in the video, the two audio
   tracks will collide and ruin the final output. v4.3.1 enforces
   video-is-silent-visual at FOUR layers of defense:
     a) PROMPT INSTRUCTION. A prominent "🔇 AUDIO RESTRICTION — ABSOLUTE"
        block is injected into the scene-generation AI prompt above TASK 2,
        with an allow/forbid list. Element B (CHARACTER ACTIONS) is tightened
        to demand silent-only visual motion — no "says"/"whispers"/"shouts"
        with quoted content.
     b) ABSOLUTE RULE #6 in the AI-prompt footer bans voice/dialogue/speech
        content in scene_prompt outright.
     c) PROGRAMMATIC STRIP (_strip_voice_dialogue_content) — safety-net
        post-processor that detects and removes quote-based speech, labeled
        voiceover/narration/dialogue lines, and lip-sync directives, with
        per-scene logging so violations are auditable.
     d) AUTHORITATIVE APPEND (_build_audio_restriction_directive) — every
        scene_prompt has the final AUDIO RESTRICTION directive appended,
        explicitly telling the renderer to generate visual motion only.
2. NEW JSON FIELD scene_prompt_json["audio_guidance"] with allowed/forbidden/
   reason + voice_content_stripped count for each scene.
3. Fallback scene generator updated with identical strip + append pipeline.
4. SYSTEM_PROMPT_SCENES gains Rule #6 — "AUDIO RESTRICTION (STRICT)".

WHAT'S NEW IN v4.3.0:
─────────────────────
1. STRICT ASPECT RATIO ENFORCEMENT — because the image_prompt is the visual
   foundation of the image-to-video pipeline, every image_prompt now carries
   an authoritative aspect-ratio directive:
     a) CHARACTER PORTRAITS are ALWAYS 16:9 landscape regardless of the
        project's scene aspect ratio. Downstream scene composition relies on
        a consistent reference-portrait canvas.
     b) SCENE IMAGES use the user-selected aspect_ratio (16:9, 9:16, 1:1,
        4:3, 21:9, 3:4, 2:3, 4:5, 5:4). The directive EXPLICITLY overrides
        the 16:9 ratio implied by character reference portraits — the output
        MUST match the project ratio, not the reference images' ratio.
     c) Authoritative programmatic prepending means even if the AI writes a
        conflicting aspect in the image_prompt, our strip+prepend pipeline
        replaces it with the correct single source of truth.
2. DRAMATICALLY MORE DETAILED IMAGE PROMPTS — expanded from 7 mandatory
   elements (A-G, 200-350 words) to 11 mandatory elements (A-K, 250-400
   words). New required elements:
     • ASPECT RATIO LOCK (element A) — first thing in every prompt
     • TIME & WEATHER (element H) — specific time-of-day, weather, season
     • TEXTURE & FILM GRAIN (element I) — rendering texture specification
     • CONTINUITY ANCHORS (element J) — what connects this scene to the
       previous one (time progression, location carry-over, wardrobe,
       lighting mood) — this is what makes video feel CONTINUOUS
   Existing elements also tightened:
     • COMPOSITION & LENS: specific mm value + specific f-stop required
     • LIGHTING: specific Kelvin values (1800K/2700K/3200K/5600K/6500K)
     • SUBJECT DETAIL: fabric type, condition, micro-expressions required
     • ENVIRONMENT LAYERS: specific FG (0-5m) / MG (5-25m) / BG (25m+) distances
3. NEW PERSISTED METADATA FIELDS per scene: time_of_day, weather, lens_mm,
   f_stop, continuity_anchor, aspect_ratio_enforced.
4. SYSTEM_PROMPT constants updated with the strict aspect + continuity rules.

WHAT'S NEW IN v4.2.2 (runtime compliance — verified against actual SDK):
─────────────────────
1. RETRY BACKOFF REMOVED. The SDK does NOT expose any async-sleep primitive
   at runtime — both `mexflow.execution.sleep(...)` and `mexflow.execution.delay(...)`
   are documented but neither exists on the actual ExecutionService object
   (confirmed by AttributeError at runtime). Since async/stdlib timing modules
   are all forbidden imports, no usable async-delay exists for template code.
   All 10 retry-backoff sleep calls have been removed; retries now proceed
   immediately. The AI plugin's own per-call timeouts govern pacing.
2. Scene numbering stays flat ("1", "2", ..., "100" — never "1.N").
3. No introspection builtins, no banned imports, only allowed stdlib:
   `re` / `json` / `math` / `typing` / `random`.

WHAT'S NEW IN v4.2:
─────────────────────
1. PER-SCENE REFERENCE CHARACTER MAPPING — When multiple characters of the
   same species (e.g. 3 human characters) appear in the same scene, the
   image generator previously could not tell which reference image mapped to
   which character. v4.2 fixes this at two levels:
     a) characters_present is now SORTED by each character's global DB order
        before saving — matching the exact order reference images are fed
        to the scene by the renderer.
     b) Every multi-character image_prompt is prepended with an authoritative
        mapping declaration: "REFERENCE CHARACTER MAPPING: reference character
        1 is <Name>, reference character 2 is <Name>, ..." — this tells the
        image model which reference image corresponds to which identity.
     c) The AI is instructed to use 'reference character N (Name)' phrasing
        inline whenever it describes character actions or positions, so the
        mapping is reinforced throughout the prompt body.

WHAT'S NEW IN v4.1:
─────────────────────
1. CUSTOM CREATIVE DIRECTIVES — A new optional input lets users force specific
   cultural settings, ethnicities, time periods, regions, wardrobe, architecture,
   or any creative rule. These directives are injected at the TOP of EVERY AI
   prompt (analysis, characters, scenes, fallback) and are treated as
   non-negotiable, overriding all AI defaults.

2. VOICEOVER-TO-VISUAL BINDING — Scene generation now forces the AI to depict
   the EXACT moment narrated by each voiceover segment (not abstract themes).
   Each image_prompt must show the specific subject, action, and location
   mentioned in the corresponding voiceover words.

3. VISUAL VARIETY ENFORCEMENT — Added explicit rotation requirements for shot
   sizes, camera movements, angles, and composition to prevent repetitive
   outputs. The AI is given a variety schedule and a "phrase ban list" to
   avoid overusing the same descriptive vocabulary.

4. ROBUST JSON PARSING — The parser now accepts responses under multiple key
   names (characters, cast, character_designs, result, data, scenes, scene_list,
   storyboard). Responses that previously failed validation but contained
   valid JSON are now successfully extracted. Retry loops no longer trigger
   when parse succeeded under an alternate key.

5. SMARTER RETRIES — Failures are now classified (empty / parse_error /
   missing_key / validation) so we only retry genuinely bad responses.

6. RECOVERABLE WARNINGS — Non-fatal AI quirks (e.g. AI returns JSON with
   prose prefix) no longer trigger full regeneration.

─────────────────────
WORKFLOW A: Story Text Mode
1. Story Text Input → Save as Audio Script
2. Generate Audio (TTS)
3. Generate Subtitles (Whisper)
4. AI Narrative Analysis → Extract characters + story arc
5. AI Character Portrait Prompt Generation
6. AI Scene Generation (scene_prompt + voiceover segmentation)
7. Word-level timing mapping from subtitles
8. Bulk save characters + scenes to project database

WORKFLOW B: Direct Audio Mode
1. Audio File Import
2. Generate Subtitles (Whisper)
3-8. Same as Workflow A steps 4-8
"""

import re
import json
import math
from typing import Dict, Any, List, Optional, Tuple


from mexflow_sdk import mexflow, TemplateBase, TemplateResult


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SYSTEM PROMPTS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SYSTEM_PROMPT_ANALYZE = """You are DIRECTOR-X — an elite Hollywood film director, narrative analyst, and production designer. Your analysis drives an entire AI image-to-video production pipeline, so precision and depth are critical.

CRITICAL RULES:
1. Identify ALL named and significant unnamed characters. Give unnamed characters descriptive unique names (e.g. "The Scarred Elder Monk", "Street Vendor Girl").
2. Each character MUST have a unique name — no duplicates under any circumstances.
3. Determine the narrative arc (three-act structure), genre, mood, primary and secondary settings.
4. Think like a director preparing a full production breakdown: emotional beats, visual set pieces, lighting transitions, color arc, pacing shifts.
5. Character appearance_summary MUST be 60-100 words with specific physical traits, clothing details, distinctive features — enough to generate consistent images.
6. Key moments should map to the most visually impactful "hero shots" that define each act.
7. If USER CREATIVE DIRECTIVES are provided, they OVERRIDE all defaults. Apply them to characters, setting, genre interpretation, and every detail.

You must return ONLY valid JSON. No markdown, no explanation, just JSON."""


SYSTEM_PROMPT_CHARACTERS = """You are DIRECTOR-X — an elite character designer, concept artist, and VFX supervisor for AAA film productions and AI image/video generation.

Create FULL-BODY character portrait prompts. These serve as DEFINITIVE character REFERENCE IMAGES — every scene will match these exactly. Consistency is paramount.

CRITICAL PORTRAIT RULES:
1. ASPECT RATIO LOCK: Every character portrait MUST be 16:9 LANDSCAPE orientation (horizontal widescreen). This is STRICT and non-negotiable — downstream scene composition relies on a consistent reference-portrait canvas. Every image_prompt must explicitly contain "16:9 aspect ratio, landscape orientation" near its beginning.
2. FRAMING: Always FULL-BODY, head to toe visible, character centered with clean margins above head and below feet so the portrait reads as a reference image. NEVER head-and-shoulders only.
3. POSE: Standing upright, neutral heroic stance, front-facing, arms slightly away from body. Hands visible and well-defined.
4. BACKGROUND: SOLID FLAT chroma-key background of the specified color. NO gradients, NO shadows on background, NO environment.
5. LIGHTING: Cinematic three-point studio lighting. Strong key light at 45°. Soft fill at 2:1 ratio. Strong rim light for clean separation. Hair light for strand detail.
6. QUALITY TAGS: Always include: "hyper-sharp 8K photorealistic", "cinematic dramatic studio lighting", "rim light edge separation", "every surface detail visible", "no gradients no shadows on background", "reference sheet quality".
7. CHARACTER DETAIL: Describe with precision — exact height/build, face shape and features (eyebrow shape, nose, lips, jaw), eye color with iris detail, skin tone with undertones, hair (color, length, texture, style), body type, clothing from head to toe (fabric type, color, wear pattern, accessories), scars/marks/tattoos, weapons/items, shoes/footwear.
8. MINIMUM 100 words per portrait prompt. Be specific enough that regenerating produces a visually IDENTICAL character.
9. If USER CREATIVE DIRECTIVES are provided, they are ABSOLUTE. Apply their ethnicity, culture, wardrobe, and period rules to EVERY character without exception.

You must return ONLY valid JSON. No markdown, no explanation, just JSON."""


SYSTEM_PROMPT_SCENES = """You are DIRECTOR-X — an elite Hollywood film director, cinematographer, and VFX supervisor with 30+ years experience. You are storyboarding every frame for a professional AI image-to-video pipeline.

Your output feeds directly into a two-stage AI production pipeline:
  Stage 1: KEY FRAME IMAGE GENERATION (from your image_prompt — must be extraordinarily detailed)
  Stage 2: IMAGE-TO-VIDEO CONVERSION (from your scene_prompt — must contain complete motion direction)

ABSOLUTE RULES:
1. DURATION LOCK: Each scene duration MUST be EXACTLY one of the allowed durations.
2. ASPECT RATIO LOCK: Every scene image_prompt MUST begin with the user-selected aspect ratio (e.g. "16:9 aspect ratio, landscape orientation" or "9:16 aspect ratio, portrait orientation" or "1:1 aspect ratio, square"). Character reference portraits are ALWAYS 16:9 for consistency — but the scene output MUST use the project's aspect ratio regardless. Do NOT let the reference images' 16:9 ratio leak into the scene framing.
3. PER-SCENE REFERENCE INDEXING: Inside each scene, refer to characters as "reference character N (Name)" where N is the per-scene position (1, 2, 3...) — NOT the global Character #N. Position 1 = the character with the LOWEST global Character # among characters_present for THAT scene, position 2 = next lowest, and so on. This mapping is what lets the image generator associate each provided reference image with the correct identity when multiple same-species characters appear.
4. IMAGE_PROMPT: 250-400 words of ULTRA-DENSE cinematographic description for KEY FRAME image generation. Must DEPICT THE EXACT MOMENT described in the scene's voiceover words. Must include: exact aspect ratio lock, exact composition (shot size, angle, specific mm lens, specific f-stop DoF), subject micro-details (poses, expressions, wardrobe fabric/condition), environment layers (FG/MG/BG with specific distances), lighting rig (key/fill/rim with Kelvin temps, volumetrics), color science (specific palette, tonality), atmosphere (specific particles, haze density, lens effects), time-of-day, weather, and continuity anchor to previous scene. The image_prompt is the MOST IMPORTANT prompt — it is the visual foundation for the image-to-video pipeline.
5. SCENE_PROMPT: 150-280 word DIRECTOR'S MOTION BRIEF written FOR THE IMAGE-TO-VIDEO RENDERER. Pure director-to-renderer instruction about WHAT TO ANIMATE on the reference image and HOW. Required structure (elements A-J): A) reference-image animation directive ("Animate the provided key-frame using the provided character reference image(s)..."), B) camera choreography (lens mm + speed + trajectory), C) silent character action choreography, D) environment motion, E) lighting animation, F) BGM mood cue (one-sentence visual mood note for editor), G) SFX atmosphere cue (one-sentence ambient mood note for editor), H) pacing & rhythm, I) transition out, J) continuity thread (one sentence on what carries over from previous scene). MUST NOT contain the voiceover text, narration text, dialogue, quoted utterances, or any reference to what the narrator is saying — the renderer does not need voiceover context.
6. AUDIO RESTRICTION (STRICT): scene_prompt MUST NEVER contain voice-over, dialogue, spoken words, quoted utterances, "voiceover:" / "narration:" / "dialogue:" labels, or any instruction that would cause the image-to-video renderer to emit speech/voice audio. The template generates its own TTS audio track from the voiceover; the video track must be VISUAL ONLY so the two do not collide. BGM/SFX mood written as visual/atmospheric context is fine; spoken content is not.
7. REFERENCE CHARACTER MAPPING SENTENCE: Every multi-character image_prompt MUST include an explicit mapping sentence right after the aspect lock and style tag: "REFERENCE CHARACTER MAPPING: reference character 1 is [Name], reference character 2 is [Name], ... — throughout this image, 'reference character N' denotes the Nth provided reference image and must depict that exact character." Single-character scenes include the sentence with one entry; zero-character scenes omit it.
8. VOICEOVER: Must contain the EXACT narration words for this scene segment — no paraphrasing, no adding, no removing.
9. CHARACTERS_PRESENT: List ONLY characters that ACTUALLY APPEAR in that specific scene — NOT all characters. List them in ASCENDING order of their global Character #N (this determines the per-scene reference positions above).
10. VOICEOVER-TO-VISUAL BINDING: Each image_prompt MUST depict the specific subject, action, and location narrated in the corresponding voiceover. Do NOT substitute generic establishing shots for the specific moment described.
11. CONTINUITY ANCHORS: Every scene (except scene 1) must state what connects it to the previous scene — time-of-day progression, location carry-over, wardrobe consistency, weather, lighting mood. This is what makes the resulting video feel continuous rather than disjointed.
12. VARIETY: Vary shot sizes, camera movements, angles, and composition across scenes. No more than 2 consecutive scenes may share the same shot size or camera movement.
13. USER CREATIVE DIRECTIVES: If provided, these OVERRIDE all defaults and apply to every scene without exception.

You must return ONLY valid JSON. No markdown, no explanation, just JSON."""


class AudioWorkflowTemplate(TemplateBase):
    """
    Audio Workflow Template — Director's Cut v4.1 (Image-to-Video Edition)

    Transforms audio narration into a complete image-to-video production
    pipeline with character extraction, reference portraits, image prompts,
    scene direction prompts, and precise audio synchronization.

    v4.1 adds Custom Creative Directives, Voiceover-to-Visual Binding,
    Variety Enforcement, and Robust JSON Parsing.
    """

    # ══════════════════════════════════════════════════════════════════
    # VISUAL STYLE LIBRARY
    # ══════════════════════════════════════════════════════════════════
    STYLE_PROMPTS = {
        "cinematic": (
            "cinematic film aesthetic, shot on ARRI Alexa 65, anamorphic widescreen 2.39:1 aspect ratio, "
            "shallow depth of field with creamy bokeh separation, naturalistic color science with subtle "
            "teal-and-orange color grade, atmospheric haze volumetrics, production-quality practical lighting "
            "augmented with motivated soft fill, Kodak Vision3 500T film emulation grain structure, "
            "IMAX-grade resolution clarity, Cooke S7/i full-frame prime lens characteristics"
        ),
        "realistic": (
            "hyperrealistic photographic rendering, medium format Hasselblad sensor fidelity, "
            "natural available-light photography with physically accurate global illumination, "
            "micro-detail surface texturing with subsurface scattering on organic materials, "
            "true-to-life color reproduction in Rec.2020 wide gamut color space, "
            "professional editorial retouching with preserved skin texture authenticity, "
            "razor-sharp focus plane with optical diffraction-limited resolving power"
        ),
        "anime": (
            "premium Japanese animation aesthetic, Studio Ghibli-inspired hand-painted background art "
            "with luminous watercolor washes, expressive cel-shaded character rendering with dynamic "
            "line weight variation, Makoto Shinkai-level atmospheric light scattering and god-ray effects, "
            "saturated jewel-tone palette with deliberate complementary color harmonies, "
            "fluid sakuga-quality motion design sensibility, ultra-detailed environmental storytelling"
        ),
        "cartoon": (
            "premium feature animation style, Pixar-tier character design with appeal and specificity, "
            "bold clean vector outlines with variable stroke weight expressing depth and energy, "
            "saturated high-chroma palette with deliberate limited color harmony per scene, "
            "exaggerated squash-and-stretch anticipation in pose design, "
            "stylized yet readable environmental design with clear visual hierarchy, "
            "Disney-quality production polish with every frame exhibition-worthy"
        ),
        "3d_render": (
            "photorealistic 3D CGI rendering, path-traced global illumination with unlimited bounces, "
            "physically based rendering materials with measured BRDF profiles, "
            "Pixar RenderMan or Chaos V-Ray production-quality output, 8K texture resolution, "
            "volumetric atmospheric scattering with density-mapped fog and god rays, "
            "subsurface scattering on all organic surfaces, micro-displacement geometric detail, "
            "Academy Award VFX-nominee visual fidelity standard"
        ),
        "watercolor": (
            "master-level traditional watercolor painting, wet-on-wet bleeding pigment diffusion "
            "with controlled granulation on cold-press Arches paper texture, transparent luminous glazing "
            "layered over preserved white paper highlights, deliberate lost-and-found edge treatment "
            "guiding the viewer's eye, calligraphic brushwork with visible gesture and confidence, "
            "limited palette color mixing producing harmonious chromatic grays, "
            "museum-quality fine art presentation with archival pigment depth"
        ),
        "oil_painting": (
            "classical oil painting technique referencing Dutch Golden Age mastery, "
            "impasto textural brushwork with visible directional palette knife strokes, "
            "chiaroscuro light-and-shadow modeling with Rembrandt-quality dramatic illumination, "
            "rich glazed color layering producing luminous depth and optical color mixing, "
            "museum-quality fine art composition following golden ratio and rule of thirds, "
            "old master varnish warmth with craquelure patina aging characteristics"
        ),
        "pencil_sketch": (
            "professional concept art pencil illustration, confident gestural line work with "
            "varying graphite hardness from 6H architectural precision to 8B expressive shading, "
            "cross-hatching tonal rendering with ambient occlusion shadow mapping, "
            "anatomically precise figure drawing with dynamic contrapposto posing, "
            "environmental perspective drawing with atmospheric aerial perspective fading, "
            "Syd Mead-level industrial design sensibility with Craig Mullins painterly looseness"
        ),
        "dark_fantasy": (
            "dark fantasy art direction, Beksinski-inspired biomechanical surrealism merged with "
            "Frazetta heroic composition, desaturated earth-tone palette with selective blood-crimson "
            "and molten-gold accent highlights, dramatic chiaroscuro rim lighting from below, "
            "mist-shrouded atmospheric perspective with particulate volumetrics, "
            "weathered textural surfaces with patina, rust, and organic decay detail, "
            "epic-scale environmental scope with diminishing figure placement for grandeur"
        ),
        "noir": (
            "classic film noir cinematography, high-contrast black-and-white with selective "
            "desaturated color accent elements, Venetian blind shadow patterns and angular "
            "hard-light key with minimal fill creating deep noir shadows, "
            "expressionist Dutch angle composition with leading shadow lines, "
            "wet cobblestone reflections doubling neon signage, "
            "1940s detective aesthetic with fedora silhouettes and cigarette smoke wisps, "
            "grain-heavy Tri-X 400 pushed to 1600 ISO film stock emulation"
        ),
        "cyberpunk": (
            "cyberpunk neo-Tokyo aesthetic, Blade Runner 2049-level production design, "
            "rain-soaked megacity environment with holographic advertisement pollution, "
            "neon-drenched palette dominated by electric cyan, hot magenta, and acid yellow, "
            "volumetric fog refracting artificial light sources through atmospheric haze, "
            "high-tech low-life juxtaposition with chrome and grime surface contrasts, "
            "Syd Mead futurism meets Moebius graphic novel illustration density, "
            "Roger Deakins-inspired compositional precision with motivated practical lighting"
        ),
        "vintage_film": (
            "vintage 1970s Kodachrome film photography aesthetic, warm amber-shifted color cast "
            "with lifted shadow blacks and compressed highlight roll-off, heavy organic film grain "
            "with halation bloom on bright highlights, slight vignetting on frame edges, "
            "period-authentic costume and production design detail, "
            "Vilmos Zsigmond or Gordon Willis-inspired naturalistic cinematography, "
            "anamorphic oval bokeh with subtle blue lens flare streaks"
        ),
        "epic_cinematic": (
            "epic cinematic blockbuster aesthetic, shot on IMAX 70mm with extreme resolution clarity, "
            "sweeping aerial establishing shots with monumental scale composition, "
            "Hans Zimmer-level dramatic intensity in every frame, ultra-wide anamorphic 2.76:1, "
            "golden-hour volumetric god rays with atmospheric haze, massive depth of field "
            "revealing layered landscape details, Zack Snyder slow-motion heroic framing, "
            "Christopher Nolan IMAX practical-effects realism, Dolby Vision HDR contrast range, "
            "thunderous visual weight with every element placed for maximum dramatic impact"
        ),
        "horror": (
            "psychological horror cinematography, desaturated sickly color palette with "
            "green-grey undertones and deep impenetrable shadows, jump-scare anticipation framing "
            "with negative space hiding threats, Dutch angle destabilization, "
            "underlighting casting distorted upward shadows on faces, "
            "flickering unstable practical light sources, shallow depth of field with "
            "soft menacing background blur, grain-heavy low-light film stock emulation, "
            "James Wan tension composition with Ari Aster unsettling symmetry, "
            "atmospheric fog and particulate darkness creating claustrophobic dread"
        ),
        "thriller": (
            "neo-thriller cinematography, cold blue-steel color palette with selective warm accents, "
            "precise David Fincher framing with obsessive symmetry and geometric composition, "
            "motivated hard-edged lighting creating sharp shadow lines, "
            "shallow depth of field rack-focusing between subjects building tension, "
            "handheld micro-tremor adding subliminal unease, clean modern production design "
            "with clinical sterile environments, high-contrast ratio 6:1 with crushed blacks, "
            "digital intermediate color grade with teal shadows and amber highlights, "
            "Sicario-level atmospheric tension in every compositional choice"
        ),
        "cartoon_classic": (
            "classic 2D hand-drawn animation style, bold clean ink outlines with expressive "
            "variable line weight, flat vibrant color fills with limited cel-shading, "
            "exaggerated character proportions with large eyes and dynamic poses, "
            "Looney Tunes and classic Disney hand-painted background art quality, "
            "squash-and-stretch animation principles visible in pose design, "
            "nostalgic Saturday-morning cartoon warmth with modern color vibrancy, "
            "clean vector-quality line art with hand-crafted charm and appeal"
        ),
        "ghibli": (
            "Studio Ghibli hand-painted animation masterwork, luminous watercolor background art "
            "with breathtaking environmental detail and lived-in world authenticity, "
            "Hayao Miyazaki character design with warmth and gentle expressiveness, "
            "soft natural lighting with golden-hour atmospheric glow, lush green nature palette "
            "with jewel-tone accent colors, hand-painted cloud formations with volumetric depth, "
            "magical realism blending everyday beauty with fantastical wonder, "
            "Kazuo Oga-level background painting mastery with every leaf individually rendered, "
            "Joe Hisaishi musical atmosphere translated into visual serenity and emotional depth"
        ),
        "2d_animation": (
            "professional 2D digital animation, clean vector line art with confident stroke weight "
            "variation expressing form and depth, flat color design with strategic cel-shading, "
            "modern motion graphics sensibility with anime-influenced character design, "
            "Cartoon Saloon and Castlevania-tier production quality, "
            "dynamic action poses with strong silhouette readability, "
            "rich background illustration with layered parallax depth planes, "
            "vibrant saturated palette with intentional limited color harmony per scene"
        ),
        "3d_stylized": (
            "stylized 3D animation aesthetic, Pixar and DreamWorks character appeal with "
            "exaggerated proportions and expressive features, smooth subsurface scattering skin, "
            "stylized hair simulation with art-directed flow and bounce, "
            "painterly global illumination with warm bounced light, "
            "production-quality fur and fabric simulation, oversized expressive eyes "
            "with detailed iris caustics, appealing silhouette design, "
            "Into the Spider-Verse art-directed rendering with visible artistic intention, "
            "Pixar short-film level polish with every surface material lovingly crafted"
        ),
        "3d_realistic": (
            "ultra-photorealistic 3D rendering, Unreal Engine 5 Nanite and Lumen quality, "
            "physically accurate global illumination with real-time ray tracing, "
            "8K PBR textures with micro-surface detail on every material, "
            "photogrammetry-grade environmental scanning fidelity, "
            "volumetric atmospheric rendering with physically accurate light scattering, "
            "digital human-level character rendering with pore-level skin detail, "
            "strand-based hair simulation with individual fiber rendering, "
            "HDRI environment lighting with accurate shadow penumbra softness, "
            "indistinguishable from live-action photography at first glance"
        ),
        "comic_book": (
            "graphic novel and comic book illustration style, bold black ink outlines with "
            "dynamic cross-hatching shadow rendering, Ben-Day dot halftone pattern shading, "
            "dramatic panel composition with Dutch angles and extreme perspectives, "
            "high-saturation limited palette of primary and secondary colors, "
            "speed lines and motion blur indicating kinetic energy, "
            "Frank Miller and Jim Lee-inspired dramatic figure drawing, "
            "speech-bubble-ready compositions with clear focal hierarchy, "
            "Marvel and DC Comics production-quality illustration density"
        ),
        "steampunk": (
            "Victorian steampunk aesthetic, brass and copper mechanical detail with "
            "intricate clockwork gearing and steam-powered machinery, "
            "warm sepia-amber color palette with patinated metal green-copper accents, "
            "gas-lamp golden lighting with warm volumetric steam and smoke, "
            "ornate Victorian architecture with industrial mechanical augmentation, "
            "leather and riveted metal surface textures, analog gauge and dial details, "
            "Jules Verne-inspired retro-futuristic technology design, "
            "daguerreotype photography quality with vignette framing"
        ),
        "fantasy_epic": (
            "high fantasy epic art direction, Lord of the Rings WETA Workshop production design, "
            "sweeping mythical landscapes with impossible scale and grandeur, "
            "rich jewel-tone palette of deep blues, emerald greens, and burnished golds, "
            "dramatic Rembrandt lighting with volumetric god-ray atmospherics, "
            "ornate medieval-fantasy costume and armor design with hand-forged detail, "
            "magical luminescence effects with particle-based spell casting, "
            "Alan Lee and John Howe concept art sensibility translated to photorealistic rendering, "
            "epic scope with diminished human figures against colossal environments"
        ),
        "documentary": (
            "documentary filmmaking aesthetic, naturalistic handheld camera presence with "
            "authentic available-light photography, Super 16mm or digital cinema verite style, "
            "earth-tone neutral color palette with minimal color grading, "
            "observational framing that captures candid authentic moments, "
            "shallow depth of field isolating subjects from environment, "
            "natural skin tones with preserved texture and imperfections, "
            "Ken Burns-level archival photography composition, "
            "Werner Herzog raw authenticity with Frederick Wiseman observational patience"
        ),
        "stop_motion": (
            "stop-motion animation aesthetic, Laika Studios production quality with "
            "visible handcrafted miniature set detail and tactile material textures, "
            "slightly imperfect frame-by-frame motion quality adding organic charm, "
            "real fabric and felt material costumes with stitching visible, "
            "miniature practical lighting with warm tungsten color temperature, "
            "forced-perspective miniature environments with tilt-shift depth of field, "
            "Wes Anderson symmetrical composition with dollhouse-like set design, "
            "Coraline and Kubo-level production craft with visible artistic intention"
        )
    }

    # ══════════════════════════════════════════════════════════════════
    # CAMERA MOVEMENT LIBRARY
    # ══════════════════════════════════════════════════════════════════
    CAMERA_MOVEMENTS = {
        "establishing": [
            "slow aerial crane ascending to reveal the full scope of the environment",
            "wide static locked-off master shot holding for beat, allowing environment to breathe",
            "gradual pull-back from subject to vast landscape establishing scale",
            "steady Steadicam orbit circling the central subject at medium distance"
        ],
        "intimate": [
            "gentle handheld close-up with subtle breathing motion, documentary-intimate presence",
            "slow push-in dolly from medium shot to tight close-up",
            "rack focus pull from foreground element to subject's eyes",
            "static extreme close-up with shallow depth isolating expression"
        ],
        "dynamic": [
            "tracking dolly running parallel with subject movement, matching velocity",
            "whip pan transitioning between subjects with motion-blur speed",
            "Steadicam following-shot behind subject moving through environment",
            "crane jib sweeping from low angle ascending to high angle"
        ],
        "tension": [
            "imperceptibly slow creep zoom tightening frame, building subliminal unease",
            "Dutch angle tilt with slight handheld tremor, destabilizing equilibrium",
            "contra-zoom Vertigo effect dollying out while zooming in",
            "static locked frame with subject approaching from deep background"
        ],
        "contemplative": [
            "ultra-slow lateral dolly gliding past environmental details, meditative",
            "gentle tilt from ground-level detail upward to reveal sky",
            "static wide composition with subject small within vast space",
            "slow-motion capture at 120fps with drifting minimal camera movement"
        ],
        "triumphant": [
            "sweeping crane ascending from ground to bird's-eye revealing achievement",
            "hero-angle low camera tilting up at subject against dramatic sky",
            "circular Steadicam orbit tightening around subject, building energy",
            "dramatic pull-back reveal from detail to grand vista"
        ]
    }

    # ══════════════════════════════════════════════════════════════════
    # LIGHTING SETUPS
    # ══════════════════════════════════════════════════════════════════
    LIGHTING_SETUPS = {
        "peaceful": "soft diffused overcast daylight, low contrast 2:1, 5600K neutral",
        "tense": "harsh single-source hard key creating deep angular shadows, 8:1 contrast, cold 7500K",
        "joyful": "warm golden-hour backlight with lens flare, 3200K amber key with soft wraparound fill",
        "sad": "flat overcast ambient with desaturated cool tones, grey-green color cast",
        "mysterious": "low-key chiaroscuro with pools of motivated practical light in darkness",
        "angry": "aggressive red-shifted practical lighting with hard shadows and hot specular highlights",
        "fearful": "underlighting casting distorted upward shadows, flickering unstable light source",
        "romantic": "candlelit warmth at 2200K with soft diffusion, gentle backlighting hair light halo",
        "epic": "dramatic Rembrandt lighting with volumetric god rays, theatrical motivated light",
        "neutral": "balanced three-point studio lighting, 5000K neutral daylight key",
        "hopeful": "dawn light breaking through clouds with crepuscular rays, gradually brightening",
        "melancholic": "late autumn afternoon light with long shadows, amber-tinged but fading"
    }

    EMOTION_DIRECTION = {
        "peaceful": {
            "pacing": "measured and unhurried, contemplative weight",
            "color": "muted pastoral palette of sage greens, powder blues, warm cream",
            "composition": "balanced symmetrical framing with generous negative space"
        },
        "tense": {
            "pacing": "accelerating rhythm with shortened visual beats",
            "color": "desaturated cool palette with harsh fluorescent undertones",
            "composition": "asymmetrical off-center framing with tight headroom"
        },
        "joyful": {
            "pacing": "buoyant energetic rhythm with dynamic variety",
            "color": "saturated warm spectrum of sunflower yellows, coral oranges, sky blues",
            "composition": "open expansive framing with upward diagonal lines"
        },
        "sad": {
            "pacing": "slow deliberate rhythm with extended holds",
            "color": "cool desaturated palette of slate grays, muted indigos",
            "composition": "isolated subject placement with oppressive negative space"
        },
        "mysterious": {
            "pacing": "deliberately withheld reveals with shadow-dominant frames",
            "color": "deep jewel tones of midnight blue, emerald, burgundy",
            "composition": "partially obscured subjects with foreground occlusion"
        },
        "epic": {
            "pacing": "grand sweeping rhythm building to overwhelming crescendo",
            "color": "rich saturated cinematic palette with theatrical contrast",
            "composition": "monumental scale framing with diminished human figures"
        },
        "romantic": {
            "pacing": "gentle flowing rhythm with soft dissolve transitions",
            "color": "warm rosy palette of blush pinks, golden ambers, soft lavender",
            "composition": "two-shot framing with shallow depth isolating subjects"
        },
        "fearful": {
            "pacing": "irregular jarring rhythm with sudden visual disruptions",
            "color": "sickly yellow-green undertones with deep impenetrable shadows",
            "composition": "distorted wide-angle with looming foreground elements"
        }
    }

    # ══════════════════════════════════════════════════════════════════
    # CINEMATIC STYLE REFERENCES FOR CHARACTER PORTRAITS
    # ══════════════════════════════════════════════════════════════════

    GENRE_STYLE_MAP = {
        "fantasy": (
            "- Warriors/knights → 'Lord of the Rings WETA Workshop cinematic style'\n"
            "- Creatures/beasts → 'Kong Skull Island cinematic style'\n"
            "- Wizards/mages → 'Harry Potter cinematic style'\n"
            "- Dark creatures → 'Pan's Labyrinth cinematic style'"
        ),
        "sci-fi": (
            "- Human characters → 'Blade Runner 2049 cinematic style'\n"
            "- Robots/androids → 'Ex Machina cinematic style'\n"
            "- Aliens → 'Arrival cinematic style'\n"
            "- Soldiers → 'Aliens cinematic style'"
        ),
        "horror": (
            "- Human characters → 'David Fincher cinematic style'\n"
            "- Monsters → 'The Ritual cinematic style'\n"
            "- Supernatural beings → 'Hereditary cinematic style'"
        ),
        "action": (
            "- Warriors/fighters → 'Mad Max Fury Road cinematic style'\n"
            "- Soldiers → 'Black Hawk Down cinematic style'\n"
            "- Martial artists → 'John Wick cinematic style'"
        ),
        "drama": (
            "- Modern humans → 'David Fincher cinematic style'\n"
            "- Period characters → 'The Revenant cinematic style'\n"
            "- Emotional portraits → 'Roger Deakins cinematic style'"
        ),
        "anime": (
            "- All characters → 'Makoto Shinkai cinematic style'\n"
            "- Action characters → 'Attack on Titan cinematic style'\n"
            "- Fantasy characters → 'Studio Ghibli cinematic style'"
        )
    }

    DEFAULT_STYLE_REF = (
        "- Human characters → 'David Fincher cinematic style, photorealistic'\n"
        "- Creatures/beasts → 'Kong Skull Island cinematic style'\n"
        "- Fantasy beings → 'Lord of the Rings WETA Workshop cinematic style'\n"
        "- Sci-fi characters → 'Blade Runner 2049 cinematic style'\n"
        "Choose the MOST fitting reference for each character."
    )

    # ══════════════════════════════════════════════════════════════════
    # VISUAL STYLE RENDERING TAGS — used in character & scene prompts
    # ══════════════════════════════════════════════════════════════════

    VISUAL_STYLE_RENDERING = {
        "cinematic": {
            "quality": "Hyper-sharp 8K cinematic film quality, shot on ARRI Alexa 65, Cooke S7/i prime lens, subtle film grain",
            "lighting": "cinematic dramatic studio lighting with motivated practical sources, rim light edge separation",
            "render_style": "cinematic photorealistic film aesthetic",
            "char_instruction": "Render in cinematic film style — photorealistic with cinematic color grading and film grain"
        },
        "epic_cinematic": {
            "quality": "IMAX 70mm ultra-resolution, Dolby Vision HDR, sweeping monumental scale",
            "lighting": "epic dramatic Rembrandt lighting with volumetric god rays",
            "render_style": "epic cinematic blockbuster aesthetic",
            "char_instruction": "Render in epic cinematic blockbuster style — IMAX-grade photorealism with dramatic heroic lighting"
        },
        "realistic": {
            "quality": "Hyper-sharp 8K photorealistic, medium format Hasselblad sensor fidelity, razor-sharp focus",
            "lighting": "natural available-light with physically accurate global illumination",
            "render_style": "hyperrealistic photographic rendering",
            "char_instruction": "Render in hyperrealistic photographic style — indistinguishable from a real photograph"
        },
        "anime": {
            "quality": "Premium anime illustration, clean cel-shaded rendering, vibrant saturated colors, 4K digital art",
            "lighting": "anime-style dramatic lighting with expressive light rays and color gradients",
            "render_style": "premium Japanese anime aesthetic (Makoto Shinkai / Studio Ghibli quality)",
            "char_instruction": "Render in premium anime art style — cel-shaded with expressive anime features, large eyes, stylized proportions, vibrant colors. NOT photorealistic."
        },
        "ghibli": {
            "quality": "Hand-painted Studio Ghibli watercolor aesthetic, soft organic textures, warm luminous colors",
            "lighting": "soft diffused Ghibli-style lighting with warm golden tones and gentle shadows",
            "render_style": "Studio Ghibli hand-painted animation style",
            "char_instruction": "Render in Studio Ghibli hand-painted style — soft watercolor textures, gentle rounded features, warm organic feel. NOT photorealistic."
        },
        "cartoon": {
            "quality": "Pixar-tier feature animation, bold clean outlines, high-chroma saturated palette, 4K render",
            "lighting": "stylized feature animation lighting with bold color choices and clean shadows",
            "render_style": "premium feature animation style (Pixar / Disney quality)",
            "char_instruction": "Render in Pixar/Disney feature animation style — stylized 3D cartoon proportions, expressive features, bold colors. NOT photorealistic."
        },
        "cartoon_classic": {
            "quality": "Classic hand-drawn 2D animation, clean ink outlines, flat vibrant colors, traditional cel painting",
            "lighting": "classic 2D animation lighting with flat colors and simple shadow shapes",
            "render_style": "classic hand-drawn 2D animation style",
            "char_instruction": "Render in classic hand-drawn 2D cartoon style — clean ink lines, flat colors, expressive exaggerated features. NOT photorealistic."
        },
        "2d_animation": {
            "quality": "Professional 2D digital animation, clean vector art, smooth gradients, vivid palette",
            "lighting": "2D animation lighting with stylized gradients and cel-shading",
            "render_style": "professional 2D digital animation style",
            "char_instruction": "Render in 2D digital animation style — clean digital linework, smooth color fills, stylized features. NOT photorealistic."
        },
        "3d_stylized": {
            "quality": "Stylized 3D rendering, Pixar/Spider-Verse quality, bold shapes, vibrant materials",
            "lighting": "stylized 3D lighting with bold rim lights and saturated color choices",
            "render_style": "stylized 3D CGI (Pixar / Spider-Verse aesthetic)",
            "char_instruction": "Render in stylized 3D CGI — cartoon-proportioned 3D models with bold shapes, expressive faces, vibrant material shaders. NOT photorealistic."
        },
        "3d_render": {
            "quality": "Photorealistic 3D CGI, path-traced global illumination, PBR materials, 8K texture resolution",
            "lighting": "physically accurate 3D studio lighting with HDRI environment, subsurface scattering on skin",
            "render_style": "photorealistic 3D CGI rendering (VFX quality)",
            "char_instruction": "Render in photorealistic 3D CGI style — VFX-quality CG character with PBR materials and physically accurate lighting"
        },
        "3d_realistic": {
            "quality": "Unreal Engine 5 photorealistic 3D, ray-traced reflections, Nanite geometry, Lumen GI",
            "lighting": "UE5 ray-traced lighting with Lumen global illumination and real-time subsurface scattering",
            "render_style": "UE5 photorealistic 3D rendering",
            "char_instruction": "Render in UE5 photorealistic 3D style — next-gen game engine quality with ray tracing and realistic material shaders"
        },
        "horror": {
            "quality": "Horror film aesthetic, desaturated sickly palette, grain-heavy low-light, sharp unsettling detail",
            "lighting": "underlighting with flickering unstable sources, deep impenetrable shadows",
            "render_style": "psychological horror cinematography",
            "char_instruction": "Render in horror film visual style — desaturated, unsettling, with sickly undertones and sharp disturbing detail"
        },
        "thriller": {
            "quality": "Neo-thriller aesthetic, cold blue-steel palette, precise clinical detail, clean modern look",
            "lighting": "hard-edged motivated lighting creating sharp shadow lines, cold color temperature",
            "render_style": "neo-thriller cinematography (David Fincher aesthetic)",
            "char_instruction": "Render in thriller film visual style — cold precise aesthetic with clinical detail and sharp contrast"
        },
        "dark_fantasy": {
            "quality": "Dark fantasy art, desaturated earth-tones with crimson/gold accents, weathered textures",
            "lighting": "dramatic chiaroscuro rim lighting, mist-shrouded atmosphere",
            "render_style": "dark fantasy art direction",
            "char_instruction": "Render in dark fantasy art style — gritty, weathered, with dramatic lighting and dark medieval atmosphere"
        },
        "fantasy_epic": {
            "quality": "High fantasy epic art, rich vibrant palette, ornate detail, majestic composition",
            "lighting": "golden magical lighting with ethereal glow effects and volumetric atmosphere",
            "render_style": "high fantasy epic art direction",
            "char_instruction": "Render in high fantasy epic style — majestic, ornate, richly detailed with magical atmosphere"
        },
        "noir": {
            "quality": "Film noir, high-contrast black-and-white with selective desaturated accents, heavy grain",
            "lighting": "hard angular key light with minimal fill, Venetian blind shadow patterns",
            "render_style": "classic film noir cinematography",
            "char_instruction": "Render in film noir visual style — high-contrast, dramatic shadows, 1940s detective aesthetic"
        },
        "cyberpunk": {
            "quality": "Cyberpunk neo-Tokyo, neon-drenched palette, chrome and grime, holographic elements",
            "lighting": "neon-soaked lighting with electric cyan, hot magenta, acid yellow, volumetric fog",
            "render_style": "cyberpunk neo-Tokyo aesthetic (Blade Runner 2049)",
            "char_instruction": "Render in cyberpunk visual style — neon-lit, futuristic tech-wear, chrome implants, rain-soaked urban aesthetic"
        },
        "steampunk": {
            "quality": "Steampunk Victorian, brass and copper mechanical detail, clockwork, leather and rivets",
            "lighting": "warm gas-lamp lighting with amber tones and brass reflections",
            "render_style": "steampunk Victorian aesthetic",
            "char_instruction": "Render in steampunk Victorian style — brass goggles, clockwork mechanisms, Victorian clothing with mechanical augmentation"
        },
        "comic_book": {
            "quality": "Comic book / graphic novel, bold ink outlines, Ben-Day dots, dynamic action composition",
            "lighting": "flat comic book lighting with bold color fills and dramatic ink shadows",
            "render_style": "comic book / graphic novel illustration style",
            "char_instruction": "Render in comic book style — bold ink outlines, flat vibrant colors, dynamic pose, graphic novel aesthetic. NOT photorealistic."
        },
        "watercolor": {
            "quality": "Master watercolor painting, wet-on-wet pigment diffusion, transparent glazing, paper texture visible",
            "lighting": "soft diffused watercolor lighting with luminous glazed highlights",
            "render_style": "master-level traditional watercolor painting",
            "char_instruction": "Render in watercolor painting style — visible brushstrokes, pigment bleeding, paper texture, transparent luminous washes. NOT photorealistic."
        },
        "oil_painting": {
            "quality": "Classical oil painting, impasto brushwork, rich glazed color layers, old master technique",
            "lighting": "chiaroscuro Rembrandt lighting with rich shadow glazing",
            "render_style": "classical oil painting (Dutch Golden Age mastery)",
            "char_instruction": "Render in classical oil painting style — visible brushstrokes, impasto texture, rich glazed colors, old master aesthetic. NOT photorealistic."
        },
        "pencil_sketch": {
            "quality": "Professional concept art pencil illustration, graphite shading, cross-hatching, paper texture",
            "lighting": "tonal graphite shading with ambient occlusion shadow mapping",
            "render_style": "professional concept art pencil illustration",
            "char_instruction": "Render in pencil sketch / concept art style — graphite linework, cross-hatching, paper texture. NOT photorealistic."
        },
        "vintage_film": {
            "quality": "Vintage 1970s Kodachrome, warm amber color cast, heavy organic film grain, halation bloom",
            "lighting": "naturalistic available-light with warm amber shift and lifted shadow blacks",
            "render_style": "vintage 1970s Kodachrome film photography aesthetic",
            "char_instruction": "Render in vintage 1970s film style — warm amber tones, heavy film grain, halation, retro color science"
        },
        "documentary": {
            "quality": "Documentary cinema verité, natural handheld feel, authentic textures, observational framing",
            "lighting": "natural available-light documentary lighting, no artificial augmentation",
            "render_style": "documentary cinema verité style",
            "char_instruction": "Render in documentary film style — naturalistic, authentic, raw observational quality"
        },
        "stop_motion": {
            "quality": "Stop motion animation, visible handcrafted miniature detail, real fabric/felt textures, imperfect charm",
            "lighting": "miniature practical lighting with warm tungsten color temperature, tilt-shift depth of field",
            "render_style": "stop motion animation (Laika / Wes Anderson aesthetic)",
            "char_instruction": "Render in stop motion animation style — handcrafted miniature look, real fabric textures, slightly imperfect puppet-like quality. NOT photorealistic."
        }
    }

    # ══════════════════════════════════════════════════════════════════
    # NEW IN v4.1: USER DIRECTIVE BLOCK BUILDER
    # ══════════════════════════════════════════════════════════════════

    @staticmethod
    def _build_user_directive_block(custom_instructions: str) -> str:
        """Build a high-priority, visually prominent block of user-defined creative
        directives that will be injected at the TOP of every AI prompt.

        Returns an empty string if no custom_instructions are provided, so the
        AI falls back to its default story-driven interpretation.

        If instructions are provided, they are wrapped in an emphatic "ABSOLUTE
        OVERRIDE" block that tells the AI these rules are non-negotiable and
        take precedence over story-implied defaults.

        These directives are parsed into discrete rules (one per line or one
        per bullet) so the AI treats each as an enforceable constraint.
        """
        if not custom_instructions or not custom_instructions.strip():
            return ""

        cleaned = custom_instructions.strip()

        # Normalize bullet characters and split into discrete rules
        # so the AI sees them as enforceable items, not a blob of prose.
        lines = []
        for raw_line in cleaned.split("\n"):
            line = raw_line.strip()
            if not line:
                continue
            # Strip common bullet prefixes
            for prefix in ("•", "-", "*", "◦", "▪", "▸", "→", "»"):
                if line.startswith(prefix):
                    line = line[len(prefix):].strip()
                    break
            # Strip numeric prefixes like "1.", "2)", "a)"
            line = re.sub(r'^(\d+[\.\)]\s*|[a-zA-Z][\.\)]\s*)', '', line).strip()
            if line:
                lines.append(line)

        if not lines:
            return ""

        # Format as a numbered enforceable rule list
        rules_numbered = "\n".join([f"   {i+1}. {line}" for i, line in enumerate(lines)])

        block = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  🎯 USER CREATIVE DIRECTIVES — ABSOLUTE, NON-NEGOTIABLE, OVERRIDES ALL ELSE  ║
╚══════════════════════════════════════════════════════════════════════════════╝

The following creative directives were given by the user. They are LOCKED RULES
that MUST be followed in EVERY part of your output — characters, settings,
scenes, image_prompts, scene_prompts, wardrobe, architecture, ethnicity, era.
These rules OVERRIDE any defaults suggested by the story text, genre, or your
own interpretation. Apply them consistently across ALL scenes and ALL characters.

LOCKED USER RULES:
{rules_numbered}

HOW TO APPLY:
 • When describing characters, every description must satisfy these rules.
 • When describing settings and environments, every scene must satisfy these rules.
 • When describing wardrobe, architecture, props, culture — all must satisfy these rules.
 • Do NOT override these rules based on what seems "more natural" for the story.
 • If a rule seems to conflict with the story, ALWAYS prefer the user rule and
   reshape the scene to fit (e.g. if story says "New York" but user says "set in
   Dhaka", you set it in Dhaka).
 • Rules compound — if multiple apply to the same element, honor ALL of them.

"""
        return block

    # ══════════════════════════════════════════════════════════════════
    # UTILITY METHODS
    # ══════════════════════════════════════════════════════════════════

    def _build_visual_style_tag(self, visual_style: str) -> Dict[str, str]:
        """Build exact visual style prefix and suffix strings to inject into every image_prompt.

        Returns a dict with 'prefix' and 'suffix' — these are COPY-PASTED into every
        image_prompt programmatically, ensuring 100% visual consistency across all scenes
        and characters. The AI's interpretation is overridden by this forced injection.
        """
        vs_render = self.VISUAL_STYLE_RENDERING.get(
            visual_style, self.VISUAL_STYLE_RENDERING.get("cinematic")
        )
        style_desc = self.STYLE_PROMPTS.get(visual_style, self.STYLE_PROMPTS.get("cinematic", ""))

        prefix = f"{vs_render['render_style']}, {style_desc}. "
        suffix = f" {vs_render['quality']}. {vs_render['lighting']}."

        return {"prefix": prefix, "suffix": suffix}

    @staticmethod
    def _sort_chars_present_by_global_order(chars_present: List[Dict]) -> List[Dict]:
        """Sort a scene's characters_present list by each character's global DB
        order (ascending). This matches the order the renderer passes reference
        images to the scene, which is crucial for the per-scene reference
        indexing convention.

        Characters with missing/zero order are placed at the end, preserving
        their relative input sequence.
        """
        if not chars_present:
            return chars_present

        def sort_key(cp):
            if isinstance(cp, dict):
                order = cp.get("order", 0)
            else:
                order = 0
            # Characters with order 0 or missing go to the end
            return (0, order) if order and order > 0 else (1, 0)

        return sorted(chars_present, key=sort_key)

    @staticmethod
    def _build_scene_reference_declaration(chars_present: List[Dict]) -> str:
        """Build the authoritative per-scene reference-image mapping.

        Given a list of characters present in a scene (already sorted by global
        DB order — see `_sort_chars_present_by_global_order`), returns a
        declarative statement that tells the image model which reference image
        index maps to which character identity.

        The position numbers in this statement are PER-SCENE (1, 2, 3, ...) —
        they match the order the renderer composites reference images for
        THIS scene, NOT the global Character #N numbers.

        Example output (3 characters in scene, sorted):
            "REFERENCE CHARACTER MAPPING: reference character 1 is Rahul,
             reference character 2 is John, and reference character 3 is Sam —
             throughout this image, 'reference character N' denotes the Nth
             provided reference image and must depict that exact character. "

        Returns empty string if no characters.
        """
        if not chars_present:
            return ""

        parts = []
        for idx, cp in enumerate(chars_present):
            if isinstance(cp, dict):
                name = (cp.get("name") or "").strip()
            else:
                name = str(cp).strip()
            if name:
                parts.append(f"reference character {idx + 1} is {name}")

        if not parts:
            return ""

        # Prose joining: "A", "A and B", "A, B, and C"
        if len(parts) == 1:
            body = parts[0]
        elif len(parts) == 2:
            body = f"{parts[0]} and {parts[1]}"
        else:
            body = ", ".join(parts[:-1]) + f", and {parts[-1]}"

        return (
            f"REFERENCE CHARACTER MAPPING: {body} — throughout this image, "
            f"'reference character N' denotes the Nth provided reference image "
            f"and must depict that exact character. "
        )

    @staticmethod
    def _strip_leading_ref_declaration(image_prompt: str) -> str:
        """Strip any leading 'REFERENCE CHARACTER MAPPING: ...' or similar
        declarations that the AI may have added at the start of its image_prompt,
        so the authoritative post-processing prepend does not duplicate.

        Only strips the very first leading declaration — does not touch
        in-body 'reference character N' references (those are wanted).
        """
        if not image_prompt:
            return image_prompt

        text = image_prompt.strip()
        # Strip a leading "REFERENCE CHARACTER MAPPING: ... ." sentence if present
        text = re.sub(
            r'^REFERENCE\s+(?:IMAGE\s+|CHARACTER\s+)?MAPPING\s*[:—-][^.]*\.\s*',
            '',
            text,
            count=1,
            flags=re.IGNORECASE
        )
        # Strip a leading series of "Reference character N is X." statements
        # (up to ~6 characters — any more and it's probably content, not a declaration)
        text = re.sub(
            r'^(?:reference\s+character\s+\d+\s+(?:is|=)\s+[A-Za-z][A-Za-z0-9_\s\'\-\.]*?[\.,;]\s*){1,6}',
            '',
            text,
            count=1,
            flags=re.IGNORECASE
        )
        return text.strip()

    # ──────────────────────────────────────────────────────────────────
    # v4.3: ASPECT RATIO ENFORCEMENT
    # ──────────────────────────────────────────────────────────────────

    @staticmethod
    def _strip_leading_aspect_directive(image_prompt: str) -> str:
        """Strip any leading 'ASPECT RATIO: ...' statement the AI may have
        written at the very start of its image_prompt, so the authoritative
        post-processing prepend does not duplicate.

        Matches patterns like:
           "ASPECT RATIO: 16:9 (landscape...) — STRICT. ..."
           "Aspect ratio: 9:16. ..."
           "[ASPECT RATIO: 1:1] ..."
        Only strips ONE leading declaration — does not touch in-body references.
        """
        if not image_prompt:
            return image_prompt
        text = image_prompt.strip()
        # Strip optional leading bracket
        text = re.sub(r'^\[\s*ASPECT\s+RATIO[^\]]*\]\s*', '', text, count=1, flags=re.IGNORECASE)
        # Strip "ASPECT RATIO: <ratio> ... ." sentence up to first period+space
        # Handle up to 4 sentences of aspect-related content (the authoritative
        # directive has ~3 sentences, so AI-duplicated ones are similar).
        for _ in range(4):
            new_text = re.sub(
                r'^ASPECT\s+RATIO\s*[:—\-][^.]*\.\s*',
                '',
                text,
                count=1,
                flags=re.IGNORECASE
            )
            if new_text == text:
                break
            text = new_text
        # Also strip a trailing "Reference character images (if provided) are at..." sentence
        text = re.sub(
            r'^Reference\s+character\s+images[^.]*\.\s*',
            '',
            text,
            count=1,
            flags=re.IGNORECASE
        )
        # Strip a "Compose all framing..." sentence if left over
        text = re.sub(
            r'^Compose\s+all\s+framing[^.]*\.\s*',
            '',
            text,
            count=1,
            flags=re.IGNORECASE
        )
        return text.strip()

    @staticmethod
    def _build_aspect_directive(aspect_ratio: str, is_character_portrait: bool = False) -> str:
        """Build the authoritative ASPECT RATIO directive for every image_prompt.

        CRITICAL rules (v4.3):
          • Character reference portraits are ALWAYS 16:9 regardless of the
            project's scene aspect ratio. Scene compositions assume a
            consistent landscape canvas for reference images; changing this
            breaks reference-image compositing.
          • Scene images use the user-selected project aspect ratio. The
            directive EXPLICITLY OVERRIDES any conflicting ratio that might
            be implied by the 16:9 reference character portraits.

        This directive is prepended to every image_prompt as the very first
        statement after the visual-style prefix — it is not optional.
        """
        if is_character_portrait:
            return (
                "ASPECT RATIO: 16:9 (landscape horizontal widescreen) — STRICT. "
                "This is a CHARACTER REFERENCE PORTRAIT and MUST be rendered "
                "at 16:9 landscape orientation regardless of any other project "
                "aspect-ratio setting. Frame the character centered, head-to-toe "
                "fully visible, with clean margins above the head and below the "
                "feet so the portrait can be reliably used as a reference image "
                "for downstream scene composition. "
            )

        effective = (aspect_ratio or "16:9").strip()
        orientation_map = {
            "16:9":  ("landscape", "horizontal widescreen cinematic"),
            "9:16":  ("portrait",  "vertical mobile / short-form video"),
            "1:1":   ("square",    "social square format"),
            "4:3":   ("landscape", "classic TV / 4:3 standard"),
            "21:9":  ("landscape", "ultra-wide anamorphic cinematic"),
            "3:4":   ("portrait",  "vertical portrait"),
            "2:3":   ("portrait",  "vertical classic photo"),
            "4:5":   ("portrait",  "vertical social feed"),
            "5:4":   ("landscape", "near-square landscape"),
        }
        orient, desc = orientation_map.get(effective, ("", ""))

        override_clause = ""
        if effective != "16:9":
            override_clause = (
                f"Reference character images (if provided) are at 16:9 landscape — "
                f"they are for CHARACTER IDENTITY reference ONLY. This final output "
                f"MUST be rendered at {effective} ({orient}), NOT at 16:9. Do NOT "
                f"inherit the reference images' 16:9 framing. "
            )
        else:
            override_clause = (
                "Reference character images (if provided) are at 16:9 landscape, "
                "matching this output's aspect ratio. Use them for character "
                "identity reference only. "
            )

        return (
            f"ASPECT RATIO: {effective}"
            + (f" ({orient}, {desc})" if orient else "")
            + f" — STRICT, NON-NEGOTIABLE. Render this image at EXACTLY {effective}"
            + (f" {orient} orientation. " if orient else ". ")
            + override_clause
            + f"Compose all framing, subject placement, headroom, lead-space, "
            f"horizon line, and environmental depth specifically for {effective}"
            + (f" {orient} orientation. " if orient else ". ")
        )

    # ──────────────────────────────────────────────────────────────────
    # v4.3.1: AUDIO CONTENT RESTRICTION
    # The template generates its own audio track via TTS from the voiceover.
    # If the image-to-video renderer ALSO produces speech/dialogue/voice,
    # the two tracks will collide and ruin the final video. scene_prompt
    # must therefore describe ONLY visual motion + BGM/SFX mood — NEVER
    # voice-over, narration, dialogue, or spoken content.
    # ──────────────────────────────────────────────────────────────────

    @staticmethod
    def _build_audio_restriction_directive() -> str:
        """Return the authoritative AUDIO CONTENT RESTRICTION directive that
        appears at the END of every scene_prompt motion_description.

        This tells the image-to-video renderer, in no uncertain terms, that
        it must NOT add voice-over, dialogue, speech, or any narrated audio
        to the generated video — because the final audio track is the TTS
        voiceover generated separately by this template.
        """
        return (
            " AUDIO RESTRICTION (STRICT): Generate VISUAL MOTION ONLY. Do NOT "
            "add any voice-over, dialogue, speech, narration, character "
            "speaking, lip-synced audio, spoken words, or any vocal audio "
            "track to the video output. Characters may be depicted with "
            "silent mouth movement if the moment calls for it, but NO audible "
            "speech. Background music mood cues (BGM) and ambient sound "
            "effects (SFX — wind, rain, fire crackle, footsteps, etc.) are "
            "acceptable as mood descriptors, but the final audio track is "
            "generated separately by this template from the voiceover — the "
            "video must not duplicate or compete with it."
        )

    @staticmethod
    def _strip_voice_dialogue_content(text: str):
        """Safety-net post-processor: remove voice-over, dialogue, narration,
        and speech directives that the AI may have slipped into a scene_prompt.

        Returns (cleaned_text, patterns_stripped_count).

        Only strips HIGH-CONFIDENCE speech instructions — content paired with
        quotes or explicit voice-over/dialogue labels. Visual/metaphorical
        uses of speech verbs (e.g. "the character's posture speaks volumes")
        are left alone to avoid false positives.

        The primary defense against voice leakage is the AI-prompt instruction
        in TASK 2 of scene generation; this function is the secondary
        programmatic defense.
        """
        if not text or not isinstance(text, str):
            return text, 0

        stripped_count = 0

        # Pattern A: "voiceover:", "voice-over:", "V.O.:", "VO:", "voice over:"
        # followed by quoted content or a sentence
        patterns_labeled = [
            r'\b(?:voice[\s\-]?over|voice[\s\-]?off|v\.?\s*o\.?)\s*[:\-—]\s*["\'""][^"\'""]*["\'""][.!?]?',
            r'\b(?:voice[\s\-]?over|voice[\s\-]?off|v\.?\s*o\.?)\s*[:\-—]\s*[^.!?\n]{3,120}[.!?]',
            r'\b(?:narration|narrator|narrating|narrated)\s*[:\-—]\s*["\'""][^"\'""]*["\'""][.!?]?',
            r'\b(?:narration|narrator)\s*[:\-—]\s*[^.!?\n]{3,120}[.!?]',
            r'\bdialog(?:ue)?\s*[:\-—]\s*["\'""][^"\'""]*["\'""][.!?]?',
            r'\bdialog(?:ue)?\s*[:\-—]\s*[^.!?\n]{3,120}[.!?]',
            r'\bmonologue\s*[:\-—]\s*["\'""][^"\'""]*["\'""][.!?]?',
            # "subtitle:" is also a no-go
            r'\bsubtitle\s*[:\-—]\s*["\'""][^"\'""]*["\'""][.!?]?',
        ]
        for pat in patterns_labeled:
            cleaned, n = re.subn(pat, '', text, flags=re.IGNORECASE)
            if n:
                text = cleaned
                stripped_count += n

        # Pattern B: sentence with speech verb + quoted utterance
        # e.g. 'Rahul says "hello".', 'she whispers "stay here".'
        speech_verbs = (
            r'(?:says?|said|speaks?|spoke|speaking|whispers?|whispered|'
            r'shouts?|shouted|utters?|uttered|calls? out|murmurs?|muttered|'
            r'announces?|announced|exclaims?|exclaimed|asks?|asked|replies?|replied|'
            r'declares?|declared|proclaims?|proclaimed|recites?|recited)'
        )
        # Build as string and pass directly to re.subn (string pattern only).
        pattern_quote_speech = (
            r'[^.!?\n]*\b' + speech_verbs +
            r'\b[^.!?\n]*["\'""][^"\'""]{2,}["\'""][^.!?\n]*[.!?]'
        )
        cleaned, n = re.subn(pattern_quote_speech, '', text, flags=re.IGNORECASE)
        if n:
            text = cleaned
            stripped_count += n

        # Pattern C: explicit "spoken dialogue", "audible speech", lip-sync, inner monologue
        # String pattern passed directly to re.subn (string pattern only).
        pattern_explicit = (
            r'\b(?:spoken\s+(?:dialogue|words|lines|narration|line)|'
            r'audible\s+(?:speech|voice|dialogue|narration)|'
            r'lip[\s\-]?syn(?:c|ced|cing)(?:\s+(?:to|with)\s+(?:the\s+)?)?(?:\s+(?:audio|speech|dialogue|voice|words|narration|monologue))?|'
            r'sync(?:ed|ing)?\s+(?:lip|mouth)(?:\s+movement)?\s+(?:to|with)\s+(?:the\s+)?(?:audio|speech|voice|dialogue|words|narration|monologue)|'
            r'(?:inner|internal)\s+monologue|'
            r'voice\s+(?:track|over\s+track|acting)|'
            r'character[\s\S]{0,30}?\bspeaks?\s+aloud|'
            r'character[\s\S]{0,30}?\bdelivers\s+[\w\s]{0,20}?\bline\b)\b[^.!?\n]*[.!?]?'
        )
        cleaned, n = re.subn(pattern_explicit, '', text, flags=re.IGNORECASE)
        if n:
            text = cleaned
            stripped_count += n

        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text).strip()

        return text, stripped_count

    def _inject_visual_style(self, image_prompt: str, style_tag: Dict[str, str]) -> str:
        """Inject the visual style prefix and suffix into an image_prompt.

        If the prompt already starts with the style prefix (or close to it),
        only the suffix is appended. This ensures no duplicate injection.
        """
        if not image_prompt:
            return image_prompt

        prompt = image_prompt.strip()
        prefix = style_tag["prefix"]
        suffix = style_tag["suffix"]

        # Check if prefix is already present (first 50 chars overlap)
        prefix_check = prefix[:50].lower()
        if not prompt[:60].lower().startswith(prefix_check[:30]):
            prompt = prefix + prompt

        # Check if suffix is already present
        suffix_check = suffix.strip()[-40:].lower()
        if suffix_check not in prompt[-80:].lower():
            prompt = prompt.rstrip(". ") + "." + suffix

        return prompt

    async def _ai_generate_with_retry(self, mexflow, prompt: str, max_tokens: int = 10000, label: str = "AI", max_retries: int = 5) -> Optional[str]:
        """Call mexflow.ai.generate with automatic retry on failure.

        Retries up to max_retries times with incremental backoff on empty
        responses, plugin errors, or other transient failures.
        """
        for attempt in range(1, max_retries + 1):
            try:
                print(f"[AUDIO_TEMPLATE][{label}] Attempt {attempt}/{max_retries} — generating ({len(prompt)} chars prompt, max_tokens={max_tokens})")
                response = await mexflow.ai.generate(prompt, max_tokens=max_tokens)
                if response and len(response.strip()) > 0:
                    print(f"[AUDIO_TEMPLATE][{label}] Attempt {attempt} succeeded ({len(response)} chars)")
                    return response
                print(f"[AUDIO_TEMPLATE][{label}] Attempt {attempt} returned empty response")
            except Exception as e:
                print(f"[AUDIO_TEMPLATE][{label}] Attempt {attempt} EXCEPTION: {e}")
            # Note: No async-sleep primitive exists in the SDK, so retries
            # proceed immediately. The plugin's own timeouts govern cadence.
        print(f"[AUDIO_TEMPLATE][{label}] FAILED after {max_retries} attempts")
        return None

    # ══════════════════════════════════════════════════════════════════
    # IMPROVED IN v4.1: ROBUST JSON PARSING
    # ══════════════════════════════════════════════════════════════════

    @staticmethod
    def _clean_and_parse_json(raw_response: str, sdk_parser=None) -> Any:
        """Robustly extract and parse JSON from AI responses.

        v4.1 IMPROVEMENTS:
        - Strips common prose prefixes ("Here is the JSON:", "Output:", "Result:")
        - Handles mixed content (text explanation before/after JSON)
        - Better truncation repair
        - More aggressive last-resort parsing with greedy brace matching
        - Handles triple-backtick variants (```json, ```JSON, ``` )
        """
        if not raw_response:
            return None

        text = raw_response.strip()

        # ── Step 0: Strip common AI prose prefixes ──
        # AIs often preface with "Here is the JSON response:" etc.
        # We strip these because the actual JSON begins later.
        common_prefixes = [
            r'^\s*here\s+(?:is|are)\s+(?:the\s+)?(?:requested\s+|valid\s+|final\s+)?(?:json|output|result|response|data|array|analysis|scenes?|characters?)\s*[:\-–—]?\s*',
            r'^\s*(?:output|result|response|answer|analysis|json)\s*[:\-–—]\s*',
            r'^\s*(?:sure|certainly|of course|okay|ok|alright)[,\s!]+\s*',
            r'^\s*(?:below|above|following)\s+is\s+[^\n]{0,80}[:\-–—]\s*',
        ]
        for pattern in common_prefixes:
            new_text = re.sub(pattern, '', text, count=1, flags=re.IGNORECASE | re.MULTILINE)
            if new_text != text:
                text = new_text.strip()
                break

        # ── Step 1: Strip markdown code fences ──
        # Handle ```json ... ```, ```JSON ... ```, ``` ... ```
        fence_match = re.match(r'^```(?:json|JSON|javascript|js)?\s*\n?(.*?)\n?```\s*$', text, re.DOTALL)
        if fence_match:
            text = fence_match.group(1).strip()
        elif text.startswith("```"):
            # Non-closing or partial fence
            first_newline = text.find("\n")
            if first_newline > 0:
                text = text[first_newline + 1:]
            else:
                text = text[3:]
            if text.rstrip().endswith("```"):
                text = text.rstrip()[:-3].rstrip()

        text = text.strip()

        # ── Step 2: Try SDK parser first (it may handle edge cases) ──
        if sdk_parser:
            try:
                result = sdk_parser(text)
                if result is not None:
                    return result
            except Exception:
                pass

        # ── Step 3: Try direct json.loads ──
        try:
            return json.loads(text)
        except (json.JSONDecodeError, ValueError):
            pass

        # ── Step 4: Extract JSON object/array from surrounding text ──
        # Find the first { or [ and match to the LAST } or ]
        obj_start = text.find("{")
        arr_start = text.find("[")

        if obj_start == -1 and arr_start == -1:
            return None

        # Pick whichever comes first
        if arr_start != -1 and (obj_start == -1 or arr_start < obj_start):
            start = arr_start
            end = text.rfind("]")
            if end > start:
                candidate = text[start:end + 1]
                try:
                    return json.loads(candidate)
                except (json.JSONDecodeError, ValueError):
                    pass
        else:
            start = obj_start
            end = text.rfind("}")
            if end > start:
                candidate = text[start:end + 1]
                try:
                    return json.loads(candidate)
                except (json.JSONDecodeError, ValueError):
                    pass

        # ── Step 5: Try repairing truncated JSON ──
        # AI responses often get cut off, leaving unclosed brackets/braces
        for candidate_text in [text, raw_response.strip()]:
            # Find the earliest of { or [
            first_obj = candidate_text.find("{")
            first_arr = candidate_text.find("[")
            if first_obj == -1 and first_arr == -1:
                continue
            if first_arr != -1 and (first_obj == -1 or first_arr < first_obj):
                start_idx = first_arr
            else:
                start_idx = first_obj

            fragment = candidate_text[start_idx:]
            # Count unclosed braces and brackets, then close them
            open_braces = 0
            open_brackets = 0
            in_string = False
            escape_next = False
            for ch in fragment:
                if escape_next:
                    escape_next = False
                    continue
                if ch == '\\' and in_string:
                    escape_next = True
                    continue
                if ch == '"' and not escape_next:
                    in_string = not in_string
                    continue
                if in_string:
                    continue
                if ch == '{':
                    open_braces += 1
                elif ch == '}':
                    open_braces -= 1
                elif ch == '[':
                    open_brackets += 1
                elif ch == ']':
                    open_brackets -= 1
            if open_braces > 0 or open_brackets > 0 or in_string:
                repaired = fragment.rstrip()
                # If we ended inside a string, close it
                if in_string:
                    repaired += '"'
                # Strip trailing comma or colon or partial key/value
                while repaired and repaired[-1] in (',', ':', ' ', '\n', '\r', '\t'):
                    repaired = repaired[:-1].rstrip()
                # Close unclosed brackets then braces
                repaired += ']' * max(0, open_brackets) + '}' * max(0, open_braces)
                try:
                    result = json.loads(repaired)
                    if isinstance(result, (dict, list)):
                        print(f"[AUDIO_TEMPLATE][JSON_REPAIR] Successfully repaired truncated JSON")
                        return result
                except (json.JSONDecodeError, ValueError):
                    pass

        # ── Step 6: Try SDK parser on original response as last resort ──
        if sdk_parser:
            try:
                result = sdk_parser(raw_response)
                if result is not None:
                    return result
            except Exception:
                pass

        # ── Step 7: Nuclear option — find any valid JSON object/array substring ──
        # Walk forward from each { or [ and try to parse progressively larger chunks.
        for candidate_text in [text, raw_response.strip()]:
            for i, ch in enumerate(candidate_text):
                if ch not in '{[':
                    continue
                # Try progressively from end of string backward
                for end_idx in range(len(candidate_text), i, -1):
                    sub = candidate_text[i:end_idx]
                    try:
                        result = json.loads(sub)
                        if isinstance(result, (dict, list)):
                            print(f"[AUDIO_TEMPLATE][JSON_SCAN] Found parseable JSON at [{i}:{end_idx}]")
                            return result
                    except (json.JSONDecodeError, ValueError):
                        continue
                # Only try starting from first { or [
                break

        return None

    # ══════════════════════════════════════════════════════════════════
    # NEW IN v4.1: FLEXIBLE DATA EXTRACTION
    # ══════════════════════════════════════════════════════════════════

    @staticmethod
    def _extract_list_from_parsed(parsed: Any, possible_keys: List[str]) -> Optional[List[Dict]]:
        """Extract a list-of-dicts from parsed JSON under ANY of the possible keys.

        Handles the case where the AI returns the list under an unexpected key name
        (e.g. 'cast' instead of 'characters', 'storyboard' instead of 'scenes').

        Also handles nested structures like:
          {"result": {"characters": [...]}}
          {"data": [...]}

        Returns the list if found, else None.
        """
        if parsed is None:
            return None
        # Already a list
        if isinstance(parsed, list):
            if len(parsed) > 0 and isinstance(parsed[0], dict):
                return parsed
            elif len(parsed) == 0:
                return []  # empty list is valid

        if not isinstance(parsed, dict):
            return None

        # Try each possible key at the top level
        for key in possible_keys:
            if key in parsed:
                value = parsed[key]
                if isinstance(value, list):
                    return value
                # Nested case: {"characters": {"list": [...]}} — unusual but possible
                if isinstance(value, dict):
                    for nested_key in possible_keys:
                        if nested_key in value and isinstance(value[nested_key], list):
                            return value[nested_key]

        # Try common wrapper keys
        wrapper_keys = ["result", "data", "response", "output", "content", "items"]
        for wrapper in wrapper_keys:
            if wrapper in parsed:
                inner = parsed[wrapper]
                if isinstance(inner, list) and len(inner) > 0 and isinstance(inner[0], dict):
                    return inner
                if isinstance(inner, dict):
                    # Recurse into wrapper
                    nested = AudioWorkflowTemplate._extract_list_from_parsed(inner, possible_keys)
                    if nested is not None:
                        return nested

        # Last resort: find the first value that is a non-empty list of dicts
        for key, value in parsed.items():
            if isinstance(value, list) and len(value) > 0 and isinstance(value[0], dict):
                print(f"[AUDIO_TEMPLATE][EXTRACT] Using fallback key '{key}' for list extraction")
                return value

        return None

    @staticmethod
    def _parse_durations(raw: str) -> List[int]:
        """Parse comma-separated duration string into sorted list of ints."""
        try:
            durations = []
            for part in raw.replace(" ", "").split(","):
                if part.strip():
                    val = int(part.strip())
                    if val > 0:
                        durations.append(val)
            return sorted(list(set(durations)))
        except (ValueError, TypeError):
            return []

    @staticmethod
    def _split_text_into_chunks(text: str, max_chars: int) -> List[str]:
        """
        Split text into chunks respecting sentence boundaries.
        Each chunk will be at most max_chars characters long.
        """
        if len(text) <= max_chars:
            return [text]

        chunks = []
        remaining = text.strip()

        while remaining:
            if len(remaining) <= max_chars:
                chunks.append(remaining)
                break

            segment = remaining[:max_chars]
            split_pos = -1

            # Priority 1: Split at last sentence boundary (. ! ?)
            for i in range(len(segment) - 1, 0, -1):
                if segment[i] in '.!?' and (i + 1 >= len(segment) or segment[i + 1] in ' \n\r\t'):
                    split_pos = i + 1
                    break

            # Priority 2: Split at last comma, semicolon, or colon
            if split_pos == -1:
                for i in range(len(segment) - 1, 0, -1):
                    if segment[i] in ',;:' and (i + 1 >= len(segment) or segment[i + 1] in ' \n\r\t'):
                        split_pos = i + 1
                        break

            # Priority 3: Split at last space (word boundary)
            if split_pos == -1:
                split_pos = segment.rfind(' ')

            # Priority 4: Hard split at max_chars
            if split_pos <= 0:
                split_pos = max_chars

            chunk = remaining[:split_pos].strip()
            if chunk:
                chunks.append(chunk)
            remaining = remaining[split_pos:].strip()

        return chunks if chunks else [text]

    @staticmethod
    def _snap_to_allowed_duration(duration: float, allowed: List[int]) -> int:
        """Snap a raw duration to the nearest allowed value."""
        if not allowed:
            allowed = [5, 10, 15]
        best = allowed[0]
        best_diff = abs(duration - best)
        for d in allowed:
            diff = abs(duration - d)
            if diff < best_diff:
                best = d
                best_diff = diff
        return int(best)

    @staticmethod
    def _snap_duration_ceil(duration: float, allowed: List[int]) -> int:
        """Snap duration to the smallest allowed value that COVERS the audio segment."""
        if not allowed:
            allowed = [5, 10, 15]
        candidates = [d for d in allowed if d >= duration]
        if candidates:
            return min(candidates)
        return max(allowed)

    @staticmethod
    def _fuzzy_match_character_name(query: str, known_names: List[str]) -> Optional[str]:
        """Fuzzy-match a character name against known names."""
        if not query or not known_names:
            return None
        query_clean = query.strip().lower()
        for name in known_names:
            if name.strip().lower() == query_clean:
                return name
        for name in known_names:
            name_lower = name.strip().lower()
            if name_lower in query_clean or query_clean in name_lower:
                return name
        query_words = set(re.sub(r'[^a-z0-9\s]', '', query_clean).split())
        query_words -= {'the', 'a', 'an', 'of', 'and', 'in', 'on', 'at', 'to', 'for'}
        for name in known_names:
            name_words = set(re.sub(r'[^a-z0-9\s]', '', name.strip().lower()).split())
            name_words -= {'the', 'a', 'an', 'of', 'and', 'in', 'on', 'at', 'to', 'for'}
            overlap = query_words & name_words
            if len(overlap) >= 2 or (len(overlap) >= 1 and len(name_words) == 1):
                return name
        return None

    def _allocate_synced_durations(
        self,
        scene_audio_starts: List[float],
        scene_audio_ends: List[float],
        allowed_durations: List[int],
        total_audio_duration: float
    ) -> List[int]:
        """Allocate scene durations that keep cumulative video time synchronized
        with actual audio timestamps."""
        n = len(scene_audio_starts)
        if n == 0:
            return []
        if n == 1:
            raw = max(scene_audio_ends[0] - scene_audio_starts[0], min(allowed_durations))
            return [self._snap_duration_ceil(raw, allowed_durations)]

        durations = []
        cumulative_video_time = 0.0

        for i in range(n):
            if i < n - 1:
                raw_dur = scene_audio_starts[i + 1] - scene_audio_starts[i]
            else:
                raw_dur = scene_audio_ends[i] - scene_audio_starts[i]
                remaining_audio = total_audio_duration - cumulative_video_time
                raw_dur = max(raw_dur, remaining_audio)

            raw_dur = max(raw_dur, min(allowed_durations) * 0.5)

            audio_target = scene_audio_starts[i]
            drift = cumulative_video_time - audio_target

            if abs(drift) < 0.5:
                snapped = self._snap_to_allowed_duration(raw_dur, allowed_durations)
            elif drift > 0:
                floor_candidates = [d for d in allowed_durations if d <= raw_dur]
                if floor_candidates:
                    snapped = max(floor_candidates)
                else:
                    snapped = min(allowed_durations)
            else:
                snapped = self._snap_duration_ceil(raw_dur, allowed_durations)

            durations.append(snapped)
            cumulative_video_time += snapped

        total_video = sum(durations)
        while total_video < total_audio_duration:
            current_last = durations[-1]
            bigger = [d for d in allowed_durations if d > current_last]
            if bigger:
                durations[-1] = min(bigger)
            else:
                durations.append(min(allowed_durations))
            total_video = sum(durations)

        return durations

    def _split_subtitle_into_scenes(
        self,
        subtitle_data: List[Dict],
        allowed_durations: List[int],
        audio_duration: float,
        required_scene_count: int
    ) -> List[Dict]:
        """Split subtitle words into scene segments based on ACTUAL TIMESTAMPS.
        This is the critical synchronization method."""
        if not subtitle_data or required_scene_count == 0:
            return []

        total_words = len(subtitle_data)
        min_dur = min(allowed_durations) if allowed_durations else 5

        # ── Step 1: Determine scene durations and time boundaries ──
        scene_durations = []
        remaining = audio_duration

        for i in range(required_scene_count):
            if i == required_scene_count - 1:
                dur = self._snap_duration_ceil(remaining, allowed_durations)
            else:
                avg_remaining = remaining / (required_scene_count - i)
                dur = self._snap_to_allowed_duration(avg_remaining, allowed_durations)
            scene_durations.append(dur)
            remaining -= dur
            if remaining < 0:
                remaining = 0

        total_video = sum(scene_durations)
        while total_video < audio_duration:
            current_last = scene_durations[-1]
            bigger = [d for d in allowed_durations if d > current_last]
            if bigger:
                scene_durations[-1] = min(bigger)
            else:
                scene_durations.append(min_dur)
            total_video = sum(scene_durations)

        scene_boundaries = []
        cumulative = 0.0
        for dur in scene_durations:
            scene_boundaries.append((cumulative, cumulative + dur))
            cumulative += dur

        print(f"[SPLIT] Scene durations: {scene_durations}")
        print(f"[SPLIT] Scene boundaries: {[(round(s,1), round(e,1)) for s,e in scene_boundaries]}")
        print(f"[SPLIT] Total video: {sum(scene_durations)}s | Audio: {round(audio_duration,1)}s")

        # ── Step 2: Assign words to scenes by their timestamp midpoint ──
        word_scene_assignment = [0] * total_words

        for w_idx in range(total_words):
            word = subtitle_data[w_idx]
            w_start = word.get("start", 0)
            w_end = word.get("end", w_start + 0.1)
            w_mid = (w_start + w_end) / 2.0

            assigned = len(scene_boundaries) - 1
            for s_idx, (s_start, s_end) in enumerate(scene_boundaries):
                if w_mid < s_end:
                    assigned = s_idx
                    break
            word_scene_assignment[w_idx] = assigned

        # ── Step 3: Find raw split points ──
        raw_splits = [0]
        for w_idx in range(1, total_words):
            if word_scene_assignment[w_idx] != word_scene_assignment[w_idx - 1]:
                raw_splits.append(w_idx)

        raw_splits.append(total_words)

        while len(raw_splits) - 1 < len(scene_durations):
            max_size = 0
            max_idx = 0
            for i in range(len(raw_splits) - 1):
                size = raw_splits[i + 1] - raw_splits[i]
                if size > max_size:
                    max_size = size
                    max_idx = i
            mid = raw_splits[max_idx] + max_size // 2
            raw_splits.insert(max_idx + 1, mid)

        while len(raw_splits) - 1 > len(scene_durations):
            min_size = float('inf')
            min_idx = 0
            for i in range(len(raw_splits) - 2):
                size = raw_splits[i + 1] - raw_splits[i]
                if size < min_size:
                    min_size = size
                    min_idx = i
            raw_splits.pop(min_idx + 1)

        SNAP_RANGE = 5
        snapped_splits = [raw_splits[0]]

        for sp_idx in range(1, len(raw_splits) - 1):
            raw_sp = raw_splits[sp_idx]
            best_sp = raw_sp
            best_score = -1

            search_lo = max(raw_splits[sp_idx - 1] + 1, raw_sp - SNAP_RANGE)
            search_hi = min(raw_splits[sp_idx + 1] if sp_idx + 1 < len(raw_splits) else total_words,
                           raw_sp + SNAP_RANGE + 1)

            for candidate in range(search_lo, search_hi):
                if candidate <= 0 or candidate >= total_words:
                    continue
                prev_word = (subtitle_data[candidate - 1].get("word", "")
                             or subtitle_data[candidate - 1].get("text", ""))

                score = 0
                if self._detect_sentence_boundary(prev_word):
                    score += 10
                elif self._detect_clause_boundary(prev_word):
                    score += 5

                if candidate < total_words:
                    prev_end = subtitle_data[candidate - 1].get("end", 0)
                    next_start = subtitle_data[candidate].get("start", 0)
                    pause = next_start - prev_end
                    if pause > 0.3:
                        score += 3
                    elif pause > 0.15:
                        score += 1

                distance = abs(candidate - raw_sp)
                score -= distance * 0.5

                if score > best_score:
                    best_score = score
                    best_sp = candidate

            snapped_splits.append(best_sp)

        snapped_splits.append(raw_splits[-1])

        # ── Step 4: Build segments ──
        segments = []
        for i in range(len(snapped_splits) - 1):
            w_start_idx = snapped_splits[i]
            w_end_idx = snapped_splits[i + 1]

            if w_start_idx >= w_end_idx:
                dur = scene_durations[i] if i < len(scene_durations) else min_dur
                prev_end = segments[-1]["end_time"] if segments else 0
                segments.append({
                    "voiceover": "",
                    "start_time": prev_end,
                    "end_time": prev_end,
                    "duration": dur,
                    "word_start_idx": w_start_idx,
                    "word_end_idx": w_start_idx,
                })
                continue

            seg_words = subtitle_data[w_start_idx:w_end_idx]

            voiceover = " ".join(
                (w.get("word", "") or w.get("text", "")) for w in seg_words
            ).strip()

            seg_start = seg_words[0].get("start", 0)
            seg_end = seg_words[-1].get("end", seg_words[-1].get("start", 0) + 0.2)

            dur = scene_durations[i] if i < len(scene_durations) else min_dur

            segments.append({
                "voiceover": voiceover,
                "start_time": round(seg_start, 3),
                "end_time": round(seg_end, 3),
                "duration": dur,
                "word_start_idx": w_start_idx,
                "word_end_idx": w_end_idx - 1,
            })

        print(f"[SPLIT] Generated {len(segments)} segments:")
        for i, seg in enumerate(segments):
            word_count = len(seg['voiceover'].split()) if seg['voiceover'] else 0
            print(f"  Scene {i+1}: {seg['start_time']:.1f}s–{seg['end_time']:.1f}s "
                  f"| dur={seg['duration']}s | words={word_count} "
                  f"| text=\"{seg['voiceover'][:60]}...\"")

        return segments

    @staticmethod
    def _detect_sentence_boundary(word: str) -> bool:
        cleaned = word.strip()
        return bool(re.search(r'[.!?;:—]$', cleaned)) or bool(re.search(r'[.!?]["\')\]]$', cleaned))

    @staticmethod
    def _detect_clause_boundary(word: str) -> bool:
        cleaned = word.strip()
        return bool(re.search(r'[,;:\-–—]$', cleaned))

    @staticmethod
    def _calculate_pause_between_words(current_end: float, next_start: float) -> float:
        return max(0, next_start - current_end)

    def _categorize_emotion_for_camera(self, emotion: str) -> str:
        emotion_lower = emotion.lower().strip()
        mapping = {
            "peaceful": "contemplative", "calm": "contemplative", "serene": "contemplative",
            "reflective": "contemplative", "meditative": "contemplative",
            "tense": "tension", "anxious": "tension", "suspenseful": "tension",
            "nervous": "tension", "uneasy": "tension", "dread": "tension",
            "joyful": "dynamic", "excited": "dynamic", "energetic": "dynamic",
            "happy": "dynamic", "celebratory": "triumphant", "triumphant": "triumphant",
            "victorious": "triumphant", "proud": "triumphant",
            "sad": "intimate", "melancholic": "intimate", "grief": "intimate",
            "lonely": "intimate", "vulnerable": "intimate",
            "mysterious": "establishing", "curious": "establishing", "wonder": "establishing",
            "awe": "establishing", "discovery": "establishing",
            "angry": "dynamic", "furious": "dynamic", "rage": "dynamic",
            "fearful": "tension", "terrified": "tension", "horror": "tension",
            "romantic": "intimate", "tender": "intimate", "loving": "intimate",
            "epic": "triumphant", "grand": "triumphant", "majestic": "triumphant",
            "hopeful": "contemplative", "inspiring": "triumphant",
            "neutral": "establishing"
        }
        return mapping.get(emotion_lower, "establishing")

    def _get_genre_style_ref(self, genre: str) -> str:
        genre_lower = genre.lower() if genre else ""
        for key, val in self.GENRE_STYLE_MAP.items():
            if key in genre_lower:
                return val
        return self.DEFAULT_STYLE_REF

    def _map_voiceover_timing(
        self,
        voiceover_text: str,
        subtitle_data: List[Dict],
        search_start_idx: int = 0
    ) -> Tuple[float, float, int]:
        if not voiceover_text or not subtitle_data:
            return (0.0, 0.0, search_start_idx)

        vo_words_raw = voiceover_text.split()
        if not vo_words_raw:
            return (0.0, 0.0, search_start_idx)

        def clean_word(w):
            return re.sub(r'[^a-zA-Z0-9\u0080-\uffff]', '', w.lower()).strip()

        vo_words_clean = [clean_word(w) for w in vo_words_raw]
        vo_words_clean = [w for w in vo_words_clean if w]

        if not vo_words_clean:
            return (0.0, 0.0, search_start_idx)

        first_vo_word = vo_words_clean[0]
        start_time = 0.0
        end_time = 0.0
        match_start_idx = search_start_idx
        found_start = False

        for idx in range(search_start_idx, len(subtitle_data)):
            sub_word = subtitle_data[idx].get("word", "") or subtitle_data[idx].get("text", "")
            sub_word_clean = clean_word(sub_word)
            if sub_word_clean == first_vo_word:
                start_time = subtitle_data[idx].get("start", 0)
                match_start_idx = idx
                found_start = True
                break

        if not found_start:
            if search_start_idx < len(subtitle_data):
                start_time = subtitle_data[search_start_idx].get("start", 0)
                match_start_idx = search_start_idx

        last_vo_word = vo_words_clean[-1]
        end_idx = match_start_idx
        max_scan = min(match_start_idx + len(vo_words_clean) * 2 + 5, len(subtitle_data))

        for idx in range(max_scan - 1, match_start_idx - 1, -1):
            if idx >= len(subtitle_data):
                continue
            sub_word = subtitle_data[idx].get("word", "") or subtitle_data[idx].get("text", "")
            sub_word_clean = clean_word(sub_word)
            if sub_word_clean == last_vo_word:
                end_time = subtitle_data[idx].get("end", subtitle_data[idx].get("start", 0) + 0.3)
                end_idx = idx
                break

        if end_time <= start_time:
            estimated_end_idx = min(match_start_idx + len(vo_words_clean) - 1, len(subtitle_data) - 1)
            end_time = subtitle_data[estimated_end_idx].get("end",
                subtitle_data[estimated_end_idx].get("start", 0) + 0.3
            )
            end_idx = estimated_end_idx

        next_search_idx = end_idx + 1
        return (start_time, end_time, next_search_idx)

    # ══════════════════════════════════════════════════════════════════
    # MAIN EXECUTION — 8-STAGE PIPELINE
    # ══════════════════════════════════════════════════════════════════

    async def execute(self, inputs: Dict[str, Any]) -> TemplateResult:
        """Main execution entry point."""

        # ── Extract all inputs ──
        input_mode = inputs.get("input_mode", "story")
        story_text = inputs.get("story_text", "").strip()
        audio_file = inputs.get("audio_file")
        language = inputs.get("language", "en-US")
        visual_style = inputs.get("visual_style", "cinematic")
        voice_style = inputs.get("voice_style", "neutral")
        add_camera = inputs.get("add_camera_movements", True)
        include_emotions = inputs.get("include_emotions", True)
        aspect_ratio = inputs.get("aspect_ratio", "16:9")
        color_grading = inputs.get("color_grading", "auto")
        narrative_continuity = inputs.get("narrative_continuity", True)
        enforce_variety = inputs.get("enforce_variety", True)
        bg_color = inputs.get("character_bg_color", "#1a5fb4")
        portrait_mode = inputs.get("portrait_mode", "single")
        max_audio_chars = int(inputs.get("max_audio_chars", 1500))

        # ── NEW v4.1: Custom Creative Directives ──
        # These are strict rules the AI must follow across all outputs.
        custom_instructions = inputs.get("custom_instructions", "") or ""
        custom_instructions = custom_instructions.strip()

        if custom_instructions:
            print(f"[AUDIO_TEMPLATE] 🎯 USER CREATIVE DIRECTIVES PROVIDED ({len(custom_instructions)} chars):")
            for line in custom_instructions.split("\n")[:10]:
                if line.strip():
                    print(f"  • {line.strip()[:120]}")
        else:
            print(f"[AUDIO_TEMPLATE] No custom creative directives — AI will use story-driven defaults")

        # ── Parse durations ──
        raw_durations = inputs.get("allowed_durations", "5, 6, 8")
        allowed_durations = self._parse_durations(raw_durations)
        if not allowed_durations:
            return mexflow.result.error(
                "Invalid durations. Provide comma-separated numbers. Example: 5, 6, 8",
                details={"field": "allowed_durations", "received": raw_durations}
            )

        max_duration_mode = inputs.get("max_duration_mode", "auto")
        if max_duration_mode == "auto":
            max_duration = "AUTO"
        else:
            max_duration = int(inputs.get("max_duration_seconds", 120))

        # ── Validate inputs ──
        if input_mode == "story":
            if not story_text:
                return mexflow.result.error(
                    "Please provide story text when using Story Text mode.",
                    details={"field": "story_text"}
                )
        else:
            if not audio_file:
                return mexflow.result.error(
                    "Please provide an audio file when using Direct Audio mode.",
                    details={"field": "audio_file"}
                )

        # ── Setup progress (8 stages) ──
        mexflow.progress.setup(8)

        # ════════════════════════════════════════════════════════════
        # STAGE 1: Configuration Check
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Configuration Check", "Verifying plugin availability...")

        config_issues = []

        if input_mode == "story":
            audio_config = await mexflow.audio_generator.get_config()
            if not audio_config:
                config_issues.append("Audio Generator plugin not configured (required for Story mode)")

        subtitle_config = await mexflow.subtitle_generator.get_config()
        if not subtitle_config:
            config_issues.append("Subtitle Generator plugin not configured")

        if config_issues:
            issue_text = "\n• ".join(config_issues)
            return mexflow.result.error(
                f"Plugin configuration required:\n• {issue_text}\n\nPlease configure in Settings > Default Plugins.",
                details={"missing_plugins": config_issues}
            )

        mexflow.progress.complete_stage("All plugins verified and ready")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 2: Audio Preparation
        # ════════════════════════════════════════════════════════════
        audio_id = None
        audio_duration = 0

        if input_mode == "story":
            mexflow.progress.start_stage("Generating Audio", "Converting narrative text to speech...")

            text_chunks = self._split_text_into_chunks(story_text, max_audio_chars)

            if len(text_chunks) == 1:
                script_id = await mexflow.audio_script.save(
                    script_text=story_text,
                    language_code=language,
                    status="generated"
                )
                if not script_id:
                    return mexflow.result.error("Failed to save audio script")

                audio_result = await mexflow.audio_generator.generate(
                    audio_script_id=script_id,
                    speaking_rate=1.0
                )
                if not audio_result.get("success"):
                    error_msg = audio_result.get("error", "Unknown error")
                    warning_msg = audio_result.get("warning", "")
                    return mexflow.result.error(
                        f"Audio generation failed: {warning_msg or error_msg}",
                        details={"stage": "audio_generation", "error": error_msg}
                    )

                audio_id = audio_result.get("audio_id")
                audio_duration = audio_result.get("duration_seconds", 0)
            else:
                mexflow.progress.update(
                    stage="Generating Audio",
                    stage_index=2,
                    total_stages=8,
                    message=(
                        f"Script is {len(story_text)} chars — splitting into {len(text_chunks)} chunks "
                        f"(max {max_audio_chars} chars each)..."
                    ),
                    current_progress=5
                )

                full_script_id = await mexflow.audio_script.save(
                    script_text=story_text,
                    language_code=language,
                    status="generated"
                )
                if not full_script_id:
                    return mexflow.result.error("Failed to save audio script")

                chunk_audio_ids = []

                for idx, chunk_text in enumerate(text_chunks):
                    if mexflow.execution.is_cancelled():
                        return mexflow.result.cancelled()

                    chunk_progress = int((idx / len(text_chunks)) * 85) + 10
                    mexflow.progress.update(
                        stage="Generating Audio",
                        stage_index=2,
                        total_stages=8,
                        message=(
                            f"Generating audio chunk {idx + 1}/{len(text_chunks)} "
                            f"({len(chunk_text)} chars)..."
                        ),
                        current_progress=chunk_progress
                    )

                    chunk_script_id = await mexflow.audio_script.save(
                        script_text=chunk_text,
                        language_code=language,
                        status="generated",
                        script_data={
                            "chunk_index": idx + 1,
                            "total_chunks": len(text_chunks),
                            "is_chunk": True,
                            "label": f"Chunk #{idx + 1}"
                        }
                    )
                    if not chunk_script_id:
                        return mexflow.result.error(
                            f"Failed to save audio script for chunk {idx + 1}",
                            details={"stage": "audio_generation", "chunk": idx + 1}
                        )

                    chunk_result = await mexflow.audio_generator.generate(
                        audio_script_id=chunk_script_id,
                        speaking_rate=1.0
                    )

                    if not chunk_result.get("success"):
                        error_msg = chunk_result.get("error", "Unknown error")
                        warning_msg = chunk_result.get("warning", "")
                        return mexflow.result.error(
                            f"Audio generation failed on chunk {idx + 1}/{len(text_chunks)}: "
                            f"{warning_msg or error_msg}",
                            details={
                                "stage": "audio_generation",
                                "chunk": idx + 1,
                                "total_chunks": len(text_chunks),
                                "error": error_msg
                            }
                        )

                    chunk_audio_ids.append(chunk_result["audio_id"])

                mexflow.progress.update(
                    stage="Generating Audio",
                    stage_index=2,
                    total_stages=8,
                    message=f"Joining {len(chunk_audio_ids)} audio chunks into final audio...",
                    current_progress=95
                )

                join_result = await mexflow.audio_tools.join_audio(
                    audio_ids=chunk_audio_ids,
                    audio_script_id=full_script_id
                )

                if not join_result.get("success"):
                    return mexflow.result.error(
                        f"Failed to join audio chunks: {join_result.get('error', 'Unknown')}",
                        details={"stage": "audio_join", "chunk_count": len(chunk_audio_ids)}
                    )

                audio_id = join_result["audio_id"]
                audio_duration = join_result.get("duration_seconds", 0)

            mexflow.progress.complete_stage(
                f"Audio generated — {audio_duration:.1f}s total duration"
                + (f" ({len(text_chunks)} chunks joined)" if len(text_chunks) > 1 else "")
            )
        else:
            mexflow.progress.start_stage("Importing Audio", "Processing uploaded audio file...")

            if audio_file:
                if isinstance(audio_file, dict):
                    audio_id = audio_file.get("id") or audio_file.get("audio_id")
                    audio_duration = audio_file.get("duration_seconds", 0)
                elif isinstance(audio_file, str):
                    file_info = mexflow.file.get_file_info(audio_file)
                    if not file_info.get("exists"):
                        return mexflow.result.error(
                            f"Audio file not found: {file_info.get('name', audio_file)}",
                            details={"stage": "audio_import", "file": audio_file}
                        )
                    if file_info.get("type") not in ("audio", "video"):
                        return mexflow.result.error(
                            "Invalid file type. Please select an audio file.",
                            details={"stage": "audio_import", "type": file_info.get("type")}
                        )
                    import_result = await mexflow.file.import_audio(
                        file_input=audio_file, language=language
                    )
                    if not import_result.get("success"):
                        return mexflow.result.error(
                            f"Failed to import audio: {import_result.get('error', 'Unknown')}",
                            details={"stage": "audio_import"}
                        )
                    audio_id = import_result.get("audio_id")
                    audio_duration = import_result.get("duration_seconds", 0)

            if not audio_id:
                return mexflow.result.error("Could not process the uploaded audio file.")
            mexflow.progress.complete_stage(f"Audio imported — {audio_duration:.1f}s")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 3: Subtitle Generation
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Generating Subtitles", "Transcribing audio with word-level timing...")

        lang_code = language.split("-")[0] if "-" in language else language
        subtitle_result = await mexflow.subtitle_generator.generate(
            audio_id=audio_id, language=lang_code
        )
        if not subtitle_result.get("success"):
            error_msg = subtitle_result.get("error", "Unknown error")
            warning_msg = subtitle_result.get("warning", "")
            return mexflow.result.error(
                f"Subtitle generation failed: {warning_msg or error_msg}",
                details={"stage": "subtitle_generation"}
            )

        subtitle_data = subtitle_result.get("subtitle_data", [])
        word_count = subtitle_result.get("word_count", 0)
        if not subtitle_data or word_count == 0:
            return mexflow.result.error(
                "No words detected in audio. Please verify the audio file contains speech."
            )

        normalized_subtitle_data = []
        for item in subtitle_data:
            if isinstance(item, dict):
                normalized = dict(item)
                if 'word' not in normalized and 'text' in normalized:
                    normalized['word'] = normalized['text']
                elif 'word' not in normalized and 'text' not in normalized:
                    continue
                normalized_subtitle_data.append(normalized)

        full_narrative = " ".join(
            (w.get("word", "") or w.get("text", "")) for w in normalized_subtitle_data
        ).strip()

        if not full_narrative:
            return mexflow.result.error("Could not build transcript from subtitle data.")

        if audio_duration <= 0 and normalized_subtitle_data:
            last_word = normalized_subtitle_data[-1]
            audio_duration_from_subs = last_word.get("end", last_word.get("start", 0))
            if audio_duration_from_subs > 0:
                audio_duration = audio_duration_from_subs + 1.5

        mexflow.progress.complete_stage(f"Transcribed {word_count} words with precise timestamps")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 4: AI Narrative Analysis
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage(
            "Analyzing Narrative",
            "Director is analyzing story structure, characters, and emotional arc..."
        )

        resume_info = await mexflow.stage.check_resume()
        analysis_data = None
        characters_data = None

        if resume_info:
            await mexflow.stage.resume_from(resume_info['execution_id'])
            stage_name = resume_info.get('stage_name', '')
            if stage_name in ("narrative_analysis", "character_generation", "scene_generation"):
                analysis_data = await mexflow.stage.get("narrative_analysis")
            if stage_name in ("character_generation", "scene_generation"):
                characters_data = await mexflow.stage.get("character_generation")

        if not analysis_data:
            analysis_data = await self._analyze_narrative(
                full_narrative, allowed_durations, max_duration, visual_style,
                custom_instructions=custom_instructions
            )
            if not analysis_data:
                return mexflow.result.error(
                    "Failed to analyze narrative. The AI could not parse the story structure."
                )
            await mexflow.stage.save("narrative_analysis", analysis_data)
            char_count = len(analysis_data.get("characters", []))
            print(f"[AUDIO_TEMPLATE][STAGE4] Analysis complete: {char_count} characters extracted")
            print(f"[AUDIO_TEMPLATE][STAGE4] Characters: {[c.get('name','?') for c in analysis_data.get('characters',[])]}")
            mexflow.progress.complete_stage(
                f"Found {char_count} characters, {len(analysis_data.get('key_moments', []))} key moments"
            )
        else:
            char_count = len(analysis_data.get("characters", []))
            print(f"[AUDIO_TEMPLATE][STAGE4] Loaded from checkpoint: {char_count} characters")
            mexflow.progress.complete_stage("Narrative analysis loaded from checkpoint")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 5: Character Portrait Generation
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage(
            "Character Design",
            "Casting Director is crafting character reference portraits..."
        )

        if not characters_data:
            characters_data = await self._generate_character_prompts(
                analysis_data, bg_color, visual_style, portrait_mode,
                custom_instructions=custom_instructions
            )
            if not characters_data:
                return mexflow.result.error("Failed to generate character portraits.")
            await mexflow.stage.save("character_generation", characters_data)
            char_portraits = characters_data.get('characters', [])
            print(f"[AUDIO_TEMPLATE][STAGE5] Generated {len(char_portraits)} character portraits")
            for c in char_portraits:
                has_prompt = bool(c.get('image_prompt',''))
                print(f"  -> #{c.get('order',0)} {c.get('name','?')} | has image_prompt={has_prompt} | appearance={c.get('appearance_summary','')[:60]}")
            mexflow.progress.complete_stage(
                f"Designed {len(char_portraits)} character portraits with order numbers"
            )
        else:
            char_portraits = characters_data.get('characters', [])
            print(f"[AUDIO_TEMPLATE][STAGE5] Loaded from checkpoint: {len(char_portraits)} characters")
            mexflow.progress.complete_stage("Character portraits loaded from checkpoint")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ── Calculate required scene count ──
        min_allowed = min(allowed_durations)
        avg_allowed = sum(allowed_durations) / len(allowed_durations)
        if audio_duration > 0:
            raw_count = audio_duration / avg_allowed
            required_scene_count = max(1, round(raw_count))
            if required_scene_count * min_allowed < audio_duration:
                required_scene_count = math.ceil(audio_duration / min_allowed)
            required_scene_count = max(required_scene_count, 1)
        else:
            estimated_duration = len(normalized_subtitle_data) / 4.0
            required_scene_count = max(1, math.ceil(estimated_duration / avg_allowed))

        # ════════════════════════════════════════════════════════════
        # STAGE 6: Scene Generation (scene_prompt)
        # ════════════════════════════════════════════════════════════
        style_desc = self.STYLE_PROMPTS.get(visual_style, self.STYLE_PROMPTS["cinematic"])

        mexflow.progress.start_stage(
            "Generating Scenes",
            f"Director is creating {required_scene_count} scenes with image & video prompts..."
        )

        scenes = await self._generate_scene_prompts(
            subtitle_data=normalized_subtitle_data,
            full_narrative=full_narrative,
            audio_duration=audio_duration,
            required_scene_count=required_scene_count,
            allowed_durations=allowed_durations,
            characters_data=characters_data,
            analysis_data=analysis_data,
            style=style_desc,
            visual_style=visual_style,
            add_camera=add_camera,
            include_emotions=include_emotions,
            aspect_ratio=aspect_ratio,
            color_grading=color_grading,
            narrative_continuity=narrative_continuity,
            enforce_variety=enforce_variety,
            custom_instructions=custom_instructions
        )

        if not scenes:
            return mexflow.result.error("Failed to generate scene prompts.")

        mexflow.progress.complete_stage(f"Generated {len(scenes)} scenes with image & video prompts")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 7: Save Characters + Scenes to Database
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Saving to Project", "Writing characters and scenes to database...")

        await self._save_to_project(characters_data, scenes, bg_color, visual_style, aspect_ratio)

        mexflow.progress.complete_stage(f"Saved {len(characters_data.get('characters', []))} characters + {len(scenes)} scenes")

        if mexflow.execution.is_cancelled():
            return mexflow.result.cancelled()

        # ════════════════════════════════════════════════════════════
        # STAGE 8: Finalize
        # ════════════════════════════════════════════════════════════
        mexflow.progress.start_stage("Finalizing", "Compiling production report...")

        total_duration = sum(s.get("duration", 0) for s in scenes)
        duration_dist = {}
        for s in scenes:
            d = s.get("duration", 0)
            duration_dist[d] = duration_dist.get(d, 0) + 1

        await mexflow.stage.complete()

        mexflow.progress.complete_stage(
            f"Production complete! {len(scenes)} scenes, "
            f"{len(characters_data.get('characters', []))} characters, {total_duration}s total"
        )

        return mexflow.result.success(
            scenes,
            message=f"Successfully created {len(scenes)} scenes with {len(characters_data.get('characters', []))} characters!",
            metadata={
                "scene_count": len(scenes),
                "character_count": len(characters_data.get("characters", [])),
                "audio_duration": audio_duration,
                "total_duration": total_duration,
                "word_count": word_count,
                "input_mode": input_mode,
                "visual_style": visual_style,
                "allowed_durations": allowed_durations,
                "duration_distribution": duration_dist,
                "aspect_ratio": aspect_ratio,
                "audio_id": audio_id,
                "custom_instructions_applied": bool(custom_instructions),
                "variety_enforced": enforce_variety
            }
        )

    # ══════════════════════════════════════════════════════════════════
    # NARRATIVE ANALYSIS — Extract characters, arc, key moments
    # ══════════════════════════════════════════════════════════════════

    async def _analyze_narrative(
        self, full_narrative: str, allowed_durations: List[int],
        max_duration, visual_style: str,
        custom_instructions: str = ""
    ) -> Optional[Dict[str, Any]]:
        """Analyze narration transcript to extract characters, narrative arc, and key moments.

        v4.1: custom_instructions injected at TOP of prompt with ABSOLUTE OVERRIDE priority.
        v4.1: Flexible key lookup — accepts 'characters' under any of several key names.
        """

        max_dur_str = f"{max_duration} seconds (hard limit)" if max_duration != "AUTO" else (
            "AUTO — determine optimal total duration based on narrative complexity"
        )

        # Build the user directive block (empty string if no instructions)
        directive_block = self._build_user_directive_block(custom_instructions)

        prompt = f"""{directive_block}Analyze this narration transcript for a professional cinematic scene breakdown. Your analysis drives an AI image-to-video production pipeline.

NARRATION:
\"\"\"
{full_narrative[:5000]}
\"\"\"

ALLOWED SCENE DURATIONS: {allowed_durations} seconds (each scene must be exactly one of these)
MAXIMUM TOTAL DURATION: {max_dur_str}
VISUAL STYLE: {visual_style}

Perform deep cinematic analysis and return this JSON structure:

{{
    "story_summary": "3-4 sentence comprehensive summary capturing core conflict, emotional journey, and resolution",
    "genre": "specific primary genre (e.g. 'dark fantasy adventure' not just 'fantasy')",
    "mood": "overall emotional tone with progression (e.g. 'begins hopeful, descends into tension, resolves with bittersweet triumph')",
    "setting": "detailed primary setting — geography, architecture, atmosphere, sensory details (60-100 words). IF USER DIRECTIVES SPECIFY A REGION/ERA, USE THAT.",
    "time_period": "time period with visual context (e.g. 'late medieval Europe, circa 1400s — stone castles, muddy roads, candlelit interiors'). IF USER DIRECTIVES SPECIFY AN ERA, USE THAT.",
    "narrative_arc": {{
        "act_1_setup": "detailed setup — who, where, what's at stake (40-60 words)",
        "act_2_confrontation": "detailed rising action — conflicts, obstacles, turning points (40-60 words)",
        "act_3_resolution": "detailed resolution — climax, aftermath, final image (40-60 words)"
    }},
    "characters": [
        {{
            "name": "Character Unique Name (MUST be unique — for unnamed characters use descriptive names like 'The Scarred Elder Monk', 'Lantern-Bearing Street Girl')",
            "role": "protagonist/antagonist/supporting/minor",
            "description": "detailed role description — motivations, arc, relationships (30-50 words)",
            "age_estimate": "specific estimated age (e.g. 'mid-30s' not 'adult')",
            "appearance_summary": "CRITICAL for AI image generation: exact hair (color, length, texture, style), face shape and features, skin tone, build/height/posture, clothing head-to-toe with fabric/color/condition, distinctive marks/scars/tattoos, accessories, weapons. Must be 60-100 words and specific enough to regenerate this character identically across dozens of images. APPLY USER DIRECTIVES to ethnicity, wardrobe, culture, era.",
            "significance": "why this character matters to the story"
        }}
    ],
    "key_moments": [
        {{
            "moment": "vivid description of the key visual moment (30-40 words)",
            "emotional_beat": "specific emotion (e.g. 'dawning realization of betrayal' not just 'surprise')",
            "characters_involved": ["Character Name 1"],
            "suggested_duration": 5,
            "act": 1
        }}
    ],
    "total_scenes_recommended": 8,
    "total_duration_recommended": 50,
    "color_arc": "detailed color progression per act (e.g. 'Act 1: warm ambers → Act 2: desaturated teals → Act 3: deep crimsons returning to gold')",
    "visual_motifs": ["specific recurring visual elements with symbolic meaning"],
    "lighting_arc": "how lighting evolves across the narrative"
}}

Rules:
- suggested_duration for each moment MUST be one of {allowed_durations}
- Sum of all suggested_durations must NOT exceed {max_dur_str}
- Give ALL characters UNIQUE names — never duplicate names
- For unnamed/generic characters, create vivid descriptive unique names
- appearance_summary for every character MUST be 60-100 words with SPECIFIC visual details
- key_moments should cover the full narrative arc
- Extract EVERY character mentioned or implied in the narration
- ALL character ethnicities, clothing styles, and cultural contexts MUST satisfy the USER CREATIVE DIRECTIVES above (if any). If no directives given, infer naturally from the story."""

        max_retries = 5
        for attempt in range(1, max_retries + 1):
            try:
                response = await self._ai_generate_with_retry(
                    mexflow, prompt, max_tokens=10000, label="ANALYZE", max_retries=5
                )
                if not response:
                    print(f"[AUDIO_TEMPLATE][ANALYZE] Attempt {attempt}: AI returned no usable response")
                    continue
                print(f"[AUDIO_TEMPLATE][ANALYZE] Raw AI response ({len(response)} chars): {repr(response[:300])}")
                data = self._clean_and_parse_json(response, mexflow.ai.parse_json)

                if isinstance(data, dict):
                    print(f"[AUDIO_TEMPLATE][ANALYZE] Parsed keys: {list(data.keys())}")

                    # ── v4.1: Flexible character key lookup ──
                    # AI might return characters under any of these key names
                    char_keys = [
                        "characters", "cast", "character_list", "character_designs",
                        "dramatis_personae", "people", "persons", "actors"
                    ]
                    characters = self._extract_list_from_parsed(data, char_keys)
                    if characters is None:
                        # Still embedded somewhere — check top-level directly
                        characters = data.get("characters") if isinstance(data.get("characters"), list) else None

                    if characters is not None and len(characters) > 0:
                        # Normalize the key to 'characters' for downstream code
                        data["characters"] = characters
                        raw_chars = characters
                        print(f"[AUDIO_TEMPLATE][ANALYZE] Extracted {len(raw_chars)} characters: {[c.get('name','?') for c in raw_chars]}")

                        # Ensure every character has a unique name and order number
                        seen_names = set()
                        for i, char in enumerate(data["characters"]):
                            name = char.get("name", f"Character {i+1}")
                            if name in seen_names:
                                name = f"{name} ({i+1})"
                            seen_names.add(name)
                            char["name"] = name
                            char["order"] = i + 1

                        print(f"[AUDIO_TEMPLATE][ANALYZE] Final characters: {[(c['name'], c['order']) for c in data['characters']]}")
                        return data

                print(f"[AUDIO_TEMPLATE][ANALYZE] Parse attempt {attempt} FAILED: no characters found in parsed data")
            except Exception as e:
                print(f"[AUDIO_TEMPLATE][ANALYZE] Attempt {attempt} EXCEPTION: {e}")

        print(f"[AUDIO_TEMPLATE][ANALYZE] FAILED after {max_retries} attempts")
        mexflow.progress.error("Narrative Analysis", f"Analysis failed after {max_retries} attempts — AI returned unparseable data")
        return None

    # ══════════════════════════════════════════════════════════════════
    # CHARACTER PORTRAIT PROMPT GENERATION
    # ══════════════════════════════════════════════════════════════════

    async def _generate_character_prompts(
        self, analysis: Dict[str, Any], bg_color: str,
        visual_style: str, portrait_mode: str = "single",
        custom_instructions: str = ""
    ) -> Optional[Dict[str, Any]]:
        """Generate detailed full-body character portrait image prompts.

        v4.1: custom_instructions injected at TOP of prompt as absolute rules.
        v4.1: Flexible key lookup.
        """

        characters_from_analysis = analysis.get("characters", [])
        char_list_str = "\n".join([
            f"- Character #{c.get('order', i+1)}: {c.get('name', 'Unknown')} "
            f"({c.get('role', '')}) — {c.get('description', '')}, "
            f"Age: {c.get('age_estimate', 'unknown')}, "
            f"Appearance: {c.get('appearance_summary', 'not specified')}"
            for i, c in enumerate(characters_from_analysis)
        ])

        genre = analysis.get("genre", "drama").lower()

        vs_render = self.VISUAL_STYLE_RENDERING.get(
            visual_style, self.VISUAL_STYLE_RENDERING.get("cinematic")
        )
        vs_quality = vs_render["quality"]
        vs_lighting = vs_render["lighting"]
        vs_render_style = vs_render["render_style"]
        vs_char_instruction = vs_render["char_instruction"]
        style_desc = self.STYLE_PROMPTS.get(visual_style, self.STYLE_PROMPTS["cinematic"])

        if portrait_mode == "4panel":
            format_instruction = (
                f"PORTRAIT FORMAT: 4-PANEL CHARACTER REFERENCE SHEET\n\n"
                f"Each image_prompt MUST follow: \"4-panel character reference sheet of "
                f"[FULL CHARACTER DESCRIPTION in {vs_render_style}]. "
                f"Top-left: full-body front view. Top-right: left side profile. "
                f"Bottom-left: right side profile. Bottom-right: back view. "
                f"[ALL physical details]. {vs_quality}, {vs_lighting}, "
                f"rim light edge separation, every detail visible. "
                f"Solid flat {bg_color} chroma-key background. No gradients.\""
            )
        else:
            format_instruction = (
                f"PORTRAIT FORMAT: SINGLE FULL-BODY FRONT-FACING PORTRAIT\n\n"
                f"Each image_prompt MUST follow: \"Full-body front-facing portrait of "
                f"[FULL CHARACTER DESCRIPTION in {vs_render_style}]. "
                f"Centered composition, standing upright, [pose]. "
                f"[ALL physical details]. {vs_quality}, {vs_lighting}, "
                f"rim light for clean edge separation. "
                f"Solid flat {bg_color} chroma-key background. No gradients, no shadows.\""
            )

        directive_block = self._build_user_directive_block(custom_instructions)

        prompt = f"""{directive_block}Create full-body character portrait image prompts for these characters.

═══════════════════════════════════════════════════════
⚠️ ASPECT RATIO — STRICT 16:9 (NON-NEGOTIABLE):
═══════════════════════════════════════════════════════
All character reference portraits MUST be designed for 16:9 LANDSCAPE orientation (horizontal widescreen). Every image_prompt MUST explicitly contain the phrase "16:9 aspect ratio, landscape orientation" near the beginning. Frame characters centered with enough vertical margin that head-to-toe is fully visible with clear space above the head and below the feet, so these portraits can be reliably used as reference images for downstream scene composition regardless of the final scene aspect ratio.

═══════════════════════════════════════════════════════
⚠️ MANDATORY VISUAL STYLE — APPLY TO EVERY CHARACTER:
═══════════════════════════════════════════════════════
Visual Style: {visual_style}
Render Style: {vs_render_style}
Style Description: {style_desc}
Character Instruction: {vs_char_instruction}

EVERY image_prompt MUST be rendered in this visual style. The style tag "{vs_render_style}" MUST appear in EVERY image_prompt. Do NOT default to photorealistic unless the visual style IS photorealistic/cinematic/realistic.

STORY CONTEXT:
{analysis.get('story_summary', '')}
Genre: {analysis.get('genre', '')}
Setting: {analysis.get('setting', '')}
Time Period: {analysis.get('time_period', '')}

CHARACTERS TO DESIGN (with their persistent ORDER NUMBERS):
{char_list_str}

BACKGROUND COLOR: {bg_color} (solid flat chroma-key, NO gradients)

{format_instruction}

Return this JSON:

{{
    "characters": [
        {{
            "name": "Character Name (MUST match exactly the name above)",
            "order": 1,
            "role": "protagonist/antagonist/supporting/minor",
            "age": "estimated age",
            "build": "body type and stature",
            "appearance_summary": "60-100 word distinctive visual summary for cross-scene reference — include: hair (color/length/texture/style), face shape, eye color, skin tone, build, signature clothing, distinctive marks. Must be unique enough to identify this character in any scene. APPLY USER DIRECTIVES (ethnicity, wardrobe, culture) consistently.",
            "image_prompt": "[FULL PORTRAIT PROMPT following the format above. MUST be 100-180 words. Structure: {vs_render_style} style tag + full-body head-to-toe description (face features, eye details, skin texture, hair, build, clothing layer by layer, footwear, accessories, weapons, scars/marks) + pose description + quality tags ({vs_quality}) + solid {bg_color} background. APPLY USER DIRECTIVES.]"
        }}
    ]
}}

CRITICAL REQUIREMENTS:
- 🎯 USER CREATIVE DIRECTIVES at the top of this prompt are ABSOLUTE. Every character's ethnicity, wardrobe, skin tone, cultural details, and era-appropriateness MUST satisfy them. Do NOT override user rules based on what seems more "typical" for the story.
- VISUAL STYLE "{vs_render_style}" MUST appear in EVERY image_prompt — this is the #1 priority
- FULL-BODY always — head to toe visible, NEVER head-and-shoulders only
- ALWAYS end with quality tags matching the visual style and background specification
- Describe EVERYTHING with precision: face shape, eye color/shape, nose, lips, jaw, skin tone/texture, hair, body proportions, each clothing layer (fabric, color, condition), accessories, weapons, scars/marks/tattoos, stance
- image_prompt MUST be 100-180 words — be exhaustively specific for consistency
- The ORDER number MUST match the character's order from the analysis
- The NAME must be EXACTLY the same unique name from analysis
- appearance_summary is used in ALL scene prompts — make it distinctively specific"""

        char_keys = [
            "characters", "cast", "character_list", "character_designs",
            "portraits", "character_portraits", "people"
        ]

        max_retries = 5
        for attempt in range(1, max_retries + 1):
            try:
                print(f"[AUDIO_TEMPLATE][CHARS] Attempt {attempt}/{max_retries}")
                response = await self._ai_generate_with_retry(
                    mexflow, prompt, max_tokens=12000, label="CHARS", max_retries=5
                )
                if not response:
                    print(f"[AUDIO_TEMPLATE][CHARS] Attempt {attempt}: AI returned no usable response")
                    continue

                print(f"[AUDIO_TEMPLATE][CHARS] Raw AI response ({len(response)} chars): {repr(response[:300])}")
                data = self._clean_and_parse_json(response, mexflow.ai.parse_json)

                # ── v4.1: Flexible character extraction ──
                characters = self._extract_list_from_parsed(data, char_keys)

                if characters is not None and len(characters) > 0:
                    print(f"[AUDIO_TEMPLATE][CHARS] Extracted {len(characters)} characters")
                    for c in characters:
                        print(f"  -> {c.get('name','?')} | image_prompt len: {len(c.get('image_prompt',''))}")

                    # Ensure order numbers are preserved
                    for i, char in enumerate(characters):
                        if "order" not in char:
                            char["order"] = i + 1

                    # ── INJECT VISUAL STYLE + 16:9 ASPECT DIRECTIVE into every character image_prompt ──
                    char_style_tag = self._build_visual_style_tag(visual_style)
                    # v4.3: Character portraits are ALWAYS 16:9 regardless of
                    # the project's scene aspect ratio — this is authoritative.
                    char_aspect_directive = self._build_aspect_directive(
                        aspect_ratio="16:9", is_character_portrait=True
                    )
                    for char in characters:
                        if char.get("image_prompt"):
                            # Strip any aspect directive the AI may have added
                            body = self._strip_leading_aspect_directive(char["image_prompt"])
                            # Prepend authoritative 16:9 directive, then inject style
                            combined = char_aspect_directive + body
                            char["image_prompt"] = self._inject_visual_style(
                                combined, char_style_tag
                            )

                    print(f"[AUDIO_TEMPLATE][CHARS] Injected visual style '{visual_style}' + 16:9 aspect directive into all character image_prompts")
                    print(f"[AUDIO_TEMPLATE][CHARS] Final characters: {[(c['name'], c.get('order',0)) for c in characters]}")
                    return {"characters": characters}

                print(f"[AUDIO_TEMPLATE][CHARS] Attempt {attempt} FAILED: unexpected data format or empty list")
            except Exception as e:
                print(f"[AUDIO_TEMPLATE][CHARS] Attempt {attempt} EXCEPTION: {e}")

        print(f"[AUDIO_TEMPLATE][CHARS] FAILED after {max_retries} attempts")
        mexflow.progress.error("Character Design", f"Character generation failed after {max_retries} attempts")
        return None

    # ══════════════════════════════════════════════════════════════════
    # SCENE GENERATION — scene_prompt + voiceover
    # v4.1: Voiceover-to-visual binding, variety enforcement, user directives
    # ══════════════════════════════════════════════════════════════════

    async def _generate_scene_prompts(
        self,
        subtitle_data: List[Dict],
        full_narrative: str,
        audio_duration: float,
        required_scene_count: int,
        allowed_durations: List[int],
        characters_data: Dict[str, Any],
        analysis_data: Dict[str, Any],
        style: str,
        visual_style: str,
        add_camera: bool,
        include_emotions: bool,
        aspect_ratio: str,
        color_grading: str,
        narrative_continuity: bool,
        enforce_variety: bool = True,
        custom_instructions: str = ""
    ) -> List[Dict]:
        """
        Generate scenes with perfect audio-video synchronization.

        v4.1 upgrades:
         - VOICEOVER-TO-VISUAL BINDING: Each image_prompt depicts the EXACT
           subject/action/location narrated in that scene's voiceover. No more
           abstract "the story's mood" — we show what the narrator is literally
           describing, frame by frame.
         - VARIETY ENFORCEMENT: Shot size, camera movement, angle, and descriptor
           rotation to avoid repetitive outputs across scenes.
         - USER DIRECTIVES: custom_instructions are injected as ABSOLUTE OVERRIDE
           at the top of the prompt, controlling ethnicity/era/region/wardrobe.
         - ROBUST PARSING: Flexible key lookup means the AI can return "scenes",
           "scene_list", "storyboard", "shots" etc. — no more false retries.

        CRITICAL ARCHITECTURE (unchanged from v4.0):
        ─────────────────────────────────────────────
        The voiceover text for each scene is split HERE using word-level
        timestamps from the subtitle engine — NOT by the AI. This guarantees
        that each scene's voiceover contains EXACTLY the words spoken during
        that scene's video duration.
        """
        import random

        # ══════════════════════════════════════════════════════════════
        # STEP 1: Split subtitle data into scene segments by TIMESTAMPS
        # ══════════════════════════════════════════════════════════════
        segments = self._split_subtitle_into_scenes(
            subtitle_data=subtitle_data,
            allowed_durations=allowed_durations,
            audio_duration=audio_duration,
            required_scene_count=required_scene_count
        )

        if not segments:
            return self._generate_fallback_scenes(
                subtitle_data, full_narrative, audio_duration,
                required_scene_count, allowed_durations,
                characters_data.get("characters", []),
                style, visual_style, aspect_ratio,
                custom_instructions=custom_instructions
            )

        actual_scene_count = len(segments)

        # ══════════════════════════════════════════════════════════════
        # STEP 2: Build context blocks for AI prompt
        # ══════════════════════════════════════════════════════════════
        chars = characters_data.get("characters", [])
        char_ref_lines = []
        for c in chars:
            order = c.get("order", 0)
            name = c.get("name", "Unknown")
            portrait = c.get("image_prompt", c.get("appearance_summary", c.get("build", "")))
            char_ref_lines.append(
                f"  Character #{order} — {name} ({c.get('role', '')}):\n    {portrait}"
            )
        char_ref_block = "\n".join(char_ref_lines)
        if chars:
            exact_names = [c.get("name", "Unknown") for c in chars]
            char_ref_block += (
                f"\n\n⚠️ EXACT CHARACTER NAMES FOR characters_present (copy-paste ONLY these):\n"
                + "\n".join([f'  - "{name}"' for name in exact_names])
            )

        analysis_block = ""
        if analysis_data:
            arc = analysis_data.get("narrative_arc", {})
            analysis_block = (
                f"Genre: {analysis_data.get('genre', '')}\n"
                f"Mood: {analysis_data.get('mood', '')}\n"
                f"Setting: {analysis_data.get('setting', '')}\n"
                f"Act 1: {arc.get('act_1_setup', '')}\n"
                f"Act 2: {arc.get('act_2_confrontation', '')}\n"
                f"Act 3: {arc.get('act_3_resolution', '')}\n"
                f"Color Arc: {analysis_data.get('color_arc', '')}"
            )

        color_grading_val = color_grading if color_grading != "auto" else "match visual style and emotional arc"

        # ── v4.1: Pre-split voiceover block — AI never re-splits these ──
        voiceover_block_lines = []
        for i, seg in enumerate(segments):
            voiceover_block_lines.append(
                f"  SCENE {i+1} (duration: {seg['duration']}s, audio: {seg['start_time']:.1f}s–{seg['end_time']:.1f}s):\n"
                f"    \"{seg['voiceover']}\""
            )
        voiceover_block = "\n".join(voiceover_block_lines)

        # ══════════════════════════════════════════════════════════════
        # STEP 3: Build directive block, variety block, voiceover-binding block
        # ══════════════════════════════════════════════════════════════
        directive_block = self._build_user_directive_block(custom_instructions)

        # ── v4.1 Fix #2: VOICEOVER-TO-VISUAL BINDING ──
        voiceover_binding_block = """
═══════════════════════════════════════════════════════════════════════════════
🎯 VOICEOVER-TO-VISUAL BINDING — THE #1 RULE FOR THIS ENGINE
═══════════════════════════════════════════════════════════════════════════════

Each scene's image_prompt MUST depict the EXACT subject, action, and location
that the voiceover is narrating AT THAT MOMENT. The image is NOT an abstract
illustration of the overall story theme — it is a literal frame of what the
narrator is describing RIGHT NOW in that scene's voiceover text.

HOW TO DO THIS (applies to EVERY scene independently):

  STEP A — Read the voiceover for that scene carefully.
  STEP B — Extract WHO/WHAT/WHERE from the voiceover:
            WHO   = the person, character, or subject being described
            WHAT  = the specific action, event, or state being narrated
            WHERE = the specific location, setting, or environmental cue
  STEP C — Build the image_prompt as a literal depiction of WHO doing WHAT in WHERE.
  STEP D — If the voiceover mentions a specific object, prop, color, weather,
            time of day, or emotion — that MUST appear visibly in the image_prompt.
  STEP E — If the voiceover is purely internal/reflective (e.g. "she remembered
            the old days"), depict the character in a pose/environment that
            triggers or matches that memory — NOT an unrelated scene.

✗ WRONG (generic, disconnected from voiceover):
    Voiceover: "He walked into the crumbling stone temple, lantern trembling in his hand."
    image_prompt: "A mysterious hero stands dramatically in an epic fantasy landscape..."

✓ RIGHT (literal depiction of the narrated moment):
    Voiceover: "He walked into the crumbling stone temple, lantern trembling in his hand."
    image_prompt: "Character #1 (Name) mid-step, crossing the threshold of a CRUMBLING
                   STONE TEMPLE entrance — weathered moss-streaked pillars, cracked lintel
                   overhead, debris on the floor. In his right hand a brass LANTERN casts
                   a trembling amber glow on his face and the cold stone walls..."

The scene_prompt MUST then describe MOTION that matches the voiceover's action
cadence — if the voiceover says "walked", the camera and character motion must
convey walking; if it says "trembling", show the tremor in the lantern's glow.

═══════════════════════════════════════════════════════════════════════════════
"""

        # ── v4.1 Fix #3: VISUAL VARIETY ENFORCEMENT ──
        if enforce_variety:
            variety_block = """
═══════════════════════════════════════════════════════════════════════════════
🎨 VISUAL VARIETY REQUIREMENTS — NO TWO SCENES MAY LOOK ALIKE
═══════════════════════════════════════════════════════════════════════════════

Repetitive output is the #1 failure mode of AI directors. You MUST deliberately
vary these elements across consecutive scenes:

 1. SHOT SIZE ROTATION — Rotate through shot sizes; NEVER use the same shot
    size in 3+ consecutive scenes. Available: EWS (extreme wide), WS (wide),
    MWS (medium wide), FS (full shot), MS (medium), MCU (medium close-up),
    CU (close-up), ECU (extreme close-up). A good sequence alternates wide
    establishing → medium action → close emotional → wide reset.

 2. CAMERA MOVEMENT VARIETY — Rotate through movement types; do NOT use the
    same movement (e.g. "slow push-in") more than twice in the whole sequence.
    Types: static locked, slow dolly in, slow dolly out, lateral tracking,
    crane up, crane down, Steadicam follow, handheld verité, orbit, whip pan,
    rack focus, Dutch-angle drift, contra-zoom.

 3. ANGLE VARIETY — Mix high angle, low angle, eye-level, bird's-eye, worm's-eye,
    over-the-shoulder, profile. Do not frame every scene at eye-level.

 4. LENS VARIETY — Vary focal lengths: wide (24mm, 28mm) for environments,
    standard (35mm, 50mm) for narrative, long (85mm, 135mm) for intimacy.

 5. BANNED REPETITION PHRASES — The following phrases are banned unless
    used ONCE across the entire sequence:
      ✗ "dramatically lit"     ✗ "atmospheric haze"    ✗ "cinematic composition"
      ✗ "epic landscape"       ✗ "mysterious figure"   ✗ "swirling mist"
      ✗ "dramatic shadows"     ✗ "ethereal glow"       ✗ "breathtaking vista"
    Write FRESH, specific descriptions each time. Describe the SPECIFIC light
    source (e.g. "oil lamp at head height"), the SPECIFIC weather (e.g. "fine
    drizzle catching the lamplight"), the SPECIFIC object (e.g. "split oak beam
    overhead"). Specificity beats drama.

 6. COMPOSITION VARIETY — Vary your compositional anchors:
    rule-of-thirds, centered symmetry, leading lines, foreground framing,
    negative-space isolation, layered depth, triangle composition.

 7. COLOR PALETTE VARIETY — Not every scene is teal/orange. Vary: warm golden,
    cool blue-green, monochromatic sepia, high-key pastel, low-key chiaroscuro,
    complementary split (red/cyan, orange/blue), analogous (red/orange/yellow),
    desaturated earth, jewel-tone.

═══════════════════════════════════════════════════════════════════════════════
"""
        else:
            variety_block = ""

        # ══════════════════════════════════════════════════════════════
        # STEP 4: Build AI prompt
        # ══════════════════════════════════════════════════════════════
        vs_render = self.VISUAL_STYLE_RENDERING.get(
            visual_style, self.VISUAL_STYLE_RENDERING.get("cinematic")
        )
        vs_render_style = vs_render["render_style"]
        vs_quality = vs_render["quality"]
        vs_char_instruction = vs_render["char_instruction"]

        ai_prompt = mexflow.ai.create_prompt(
            '''{directive_block}You are DIRECTOR-X — an elite filmmaker directing a professional AI image-to-video pipeline.

═══════════════════════════════════════════════════════
⚠️ MANDATORY VISUAL STYLE — APPLY TO EVERY SCENE:
═══════════════════════════════════════════════════════
Visual Style: {visual_style}
Render Style: {vs_render_style}
Style Description: {style}
Quality Tags: {vs_quality}
Character Rendering: {vs_char_instruction}

EVERY image_prompt MUST be rendered in "{vs_render_style}" style. This style tag MUST appear at the START of EVERY image_prompt. Do NOT default to "photorealistic" or "cinematic" unless the selected visual style IS photorealistic/cinematic/realistic. The visual style controls the ENTIRE look — characters, environments, lighting, and atmosphere must ALL match this style.
{voiceover_binding_block}{variety_block}
═══════════════════════════════════════════════════════
CRITICAL: VOICEOVER IS ALREADY SPLIT — DO NOT CHANGE IT
═══════════════════════════════════════════════════════

The voiceover text for each scene has been precisely split using word-level audio timestamps. Each scene's voiceover contains EXACTLY the words spoken during that scene's video duration. You MUST NOT modify, add, remove, reorder, or redistribute ANY voiceover text. Copy each scene's voiceover VERBATIM into your output.

═══════════════════════════════════════════════════════
🔇 AUDIO RESTRICTION — ABSOLUTE, APPLIES TO SCENE_PROMPT ONLY
═══════════════════════════════════════════════════════

This template generates its OWN audio track via text-to-speech from the pre-split voiceover text. The image-to-video renderer must produce the VIDEO ONLY — it must NOT generate any additional voice-over, dialogue, spoken lines, narration, or audible speech, because those would collide with the TTS track and ruin the final video.

Therefore the scene_prompt field (motion direction for the image-to-video renderer) MUST NEVER contain:
  ✗ Quoted dialogue ("Hello", "stay back!", etc.)
  ✗ "voiceover: ..." / "narration: ..." / "dialogue: ..." / "V.O.: ..." labels
  ✗ Instructions to sync lip movement to audio or to a speech track
  ✗ "The character says/speaks/whispers/shouts 'words'" constructions
  ✗ Any instruction that implies an audio voice/speech track must be generated

The scene_prompt MAY contain:
  ✓ Silent visual description of mouth movement when the moment calls for it (e.g. "lips part briefly in a silent breath" — but never quoted words)
  ✓ Background music MOOD descriptors for reference (e.g. "pacing supports a swelling orchestral undertone" — conceptual, not an audio directive)
  ✓ Ambient sound-effect atmosphere cues as visual context (e.g. "rain pattering on copper rooftops, distant thunder rumbling" — these are VISUAL/atmospheric cues that the image generator can depict, not audio commands)
  ✓ Everything visual: camera motion, character physical action, environmental dynamics, lighting transitions, pacing

REMINDER: The VOICEOVER field is the narration — this is already set by the pre-split subtitle timing and will be rendered as TTS audio. The scene_prompt is the VIDEO motion direction, which must be silent-visual-only.

═══════════════════════════════════════════════════════
YOUR TWO TASKS — VISUAL PROMPT GENERATION:
═══════════════════════════════════════════════════════

TASK 1 — IMAGE PROMPT (Ultra-Dense Key Frame — 250-400 words per scene):

Write an extraordinarily detailed description of the perfect frozen KEY FRAME moment in "{vs_render_style}" style. The frame must LITERALLY depict what the voiceover is narrating for that scene (see VOICEOVER-TO-VISUAL BINDING above). The image_prompt is THE MOST IMPORTANT prompt — it is what the image-to-video pipeline uses as its visual foundation. Every bit of specificity you add here (exact lens mm, exact Kelvin temperatures, exact fabric materials, exact color palettes, exact time of day) pays off as consistency and continuity in the final video. START every image_prompt with the aspect ratio lock, then the style tag "{vs_render_style}".

MANDATORY ELEMENTS IN EVERY image_prompt (all 11 are required):

   A) ASPECT RATIO LOCK: Begin the image_prompt with "{aspect_ratio} aspect ratio, [orientation] orientation" where [orientation] is "landscape" for 16:9/4:3/21:9, "portrait" for 9:16/3:4/2:3/4:5, "square" for 1:1. This is the SINGLE MOST IMPORTANT framing constraint — every composition decision flows from it. Reference character portraits are at 16:9, but THIS output is {aspect_ratio}; do NOT let the reference images' ratio leak into the framing.

   B) VISUAL STYLE: Immediately after the aspect lock, include "{vs_render_style}" — this sets the entire rendering pipeline. Style choice overrides genre assumptions.

   C) COMPOSITION & LENS (be SPECIFIC, not vague):
      • Shot size: EWS / WS / MWS / FS / MS / MCU / CU / ECU (pick exactly one)
      • Camera angle: low / high / eye-level / bird's-eye / worm's-eye / Dutch (pick one; vary across scenes)
      • Focal length: give an EXACT mm value — 18mm / 24mm / 28mm / 35mm / 50mm / 85mm / 135mm (not "wide lens")
      • Aperture: give an EXACT f-stop — f/1.4 / f/1.8 / f/2.8 / f/4 / f/5.6 / f/8 / f/11
      • Depth of field: shallow / medium / deep — specify what's in focus and what's bokeh
      • Framing principle: rule-of-thirds / centered symmetry / leading lines / foreground framing / negative-space isolation / layered depth / triangle composition (pick one)
      • Subject placement: exactly where each subject sits in the frame (e.g. "reference character 1 occupies the left third, looking toward frame-right where reference character 2 stands in the midground")

   D) SUBJECT DETAIL (WHO/WHAT from the voiceover — be exhaustively specific):
      • Character positions: foreground / midground / background placement per character
      • Exact action poses at the narrated moment: body language, hands, feet, weight distribution
      • Micro-expressions: not "smiling" but "the corner of the mouth lifts slightly, eyes crinkle at the outer edge, a flicker of hesitation in the brow"
      • Wardrobe: exact fabric (linen / wool / silk / leather / denim / cotton weave), exact color, exact condition (pristine / worn / frayed / bloodstained / rain-soaked), layer-by-layer description
      • Identify each character per the REFERENCE CHARACTER MAPPING (element K below): "reference character 1 (Name) does X, reference character 2 (Name) does Y"
      • Props and objects held/worn: specific material, weight, condition

   E) ENVIRONMENT LAYERS (FG/MG/BG with specific distances AND materials):
      • FOREGROUND (0-5m from camera): specific objects, textures, depth cues — e.g. "foreground: weathered oak branch with curling lichen crossing the lower third of frame, out-of-focus at f/2.8"
      • MIDGROUND (5-25m): the subject area — specific environmental details where the action happens
      • BACKGROUND (25m+): atmospheric perspective, layered recession, how far the eye can travel
      • Include materials (stone / wood / metal / fabric / foliage / water / dust / smoke), surfaces, wear patterns

   F) LIGHTING (specific sources with Kelvin values where plausible):
      • Primary (key) light: type (sun / window / practical / flame / moon / fluorescent), position (high-left / low-right / behind / etc.), approximate Kelvin (1800K candlelight / 2700K tungsten / 3200K warm / 4500K midday / 5600K daylight / 6500K overcast / 10000K blue shade)
      • Fill light: ratio to key (1:2 hard / 1:4 medium / 1:8 soft)
      • Rim/backlight: where it strikes, what it separates from the background
      • Practical lights visible in frame (lamps / candles / fires / screens) with their own Kelvin
      • Shadow quality: hard-edged / soft / overlapping / textured / dappled
      • Atmospheric light behaviour: volumetric rays / catchlight in eyes / specular highlights / subsurface scattering on skin

   G) COLOR & ATMOSPHERE (be precise):
      • Dominant palette (3-5 specific colors, e.g. "burnt ochre, verdigris, deep slate, cream-white, oxblood")
      • Overall color temperature (warm / cool / neutral / split-complementary)
      • Atmospheric density: clear / light haze / medium fog / heavy smoke — describe specifically
      • Particles in air: dust / pollen / ash / snow / rain / embers — quantified (sparse / medium / thick)
      • Lens effects: chromatic aberration / slight vignetting / subtle flare / grain texture

   H) TIME & WEATHER (always specify, even indoors):
      • Specific time of day: dawn / early morning / late morning / midday / afternoon / golden hour / dusk / blue hour / night / late night / 3AM
      • Specific weather: clear / overcast / light rain / heavy rain / thunderstorm / fog / snow / wind / still
      • Season: early spring / summer / late autumn / winter (affects foliage, light quality, wardrobe)

   I) TEXTURE & FILM GRAIN (specify rendering texture):
      • Grain structure: fine / medium / coarse — matching the visual style
      • Sharpness: clinical / natural / slightly soft / diffused
      • Skin/material rendering: photographic / painterly / stylized — matching "{vs_render_style}"

   J) CONTINUITY ANCHORS (connect this scene to its neighbours):
      • What carries over from the previous scene: time-of-day progression / location / wardrobe / weather / lighting mood
      • What shifts (if any) and what justifies the shift: a cut in time, a location change, an emotional beat
      • This field is what makes the resulting video feel CONTINUOUS rather than disjointed

   K) REFERENCE CHARACTER INDEXING: This is CRITICAL when multiple characters of the same species (e.g. multiple humans) appear in one scene — without a clear mapping, the image model CANNOT tell which reference image corresponds to which identity. Follow this strict convention:

      (i)  characters_present MUST be listed in ascending order of their Character Library #N (i.e. the character with the lowest global Character # first, then next lowest, etc.). This is the order the renderer will pass reference images to this scene.

      (ii) Begin the image_prompt BODY (after the aspect lock and style tag) with an explicit REFERENCE CHARACTER MAPPING sentence. Example for a scene where Character #1 (Rahul) and Character #3 (Sam) appear: "REFERENCE CHARACTER MAPPING: reference character 1 is Rahul, reference character 2 is Sam — throughout this image, 'reference character N' denotes the Nth provided reference image and must depict that exact character." Note: position 1 is the LOWEST-numbered character in characters_present for THIS scene, NOT always global #1. If only Char #3 and Char #5 appear, position 1 = Char #3 (first in order), position 2 = Char #5 (second in order).

      (iii) Throughout the rest of the image_prompt body, refer to each character using "reference character N (Name)" where N is the per-scene position established above. E.g. "reference character 1 (Rahul) stands in the foreground holding a lantern, while reference character 2 (Sam) kneels beside the altar to his right." This reinforces identity-to-reference-image binding in every sentence that describes a character.

      (iv) If only one character is present, still use this convention: "REFERENCE CHARACTER MAPPING: reference character 1 is [Name]. Reference character 1 (Name) stands..."

      (v)  If NO characters are present (environment-only scene), omit the mapping sentence — just write the scene.

═══════════════════════════════════════════════════════
🎬 HOLLYWOOD CONTINUITY ORCHESTRATION (applies to ALL scene_prompts)
═══════════════════════════════════════════════════════

You are choreographing the entire sequence as a continuous Hollywood production. Treat the scene array as a connected film, not isolated shots. Specifically:

 1) GROUP CONSECUTIVE-CONTEXT SCENES. Look at the pre-split voiceover segments above. When 2+ consecutive scenes share continuous narrative context (same subject, same location, same time, no implied scene break in the narration), choreograph them as ONE CONTINUOUS TAKE broken only by your transition decisions. The character must stay in the SAME wardrobe state, lighting must evolve smoothly (not reset), the camera must feel like it could plausibly have traveled from the previous scene's last frame to this scene's first frame.

 2) NEVER JUMP-CUT WITHIN CONTINUOUS CONTEXT. If voiceover scenes 3, 4, 5 are one continuous thought, scene_prompt 4 must continue scene 3's camera trajectory (e.g. if scene 3 ended in a slow push-in, scene 4 either continues the push-in or begins where scene 3's camera came to rest). Scene 5 likewise. The transition between them should be a soft connector (continued motion, match cut on motion or eye-line) NOT a hard cut to a new angle/location.

 3) JUSTIFY EVERY HARD CUT. If you do choose a hard cut between two scenes, your scene_prompt's element I (TRANSITION OUT) must specify it deliberately and your element J (CONTINUITY THREAD) on the next scene must explain what carries through the cut (matched color, matched motion direction, matched composition geometry).

 4) BUILD ARC INTENSITY ACROSS THE SEQUENCE. Camera energy, lighting drama, color saturation, and pacing should follow the narrative arc you can infer from reading ALL voiceovers together. Wide+slow at story setup, tighter+more dynamic at conflict, stillness or release at resolution.

 5) WARDROBE / TIME / WEATHER LOCK ACROSS A CONTINUOUS BLOCK. If scenes 2-7 are one continuous time-block, the character wardrobe must be IDENTICAL across all six. Time-of-day must progress monotonically (cannot go from dusk to noon to dusk). Weather must be the same state unless an external trigger justifies the change.

This orchestration is what separates an AI sequence from a professional film. Apply it.

TASK 2 — SCENE PROMPT (Director's Motion Brief — 150-280 words per scene):

The scene_prompt is a PROFESSIONAL DIRECTOR'S BRIEF written FOR THE IMAGE-TO-VIDEO RENDERER. The renderer will receive (a) the image_prompt's generated key-frame still and (b) the character reference images. Your scene_prompt tells the renderer WHAT TO ANIMATE, HOW TO ANIMATE IT, and WHAT MOOD/BGM/SFX ATMOSPHERE the scene carries.

This is the most professional Hollywood approach: the director hands the choreographer a shot brief — never the dialogue, never the script lines, never the narration text. The brief is action, motion, blocking, camera, mood. That is exactly what scene_prompt must be.

⚠️ WHAT scene_prompt MUST NOT CONTAIN:
   ✗ Voice-over text, narration text, dialogue, quoted utterances
   ✗ "voiceover:" / "narration:" / "dialogue:" / "V.O.:" labels
   ✗ Any reference to what the narrator is SAYING
   ✗ Any instruction that would cause the renderer to generate speech audio
   ✗ "synced to voiceover beats" / "matches narration cadence" / similar phrasing
   ✗ The voiceover text repeated for context — the renderer does NOT need it; the image already contains the visual context

⚠️ WHAT scene_prompt MUST CONTAIN — Director's Brief structure:

   A) REFERENCE-IMAGE ANIMATION DIRECTIVE: Open with what the renderer should do with the reference images. Example: "Animate the provided key-frame using the provided character reference image(s) as identity anchors. Reference character 1 (Name) performs the following action..." For environment-only scenes: "Animate the provided key-frame as a continuous moving plate..."

   B) CAMERA CHOREOGRAPHY: Type, direction, speed, trajectory, start framing → end framing. Specific terms: locked-off / slow dolly in / pull out / lateral track / steadicam follow / handheld verité / crane up / orbit / whip pan / rack focus / push-in. Specify lens (e.g. "35mm at f/2.8") and pacing (slow/medium/fast/staccato). Match the SCENE DURATION, not external rhythm.

   C) CHARACTER ACTION CHOREOGRAPHY: Frame-by-frame physical action only. Body movement, gesture sequences, expression shifts (eyes, brows, mouth corners, jaw), gaze direction, weight transfer, hand articulation. Silent visual motion only — if the moment has implied speech, depict only the silent breath/lip-parting micro-action without quoted words and without "says/whispers/shouts" verbs followed by quotes.

   D) ENVIRONMENT MOTION: Wind direction & strength (still / breeze / gust / gale), water motion, particle drift (dust / pollen / ash / snow / embers), fabric/hair flutter, foliage sway, distant elements (clouds, traffic, wildlife), reflections shifting on surfaces.

   E) LIGHTING ANIMATION: How light evolves through the duration — key-light drift, shadow lengthening/shortening, practical-light flicker (candles / lamps / fires), color temperature shift (warm-to-cool / cool-to-warm), volumetric ray motion, lens-flare bloom timing.

   F) BGM MOOD CUE (atmospheric direction, NOT audio command): One concise sentence describing the music mood the scene visually supports — e.g. "Visual pacing supports a slow swelling string arrangement with low brass undertone" or "Frame energy supports a percussive driving rhythm with sparse synth pulses". This is mood for the editor, not an instruction to generate speech.

   G) SFX ATMOSPHERE CUE (visual-context, NOT audio command): One concise sentence describing ambient sound atmosphere the scene's visuals imply — e.g. "Visual atmosphere implies wind through dry leaves, distant temple bells" or "Visual atmosphere implies fluorescent buzz, footsteps on wet concrete, distant siren". These are mood notes for the SFX editor, not commands to render audio.

   H) PACING & RHYTHM: Internal scene tempo — slow burn / building / staccato / sustained / explosive. State where in the duration the visual energy peaks (start / 25% / midpoint / 75% / end). State if pacing is even or accelerating/decelerating.

   I) TRANSITION OUT: How this scene hands off to the next scene — cut / 0.5s dissolve / 1s fade / match cut on motion / match cut on color / whip pan / iris / J-cut visual prep. Be specific about what visual element bridges to the next scene if continuity matters.

   J) CONTINUITY THREAD: One sentence stating what is CARRIED OVER from the previous scene's last frame (lighting mood, time-of-day position, weather state, character wardrobe, location relationship), and what SHIFTS at this scene's start. For Scene 1, write "Opening scene — establishes baseline."

═══════════════════════════════════════════════════════
PRE-SPLIT VOICEOVER SEGMENTS (LOCKED — DO NOT MODIFY):
═══════════════════════════════════════════════════════
{voiceover_block}

═══════════════════════════════════════════════════════
STORY ANALYSIS & NARRATIVE ARC:
═══════════════════════════════════════════════════════
{analysis_block}

═══════════════════════════════════════════════════════
CHARACTER REFERENCE LIBRARY (global character list — #N is the global ID):
═══════════════════════════════════════════════════════
{char_ref_block}

NOTE ON REFERENCE IMAGE INDEXING: The global #N numbers above identify characters in the project database. However, inside each scene's image_prompt you must use PER-SCENE reference positions (1, 2, 3, ...) that match the ascending order of Character #N values among ONLY the characters actually present in that scene. See element K above for the exact convention.

═══════════════════════════════════════════════════════
PRODUCTION PARAMETERS:
═══════════════════════════════════════════════════════
Visual Style: {visual_style} — "{vs_render_style}"
Style Details: {style}
Aspect Ratio: {aspect_ratio}
Color Grading Direction: {color_grading_val}

REMINDER: Every image_prompt MUST start with "{aspect_ratio} aspect ratio" lock, then "{vs_render_style}" style tag, then (for multi-character scenes) the REFERENCE CHARACTER MAPPING sentence, then LITERALLY depict the narrated moment from that scene's voiceover with all 11 mandatory elements A-K, and maintain visual variety from adjacent scenes. Character reference portraits were generated at 16:9 — this scene's OUTPUT must be {aspect_ratio} regardless.

═══════════════════════════════════════════════════════
OUTPUT — STRICT JSON:
═══════════════════════════════════════════════════════

Return ONLY a JSON object with this exact structure. Use key "scenes" (not any other name):

{{
  "scenes": [
    {{
      "scene_number": 1,
      "title": "Evocative 3-6 word cinematic title",
      "voiceover": "COPY THE EXACT PRE-SPLIT VOICEOVER TEXT FOR THIS SCENE — VERBATIM, NO CHANGES",
      "voiceover_subject_who": "WHO is described/acting in this scene's voiceover",
      "voiceover_action_what": "WHAT action/event is being narrated",
      "voiceover_location_where": "WHERE the narrated moment takes place",
      "characters_present": ["Exact Character Name From Library"],
      "image_prompt": "250-400 word ULTRA-DENSE key frame description that LITERALLY depicts the WHO/WHAT/WHERE above, with ALL 11 mandatory elements A-K. MUST START with ASPECT RATIO LOCK ({aspect_ratio} orientation), followed by the {vs_render_style} style tag. For multi-character scenes, the REFERENCE CHARACTER MAPPING sentence comes right after the style tag: 'REFERENCE CHARACTER MAPPING: reference character 1 is [Name], reference character 2 is [Name], ... — throughout this image, reference character N denotes the Nth provided reference image.' Then reference each character inline as 'reference character N (Name)' throughout the body. Include TIME/WEATHER, LIGHTING with specific Kelvin, COMPOSITION with specific lens mm and f-stop, and CONTINUITY ANCHORS.",
      "scene_prompt": "150-280 word DIRECTOR'S MOTION BRIEF written FOR THE IMAGE-TO-VIDEO RENDERER. Structure: A) reference-image animation directive, B) camera choreography (lens + speed + trajectory), C) character action choreography (silent physical motion only), D) environment motion, E) lighting animation, F) BGM mood cue (one sentence, atmospheric mood for editor — NOT an audio command), G) SFX atmosphere cue (one sentence, ambient mood for editor — NOT an audio command), H) pacing & rhythm, I) transition out, J) continuity thread (one sentence on what is carried over from previous scene). MUST NOT contain the voiceover text, narration text, quoted dialogue, voice-over labels, or any reference to what the narrator is saying. The renderer does not need voiceover context — the image_prompt already contains the visual context. The TTS audio track is generated separately by the template.",,
      "emotion": "specific emotional tone",
      "camera": "camera movement and lens summary",
      "lighting": "lighting rig summary with color temps",
      "transition": "cut/dissolve/fade_to_black/match_cut",
      "camera_movement_type": "static/dolly/crane/steadicam/handheld/tracking",
      "camera_speed": "ultra_slow/slow/medium/fast",
      "shot_size": "EWS/WS/MWS/FS/MFS/MS/MCU/CU/ECU",
      "color_palette": ["color1", "color2", "color3"],
      "atmosphere": "atmospheric elements summary",
      "time_of_day": "specific time: dawn / early morning / late morning / midday / afternoon / golden hour / dusk / blue hour / night / 3AM",
      "weather": "specific weather: clear / overcast / light rain / heavy rain / thunderstorm / fog / snow / windy / still",
      "lens_mm": "specific focal length in mm, e.g. 35",
      "f_stop": "specific aperture, e.g. f/2.8",
      "continuity_anchor": "what connects this scene to the previous one (time progression, location carry-over, wardrobe, mood). Empty string for scene 1.",
      "bgm_cue": "ONE concise sentence describing the music mood the scene visually supports — for the music editor. NOT an audio command. e.g. 'Visual pacing supports a slow swelling string arrangement with low brass undertone.'",
      "sfx_cue": "ONE concise sentence describing ambient sound atmosphere the scene's visuals imply — for the SFX editor. NOT an audio command. e.g. 'Visual atmosphere implies wind through dry leaves, distant temple bells.'",
      "continuity_thread": "ONE sentence stating exactly what is carried over from the previous scene's last frame and what shifts at this scene's start. For Scene 1 write 'Opening scene — establishes baseline.'"
    }}
  ]
}}

Return EXACTLY {actual_scene_count} scenes in the array.

═══════════════════════════════════════════════════════
⚠️ CHARACTERS_PRESENT — CRITICAL ACCURACY RULES:
═══════════════════════════════════════════════════════

The characters_present field determines which character reference images are composited into each scene. WRONG characters will RUIN the entire project. Follow these rules with ZERO exceptions:

a) ONLY list characters who are PHYSICALLY VISIBLE or DIRECTLY ACTING in that specific scene's visual frame. Ask: "Would a camera filming this scene capture this character?" If NO → do NOT include them.
b) Characters merely MENTIONED in voiceover or dialogue but NOT visually present in the scene MUST NOT be listed. Example: narrator says "he remembered his mother" — if mother is not shown on screen, do NOT list her.
c) Use the EXACT character name as written in the Character Reference Library above — letter-for-letter, including capitalization, spaces, and any special characters. Do NOT abbreviate, paraphrase, or modify names.
d) If a scene is an establishing shot, landscape, environment, or abstract visual with NO characters visible → set characters_present to an EMPTY array: []
e) NEVER default to listing all characters. NEVER assume a character is present just because they appeared in a previous scene.
f) Each scene must be evaluated INDEPENDENTLY. A character present in Scene 3 is NOT automatically present in Scene 4.
g) Order characters_present in ASCENDING ORDER of their global Character #N (lowest # first). This is MANDATORY — it determines the per-scene reference-image positions described in element K. Do NOT reorder by visual prominence; the image_prompt text can still establish prominence through composition language ("in the foreground", "closest to camera", etc.).

ABSOLUTE RULES — VIOLATION INVALIDATES OUTPUT:
1. EXACTLY {actual_scene_count} scenes in the "scenes" array
2. voiceover MUST be copied VERBATIM from the pre-split segments above — NO modifications, NO redistribution
3. image_prompt: 250-400 words with ALL 11 mandatory elements (A-K), LITERALLY depicting the voiceover moment
4. image_prompt MUST START with "{aspect_ratio} aspect ratio" lock as the first framing statement — this overrides reference-image ratios
5. scene_prompt: 150-280 word DIRECTOR'S MOTION BRIEF with ALL 10 mandatory elements (A-J). Pure director-to-renderer instruction about WHAT TO ANIMATE on the reference image and HOW. Pacing matches scene duration, NOT external rhythm.
6. scene_prompt MUST NOT contain the voiceover text, narration text, quoted dialogue, voice-over labels, or any reference to what the narrator is saying. The renderer does NOT need voiceover context — the image_prompt already contains all visual context. The TTS audio is generated separately by the template; if the scene_prompt repeats voiceover content, the result will be muddled visuals or competing audio. BGM mood cue (element F) and SFX atmosphere cue (element G) are acceptable as one-sentence visual-mood notes for the editor — they are NOT audio-generation commands.
7. characters_present: ONLY characters VISUALLY ON SCREEN. Use EXACT names. Empty array [] if no characters visible. Order ascending by global Character #N.
8. scene_number: sequential integers from 1
9. Every scene must have VISUAL VARIETY from its neighbors (shot size, camera, angle, color, composition principle)
10. CONTINUITY ANCHORS — image_prompt's element J (visual carry-over) AND scene_prompt's element J (continuity thread) together create unbroken visual narrative across scenes. When the voiceover context is continuous across multiple scenes, the visual continuity must be even stronger — same lighting state, same character wardrobe, smooth camera evolution, no jump-cuts unless intentional. Treat consecutive-voiceover-context scenes as ONE long take broken only by your transition decisions.
11. USER CREATIVE DIRECTIVES (if provided at top) override all defaults

Return ONLY the JSON object:''',
            directive_block=directive_block,
            voiceover_binding_block=voiceover_binding_block,
            variety_block=variety_block,
            voiceover_block=voiceover_block,
            actual_scene_count=actual_scene_count,
            style=style,
            visual_style=visual_style,
            vs_render_style=vs_render_style,
            vs_quality=vs_quality,
            vs_char_instruction=vs_char_instruction,
            aspect_ratio=aspect_ratio,
            color_grading_val=color_grading_val,
            analysis_block=analysis_block,
            char_ref_block=char_ref_block
        )

        # ══════════════════════════════════════════════════════════════
        # STEP 5: Generate with AI (with validation + retry)
        # ══════════════════════════════════════════════════════════════
        all_char_names = [c.get("name", "") for c in chars if c.get("name")]
        print(f"[AUDIO_TEMPLATE][SCENES] char_ref_block has {len(chars)} characters:")
        for c in chars:
            print(f"  -> #{c.get('order',0)} {c.get('name','?')} | image_prompt len={len(c.get('image_prompt',''))} | appearance len={len(c.get('appearance_summary',''))}")

        # v4.1: Flexible key lookup for scenes
        scene_keys = [
            "scenes", "scene_list", "scene_array", "storyboard",
            "shots", "shot_list", "sequence", "breakdown",
            "result", "data", "output"
        ]

        ai_scenes = None
        scene_gen_retries = 3
        for scene_attempt in range(1, scene_gen_retries + 1):
            print(f"[AUDIO_TEMPLATE][SCENES] Scene generation attempt {scene_attempt}/{scene_gen_retries} — requesting {actual_scene_count} scenes (prompt {len(ai_prompt)} chars)")
            response = await self._ai_generate_with_retry(
                mexflow, ai_prompt, max_tokens=80000, label="SCENES", max_retries=5
            )
            print(f"[AUDIO_TEMPLATE][SCENES] AI response length: {len(response) if response else 0}")

            if not response:
                print(f"[AUDIO_TEMPLATE][SCENES] Attempt {scene_attempt}: EMPTY response")
                continue

            # ── v4.1: Robust parse with flexible key lookup ──
            parsed = self._clean_and_parse_json(response, mexflow.ai.parse_json)

            # First try flexible list extraction
            candidate_scenes = self._extract_list_from_parsed(parsed, scene_keys)

            if candidate_scenes is None or len(candidate_scenes) == 0:
                # If still nothing, check if parsed is itself a non-empty list
                if isinstance(parsed, list) and len(parsed) > 0 and isinstance(parsed[0], dict):
                    candidate_scenes = parsed
                else:
                    # Determine what kind of value we got (using isinstance — no builtin introspection)
                    if isinstance(parsed, list):
                        parsed_kind = "list"
                    elif isinstance(parsed, dict):
                        parsed_kind = "dict"
                    elif parsed is None:
                        parsed_kind = "None"
                    else:
                        parsed_kind = "other"
                    print(f"[AUDIO_TEMPLATE][SCENES] Attempt {scene_attempt}: No scenes found in response. Parsed kind: {parsed_kind}")
                    if isinstance(parsed, dict):
                        print(f"[AUDIO_TEMPLATE][SCENES] Available keys: {list(parsed.keys())}")
                    continue

            print(f"[AUDIO_TEMPLATE][SCENES] Extracted {len(candidate_scenes)} scenes from AI")

            # ── Validate characters_present quality ──
            total_chars = len(all_char_names)
            if total_chars >= 2 and len(candidate_scenes) >= 3:
                scenes_with_all_chars = 0
                for s in candidate_scenes:
                    cp = s.get("characters_present", [])
                    cp_names = set()
                    for c in cp:
                        if isinstance(c, str):
                            cp_names.add(c.strip().lower())
                        elif isinstance(c, dict):
                            cp_names.add((c.get("name") or "").strip().lower())
                    known_lower = set(n.lower() for n in all_char_names)
                    if cp_names >= known_lower:
                        scenes_with_all_chars += 1

                ratio = scenes_with_all_chars / len(candidate_scenes)
                print(f"[AUDIO_TEMPLATE][SCENES] Character validation: {scenes_with_all_chars}/{len(candidate_scenes)} scenes have ALL {total_chars} characters (ratio={ratio:.2f})")

                if ratio > 0.6:
                    print(f"[AUDIO_TEMPLATE][SCENES] ⚠️ REJECTED: AI dumped all characters into {int(ratio*100)}% of scenes — retrying")
                    continue

            ai_scenes = candidate_scenes
            print(f"[AUDIO_TEMPLATE][SCENES] ✓ Accepted: {len(ai_scenes)} scenes with valid character distribution")
            break

        if not ai_scenes:
            print("[AUDIO_TEMPLATE][SCENES] All attempts failed — falling back")
            return self._generate_fallback_scenes(
                subtitle_data, full_narrative, audio_duration,
                required_scene_count, allowed_durations, chars,
                style, visual_style, aspect_ratio,
                custom_instructions=custom_instructions
            )

        print(f"[AUDIO_TEMPLATE][SCENES] Got {len(ai_scenes)} scenes from AI")
        for s in ai_scenes[:3]:
            cp = s.get("characters_present", [])
            print(f"  -> Scene {s.get('scene_number','?')}: characters_present={cp}")

        # Sort by scene_number
        ai_scenes.sort(key=lambda s: int(s.get("scene_number", 0)) if s.get("scene_number") is not None else 0)

        # ══════════════════════════════════════════════════════════════
        # STEP 6: Build final scenes using PRE-SPLIT timestamps
        # ══════════════════════════════════════════════════════════════
        all_char_names = [c.get("name", "") for c in chars if c.get("name")]
        scenes = []
        cumulative_video_time = 0.0

        scene_style_tag = self._build_visual_style_tag(visual_style)
        print(f"[AUDIO_TEMPLATE][SCENES] Visual style tag built for '{visual_style}': prefix={scene_style_tag['prefix'][:60]}...")

        for i, seg in enumerate(segments):
            scene_idx = i + 1
            ai_scene = ai_scenes[i] if i < len(ai_scenes) else {}

            # VOICEOVER, DURATION, TIMING: Always from pre-split segment — NEVER from AI
            voiceover = seg["voiceover"]
            duration = seg["duration"]
            audio_start = seg["start_time"]
            audio_end = seg["end_time"]

            video_start = cumulative_video_time
            video_end = video_start + duration
            cumulative_video_time = video_end

            emotion = ai_scene.get("emotion", "neutral")
            camera_category = self._categorize_emotion_for_camera(emotion)
            camera_text = ai_scene.get("camera", "")
            if not camera_text and add_camera:
                category_moves = self.CAMERA_MOVEMENTS.get(camera_category, self.CAMERA_MOVEMENTS["establishing"])
                camera_text = random.choice(category_moves)

            lighting_text = ai_scene.get("lighting", "")
            if not lighting_text:
                lighting_text = self.LIGHTING_SETUPS.get(emotion.lower().strip(), self.LIGHTING_SETUPS["neutral"])

            # Characters present — EXACT MATCH ONLY from AI output
            raw_chars_present = ai_scene.get("characters_present", [])
            chars_present = []
            matched_names = set()

            for cp in raw_chars_present:
                cp_name = ""
                if isinstance(cp, str):
                    cp_name = cp.strip()
                elif isinstance(cp, dict):
                    cp_name = (cp.get("name") or "").strip()

                if not cp_name:
                    continue

                # Exact match first
                exact = None
                for known in all_char_names:
                    if known.strip().lower() == cp_name.lower():
                        exact = known
                        break

                # Substring containment
                if not exact:
                    for known in all_char_names:
                        kl = known.strip().lower()
                        cl = cp_name.lower()
                        if kl in cl or cl in kl:
                            exact = known
                            break

                if exact and exact not in matched_names:
                    order_num = next((c.get("order", 0) for c in chars if c.get("name") == exact), 0)
                    chars_present.append({"name": exact, "order": order_num})
                    matched_names.add(exact)

            # ── v4.2: SORT chars_present by global DB order (ascending) ──
            # This is critical — the renderer composites reference images in
            # ascending global order, and per-scene "reference character N"
            # labels in the image_prompt must match that order exactly.
            chars_present = self._sort_chars_present_by_global_order(chars_present)

            # ── Build comprehensive JSON scene_prompt ──
            scene_prompt_text = ai_scene.get("scene_prompt", "").strip()

            # v4.3.1: STRIP any voice-over / dialogue / speech content that
            # the AI may have slipped in. The template generates its own TTS
            # audio — if the image-to-video renderer also emits speech, the
            # two tracks collide. Safety-net stripping + authoritative
            # append of the AUDIO RESTRICTION directive is the defense.
            scene_prompt_text, voice_strips = self._strip_voice_dialogue_content(scene_prompt_text)
            if voice_strips:
                print(f"[AUDIO_TEMPLATE][SCENES] Scene {scene_idx}: stripped {voice_strips} voice/dialogue pattern(s) from scene_prompt")

            # Append authoritative AUDIO RESTRICTION directive so the renderer
            # is explicitly told NO voice / dialogue / speech track.
            audio_restriction = self._build_audio_restriction_directive()
            scene_prompt_text = (scene_prompt_text.rstrip(". ") + ".") if scene_prompt_text else ""
            scene_prompt_text = scene_prompt_text + audio_restriction

            emotion_dir = self.EMOTION_DIRECTION.get(emotion.lower().strip(), {})

            scene_prompt_json = {
                "motion_description": scene_prompt_text,
                "audio_guidance": {
                    "allowed": "BGM mood cues and SFX ambient atmosphere as visual/atmospheric context only",
                    "forbidden": "voice-over, dialogue, narration, spoken words, lip-synced audio, any speech/audio track",
                    "reason": "Template generates TTS audio track separately from voiceover — video must be visual-only so the two tracks do not collide",
                    "voice_content_stripped": voice_strips
                },
                "bgm_cue": ai_scene.get("bgm_cue", ""),
                "sfx_cue": ai_scene.get("sfx_cue", ""),
                "continuity_thread": ai_scene.get("continuity_thread", ""),
                "voiceover_binding": {
                    "who": ai_scene.get("voiceover_subject_who", ""),
                    "what": ai_scene.get("voiceover_action_what", ""),
                    "where": ai_scene.get("voiceover_location_where", "")
                },
                "camera": {
                    "movement_type": ai_scene.get("camera_movement_type", camera_category),
                    "direction": camera_text,
                    "speed": ai_scene.get("camera_speed", "medium"),
                    "lens_mm": 35,
                    "stabilization": "steadicam"
                },
                "characters": [
                    {
                        "scene_ref_position": idx + 1,
                        "global_order": cp.get("order", 0),
                        "name": cp.get("name", ""),
                        "character_ref": f"reference character {idx + 1} ({cp.get('name', '')})",
                        "action": "present in scene",
                        "expression_arc": emotion
                    }
                    for idx, cp in enumerate(chars_present)
                ],
                "environment": {
                    "motion": "ambient atmospheric movement",
                    "particles": ai_scene.get("atmosphere", "ambient atmospheric particles")
                },
                "lighting_dynamics": {
                    "setup": lighting_text,
                    "progression": "as described in scene_prompt"
                },
                "composition": {
                    "shot_size": ai_scene.get("shot_size", "MS"),
                    "aspect_ratio": aspect_ratio,
                    "depth_of_field": "cinematic"
                },
                "color_grading": {
                    "palette": ai_scene.get("color_palette", []),
                    "tonality": "match visual style",
                    "grade_reference": color_grading if color_grading != "auto" else "match visual style and emotion"
                },
                "pacing": {
                    "rhythm": emotion_dir.get("pacing", "moderate") if emotion_dir else "moderate",
                    "intensity_arc": "as driven by narration"
                },
                "transition": {
                    "type": ai_scene.get("transition", "cut"),
                    "to_next_scene": "continuous narrative flow"
                },
                "audio_sync": {
                    "video_start_time": round(video_start, 3),
                    "video_end_time": round(video_end, 3),
                    "audio_start_time": round(audio_start, 3),
                    "audio_end_time": round(audio_end, 3),
                    "duration_seconds": duration,
                    "sync_drift_ms": round((video_start - audio_start) * 1000, 1)
                },
                "technical": {
                    "visual_style": visual_style,
                    "aspect_ratio": aspect_ratio,
                    "render_quality": vs_render["quality"]
                }
            }

            scene_prompt_str = json.dumps(scene_prompt_json, ensure_ascii=False)

            # ── v4.2: BUILD AUTHORITATIVE REFERENCE CHARACTER MAPPING ──
            # chars_present is already sorted by global DB order (ascending), so
            # their positions in this list (0, 1, 2, ...) map directly to the
            # reference image indices that will be passed to this scene at render time.
            ref_declaration = self._build_scene_reference_declaration(chars_present)

            # ── v4.3: BUILD AUTHORITATIVE ASPECT RATIO DIRECTIVE ──
            # Forces the user-selected aspect_ratio into every scene image_prompt,
            # explicitly overriding the 16:9 ratio of the character reference portraits.
            aspect_directive = self._build_aspect_directive(
                aspect_ratio=aspect_ratio, is_character_portrait=False
            )

            # ── INJECT VISUAL STYLE + ASPECT + REFERENCE MAPPING into scene image_prompt ──
            raw_image_prompt = ai_scene.get("image_prompt", "")

            # Strip any leading aspect + ref-mapping sentence the AI may have written itself,
            # so our authoritative versions are the single source of truth.
            if raw_image_prompt:
                raw_image_prompt = self._strip_leading_aspect_directive(raw_image_prompt)
                if ref_declaration:
                    raw_image_prompt = self._strip_leading_ref_declaration(raw_image_prompt)

            # Prepend: [aspect_directive][ref_declaration][body]
            # After _inject_visual_style runs, the final order is:
            #   [style_prefix][aspect_directive][ref_declaration][body][style_suffix]
            combined_prompt = (aspect_directive + ref_declaration + raw_image_prompt) if raw_image_prompt else raw_image_prompt

            styled_image_prompt = self._inject_visual_style(combined_prompt, scene_style_tag) if combined_prompt else ""

            # Log the mapping so it's auditable in production
            if chars_present:
                ref_log = ", ".join(
                    f"ref{idx+1}={cp.get('name','?')}(global#{cp.get('order','?')})"
                    for idx, cp in enumerate(chars_present)
                )
                print(f"[AUDIO_TEMPLATE][SCENES] Scene {scene_idx} aspect={aspect_ratio} | ref mapping: {ref_log}")

            scene = {
                "scene_id_str": f"{scene_idx}",
                "title": ai_scene.get("title", f"Scene {scene_idx}"),
                "image_prompt": styled_image_prompt,
                "scene_prompt": scene_prompt_str,
                "scene_description": voiceover,
                "description": voiceover,
                "voiceover": voiceover,
                "duration": duration,
                "start_time": round(audio_start, 3),
                "end_time": round(audio_end, 3),
                "camera": camera_text,
                "emotion": emotion,
                "lighting": lighting_text,
                "characters_present": chars_present,
                "characters": [{"name": cp.get("name", ""), "role": "subject"} for cp in chars_present],
                "order": scene_idx,
                "transition": ai_scene.get("transition", "cut"),
                "metadata": {
                    "image_prompt": styled_image_prompt,
                    "scene_prompt": scene_prompt_str,
                    "scene_prompt_json": scene_prompt_json,
                    "camera_info": camera_text,
                    "lighting_info": lighting_text,
                    "emotion": emotion,
                    "transition": ai_scene.get("transition", "cut"),
                    "characters_present": [cp.get("name", "") for cp in chars_present],
                    "reference_mapping": [
                        {"scene_ref_position": idx + 1, "name": cp.get("name", ""), "global_order": cp.get("order", 0)}
                        for idx, cp in enumerate(chars_present)
                    ],
                    "aspect_ratio": aspect_ratio,
                    "visual_style": visual_style,
                    "color_grading": color_grading,
                    "start_time": round(audio_start, 3),
                    "end_time": round(audio_end, 3),
                    "video_start_time": round(video_start, 3),
                    "video_end_time": round(video_end, 3),
                    "duration": duration,
                    "sync_drift_ms": round((video_start - audio_start) * 1000, 1),
                    "voiceover_binding": {
                        "who": ai_scene.get("voiceover_subject_who", ""),
                        "what": ai_scene.get("voiceover_action_what", ""),
                        "where": ai_scene.get("voiceover_location_where", "")
                    },
                    "time_of_day": ai_scene.get("time_of_day", ""),
                    "weather": ai_scene.get("weather", ""),
                    "lens_mm": ai_scene.get("lens_mm", ""),
                    "f_stop": ai_scene.get("f_stop", ""),
                    "continuity_anchor": ai_scene.get("continuity_anchor", ""),
                    "continuity_thread": ai_scene.get("continuity_thread", ""),
                    "bgm_cue": ai_scene.get("bgm_cue", ""),
                    "sfx_cue": ai_scene.get("sfx_cue", ""),
                    "aspect_ratio_enforced": aspect_ratio,
                    "custom_instructions_applied": bool(custom_instructions),
                    "variety_enforced": bool(enforce_variety)
                }
            }
            scenes.append(scene)

        # Re-number
        for i, s in enumerate(scenes):
            s["order"] = i + 1
            s["scene_id_str"] = f"{i + 1}"

        # Log final sync report
        total_dur = sum(s["duration"] for s in scenes)
        print(f"[AUDIO_TEMPLATE][SCENES] ═══ SYNC REPORT ═══")
        print(f"[AUDIO_TEMPLATE][SCENES] Total scenes: {len(scenes)}")
        print(f"[AUDIO_TEMPLATE][SCENES] Total video duration: {total_dur}s")
        print(f"[AUDIO_TEMPLATE][SCENES] Total audio duration: {round(audio_duration, 2)}s")
        print(f"[AUDIO_TEMPLATE][SCENES] Custom directives applied: {bool(custom_instructions)}")
        print(f"[AUDIO_TEMPLATE][SCENES] Variety enforcement: {bool(enforce_variety)}")
        for i, s in enumerate(scenes):
            meta = s.get("metadata", {})
            drift = meta.get("sync_drift_ms", 0)
            cp_names = [cp.get("name", "") if isinstance(cp, dict) else cp for cp in s.get("characters_present", [])]
            word_ct = len(s.get("voiceover", "").split()) if s.get("voiceover") else 0
            vb = meta.get("voiceover_binding", {})
            print(f"  Scene {i+1}: dur={s['duration']}s | audio={s['start_time']}-{s['end_time']}s | "
                  f"video={meta.get('video_start_time',0)}-{meta.get('video_end_time',0)}s | "
                  f"drift={drift}ms | words={word_ct} | chars={cp_names}")
            if vb.get("who") or vb.get("what") or vb.get("where"):
                print(f"    ↪ Binding: WHO={vb.get('who','')[:30]} | WHAT={vb.get('what','')[:30]} | WHERE={vb.get('where','')[:30]}")

        return scenes

    # ══════════════════════════════════════════════════════════════════
    # DATABASE SAVE — Characters + Scenes
    # ══════════════════════════════════════════════════════════════════

    async def _save_to_project(
        self,
        characters_data: Dict[str, Any],
        scenes: List[Dict],
        bg_color: str,
        visual_style: str,
        aspect_ratio: str
    ) -> None:
        """Save characters and scenes to the project database."""

        chars = characters_data.get("characters", []) if characters_data else []
        all_character_names = [c.get("name", "") for c in chars if c.get("name")]
        print(f"[AUDIO_TEMPLATE] _save_to_project: {len(chars)} characters, {len(scenes)} scenes")

        # ── Save characters to project_data ──
        character_list_for_project = []
        for char in chars:
            char_name = char.get("name", "Unknown")
            char_prompt = char.get("image_prompt", char.get("appearance_summary", ""))

            character_list_for_project.append({
                "name": char_name,
                "prompt": char_prompt
            })

            try:
                await mexflow.project_data.add_character(char_name, char_prompt)
            except Exception as e:
                print(f"[AUDIO_TEMPLATE] add_character failed for {char_name!r}: {e}")

        try:
            result_save = await mexflow.project_data.save_characters(character_list_for_project)
            print(f"[AUDIO_TEMPLATE] save_characters({len(character_list_for_project)}) -> {result_save}")
        except Exception as e:
            print(f"[AUDIO_TEMPLATE] save_characters EXCEPTION: {e}")

        # ── Save scenes via bulk save ──
        bulk_scenes = []
        for i, scene in enumerate(scenes):
            scene_id = scene.get("scene_id_str", f"{i + 1}")

            scene_characters_present = scene.get("characters_present", [])

            chars_present_names = []
            for cp in scene_characters_present:
                if isinstance(cp, dict):
                    chars_present_names.append(cp.get("name", ""))
                elif isinstance(cp, str):
                    chars_present_names.append(cp)

            bulk_scenes.append({
                "scene_id_str": scene_id,
                "title": scene.get("title", f"Scene {i + 1}"),
                "image_prompt": scene.get("image_prompt", ""),
                "voiceover": scene.get("voiceover", ""),
                "duration": scene.get("duration", 5),
                "scene_prompt": scene.get("scene_prompt", ""),
                "scene_description": scene.get("voiceover", ""),
                "characters_present": chars_present_names,
                "characters": [{"name": cn} for cn in chars_present_names],
                "metadata": scene.get("metadata", {
                    "image_prompt": scene.get("image_prompt", ""),
                    "scene_prompt": scene.get("scene_prompt", ""),
                    "camera_info": scene.get("camera", ""),
                    "lighting_info": scene.get("lighting", ""),
                    "emotion": scene.get("emotion", "neutral"),
                    "transition": scene.get("transition", "cut"),
                    "characters_present": chars_present_names,
                    "aspect_ratio": aspect_ratio,
                    "visual_style": visual_style,
                    "start_time": scene.get("start_time", 0),
                    "end_time": scene.get("end_time", 0),
                    "duration": scene.get("duration", 5)
                })
            })

        try:
            await mexflow.scene_data.save_scenes_bulk(
                scenes=bulk_scenes,
                clear_existing=True
            )
        except Exception as e:
            print(f"[AUDIO_TEMPLATE] save_scenes_bulk exception: {e}")

        # Per-scene follow-up saves
        for i, scene in enumerate(scenes):
            scene_id = scene.get("scene_id_str", f"{i + 1}")

            try:
                await mexflow.scene_data.save_scene_duration(
                    scene_id, scene.get("duration", 5)
                )
            except Exception:
                pass

            try:
                await mexflow.scene_data.save_scene_prompt(
                    scene_id, scene.get("scene_prompt", "")
                )
            except Exception:
                pass

            try:
                await mexflow.scene_data.save_scene_description(
                    scene_id, scene.get("voiceover", "")
                )
            except Exception:
                pass

            try:
                scene_meta = scene.get("metadata", {})
                await mexflow.scene_data.save_metadata(scene_id, scene_meta)
            except Exception:
                pass

            chars_present_names = []
            for cp in scene.get("characters_present", []):
                if isinstance(cp, dict):
                    chars_present_names.append(cp.get("name", ""))
                elif isinstance(cp, str):
                    chars_present_names.append(cp)

            try:
                await mexflow.scene_data.save_characters_present(
                    scene_id, chars_present_names
                )
            except Exception:
                pass

            try:
                await mexflow.scene_data.update_status(scene_id, "generated")
            except Exception:
                pass

            mexflow.progress.update(
                stage="Saving to Project",
                stage_index=7,
                total_stages=8,
                current_progress=((i + 1) / len(scenes)) * 100,
                message=f"Saved scene {i + 1} of {len(scenes)}: {scene.get('title', '')}"
            )

    # ══════════════════════════════════════════════════════════════════
    # FALLBACK SCENE GENERATOR
    # ══════════════════════════════════════════════════════════════════

    def _generate_fallback_scenes(
        self,
        subtitle_data: List[Dict],
        full_narrative: str,
        audio_duration: float,
        required_scene_count: int,
        allowed_durations: List[int],
        characters: List[Dict],
        style: str,
        visual_style: str,
        aspect_ratio: str = "16:9",
        custom_instructions: str = ""
    ) -> List[Dict]:
        """Generate fallback scenes when AI is unavailable.
        Uses the same timestamp-driven splitting as the main pipeline
        to guarantee perfect audio-video sync.

        v4.1: accepts custom_instructions and bakes a summary of them into
        each fallback image_prompt so user directives are still partially honored.
        """
        import random

        if not subtitle_data or required_scene_count == 0:
            return []

        min_dur = min(allowed_durations) if allowed_durations else 5

        # ── Use the same timestamp splitter as the main pipeline ──
        segments = self._split_subtitle_into_scenes(
            subtitle_data=subtitle_data,
            allowed_durations=allowed_durations,
            audio_duration=audio_duration,
            required_scene_count=required_scene_count
        )

        if not segments:
            return []

        # v4.2: Character references are now handled via per-scene
        # _build_scene_reference_declaration inside the loop below —
        # no pre-built global list needed here.

        # v4.1: Condense custom_instructions into a tag for fallback image_prompts
        directive_tag = ""
        if custom_instructions and custom_instructions.strip():
            # Pull out the first 2-3 meaningful lines as a compact tag
            clean_lines = []
            for line in custom_instructions.split("\n"):
                line = line.strip().lstrip("•-*◦▪▸→»").strip()
                line = re.sub(r'^(\d+[\.\)]\s*|[a-zA-Z][\.\)]\s*)', '', line).strip()
                if line:
                    clean_lines.append(line)
                if len(clean_lines) >= 3:
                    break
            if clean_lines:
                directive_tag = " User creative directives: " + "; ".join(clean_lines) + "."

        # ── Build scenes using pre-split segments ──
        scenes = []
        cumulative_video_time = 0.0

        fallback_style_tag = self._build_visual_style_tag(visual_style)
        vs_render = self.VISUAL_STYLE_RENDERING.get(
            visual_style, self.VISUAL_STYLE_RENDERING.get("cinematic")
        )

        # v4.1: Rotate shot sizes for variety in fallback
        shot_rotation = ["Wide establishing shot", "Medium shot", "Close-up shot",
                         "Medium wide shot", "Full shot", "Medium close-up"]
        camera_rotation = list(self.CAMERA_MOVEMENTS.keys())

        for scene_num, seg in enumerate(segments, 1):
            voiceover = seg["voiceover"]
            duration = seg["duration"]
            audio_start = seg["start_time"]
            audio_end = seg["end_time"]

            video_start = cumulative_video_time
            video_end = video_start + duration
            cumulative_video_time = video_end

            # ── v4.2: Determine chars_present FIRST (before building image_prompt) ──
            # so we can sort them by global order and build the reference mapping
            # the same way the main path does.
            chars_present = []
            if characters:
                vo_lower = voiceover.lower()
                for c in characters:
                    cname = c.get("name", "")
                    if not cname:
                        continue
                    cn_words = [w for w in cname.lower().split()
                                if w not in ('the', 'a', 'an', 'of', 'and', 'in', 'at', 'to', 'with') and len(w) > 2]
                    min_required = len(cn_words) if len(cn_words) <= 2 else max(2, (len(cn_words) + 1) // 2 + 1)
                    matches = sum(1 for w in cn_words if w in vo_lower)
                    if matches >= min_required:
                        chars_present.append({"name": cname, "order": c.get("order", 0)})

            # v4.2: Sort by global DB order so reference positions align with
            # the ascending order renderer passes reference images.
            chars_present = self._sort_chars_present_by_global_order(chars_present)

            # v4.2: Build authoritative reference-character-mapping sentence
            ref_declaration = self._build_scene_reference_declaration(chars_present)

            # v4.3: Build authoritative aspect ratio directive (scene, not character portrait)
            aspect_directive = self._build_aspect_directive(
                aspect_ratio=aspect_ratio, is_character_portrait=False
            )

            # char_mention kept for scene_prompt (motion) text — inline character list
            char_mention = ""
            if chars_present:
                parts = [f"reference character {idx + 1} ({cp.get('name','')})"
                         for idx, cp in enumerate(chars_present)]
                char_mention = ", ".join(parts) + " present in frame. "

            # v4.1: Rotate shot sizes across scenes for variety
            shot_type = shot_rotation[(scene_num - 1) % len(shot_rotation)]

            # v4.1: Derive a narrated-moment phrase from voiceover text
            narrated_phrase = voiceover.strip()
            if len(narrated_phrase) > 140:
                narrated_phrase = narrated_phrase[:140].rsplit(" ", 1)[0] + "..."

            # v4.3: aspect_directive FIRST, then ref_declaration, then body
            raw_image_prompt = (
                f"{aspect_directive}"
                f"{ref_declaration}"
                f"{shot_type} framed in {aspect_ratio}, literally depicting: \"{narrated_phrase}\". "
                f"ENVIRONMENT: Layered composition with foreground depth elements, textured midground, "
                f"atmospheric background with aerial perspective. "
                f"LIGHTING: {vs_render['lighting']}. "
                f"COLOR: Rich palette matching visual style, medium contrast, preserved shadow detail."
                f"{directive_tag}"
            )
            image_prompt = self._inject_visual_style(raw_image_prompt, fallback_style_tag)

            camera_category = camera_rotation[(scene_num - 1) % len(camera_rotation)]
            camera = random.choice(
                self.CAMERA_MOVEMENTS.get(camera_category, self.CAMERA_MOVEMENTS["establishing"])
            )

            # v4.4.0: Director's-brief structure for fallback — no voiceover
            # context, pure animation direction to the renderer.
            ref_clause = (
                f"Animate the provided key-frame using the provided character reference image(s) as identity anchors. {char_mention}"
                if chars_present else
                "Animate the provided key-frame as a continuous moving plate. "
            )
            scene_prompt_text = (
                f"{ref_clause}"
                f"Camera: {camera} — slow pace, locked-off feel, lens around {35 if scene_num == 1 else 50}mm. "
                f"Character action: silent natural physical presence — gentle breathing, micro-shifts of weight, slow blinks, no audible speech and no lip-sync to dialogue. "
                f"Environment motion: subtle ambient breeze through the frame, distant atmospheric particles drifting, faint reflective shifts on visible surfaces. "
                f"Lighting animation: smooth held lighting state evolving subtly through the duration, no abrupt changes. "
                f"BGM mood cue: visual pacing supports a sustained low-tempo underscore matching the {visual_style} aesthetic. "
                f"SFX atmosphere cue: visual atmosphere implies the natural ambience of the depicted location. "
                f"Pacing: even, slow burn. Transition out: soft cut to next scene."
            )

            # Defense-in-depth strip + authoritative audio restriction append
            scene_prompt_text, _voice_strips_fb = self._strip_voice_dialogue_content(scene_prompt_text)
            scene_prompt_text = scene_prompt_text.rstrip(". ") + "." + self._build_audio_restriction_directive()

            scene_prompt_json = {
                "motion_description": scene_prompt_text,
                "audio_guidance": {
                    "allowed": "BGM mood cues and SFX ambient atmosphere as visual/atmospheric context only",
                    "forbidden": "voice-over, dialogue, narration, spoken words, lip-synced audio, any speech/audio track",
                    "reason": "Template generates TTS audio track separately from voiceover — video must be visual-only so the two tracks do not collide",
                    "voice_content_stripped": _voice_strips_fb
                },
                "bgm_cue": f"Visual pacing supports a sustained low-tempo underscore matching the {visual_style} aesthetic.",
                "sfx_cue": "Visual atmosphere implies the natural ambience of the depicted location.",
                "continuity_thread": "Opening scene — establishes baseline." if scene_num == 1 else "Carries continuous lighting state and wardrobe from the previous scene.",
                "voiceover_binding": {
                    "who": "(inferred from voiceover)",
                    "what": narrated_phrase[:80],
                    "where": "(inferred from voiceover)"
                },
                "camera": {
                    "movement_type": camera_category,
                    "direction": camera,
                    "speed": "slow",
                    "lens_mm": 35 if scene_num == 1 else 50,
                    "stabilization": "steadicam"
                },
                "characters": [
                    {
                        "scene_ref_position": idx + 1,
                        "global_order": cp.get("order", 0),
                        "name": cp.get("name", ""),
                        "character_ref": f"reference character {idx + 1} ({cp.get('name', '')})",
                        "action": "present with natural stance",
                        "expression_arc": "neutral"
                    }
                    for idx, cp in enumerate(chars_present)
                ],
                "environment": {
                    "motion": "subtle wind, ambient particle drift",
                    "particles": "atmospheric dust motes"
                },
                "lighting_dynamics": {
                    "setup": self.LIGHTING_SETUPS["neutral"],
                    "progression": "consistent natural light"
                },
                "composition": {
                    "shot_size": "WS" if scene_num == 1 else "MS",
                    "aspect_ratio": aspect_ratio,
                    "depth_of_field": "deep" if scene_num == 1 else "medium"
                },
                "color_grading": {
                    "palette": ["neutral tones", "earth tones"],
                    "tonality": "neutral",
                    "grade_reference": visual_style
                },
                "pacing": {
                    "rhythm": "measured",
                    "intensity_arc": "steady"
                },
                "transition": {
                    "type": "cut",
                    "to_next_scene": "continuous"
                },
                "audio_sync": {
                    "video_start_time": round(video_start, 3),
                    "video_end_time": round(video_end, 3),
                    "audio_start_time": round(audio_start, 3),
                    "audio_end_time": round(audio_end, 3),
                    "duration_seconds": duration,
                    "sync_drift_ms": round((video_start - audio_start) * 1000, 1)
                },
                "technical": {
                    "visual_style": visual_style,
                    "aspect_ratio": aspect_ratio,
                    "render_quality": vs_render["quality"]
                }
            }
            scene_prompt_str = json.dumps(scene_prompt_json, ensure_ascii=False)

            scene = {
                "scene_id_str": f"{scene_num}",
                "title": f"Scene {scene_num}",
                "image_prompt": image_prompt,
                "scene_prompt": scene_prompt_str,
                "voiceover": voiceover,
                "scene_description": voiceover,
                "description": voiceover,
                "duration": duration,
                "start_time": round(audio_start, 3),
                "end_time": round(audio_end, 3),
                "camera": camera,
                "emotion": "neutral",
                "lighting": self.LIGHTING_SETUPS["neutral"],
                "characters_present": chars_present,
                "characters": [{"name": cp.get("name", ""), "role": "subject"} for cp in chars_present],
                "order": scene_num,
                "transition": "cut",
                "metadata": {
                    "image_prompt": image_prompt,
                    "scene_prompt": scene_prompt_str,
                    "scene_prompt_json": scene_prompt_json,
                    "camera_info": camera,
                    "lighting_info": self.LIGHTING_SETUPS["neutral"],
                    "emotion": "neutral",
                    "transition": "cut",
                    "characters_present": [cp.get("name", "") for cp in chars_present],
                    "reference_mapping": [
                        {"scene_ref_position": idx + 1, "name": cp.get("name", ""), "global_order": cp.get("order", 0)}
                        for idx, cp in enumerate(chars_present)
                    ],
                    "aspect_ratio": aspect_ratio,
                    "visual_style": visual_style,
                    "start_time": round(audio_start, 3),
                    "end_time": round(audio_end, 3),
                    "video_start_time": round(video_start, 3),
                    "video_end_time": round(video_end, 3),
                    "duration": duration,
                    "sync_drift_ms": round((video_start - audio_start) * 1000, 1),
                    "bgm_cue": f"Visual pacing supports a sustained low-tempo underscore matching the {visual_style} aesthetic.",
                    "sfx_cue": "Visual atmosphere implies the natural ambience of the depicted location.",
                    "continuity_thread": "Opening scene — establishes baseline." if scene_num == 1 else "Carries continuous lighting state and wardrobe from the previous scene.",
                    "aspect_ratio_enforced": aspect_ratio,
                    "custom_instructions_applied": bool(custom_instructions),
                    "fallback": True
                }
            }
            scenes.append(scene)

        return scenes


# Required export
Template = AudioWorkflowTemplate
